import type { LinguiConfig } from "@lingui/conf";
type ExtendedLinguiConfig = LinguiConfig & {
    babelOptions?: {
        presets?: any[];
        plugins?: any[];
    };
};
declare const config: ExtendedLinguiConfig;
export default config;
