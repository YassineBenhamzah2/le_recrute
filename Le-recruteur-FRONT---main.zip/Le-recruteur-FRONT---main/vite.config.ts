import react from "@vitejs/plugin-react";
import path from "path";
import { defineConfig } from "vite";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react({
      babel: {
        plugins: ["macros"],
      },
    }),
  ],
  optimizeDeps: {
    exclude: ["lucide-react", "ollama"],
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },

  // This tells Vite to replace any occurrence of `global` in the code
  // with `window` during the build process.
  define: {
    global: "window",
  },

  // Provide empty mocks for Node.js modules
  build: {
    rollupOptions: {
      external: ["ollama", "node:fs", "node:path"],
    },
  },
});
