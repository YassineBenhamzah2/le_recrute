/* eslint-disable @typescript-eslint/no-explicit-any */
import { t } from "@lingui/macro";
import React, {
  createContext,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { authService } from "../lib/network/auth";
import { roleService } from "../lib/network/roles";
import { sectorsService } from "../lib/network/sector";
import { tokenManager } from "../lib/network/utils/tokenManager";
import { AuthContextType, User } from "../lib/types/auth";
import {
  LoginRequest,
  PermissionInfo,
  RegisterCandidateRequest,
  RegisterRecruiterRequest,
  RegisterRecruiterResponse,
  Sector,
} from "../lib/types/base";

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Auth service functions
const authOps = {
  // Handle API errors consistently
  handleAuthError: (error: any): string => {
    if (error?.response?.data?.error?.message) {
      return error.response.data.error.message;
    } else if (error?.message) {
      return error.message;
    }
    return t({
      id: "auth.authFailed",
      message: "Authentication failed. Please try again.",
    });
  },
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null); // Token State
  const [isLoading, setIsLoading] = useState(true);
  const [sectors, setSectors] = useState<Sector[]>([]);

  // Function to load sectors when needed (recruiter signup)
  const loadSectors = useCallback(async () => {
    try {
      const res = await sectorsService.getAll();
      const sectorsData = res?.data || [];
      setSectors(sectorsData);
      return sectorsData;
    } catch (error) {
      console.error("Failed to load sectors:", error);
      setSectors([]);
      throw error;
    }
  }, []);

  // Function to fetch user permissions by role ID
  const fetchUserPermissions = useCallback(
    async (roleId: number): Promise<PermissionInfo[]> => {
      try {
        const response = await roleService.getRolePermissions(roleId);
        if (response.success && response.data) {
          return response.data.permissions.map((permission) => ({
            id: permission.id,
            name: permission.name,
            description: permission.description,
            permissionType: permission.permissionType,
          }));
        }
        return [];
      } catch (error) {
        console.error("Failed to fetch user permissions:", error);
        return [];
      }
    },
    []
  );

  // Function to update user with permissions
  const updateUserWithPermissions = useCallback(
    async (user: User): Promise<User> => {
      if (user.role?.id && user.role.type !== "CANDIDATE") {
        try {
          const permissions = await fetchUserPermissions(user.role.id);
          return {
            ...user,
            role: {
              ...user.role,
              permissions,
            },
          };
        } catch (error) {
          console.error("Failed to load permissions for user:", error);
          return user;
        }
      }
      return user;
    },
    [fetchUserPermissions]
  );

  useEffect(() => {
    const loadUserWithPermissions = async () => {
      // Check localStorage for user data and tokens separately
      const savedUserData = localStorage.getItem("userData");
      const accessToken = localStorage.getItem("accessToken");
      const refreshToken = localStorage.getItem("refreshToken");

      if (savedUserData && accessToken) {
        try {
          const parsedUserData = JSON.parse(savedUserData);

          // Reconstruct user object with tokens
          const user: User = {
            ...parsedUserData,
            accessToken: accessToken,
            refreshToken: refreshToken,
          };

          // Load permissions if user has a role ID and is not a candidate
          const updatedUser = await updateUserWithPermissions(user);
          setToken(accessToken);
          setUser(updatedUser);
          setIsLoading(false);
        } catch (error) {
          console.error("Error loading user data:", error);
          setIsLoading(false);
        }
      } else {
        setIsLoading(false);
      }
    };

    loadUserWithPermissions();
  }, [updateUserWithPermissions]);

  const login = async (email: string, password: string) => {
    try {
      const loginData: LoginRequest = { email, password };
      const response = await authService.login(loginData);

      if (response.success && response.data) {
        const authData = response.data;

        // Check if response data is an array or object
        const loginData = Array.isArray(authData) ? authData[0] : authData;

        // Extract tokens with fallback to different possible field names
        const accessToken =
          loginData.accessToken || loginData.token || loginData.access_token;
        const refreshToken = loginData.refreshToken || loginData.refresh_token;

        if (!accessToken) {
          throw new Error("Invalid response: missing access token");
        }

        // Create user object from API response
        const user: User = {
          id: loginData.id,
          email: loginData.email,
          firstname: loginData.firstname,
          lastname: loginData.lastname,
          role: loginData.role, // Now expects RoleInfo object instead of string
          profilePicture:
            loginData.profilePicture || loginData.companyLogoUrl || null,
          accessToken: accessToken,
          refreshToken: refreshToken,
        };

        // Store tokens using tokenManager
        tokenManager.storeAuthData(user, {
          accessToken: accessToken,
          refreshToken: refreshToken,
        });

        // Load permissions for the user
        const updatedUser = await updateUserWithPermissions(user);
        setToken(accessToken);
        setUser(updatedUser);
        return updatedUser;
      } else {
        throw new Error(t({ id: "auth.loginFailed", message: "Login failed" }));
      }
    } catch (error: any) {
      // Handle API errors using helper function
      throw new Error(authOps.handleAuthError(error));
    }
  };

  const registerCandidate = async (data: RegisterCandidateRequest) => {
    try {
      const response = await authService.registerCandidate(data);

      if (response.success && response.data) {
        const authData = response.data;

        // Check if response data is an array (like login) or object
        const registerData = Array.isArray(authData) ? authData[0] : authData;

        // Create user object from response with defensive checks
        const candidateUser: User = {
          id: registerData.candidateId,
          firstname: registerData.firstname,
          lastname: registerData.lastname,
          email: registerData.email,
          role: registerData.role, // Now expects RoleInfo object
          profilePicture: registerData.profilePic,
          accessToken: registerData.accessToken,
          refreshToken: registerData.refreshToken,
          candidateId: registerData.candidateId,
        };

        // Store tokens using tokenManager
        tokenManager.storeAuthData(candidateUser, {
          accessToken: registerData.accessToken,
          refreshToken: registerData.refreshToken,
        });

        // SET THE TOKEN STATE AFTER REGISTRATION
        setToken(registerData.accessToken);

        // Candidates don't need permissions loaded
        setUser(candidateUser);

        return {
          user: candidateUser,
          accessToken: authData.accessToken,
          refreshToken: authData.refreshToken,
        };
      } else {
        throw new Error(
          t({ id: "auth.registrationFailed", message: "Registration failed" })
        );
      }
    } catch (error: any) {
      // Handle API errors using helper function
      throw new Error(authOps.handleAuthError(error));
    }
  };

  const registerRecruiter = async (data: RegisterRecruiterRequest) => {
    try {
      // Map form fields to API fields
      const formData = new FormData();
      formData.append("firstName", data.firstname); // Changed from firstname to firstName
      formData.append("lastName", data.lastname); // Changed from lastname to lastName
      formData.append("email", data.email);
      formData.append("password", data.password);
      formData.append("licenseKey", data.licenseKey); // Required license key
      if (data.position) {
        formData.append("position", data.position);
      }
      formData.append("companyName", data.entreprise);
      formData.append("location", data.localisation);
      formData.append("phone", data.phone);
      formData.append("companyDescription", data.description);
      formData.append("logo", data.logo);
      formData.append("companySectorId", String(Number(data.sectorOfActivity)));

      // Debug formData values
      console.log("FormData for recruiter registration:");
      for (const [key, value] of formData.entries()) {
        console.log(`${key}: ${value instanceof File ? value.name : value}`);
      }

      const response = await authService.registerRecruiter(formData);
      if (response.success && response.data) {
        const authData = response.data as RegisterRecruiterResponse;
        // Create user object from response
        const recruiterData = Array.isArray(authData) ? authData[0] : authData;
        const recruiterUser: User = {
          id: recruiterData.recruiterId,
          firstname: recruiterData.firstname,
          lastname: recruiterData.lastname,
          email: recruiterData.email,
          role: recruiterData.role, // Now expects RoleInfo object
          profilePicture: recruiterData.companyLogoUrl,
          accessToken: recruiterData.accessToken,
          refreshToken: recruiterData.refreshToken,
        };
        // Store tokens using tokenManager
        tokenManager.storeAuthData(recruiterUser, {
          accessToken: recruiterData.accessToken,
          refreshToken: recruiterData.refreshToken,
        });

        // Load permissions for the recruiter
        const updatedUser = await updateUserWithPermissions(recruiterUser);

        // SET THE TOKEN STATE AFTER REGISTRATION
        setToken(recruiterData.accessToken);
        setUser(updatedUser);

        return {
          user: updatedUser,
          accessToken: recruiterData.accessToken,
          refreshToken: recruiterData.refreshToken,
        };
      } else {
        const errorMsg =
          (response as any)?.error?.message ||
          t({ id: "auth.registrationFailed", message: "Registration failed" });
        throw new Error(errorMsg);
      }
    } catch (error: any) {
      // Handle API errors with clean messages
      if (error.response?.data?.error?.message) {
        throw new Error(error.response.data.error.message);
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error(
          t({
            id: "auth.registrationFailedTryAgain",
            message: "Registration failed. Please try again.",
          })
        );
      }
    }
  };

  const logout = () => {
    // Use role.type instead of role string for checking user type
    const isRecruiter = user?.role?.type === "RECRUITER";
    const redirectTo = isRecruiter ? "/auth/recruiter-signin" : "/auth/signin";
    // Clear React state before redirecting
    setUser(null);
    setToken(null);
    // Use hard redirect to avoid route-guard race conditions
    tokenManager.logout(redirectTo);
  };

  // Permission checking functions
  const hasPermission = useCallback(
    (permissionName: string): boolean => {
      if (!user?.role?.permissions) return false;
      return user.role.permissions.some(
        (permission) => permission.name === permissionName
      );
    },
    [user]
  );

  const hasAnyPermission = useCallback(
    (permissionNames: string[]): boolean => {
      if (!user?.role?.permissions) return false;
      return permissionNames.some((permissionName) =>
        user.role.permissions!.some(
          (permission) => permission.name === permissionName
        )
      );
    },
    [user]
  );

  const hasAllPermissions = useCallback(
    (permissionNames: string[]): boolean => {
      if (!user?.role?.permissions) return false;
      return permissionNames.every((permissionName) =>
        user.role.permissions!.some(
          (permission) => permission.name === permissionName
        )
      );
    },
    [user]
  );

  const isAdmin = useCallback((): boolean => {
    return user?.role?.type === "ADMIN";
  }, [user]);

  const isRecruiter = useCallback((): boolean => {
    return user?.role?.type === "RECRUITER";
  }, [user]);

  const isCandidate = useCallback((): boolean => {
    return user?.role?.type === "CANDIDATE";
  }, [user]);

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        login,
        logout,
        isLoading,
        registerCandidate,
        registerRecruiter,
        sectors,
        loadSectors,
        // Permission functions
        hasPermission,
        hasAnyPermission,
        hasAllPermissions,
        isAdmin,
        isRecruiter,
        isCandidate,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error(
      t({
        id: "auth.missingAccessToken",
        message: "Invalid response: missing access token",
      })
    );
  }
  return context;
};
