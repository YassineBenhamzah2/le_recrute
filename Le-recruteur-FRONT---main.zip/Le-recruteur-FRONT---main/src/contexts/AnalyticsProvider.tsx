import { useEffect, useCallback } from "react";
import { useLocation } from "react-router-dom";
import { EventCategory } from "../lib/analytics/googleAnalytics";
import { webAnalytics } from "../lib/analytics/webAnalytics";
import { initializeAnalytics } from "../lib/analytics/initAnalytics";

export const AnalyticsProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const location = useLocation();

  // Track errors globally
  const handleGlobalErrors = useCallback((event: ErrorEvent) => {
    const errorMessage = event.message;
    const errorSource = event.filename;
    const errorLine = event.lineno;

    // Record error through our analytics wrapper
    webAnalytics.recordError(`${errorMessage} (${errorSource}:${errorLine})`);

    // Don't prevent default behavior
    return false;
  }, []);

  // Initialize Google Analytics and error tracking
  useEffect(() => {
    // Initialize analytics
    initializeAnalytics();

    // Add global error handler
    window.addEventListener("error", handleGlobalErrors);

    // Record session start event
    webAnalytics.recordEvent(
      EventCategory.WEB_INTERACTION,
      "Session Started",
      navigator.userAgent
    );

    // Clean up error handler on unmount
    return () => {
      window.removeEventListener("error", handleGlobalErrors);
    };
  }, [handleGlobalErrors]);

  // Track page views when the route changes
  useEffect(() => {
    const currentPath = location.pathname + location.search;
    webAnalytics.recordPageView(currentPath);
  }, [location]);

  return <>{children}</>;
};

export default AnalyticsProvider;
