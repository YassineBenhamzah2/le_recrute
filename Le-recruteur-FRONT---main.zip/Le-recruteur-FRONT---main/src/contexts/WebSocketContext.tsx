import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { useAuth } from './AuthContext';
import { settings } from '@/lib/settings/main';
import { notificationEmitter } from '@/lib/events/notificationEmitter';

interface WebSocketContextType {
  isConnected: boolean;
}

const WebSocketContext = createContext<WebSocketContextType | null>(null);

export const useWebSocket = () => {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error('useWebSocket must be used within a WebSocketProvider');
  }
  return context;
};

interface WebSocketProviderProps {
  children: ReactNode;
}

export const WebSocketProvider: React.FC<WebSocketProviderProps> = ({ children }) => {
  const { user, token } = useAuth();
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    console.log("[WebSocketProvider] useEffect triggered. User:", user, "Token:", token);

    if (!user || !token) {
      console.log("[WebSocketProvider] No user or token, will not connect.");
      return;
    }
    console.log("[WebSocketProvider] Attempting to connect with token:", token);

    const socketURL = `${settings.WS_ADDRESS}/ws?token=${token}`;

    const stompClient = new Client({
      webSocketFactory: () => new SockJS(socketURL),
      // connectHeaders: {
      //   Authorization: `Bearer ${token}`,
      // },
      debug: (str) => console.log('STOMP: ' + str),
      reconnectDelay: 5000,
    });

    stompClient.onConnect = (frame) => {
      setIsConnected(true);
      console.log('Connected to WebSocket:', frame);

      stompClient.subscribe(`/user/queue/notifications`, (message) => {
        try {
          const newNotification = JSON.parse(message.body);
          notificationEmitter.emit(newNotification);
        } catch (error) {
          console.error("Could not parse incoming notification", error);
        }
      });
    };

    stompClient.onStompError = (frame) => {
      console.error('Broker reported error: ' + frame.headers['message']);
    };
    
    stompClient.activate();

    return () => {
      if (stompClient.active) {
        stompClient.deactivate();
      }
    };
  }, [user, token]);

  return (
    <WebSocketContext.Provider value={{ isConnected }}>
      {children}
    </WebSocketContext.Provider>
  );
};