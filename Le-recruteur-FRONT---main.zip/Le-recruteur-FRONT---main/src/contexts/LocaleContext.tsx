import { i18n } from "@lingui/core";
import { I18nProvider } from "@lingui/react";
import {
  createContext,
  ReactNode,
  useContext,
  useEffect,
  useState,
} from "react";
import { dynamicActivate } from "../i18n";
import {
  DEFAULT_LOCALE,
  LOCALE_STORAGE_KEY,
  LocaleInfo,
  SUPPORTED_LOCALES,
} from "../i18n/locales";

interface LocaleContextType {
  locale: string;
  localeInfo: LocaleInfo;
  setLocale: (locale: string) => Promise<void>;
  isLoading: boolean;
  supportedLocales: typeof SUPPORTED_LOCALES;
}

const LocaleContext = createContext<LocaleContextType | undefined>(undefined);

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setCurrentLocale] = useState<string>(DEFAULT_LOCALE);
  const [isLoading, setIsLoading] = useState(true);

  const setLocale = async (newLocale: string) => {
    const validLocale = SUPPORTED_LOCALES[newLocale]
      ? newLocale
      : DEFAULT_LOCALE;

    if (locale === validLocale && !isLoading) return; // Prevent unnecessary reloads

    setIsLoading(true);
    try {
      // CORRECTED: Call our new, robust activation function
      await dynamicActivate(validLocale);
      setCurrentLocale(validLocale);
      localStorage.setItem(LOCALE_STORAGE_KEY, validLocale);
    } catch (error) {
      console.error("Failed to change locale:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    
    const savedLocale =
      localStorage.getItem(LOCALE_STORAGE_KEY) ||
      navigator.language.split("-")[0];
    setLocale(savedLocale);
  }, []);

  const contextValue = {
    locale,
    localeInfo: SUPPORTED_LOCALES[locale],
    setLocale,
    isLoading,
    supportedLocales: SUPPORTED_LOCALES,
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        Loading...
      </div>
    );
  }

  return (
    <LocaleContext.Provider value={contextValue}>
      <I18nProvider i18n={i18n}>{children}</I18nProvider>
    </LocaleContext.Provider>
  );
}

export function useLocale() {
  const context = useContext(LocaleContext);
  if (!context) {
    throw new Error("useLocale must be used within LocaleProvider");
  }
  return context;
}
