import React from "react";
import ReportedEmployees from "../components/Dashboard/ReportedEmployees";

const AdminReportedEmployeesPage: React.FC = () => {
  return <ReportedEmployees />;
};

export default AdminReportedEmployeesPage;
