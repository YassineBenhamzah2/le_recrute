import CandidateViewDetails from "@/components/Dashboard/AdminComponents/CandidateViewComponents/CandidateViewDetails";
import CandidateViewSidebar from "@/components/Dashboard/AdminComponents/CandidateViewComponents/CandidateViewSidebar";
import { api } from "@/lib/network/utils/api";
import { settings } from "@/lib/settings/main";
import { Trans, t } from "@lingui/macro";
import { ArrowLeft } from "lucide-react";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";

export interface CandidateInfo {
  firstName: string;
  lastName: string;
  title: string;
  country: string;
  city: string;
  address: string;
  email: string;
  phone: string;
  linkedin: string;
  avatar: string;
  cvUrl: string | null;
}

interface Overview {
  description: string;
}

interface Experience {
  id: number;
  position: string;
  company: Company;
  industry: Industry;
  startDate: string;
  endDate: string;
  current: boolean;
  location: string;
  workplaceRating: string;
  description: string;
}
interface Company {
  id: number;
  name: string;
  logo: string;
}
interface Industry {
  id: number;
  name: string;
}

interface CertificationItem {
  id: number;
  name: string;
}

interface EducationItem {
  id: number;
  title: string;
  institution: string;
  location: string;
  startedAt: string;
  endedAt: string;
  current: boolean;
}

interface EducationCertifications {
  educations: EducationItem[];
  certifications: CertificationItem[];
}

interface Skill {
  id: number;
  name: string;
  level: number;
  type: "SOFTSKILL" | "HARDSKILL";
}

interface Language {
  id: number;
  name: string;
  level: number;
}

const AdminCandidateView: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const { candidateId } = useParams();

  const navigate = useNavigate();

  const [candiadateInfo, setCandidateInfo] = useState<CandidateInfo | null>(
    null
  );

  const [overview, setOverview] = useState<Overview>({ description: "" });

  const [experiences, setExperiences] = useState<Experience[]>([]);

  const [educationCerts, setEducationCerts] =
    useState<EducationCertifications | null>(null);

  const [skills, setSkills] = useState<Skill[]>([]);

  const [languages, setLanguages] = useState<Language[]>([]);

  useEffect(() => {
    api
      .getItem<CandidateInfo>(`/candidate/profile/info/${candidateId}`)
      .then((data) => {
        if (data.avatar && data.avatar.startsWith("uploads/")) {
          data.avatar = `${settings.IMG_ADDRESS}${data.avatar}`;
        } else if (!data.avatar) {
          data.avatar = settings.DEFAULT_USER_AVATAR ;
        }

        setCandidateInfo(data);
      })
      .catch((error) => {
        toast.error(
          t({
            id: "admin.candidate_view.error_loading_info",
            message: "Erreur lors du chargement des infos du candidat",
          })
        );
        setError(error);
        console.error("Fetch error:", error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [candidateId]);

  useEffect(() => {
    api
      .getItem<Overview>(`/candidate/profile/overview/${candidateId}`)
      .then((data) => {
        setOverview(data);
      })
      .catch(() => {
        toast.error(
          t({
            id: "admin.candidate_view.error_loading_overview",
            message:
              "Impossible de charger l'overview du candidate. Veuillez réessayer.",
          })
        );
      });
  }, [candidateId]);

  useEffect(() => {
    api
      .getItem<Experience[]>(`/candidate/profile/experiences/${candidateId}`)
      .then((data) => {
        const updatedData = data.map((e) => ({
          ...e,
          company: {
            ...e.company,
            logo: e.company.logo
              ? `${settings.IMG_ADDRESS}${e.company.logo}`
              : settings.DEFAULT_COMPANY_AVATAR ,
          },
        }));
        setExperiences(updatedData);
      })
      .catch(() => {
        toast.error(
          t({
            id: "admin.candidate_view.error_loading_experiences",
            message:
              "Impossible de charger les expériences. Veuillez réessayer.",
          })
        );
      });
  }, [candidateId]);

  useEffect(() => {
    api
      .getItem<EducationCertifications>(
        `/candidate/profile/educations/${candidateId}`
      )
      .then((data) => setEducationCerts(data))
      .catch(() =>
        toast.error(
          t({
            id: "admin.candidate_view.error_loading_educations",
            message: "Erreur chargement educations / certifications",
          })
        )
      );
  }, [candidateId]);

  useEffect(() => {
    api
      .getItem<Skill[]>(`/candidate/profile/skills/${candidateId}`)
      .then((data) => setSkills(data))
      .catch(() =>
        toast.error(
          t({
            id: "admin.candidate_view.error_loading_skills",
            message: "Erreur chargement skills",
          })
        )
      );
  }, [candidateId]);

  useEffect(() => {
    api
      .getItem<Language[]>(`/candidate/profile/languages/${candidateId}`)
      .then((data) => {
        setLanguages(data);
      })
      .catch(() =>
        toast.error(
          t({
            id: "admin.candidate_view.error_loading_languages",
            message: "Erreur chargement languages",
          })
        )
      );
  }, [candidateId]);

  // Handle going back to candidates list
  const handleGoBack = () => {
    navigate(-1);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-[#238d94]"></div>
      </div>
    );
  }

  if (error || !candiadateInfo) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            <Trans id="admin.candidate_view.profile_not_found_title">
              Profile Not Found
            </Trans>
          </h2>
          <p className="text-gray-600">
            {error ||
              t({
                id: "admin.candidate_view.profile_not_found_message",
                message:
                  "The candidate profile you're looking for doesn't exist.",
              })}
          </p>
          <button
            onClick={handleGoBack}
            className="mt-6 inline-flex items-center px-4 py-2 bg-[#238d94] text-white font-medium rounded-lg hover:bg-[#1a7379] transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            <Trans id="admin.candidate_view.back_to_candidates_button">
              Back to Candidates
            </Trans>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <button
          onClick={handleGoBack}
          className="inline-flex items-center px-4 py-2 bg-[#238d94] text-white font-medium rounded-lg hover:bg-[#1a7379] transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          <Trans id="admin.candidate_view.back_to_candidates_nav">
            Back to Candidates
          </Trans>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Sidebar - Candidate Header */}
        <div className="lg:col-span-1">
          <CandidateViewSidebar candidateInfo={candiadateInfo} />
        </div>

        {/* Right Content - Candidate Details */}
        <div className="lg:col-span-2">
          <CandidateViewDetails
            overview={overview.description}
            experiences={experiences}
            educationCertifications={educationCerts}
            skills={skills}
            languages={languages}
          />
        </div>
      </div>
    </div>
  );
};

export default AdminCandidateView;
