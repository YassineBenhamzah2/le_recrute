import BaseDashboard from "../components/Dashboard/BaseDashboard";
import CandidateSidebar from "../components/Layout/CandidateSidebar";
import CandidateNavbar from "../components/Layout/CandidateNavbar";
import CandidateApplicationsDashboard from "../components/CandidateComponents/CandidateApplicationsDashboard";

const CandidateApplications = () => {
    return (
        <BaseDashboard SideBar={<CandidateSidebar />}>
            <CandidateNavbar />
            <CandidateApplicationsDashboard />
        </BaseDashboard>
    );
};

export default CandidateApplications;
