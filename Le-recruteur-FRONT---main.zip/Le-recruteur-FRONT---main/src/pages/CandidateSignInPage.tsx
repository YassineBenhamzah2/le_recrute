import React from 'react';
import LoginForm from '../components/Auth/LoginForm';
import Header from '../components/Layout/Header';
import { Trans, t } from '@lingui/macro';

const CandidateSignInPage: React.FC = () => {

  return (
    <div className="h-screen bg-gray-50 flex flex-col overflow-hidden">
      {/* Header at the top */}
      <Header isMobileMenuOpen={false} setIsMobileMenuOpen={() => {}} />

      {/* Split layout below header */}
      <div className={`flex flex-1 relative overflow-hidden lg:flex-row`}>
        {/* Left Side - Form */}
        <div className="w-full lg:w-[50%] flex items-center justify-center p-8 bg-white">
          <div className="w-full max-w-md">
            <LoginForm onToggleMode={() => {}} />
          </div>
        </div>

        {/* Spacer */}
        <div className="hidden lg:block w-[5%] bg-white"></div>

        {/* Right Side - Image and Overlay */}
        <div className="hidden lg:block w-[45%] h-full min-h-full relative">
          <img
            src="/login bckg.png"
            alt={t({ id: "candidateSignIn.imageAlt", message: "Join Our Community" })}
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-30"></div>
          <div className="relative z-10 flex flex-col items-center justify-center h-full text-white px-8">
            <h2 className="text-3xl font-bold mb-4 text-center" style={{ fontFamily: "'Segoe UI', Arial, sans-serif" }}>
              <Trans id="candidateSignIn.heading">Join Our Community</Trans>
            </h2>
            <p className="text-lg text-center" style={{ fontFamily: "'Segoe UI', Arial, sans-serif", fontWeight: '300' }}>
              <Trans id="candidateSignIn.description">
                Connect with thousands of professionals and find your next opportunity
              </Trans>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateSignInPage;
