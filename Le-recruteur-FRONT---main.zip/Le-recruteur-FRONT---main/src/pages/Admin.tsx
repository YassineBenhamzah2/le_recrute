import { Bell, Filter, LogOut, Search, Settings, User } from "lucide-react";
import AdminBaseDashboard from "../components/Dashboard/AdminBaseDashboard";
import AdminDashboard from "../components/Dashboard/AdminDashboard";
import AdminSidebar from "../components/Layout/AdminSidebar";

const Admin = () => {
  // Admin Header Component
  const AdminHeader = () => (
    <div className="flex items-center justify-between">
      <div className="flex items-center space-x-6">
        <div className="relative">
          <Search
            className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"
            size={20}
          />
          <input
            type="text"
            placeholder="Search users, jobs, companies..."
            className="pl-12 pr-6 py-3 w-96 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#238D94] focus:border-transparent focus:bg-white transition-all duration-200"
          />
        </div>
        <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-[#238D94] hover:bg-gray-50 rounded-xl transition-colors duration-200">
          <Filter size={18} />
          <span className="font-medium">Filters</span>
        </button>
      </div>

      <div className="flex items-center space-x-6">
        <button className="relative p-3 text-gray-600 hover:text-[#238D94] hover:bg-gray-50 rounded-xl transition-colors duration-200">
          <Bell size={22} />
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-medium">
            5
          </span>
        </button>

        <div className="flex items-center space-x-4">
          <div className="text-right">
            <p className="text-base font-semibold text-gray-900">Admin User</p>
            <p className="text-sm text-gray-500">Super Administrator</p>
          </div>
          <div className="relative group">
            <button className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-xl transition-colors duration-200">
              <div className="w-10 h-10 bg-gradient-to-br from-[#238D94] to-[#1a6b72] rounded-xl flex items-center justify-center shadow-lg">
                <User className="text-white" size={18} />
              </div>
            </button>

            <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-gray-100 py-3 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
              <a
                href="#"
                className="flex items-center space-x-3 px-6 py-3 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
              >
                <User size={16} />
                <span>View Profile</span>
              </a>
              <a
                href="#"
                className="flex items-center space-x-3 px-6 py-3 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
              >
                <Settings size={16} />
                <span>Account Settings</span>
              </a>
              <hr className="my-2 mx-3" />
              <a
                href="#"
                className="flex items-center space-x-3 px-6 py-3 text-sm text-red-600 hover:bg-red-50 transition-colors"
              >
                <LogOut size={16} />
                <span>Sign Out</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Admin Footer Component
  const AdminFooter = () => (
    <div className="flex items-center justify-between text-sm text-gray-500">
      <div>© 2025 Le Recruteur. All rights reserved.</div>
      <div className="flex items-center space-x-4">
        <span>Version 1.0.0</span>
        <span>•</span>
        <a href="#" className="hover:text-[#238D94] transition-colors">
          Support
        </a>
        <span>•</span>
        <a href="#" className="hover:text-[#238D94] transition-colors">
          Documentation
        </a>
      </div>
    </div>
  );

  return (
    <AdminBaseDashboard
      SideBar={<AdminSidebar />}
      Header={<AdminHeader />}
      Footer={<AdminFooter />}
    >
      {/* Only show dashboard content on /admin route */}
      <AdminDashboard section="dashboard" />
    </AdminBaseDashboard>
  );
};

export default Admin;
