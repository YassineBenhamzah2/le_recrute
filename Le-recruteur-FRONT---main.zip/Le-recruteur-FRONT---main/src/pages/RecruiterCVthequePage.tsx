import React from "react";
import BaseDashboard from "../components/Dashboard/BaseDashboard";
import RecruiterSidebar from "../components/Layout/RecruiterSidebar";
import RecruiterFooter from "../components/Layout/RecruiterFooter";
import RecruiterHeader from "@/components/Layout/RecruiterHeader";
import { CVthequePage } from "../components/Dashboard/RecruiterCVthequeDashboard";

const RecruiterCVtheque: React.FC = () => {
  return (
    <BaseDashboard
      SideBar={<RecruiterSidebar />}
      Footer={<RecruiterFooter />}
      Header={<RecruiterHeader />}
    >
      <CVthequePage />
    </BaseDashboard>
  );
};

export default RecruiterCVtheque;
