import React from "react";
import { LicenseDashboard } from "../components/Dashboard/LicenseDashboardTable";

const AdminLicensesPage: React.FC = () => {
  return <LicenseDashboard />;
};

export default AdminLicensesPage;
