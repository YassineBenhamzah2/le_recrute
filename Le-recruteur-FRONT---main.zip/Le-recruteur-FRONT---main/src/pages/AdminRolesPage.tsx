import React from "react";
import { RolePermissionManager } from "../components/Dashboard/RolePermissionManager";
import { Trans, t } from '@lingui/macro';

const AdminRolesPage: React.FC = () => {
  return (
    <div className="p-6 min-h-screen bg-gradient-to-br from-gray-50 to-white">
      <div className="relative overflow-hidden mb-8">
        <div className="absolute inset-0 bg-gradient-to-r from-ehc-green/5 to-ehc-green/10 rounded-2xl"></div>
        <div className="relative p-8 rounded-2xl border border-white/20 backdrop-blur-sm">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              <Trans id="role.Management_Dash.title">Role Management Dashboard</Trans>
            </h1>
            <p className="text-gray-600 text-lg">
              <Trans id="role.Management_Dash.description">Configure and manage system roles and their permissions</Trans>
            </p>
          </div>
        </div>
      </div>
      <RolePermissionManager />
    </div>
  );
};

export default AdminRolesPage;