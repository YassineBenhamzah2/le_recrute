import React from 'react';
import RegisterForm from '../components/Auth/RegisterForm';
import Header from '../components/Layout/Header';
import { Trans, t } from "@lingui/macro";

const CandidateSignUpPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white flex flex-col overflow-hidden overflow-y-hidden">
      <Header isMobileMenuOpen={false} setIsMobileMenuOpen={() => {}} />
      <div className="flex flex-1 relative overflow-hidden">
        {/* Left Side - Image and Overlay */}
        <div className="hidden lg:block relative w-[46%] h-[110vh] mr-5" style={{ marginRight: '40px' }}>
          <img
            src="/signup bckg.png"
            alt={t({
                  id: "signup.imageAlt",
                  message: "Start Your Career Journey",
                })}
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-30"></div>
          <div className="relative z-10 flex flex-col items-center justify-center h-full text-white px-8">
            <h2 className="text-3xl font-bold mb-4 text-center" style={{ fontFamily: "'Segoe UI', Arial, sans-serif" }}>
              <Trans id="signup.heading">Start Your Career Journey</Trans>
            </h2>
            <p className="text-lg text-center" style={{ fontFamily: "'Segoe UI', Arial, sans-serif", fontWeight: '300' }}>
              <Trans id="signup.description">
                Join thousands of professionals who have found their dream jobs with us
              </Trans>
            </p>
          </div>
        </div>
        {/* Right Side - Registration Form */}
        <div className="w-full lg:w-[50%] flex items-center justify-center p-8 bg-white">
          <div className="w-full max-w-md">
            <RegisterForm />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateSignUpPage;
