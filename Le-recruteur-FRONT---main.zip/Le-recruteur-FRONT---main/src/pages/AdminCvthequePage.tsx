import React from "react"
import CvthequeAdmin from "../components/Dashboard/AdminComponents/CVthequeAdmin";

const AdminCvthequePage: React.FC = () => {
    return <CvthequeAdmin />
}

export default AdminCvthequePage;