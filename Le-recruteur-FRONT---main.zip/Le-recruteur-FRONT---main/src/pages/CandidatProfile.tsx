import React from 'react';
import BaseDashboard from "../components/Dashboard/BaseDashboard";
import ProfileCandidate from '../components/Dashboard/ProfileCandidate';
import CandidateSidebar from '../components/Layout/CandidateSidebar';
import CandidateNavbar from '../components/Layout/CandidateNavbar';

const CandidatProfile: React.FC = () => {
    return (
        <BaseDashboard SideBar={<CandidateSidebar />}>
            <CandidateNavbar />
            <ProfileCandidate />
        </BaseDashboard>
    );
};

export default CandidatProfile;
