import BaseDashboard from "../components/Dashboard/BaseDashboard";
import RecruiterDashboard from "../components/Dashboard/RecruiterDashboard";
import RecruiterSidebar from "../components/Layout/RecruiterSidebar";
import RecruiterFooter from "../components/Layout/RecruiterFooter";
import RecruiterHeader from "@/components/Layout/RecruiterHeader";

const Recruiter = () => {
  return (
    <BaseDashboard
      SideBar={<RecruiterSidebar />}
      Footer={<RecruiterFooter />}
      Header={<RecruiterHeader />}
    >
      <RecruiterDashboard />
    </BaseDashboard>
  );
};

export default Recruiter;
