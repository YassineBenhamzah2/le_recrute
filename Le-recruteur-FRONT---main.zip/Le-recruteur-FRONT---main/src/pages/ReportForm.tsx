import React, { useState} from "react";
import { X} from "lucide-react";
import { Trans, t } from '@lingui/macro';
import { ReportFormData } from "@/lib/types/jobOffer";
import { useAuth } from "@/contexts/AuthContext";

// Define a custom type for the data that will be sent to the server

interface ReportFormProps {
  onSave: (postData: ReportFormData) => void;
  onCancel: () => void;
}

export default function ReportForm({ onSave, onCancel }: ReportFormProps) {
  const { user } = useAuth();
  const [formData, setFormData] = useState<ReportFormData>({
    firstName: user?.firstname || "",
    lastName: user?.lastname ||  "",
    email: user?.email || "",
    phone: user?.phone || "",
    reportReason: "",
   
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const handleInputChange = (field: keyof ReportFormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-xl font-semibold">
              <Trans>Create Report</Trans>
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              <Trans>
                Fill in the report details below.
              </Trans>
            </p>
          </div>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-gray-500 p-1 rounded-full hover:bg-gray-100"
            title={t({ id: "report_form.close", message: "Close" })}
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* First Name Field */}
          <div>
            <label
              htmlFor="firstName"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="report_form.first_name_label">First Name</Trans>
            </label>
            <input
              id="firstName"
              type="text"
              required
              value={formData.firstName}
              onChange={(e) => handleInputChange('firstName', e.target.value)}
              placeholder={t({ id: "report_form.first_name_placeholder", message: "Enter first name..." })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Last Name Field */}
          <div>
            <label
              htmlFor="lastName"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="report_form.last_name_label">Last Name</Trans>
            </label>
            <input
              id="lastName"
              type="text"
              required
              value={formData.lastName}
              onChange={(e) => handleInputChange('lastName', e.target.value)}
              placeholder={t({ id: "report_form.last_name_placeholder", message: "Enter last name..." })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Email Field */}
          <div>
            <label
              htmlFor="email"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="report_form.email_label">Email</Trans>
            </label>
            <input
              id="email"
              type="email"
              required
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder={t({ id: "report_form.email_placeholder", message: "Enter email address..." })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Phone Field */}
          <div>
            <label
              htmlFor="phone"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="report_form.phone_label">Phone</Trans>
            </label>
            <input
              id="phone"
              type="tel"
              required
              value={formData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              placeholder={t({ id: "report_form.phone_placeholder", message: "Enter phone number..." })}
              className="w-full px-3 py-2 border  border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Report Reason Field */}
          <div>
            <label
              htmlFor="reportReason"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="report_form.reason_label">Report Reason</Trans>
            </label>
            <textarea
              id="reportReason"
              required
              value={formData.reportReason}
              onChange={(e) => handleInputChange('reportReason', e.target.value)}
              placeholder={t({ id: "report_form.reason_placeholder", message: "Describe the reason for this report..." })}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-vertical"
            />
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              <Trans id="report_form.cancel">Cancel</Trans>
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-[#238D94] text-white rounded-lg hover:bg-[#1a6b72] transition-colors"
            >
              <Trans id="report_form.submit">Submit Report</Trans>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}