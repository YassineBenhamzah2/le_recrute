import React, { useState } from 'react';
import Header from '../components/Layout/Header';
import Footer from '../components/Layout/Footer';
import RegisterRecruiterForm from '../components/Auth/RegisterRecruiterForm';
import { Trans } from "@lingui/react/macro";
import { t } from "@lingui/core/macro";

const RecruiterSignUpPage: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  return (
    <div className="min-h-screen bg-white flex flex-col overflow-hidden overflow-y-hidden">
      <Header isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
      <div className="flex flex-1 relative overflow-hidden">
         {/* left Side - Registration Form */}
         <div className="w-full lg:w-[55%] flex items-center justify-center p-8 mb-10">
          <div className="w-full max-w-md">
            <RegisterRecruiterForm />
          </div>
        </div>
        {/* right Side - Image and Overlay */}
        <div className="hidden lg:block relative w-[45%] h-[130vh]">
          <img
            src="/rec signup img.png"
            alt={t({
              id: 'recruiterSignUp.img_alt',
              message: 'Start Your Career Journey',
            })}
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-20"></div>
          <div className="relative z-10 flex flex-col items-center justify-center h-full text-white px-8">
            <h2 className="text-3xl font-bold mb-4 text-center" style={{ fontFamily: "'Segoe UI', Arial, sans-serif" }}>
              <Trans id="recruiterSignUp.heading">Start Your Career Journey</Trans>
            </h2>
            <p className="text-lg text-center" style={{ fontFamily: "'Segoe UI', Arial, sans-serif", fontWeight: '300' }}>
              <Trans id="recruiterSignUp.subheading">
                Join thousands of professionals who have found their dream jobs with us
              </Trans>
            </p>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default RecruiterSignUpPage; 