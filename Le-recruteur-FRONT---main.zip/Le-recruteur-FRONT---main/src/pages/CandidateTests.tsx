import React, { useState } from "react";
import CandidateTestList from "../components/CandidateComponents/TestsComponents/CandidateTestList";
import CandidateTestModal from "../components/CandidateComponents/TestsComponents/CandidateTestModal";
import TestResults from "../components/CandidateComponents/TestsComponents/TestResults";
import CandidateNavbar from "../components/Layout/CandidateNavbar";
import CandidateSidebar from "../components/Layout/CandidateSidebar";
import { candidateTestService } from "../lib/network/candidateTest";
import { CandidateTest, TestAttempt } from "../lib/types/candidateTests";

// Import ExtendedCandidateTest from CandidateTestList.tsx
interface ExtendedCandidateTest {
  id: string;
  title: string;
  description?: string;
  status?: string;
  bestScore?: number;
  attempts?: number;
  maxAttempts?: number;
  assignedDate?: string;
  lastAttemptDate?: string;
  dueDate?: string;
  category?: string;
  difficulty?: string;
  duration?: number;
  totalQuestions?: number;
  passingScore?: number;
  tags?: string[];
  isActive?: boolean;
  instructions?: string[];
  job?: { id: string; title: string; company: string };
  completedAt?: Date | null;
  questions?: unknown[]; // Using unknown for TestQuestion to avoid type issues
  createdAt?: string;
  updatedAt?: string;
}

const CandidateTests: React.FC = () => {
  const [selectedTest, setSelectedTest] = useState<CandidateTest | null>(null);
  const [showTestModal, setShowTestModal] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [currentAttempt, setCurrentAttempt] = useState<TestAttempt | null>(
    null
  );
  const [testResult, setTestResult] = useState<CandidateTest | null>(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Handle the type difference between ExtendedCandidateTest and CandidateTest
  const handleStartTest = (test: ExtendedCandidateTest) => {
    // Convert ExtendedCandidateTest to CandidateTest
    const candidateTest = {
      id: test.id,
      title: test.title,
      description: test.description || "",
      duration: test.duration || 60,
      totalQuestions: test.totalQuestions || 0,
      passingScore: test.passingScore || 70,
      instructions: test.instructions || [],
      isActive: test.isActive !== false,
      createdAt: test.createdAt || new Date().toISOString(),
      updatedAt: test.updatedAt || new Date().toISOString(),
      category: test.category,
      difficulty: test.difficulty,
      tags: test.tags || [],
    } as CandidateTest; // Cast the entire object to avoid individual property type issues

    setSelectedTest(candidateTest);
    setShowTestModal(true);
  };

  const handleTestComplete = async (attempt: TestAttempt) => {
    setCurrentAttempt(attempt);
    setShowTestModal(false);

    try {
      // Fetch the test results from API
      const result = await candidateTestService.getTestResults(attempt.testId);

      if (result.success && result.data) {
        const apiResult = result.data;
        console.log("apiResult", apiResult);

        setTestResult(apiResult);
        setShowResults(true);
        setRefreshTrigger((prev) => prev + 1);
      } else {
        throw new Error("Failed to retrieve test results");
      }
    } catch (error) {
      console.error("Error fetching test results:", error);

      setShowResults(false);
      setRefreshTrigger((prev) => prev + 1);
    }
  };

  const handleCloseModal = () => {
    setShowTestModal(false);
    setSelectedTest(null);
    setCurrentAttempt(null);
  };

  const handleCloseResults = () => {
    setShowResults(false);
    setTestResult(null);
    setCurrentAttempt(null);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <div className=" w-20 ">
        <CandidateSidebar />
      </div>
      <div className="flex-1 flex flex-col overflow-hidden">
        <CandidateNavbar />
        <main className="flex-1 overflow-y-auto pb-16">
          <CandidateTestList
            onStartTest={handleStartTest}
            refreshTrigger={refreshTrigger}
          />
        </main>
      </div>

      {/* Modals - These should be at the top level to overlay everything */}
      {showTestModal && selectedTest && (
        <CandidateTestModal
          test={selectedTest}
          onComplete={handleTestComplete}
          onClose={handleCloseModal}
        />
      )}

      {showResults && testResult && currentAttempt && (
        <TestResults
          result={testResult}
          test={selectedTest!}
          onClose={handleCloseResults}
        />
      )}
    </div>
  );
};

export default CandidateTests;
