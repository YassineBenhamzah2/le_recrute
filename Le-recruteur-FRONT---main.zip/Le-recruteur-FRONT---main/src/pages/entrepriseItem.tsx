import { useNavigate } from "react-router-dom";
import EntrepriseDetails from "@/components/Landing/EntrepriseItemPage";
import { useParams } from "react-router-dom";
import { t } from "@lingui/macro";

const Entreprise = () => {
  const router = useNavigate();
  const { id } = useParams();
  const onGetStarted = () => {
    router("/auth/");
  };
  const onSignIn = () => {
    router("/auth/");
  };
  if (!id) {
    return <div>
      {t({ id: "entreprise.notFound", message: "Company not found" })}
    </div>;
  }
  return (
    <EntrepriseDetails
      onGetStarted={onGetStarted}
      onSignIn={onSignIn}
      companyId={+id}
    />
  );
};

export default Entreprise;
