import React from "react";
import BlogDetail from "../components/Landing/BlogDetail";

const BlogDetailPage: React.FC = () => {
  return <BlogDetail />;
};

export default BlogDetailPage;
