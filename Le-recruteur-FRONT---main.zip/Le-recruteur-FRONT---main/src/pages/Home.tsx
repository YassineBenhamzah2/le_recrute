import HomePage from '@/components/Landing/HomePage';

const Home = () => <HomePage />;

export default Home;