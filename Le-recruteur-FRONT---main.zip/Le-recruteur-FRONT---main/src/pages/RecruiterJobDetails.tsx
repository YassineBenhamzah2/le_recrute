import BaseDashboard from "@/components/Dashboard/BaseDashboard";
import { RecruiterJobDetailsDashboard } from "@/components/Dashboard/RecruiterJobDetailsDashboard";
import RecruiterSidebar from "@/components/Layout/RecruiterSidebar";
import RecruiterFooter from "@/components/Layout/RecruiterFooter";
import RecruiterHeader from "@/components/Layout/RecruiterHeader";

const RecruiterJobsDetails = () => {
  return (
    <BaseDashboard
      SideBar={<RecruiterSidebar />}
      Footer={<RecruiterFooter />}
      Header={<RecruiterHeader />}
    >
      <RecruiterJobDetailsDashboard />
    </BaseDashboard>
  );
};

export default RecruiterJobsDetails;
