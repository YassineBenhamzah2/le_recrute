import React from "react";
import { PermissionBrowser } from "../components/Dashboard/PermissionBrowser";

const AdminPermissionsPage: React.FC = () => {
  return <PermissionBrowser />;
};

export default AdminPermissionsPage;
