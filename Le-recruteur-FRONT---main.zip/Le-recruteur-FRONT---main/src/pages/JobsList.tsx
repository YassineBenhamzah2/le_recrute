import JobsListPage from "@/components/Landing/JobsList";
import { useNavigate } from "react-router-dom";

export default function JobsList() {
  const router = useNavigate();
  const onGetStarted = () => {
    router("/auth/");
  };
  const onSignIn = () => {
    router("/auth/");
  };
  return <JobsListPage onGetStarted={onGetStarted} onSignIn={onSignIn} />;
}
