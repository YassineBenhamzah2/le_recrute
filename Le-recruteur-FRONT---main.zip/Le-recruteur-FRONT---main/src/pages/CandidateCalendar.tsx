import BaseDashboard from "../components/Dashboard/BaseDashboard";
import CandidateSidebar from "../components/Layout/CandidateSidebar";
import CandidateNavbar from "../components/Layout/CandidateNavbar";
import CandidateCalendrierDashboard from "../components/CandidateComponents/CandidateCalendarDashboard";

const CandidateCalendar = () => {
    return (
        <BaseDashboard SideBar={<CandidateSidebar />}>
            <CandidateNavbar />
            <CandidateCalendrierDashboard />
        </BaseDashboard>
    );
};

export default CandidateCalendar;
