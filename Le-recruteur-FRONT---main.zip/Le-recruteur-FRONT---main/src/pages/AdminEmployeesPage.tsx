import React from "react";
import EmployeeManagement from "../components/Dashboard/EmployeeManagement";

const AdminEmployeesPage: React.FC = () => {
  return <EmployeeManagement />;
};

export default AdminEmployeesPage;
