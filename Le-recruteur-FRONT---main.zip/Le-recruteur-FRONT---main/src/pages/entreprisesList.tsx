import { useNavigate } from "react-router-dom";
import EntreprisePage from "@/components/Landing/EntrepriseListPage";
const Entreprise = () => {
  const router = useNavigate();

  const onGetStarted = () => {
    router("/auth/");
  };
  const onSignIn = () => {
    router("/auth/");
  };
  return <EntreprisePage onGetStarted={onGetStarted} onSignIn={onSignIn} />;
};

export default Entreprise;
