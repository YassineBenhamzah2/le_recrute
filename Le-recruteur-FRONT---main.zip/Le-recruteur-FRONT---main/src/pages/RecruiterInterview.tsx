import BaseDashboard from "../components/Dashboard/BaseDashboard";
import RecruiterInterviewDashboard from "../components/Dashboard/RecruiterInterviewDashboard";
import RecruiterSidebar from "../components/Layout/RecruiterSidebar";
import RecruiterFooter from "../components/Layout/RecruiterFooter";
import RecruiterHeader from "@/components/Layout/RecruiterHeader";

const RecruiterInterview = () => {
  return (
    <BaseDashboard
      SideBar={<RecruiterSidebar />}
      Footer={<RecruiterFooter />}
      Header={<RecruiterHeader />}
    >
      <RecruiterInterviewDashboard />
    </BaseDashboard>
  );
};

export default RecruiterInterview;
