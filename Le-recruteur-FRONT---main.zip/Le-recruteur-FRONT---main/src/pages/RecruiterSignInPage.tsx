import React from 'react';
import RecruiterLoginForm from '../components/Auth/RecruiterLoginForm';
import Header from '../components/Layout/Header';
import Footer from '@/components/Layout/Footer';
import { Trans } from '@lingui/react/macro';

const RecruiterSignInPage: React.FC = () => {
  return (
    <div className=" flex flex-col">
      <Header isMobileMenuOpen={false} setIsMobileMenuOpen={() => {}} />
      <div className="min-h-[80vh] flex flex-1 items-center justify-center">
        <div className="flex flex-row w-[85%]">
          {/* Left: Marketing Sentences */}
          <div className="flex flex-col w-[500px] relative top-[60px] gap-[15px]" style={{ fontFamily: "'Nono Sans', sans-serif" }}>
            <span className="text-5xl font-semibold text-[#229b8e] mb-2">
              <Trans id="recruiterSignIn.smartTools">Smart tools</Trans>
            </span>
            <span className="text-5xl font-semibold text-[#229b8e] mb-2">
              <Trans id="recruiterSignIn.fastHires">Fast hires</Trans>
            </span>
            <span className="text-5xl font-semibold text-[#229b8e]">
              <Trans id="recruiterSignIn.betterRecruiting">
                Better <span className='italic'>recruiting</span>
              </Trans>
            </span>
          </div>
          {/* Right: Form */}
          <div className="w-[43rem] bg-[#a7acb25f] rounded-[20px] p-3 flex flex-col items-center ml-20">
            <RecruiterLoginForm />
          </div>
        </div>
      </div>
      <div className="flex justify-center mt-12 mb-[10rem]">
        <div className="flex flex-row gap-12">
          {/* Box 1 */}
          <div className="border border-[#229b8e] rounded-lg p-8 w-80 flex flex-col items-center bg-white transition-transform duration-500 hover:scale-105">
            <div className="w-20 h-20 rounded-full bg-[#229b8e] flex items-center justify-center mb-6">
              <span className="text-white text-3xl font-bold" dir='ltr'>01</span>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold mb-2">
                <Trans id="recruiterSignIn.box1Title">Create your free account</Trans>
              </div>
              <div className="text-gray-500">
                <Trans id="recruiterSignIn.box1Desc">
                  Get started in seconds — just take a small step and unlock access to our recruitment tools and start building your hiring journey.
                </Trans>
              </div>
            </div>
          </div>
          {/* Box 2 */}
          <div className="border border-[#229b8e] rounded-lg p-8 w-80 flex flex-col items-center bg-white transition-transform duration-500 hover:scale-105">
            <div className="w-20 h-20 rounded-full bg-[#229b8e] flex items-center justify-center mb-6">
              <span className="text-white text-3xl font-bold">02</span>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold mb-2">
                <Trans id="recruiterSignIn.box2Title">Post your job offer</Trans>
              </div>
              <div className="text-gray-500">
                <Trans id="recruiterSignIn.box2Desc">
                  Publish your opportunity and put it in front of the right talent — fast, easy, and effective.
                </Trans>
              </div>
            </div>
          </div>
          {/* Box 3 */}
          <div className="border border-[#229b8e] rounded-lg p-8 w-80 flex flex-col items-center bg-white transition-transform duration-500 hover:scale-105">
            <div className="w-20 h-20 rounded-full bg-[#229b8e] flex items-center justify-center mb-6">
              <span className="text-white text-3xl font-bold">03</span>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold mb-2">
                <Trans id="recruiterSignIn.box3Title">Find your hires</Trans>
              </div>
              <div className="text-gray-500">
                <Trans id="recruiterSignIn.box3Desc">
                  Use our intelligent matching and filtering tools to discover qualified candidates and build your dream team faster than ever.
                </Trans>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer/>
    </div>
  );
};

export default RecruiterSignInPage;
