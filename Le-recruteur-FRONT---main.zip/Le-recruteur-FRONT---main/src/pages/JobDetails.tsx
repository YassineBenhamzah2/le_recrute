import Footer from "@/components/Layout/Footer";
import Header from "@/components/Layout/Header";
import ApplyJobForm from "@/components/Modals/applyJobForm";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { jobOffersService } from "@/lib/network/pages/jobOffers";
import { settings } from "@/lib/settings/main";
import { JobOffer, ReportFormData } from "@/lib/types/jobOffer";
import { toast } from "sonner";
import {
  Bookmark,
  Building2,
  MapPin,
  MessageCircle,
  Phone,
  Share,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Trans , t } from '@lingui/macro';
import ReportForm from "./ReportForm";

type NotificationState = {
  title: string;
  description?: React.ReactNode;
  variant: "success" | "destructive";
} | null;

export default function JobDetails() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isApplyFormOpen, setIsApplyFormOpen] = useState(false);
  const [job, setJob] = useState<JobOffer | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const { user, isCandidate: checkIsCandidate } = useAuth();
  const [showModal, setShowModal] = useState(false);

  

  // Fetch single job by ID
  useEffect(() => {
    const jobId = Number(id);
    if (!id || Number.isNaN(jobId)) {
      setError("Invalid job ID");
      setLoading(false);
      return;
    }
    let isMounted = true;
    (async () => {
      try {
        setLoading(true);
        setError(null);
        const res = await jobOffersService.getById(jobId);
        if (!isMounted) return;
        setJob(res.data ?? null);
      } catch (e) {
        if (!isMounted) return;
        setError((e as Error)?.message || "Failed to load job");
        setJob(null);
      } finally {
        if (isMounted) setLoading(false);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, [id]);

  const handleSignIn = () => {
    navigate("/auth");
  };

  const handleGetStarted = () => {
    console.log("Get started clicked");
  };

  const handleReport = () => {
    console.log("Report clicked");
    if (!user) {
      navigate("/auth");
      return;
    }
    setShowModal(true);
  };

  

  const handleShareJob = () => {
    console.log("Share job clicked");
  };

  const handleBookmark = async () => {
    if (!user) {
      navigate("/auth");
      return;
    }
    if (!job) return;
    try {
      await jobOffersService.bookmarkJob(job.id);
      const refreshed = await jobOffersService.getById(job.id);
      setJob(refreshed.data || null);
    } catch (e) {
      console.error(e);
    }
  };

  const handleApplyNow = () => {
    if (!user) {
      navigate("/auth");
      return;
    }
    setIsApplyFormOpen(true);
  };

  const handleCloseApplyForm = () => {
    setIsApplyFormOpen(false);
  };

  const handleApplied = async (appliedJobId: number) => {
    if (!job || job.id !== appliedJobId) return;
    if (!isCandidate || !Number.isFinite(candidateIdNum)) return;
    // Optimistic update
    setJob((prev) =>
      !prev
        ? prev
        : ({
            ...prev,
            appliedBy: Array.from(
              new Set([...(prev.appliedBy || []), Number(candidateIdNum)])
            ),
          } as JobOffer)
    );

    // Background reconcile
    try {
      const refreshed = await jobOffersService.getById(appliedJobId);
      setJob(refreshed.data || null);
    } catch (e) {
      console.error(e);
    }
  };

  // Share link copy state/handler
  const [copied, setCopied] = useState(false);
  const handleShareBtn = () => {
    const url = window.location.href;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 3000);
      });
    }
  };

  const companyName = job?.company?.name ?? "Unknown Company";
  const companyId = job?.company?.id ?? "";

  const cleanString = (str: string): string => {
      if (!str) return str;
      return str.replace(/[\u200B-\u200D\uFEFF]/g, '');
    };

 const handleSaveReport = async (reportData: ReportFormData) => {
  try {

    console.log("Données du rapport:", reportData);
    const cleanedData = {
      firstName: cleanString(reportData.firstName),
      lastName: cleanString(reportData.lastName),
      email: cleanString(reportData.email),
      phone: cleanString(reportData.phone),
      reportReason: cleanString(reportData.reportReason),
    };

    console.log("Données nettoyées:", cleanedData);
    
    const reportDataWithCompany = {
      ...cleanedData,
      companyId: companyId as number,
      id: user?.id as number  // Note: utilisez "id" au lieu de "userId" si c'est ce qu'attend le backend
    };
    
    // Appel API via le service
    const response = await jobOffersService.createReport(reportDataWithCompany);

    if (response.success){
      toast.success(t`Report has been submitted successfully.`)
    }
    // Fermer le modal
    setShowModal(false);
    
  } catch (error) {
    console.error("Error submitting report:", error);
    toast.error(t`Failed to submit report. Please try again.`);
  }
};

  const companyLogo =
    `${settings.IMG_ADDRESS}${job?.company?.logo}` || "/ehc logo.png";
  const onLogoError = (e: React.SyntheticEvent<HTMLImageElement>) => {
    (e.currentTarget as HTMLImageElement).src = "/ehc logo.png";
  };

  const jobTypeLabel = job?.jobType
    ? job.jobType.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())
    : "";
  const salaryText = job
    ? job.negotiable
      ? "Negotiable"
      : job.minSalary && job.maxSalary
      ? `${job.minSalary} - ${job.maxSalary} ${job.currency}`
      : job.minSalary
      ? `${job.minSalary} ${job.currency}`
      : job.maxSalary
      ? `${job.maxSalary} ${job.currency}`
      : "—"
    : "—";
  const requirements: string[] = Array.isArray(job?.requirements)
    ? job!.requirements
        .flatMap((r) => String(r).split(/\r?\n/))
        .map((s) => s.trim())
        .filter(Boolean)
    : [];

  const responsibilities: string[] = Array.isArray(job?.responsibilities)
    ? job!.responsibilities
        .flatMap((r) => String(r).split(/\r?\n/))
        .map((s) => s.trim())
        .filter(Boolean)
    : [];

  // User role aware UI states
  const isLoggedIn = !!user;
  const isCandidate = checkIsCandidate();
  const candidateId = user?.candidateId ?? user?.id;
  const candidateIdNum = candidateId == null ? NaN : Number(candidateId);
  const isBookmarked = useMemo(() => {
    if (!isCandidate || !Number.isFinite(candidateIdNum) || !job) return false;
    return (
      Array.isArray(job.bookmarkedBy) &&
      job.bookmarkedBy.some((id) => Number(id) === candidateIdNum)
    );
  }, [isCandidate, candidateIdNum, job]);
  const isApplied = useMemo(() => {
    if (!isCandidate || !Number.isFinite(candidateIdNum) || !job) return false;
    return (
      Array.isArray(job.appliedBy) &&
      job.appliedBy.some((id) => Number(id) === candidateIdNum)
    );
  }, [isCandidate, candidateIdNum, job]);
  const bookmarkDisabled = isLoggedIn && !isCandidate;
  const applyDisabled =
    (isLoggedIn && !isCandidate) || (isCandidate && isApplied);

  if (loading || error) {
    return (
      <div className="min-h-screen bg-white">
        <Header
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          onSignIn={() => navigate("/auth")}
          onGetStarted={() => {}}
        />
        <div className="bg-[#E0F2F1] py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-6xl font-bold text-ehc-green font-poppins">
                <Trans id="job.details.title">Job Details</Trans>
              </h1>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 py-10">
          {loading && <div className="text-gray-600">
              <Trans id="job.loading">Loading job…</Trans>
            </div>}
          {error && <div className="text-red-600">{error}</div>}
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onSignIn={handleSignIn}
        onGetStarted={handleGetStarted}
      />

      {/* Hero Section with Job Details Title */}
      <div className="bg-[#E0F2F1] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-6xl font-bold text-ehc-green font-poppins">
              <Trans id="job.details.title">Job Details</Trans>
            </h1>
          </div>
        </div>
      </div>

      {/* Margin bottom spacing */}
      <div className="h-12"></div>

      {/* Main Content Container */}
      <div className="max-w-screen mx-auto">
        {/* Company Profile Section */}
        <div className="bg-ehc-green py-6 rounded-t-3xl">
          <h2 className="text-2xl font-bold text-white font-poppins ml-20 ">
            <Trans id="job.company.profile">Company Profile</Trans>
          </h2>
        </div>

        {/* Job Information Grid */}
        <div className="py-12 mx-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column - Job Information */}
            <div className="lg:pr-12">
              {/* Job Title */}
              <div className="mb-8">
                <h3 className="text-3xl font-bold text-ehc-green font-poppins leading-tight">
                  {job?.title ?? "—"}
                </h3>
              </div>

              {/* Company Details */}
              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <Building2 className="w-5 h-5 text-ehc-green flex-shrink-0" />
                  <div className="text-base">
                    <span className="font-semibold text-gray-700 font-poppins">
                      <Trans id="job.company.label">Company :</Trans>{" "}
                    </span>
                    <span className="text-gray-600 font-poppins">
                      {companyName}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-ehc-green flex-shrink-0" />
                  <div className="text-base">
                    <span className="font-semibold text-gray-700 font-poppins">
                      <Trans id="job.company.phone">Phone :</Trans>{" "}
                    </span>
                    <span className="text-gray-600 font-poppins">
                      {job?.company?.phone ?? "—"}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-ehc-green flex-shrink-0" />
                  <div className="text-base">
                    <span className="font-semibold text-gray-700 font-poppins">
                      <Trans id="job.company.location">Location :</Trans>{" "}
                    </span>
                    <span className="text-gray-600 font-poppins">
                      {job?.company?.address ?? "—"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-3">
                <Button
                  onClick={handleReport}
                  className="bg-ehc-green hover:bg-ehc-green/90 text-white px-6 py-2.5 rounded-md font-poppins font-medium flex items-center gap-2 text-sm"
                >
                  <MessageCircle className="w-4 h-4" />
                  <Trans id="job.actions.report">Report</Trans>
                </Button>

                <Button
                  onClick={handleShareJob}
                  variant="outline"
                  className="border-2 border-ehc-green text-ehc-green hover:bg-ehc-green hover:text-white px-6 py-2.5 rounded-md font-poppins font-medium flex items-center gap-2 text-sm"
                >
                  <Share className="w-4 h-4" />
                  <Trans id="job.actions.share">Share offer</Trans>
                </Button>

                <Button
                  onClick={handleBookmark}
                  variant="outline"
                  disabled={bookmarkDisabled}
                  className={`border-2 ${
                    isBookmarked
                      ? "border-ehc-green bg-ehc-green text-white"
                      : "border-ehc-green text-ehc-green hover:bg-ehc-green hover:text-white"
                  } px-3 py-2.5 rounded-md ${
                    bookmarkDisabled ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                >
                  <Bookmark className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Right Column - Company Logo */}
            <div className="flex justify-center lg:justify-end items-start lg:pl-8">
              <div className="bg-blue-400 rounded-lg shadow-lg border border-gray-200 w-[30rem] h-[20rem]">
                <img
                  src={companyLogo}
                  onError={onLogoError}
                  alt={companyName}
                  className="w-full h-full object-contain border border-ehc-green-light rounded"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Job Details Section */}
        <div className="mt-12">
          <div className="bg-ehc-green py-6 rounded-t-3xl">
            <h2 className="text-2xl font-bold text-white font-poppins ml-20 ">
              <Trans id="job.details.title">Job Details</Trans>
            </h2>
          </div>

          <div className="bg-white p-8 rounded-b-2xl mx-20">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
              {/* Left Column - Job Description */}
              <div className="lg:col-span-3 space-y-6">
                {/* About the Role */}
                <div>
                  <h3 className="text-base font-semibold text-ehc-green font-poppins mb-3 flex items-center">
                    <span className="w-2 h-2 bg-ehc-green rounded-full mr-2"></span>
                    <Trans id="job.role.about">About the Role:</Trans>
                  </h3>
                  <p className="text-gray-700 font-poppins text-sm leading-relaxed whitespace-pre-line">
                    {job?.description ?? "—"}
                  </p>
                </div>

                {/* Key Responsibilities */}
                <div>
                  <h3 className="text-base font-semibold text-ehc-green font-poppins mb-3 flex items-center">
                    <span className="w-2 h-2 bg-ehc-green rounded-full mr-2"></span>
                    <Trans id="job.role.responsibilities">Key Responsibilities:</Trans>
                  </h3>
                  <ul className="space-y-2 text-gray-700 font-poppins text-sm">
                    {responsibilities?.length > 0 ? (
                      responsibilities?.map((resp, idx) => (
                        <li key={idx} className="flex items-start">
                          <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          {resp}
                        </li>
                      ))
                    ) : (
                      <li className="text-gray-500">
                        <Trans id="job.noResponsibilities">No responsibilities specified.</Trans>
                      </li>
                    )}
                  </ul>
                </div>

                {/* Requirements */}
                <div>
                  <h3 className="text-base font-semibold text-ehc-green font-poppins mb-3 flex items-center">
                    <span className="w-2 h-2 bg-ehc-green rounded-full mr-2"></span>
                    <Trans id="job.role.requirements">Requirements:</Trans>
                  </h3>
                  <ul className="space-y-2 text-gray-700 font-poppins text-sm">
                    {requirements.length > 0 ? (
                      requirements.map((req, idx) => (
                        <li key={idx} className="flex items-start">
                          <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          {req}
                        </li>
                      ))
                    ) : (
                      <li className="text-gray-500">
                        <Trans id="job.noRequirements">No requirements specified.</Trans>
                      </li>
                    )}
                  </ul>
                </div>
              </div>

              {/* Right Column - Job Info Cards */}
              <div className="lg:col-span-2 space-y-4">
                {/* Salary & Location Card */}
                <div
                  className="bg-white rounded-xl border border-[#CFE6E7] p-6 flex items-center justify-center"
                  style={{ boxShadow: "0 0 0 2px #CFE6E7" }}
                >
                  <div className="flex w-full">
                    {/* Salary Column */}
                    <div className="flex-1 flex flex-col items-center justify-center text-center">
                      <div className="flex flex-col">
                        <div className="text-sm font-semibold text-gray-800 font-poppins mb-1">
                          <Trans id="job.salary.label">Salary</Trans>
                        </div>
                        <div className="text-lg font-bold text-ehc-green font-poppins mb-1">
                          {salaryText}
                        </div>
                        <div className="text-sm text-gray-500 font-poppins">
                          {job?.currency || ""}
                        </div>
                      </div>
                    </div>
                    {/* Divider */}
                    <div
                      className="w-px bg-[#CFE6E7] mx-6"
                      style={{ minHeight: "70px" }}
                    ></div>
                    {/* Location Column */}
                    <div className="flex-1 flex flex-col items-center justify-center text-center">
                      <svg
                        className="w-8 h-8 text-ehc-green mb-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"
                        />
                      </svg>
                      <div className="text-base font-semibold text-gray-800 font-poppins mb-1">
                        <Trans id="job.location.label">Job Location</Trans>
                      </div>
                      <div className="text-sm text-gray-600 font-poppins">
                        {job?.location ?? "—"}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Job Overview Card */}
                <div
                  className="bg-white rounded-xl border border-[#CFE6E7] p-5 shadow-sm"
                  style={{ boxShadow: "0 0 0 2px #CFE6E7" }}
                >
                  <h4 className="text-lg font-semibold text-gray-800 font-poppins mb-4">
                    <Trans id="job.overview.title">Job Overview</Trans>
                  </h4>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-left">
                      <div className="w-8 h-8 text-ehc-green mb-2">
                        <svg
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          viewBox="0 0 24 24"
                        >
                          <rect
                            x="3"
                            y="4"
                            width="18"
                            height="18"
                            rx="2"
                            ry="2"
                          />
                          <line x1="16" y1="2" x2="16" y2="6" />
                          <line x1="8" y1="2" x2="8" y2="6" />
                          <line x1="3" y1="10" x2="21" y2="10" />
                        </svg>
                      </div>
                      <div className="text-xs text-gray-500 font-poppins uppercase mb-1">
                        <Trans id="job.posted.label">JOB POSTED:</Trans>
                      </div>
                      <div className="text-sm font-semibold text-gray-800 font-poppins">
                        {job?.publicationDate ?? "—"}
                      </div>
                    </div>

                    <div className="text-left">
                      <div className="w-8 h-8 text-ehc-green mb-2">
                        <svg
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          viewBox="0 0 24 24"
                        >
                          <circle cx="12" cy="12" r="10" />
                          <polyline points="12,6 12,12 16,14" />
                        </svg>
                      </div>
                      <div className="text-xs text-gray-500 font-poppins uppercase mb-1">
                        <Trans id="job.expire.label">JOB EXPIRE IN:</Trans>
                      </div>
                      <div className="text-sm font-semibold text-gray-800 font-poppins">
                        {job?.deadlineDate ?? "—"}
                      </div>
                    </div>

                    <div className="text-left">
                      <div className="w-8 h-8 text-ehc-green mb-2">
                        <svg
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          viewBox="0 0 24 24"
                        >
                          <rect x="3" y="3" width="7" height="7" />
                          <rect x="14" y="3" width="7" height="7" />
                          <rect x="14" y="14" width="7" height="7" />
                          <rect x="3" y="14" width="7" height="7" />
                        </svg>
                      </div>
                      <div className="text-xs text-gray-500 font-poppins uppercase mb-1">
                        <Trans id="job.type.label">JOB TYPE:</Trans>
                      </div>
                      <div className="text-sm font-semibold text-gray-800 font-poppins">
                        {jobTypeLabel || "—"}
                      </div>
                    </div>

                    <div className="text-left">
                      <div className="w-8 h-8 text-ehc-green mb-2">
                        <svg
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          viewBox="0 0 24 24"
                        >
                          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                          <polyline points="14,2 14,8 20,8" />
                          <line x1="16" y1="13" x2="8" y2="13" />
                          <line x1="16" y1="17" x2="8" y2="17" />
                          <polyline points="10,9 9,9 8,9" />
                        </svg>
                      </div>
                      <div className="text-xs text-gray-500 font-poppins uppercase mb-1">
                        <Trans id="job.requiredExperience.label">REQUIRED EXPERIENCE</Trans>
                      </div>
                      <div className="text-sm font-semibold text-gray-800 font-poppins">
                        -
                      </div>
                    </div>

                    <div className="text-left col-span-2">
                      <div className="w-8 h-8 text-ehc-green mb-2">
                        <svg
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          viewBox="0 0 24 24"
                        >
                          <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
                          <path d="M6 12v5c3 3 9 3 12 0v-5" />
                        </svg>
                      </div>
                      <div className="text-xs text-gray-500 font-poppins uppercase mb-1">
                        <Trans id="job.requiredEducation.label">REQUIRED EDUCATION</Trans>
                      </div>
                      <div className="text-sm font-semibold text-gray-800 font-poppins">
                        -
                      </div>
                    </div>
                  </div>
                </div>

                {/* Share this job Card */}
                <div
                  className="bg-white rounded-xl border border-[#CFE6E7] p-5 shadow-sm"
                  style={{ boxShadow: "0 0 0 2px #CFE6E7" }}
                >
                  <h4 className="text-lg font-semibold text-gray-800 font-poppins mb-3">
                    <Trans id="job.share.title">Share this offer:</Trans>
                  </h4>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={handleShareBtn}
                      disabled={copied}
                      className={`flex items-center gap-2 text-sm font-poppins border border-ehc-green rounded-lg px-3 py-2 ${
                        copied
                          ? "bg-ehc-green text-white"
                          : "text-ehc-green hover:underline"
                      }`}
                      aria-live="polite"
                    >
                      {copied ? (
                        <Trans id="job.share.copied">Copied ✔</Trans>
                      ) : (
                        <>
                          <svg
                            className="w-4 h-4"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            viewBox="0 0 24 24"
                          >
                            <path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71" />
                            <path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71" />
                          </svg>
                          <Trans id="job.share.link">Share Link</Trans>
                        </>
                      )}
                    </button>
                    <div className="flex gap-2">
                      <a
                        href={`https://www.linkedin.com`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-8 h-8 bg-[#0077b5] rounded-lg flex items-center justify-center text-white hover:opacity-80"
                      >
                        <svg
                          className="w-4 h-4"
                          fill="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                        </svg>
                      </a>
                      <a
                        href={`https://www.facebook.com`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-8 h-8 bg-[#1877f2] rounded-lg flex items-center justify-center text-white hover:opacity-80"
                      >
                        <svg
                          className="w-4 h-4"
                          fill="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                        </svg>
                      </a>
                      <a
                        href={`https://twitter.com`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-8 h-8 bg-black rounded-lg flex items-center justify-center text-white hover:opacity-80"
                      >
                        <svg
                          className="w-4 h-4"
                          fill="currentColor"
                          viewBox="0 0 24 24"
                          aria-hidden="true"
                        >
                          <path d="M18.244 2H21.5l-7.5 8.555L22 22h-6.5l-5.06-5.966L4.6 22H1.333l7.894-9.009L2 2h6.667l4.807 5.662L18.244 2z" />
                        </svg>
                      </a>
                    </div>
                  </div>
                </div>

                {/* Apply Now Button */}
                <div className="w-full pt-10">
                  <button
                    onClick={handleApplyNow}
                    disabled={applyDisabled}
                    className={`bg-ehc-green hover:bg-ehc-green/90 text-white py-3 px-8 rounded-xl font-poppins font-semibold text-lg w-full ${
                      applyDisabled ? "opacity-50 cursor-not-allowed" : ""
                    }`}
                  >
                    {isCandidate && isApplied ? "Applied" : "Apply Now"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Apply Job Form Modal */}
      <ApplyJobForm
        isOpen={isApplyFormOpen}
        onClose={handleCloseApplyForm}
        jobId={job?.id}
        jobTitle={job?.title ?? ""}
        questions={job?.questions}
        questionIds={job?.questionsIds}
        onApplied={handleApplied}
      />

      {showModal  && (
        <ReportForm
          onSave={handleSaveReport}
          onCancel={() => {
            setShowModal(false);
          }}
        />
      )}

      <Footer />
    </div>
  );
}
