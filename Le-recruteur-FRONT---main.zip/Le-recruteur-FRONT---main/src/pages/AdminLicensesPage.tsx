import React from "react";
import { LicenseDashboard } from "../components/Dashboard/LicenseDashboard";

const AdminLicensesPage: React.FC = () => {
  return <LicenseDashboard />;
};

export default AdminLicensesPage;
