import { useNavigate } from "react-router-dom";
import FAQPage from "@/components/Landing/FAQPage";

const FAQ = () => {
    const router = useNavigate();
    const onGetStarted = () => {
        router("/auth/");
    }
    const onSignIn = () => {
        router("/auth/");
    }
    return (
        <FAQPage onGetStarted={onGetStarted} onSignIn={onSignIn} />
    );
};

export default FAQ;