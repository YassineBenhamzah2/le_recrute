import BaseDashboard from "@/components/Dashboard/BaseDashboard";
import RecruiterProfileDashboard from "@/components/Dashboard/RecruiterProfileDashboard";
import RecruiterSidebar from "@/components/Layout/RecruiterSidebar";
import RecruiterFooter from "@/components/Layout/RecruiterFooter";
import RecruiterHeader from "@/components/Layout/RecruiterHeader";

const RecruiterProfile = () => {
  return (
    <BaseDashboard
      SideBar={<RecruiterSidebar />}
      Footer={<RecruiterFooter />}
      Header={<RecruiterHeader />}
    >
      <RecruiterProfileDashboard />
    </BaseDashboard>
  );
};

export default RecruiterProfile ;
