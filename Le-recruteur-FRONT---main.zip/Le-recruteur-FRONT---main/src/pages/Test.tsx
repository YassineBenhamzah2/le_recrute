import React from "react";
import { useSearchParams } from "react-router-dom";
import BaseDashboard from "@/components/Dashboard/BaseDashboard";
import TestPreview from "@/components/Dashboard/TestPreview";
import RecruiterSidebar from "@/components/Layout/RecruiterSidebar";
import RecruiterFooter from "@/components/Layout/RecruiterFooter";
import RecruiterHeader from "@/components/Layout/RecruiterHeader";

const Test: React.FC = () => {
  const [searchParams] = useSearchParams();
  const id = searchParams.get("id");

  return (
    <BaseDashboard
      SideBar={<RecruiterSidebar />}
      Footer={<RecruiterFooter />}
      Header={<RecruiterHeader />}
    >
      <TestPreview id={id || undefined} />
    </BaseDashboard>
  );
};

export default Test;
