import React from 'react';
import { useNavigate } from 'react-router-dom';
import AboutUsPage from '@/components/Landing/AboutUsPage';

const AboutUs: React.FC = () => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    // Rediriger vers la page d'inscription ou d'authentification
    navigate('/auth/register');
  };

  const handleSignIn = () => {
    // Rediriger vers la page de connexion
    navigate('/auth');
  };

  return (
    <AboutUsPage 
      onGetStarted={handleGetStarted}
      onSignIn={handleSignIn}
    />
  );
};

export default AboutUs;