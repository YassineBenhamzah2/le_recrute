import { useNavigate } from "react-router-dom";
import Pricing from "../components/Landing/Pricing";

const PricingPage = () => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate("/auth");
  };

  const handleSignIn = () => {
    navigate("/auth");
  };

  return <Pricing onGetStarted={handleGetStarted} onSignIn={handleSignIn} />;
};

export default PricingPage;
