import { useNavigate } from "react-router-dom";
import Blog from "../components/Landing/Blog";

const BlogPage = () => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate("/auth");
  };

  const handleSignIn = () => {
    navigate("/auth");
  };

  return (
    <Blog 
      onGetStarted={handleGetStarted}
      onSignIn={handleSignIn}
    />
  );
};

export default BlogPage;
