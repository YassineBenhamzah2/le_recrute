import React from 'react';
import CandidateNavbar from '@/components/Layout/CandidateNavbar';
import CandidateSidebar from '@/components/Layout/CandidateSidebar';
import CandidateJobDetails from '@/components/CandidateComponents/CandidateJobDetails';

const CandidateJobDetailsPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <CandidateNavbar />
      <CandidateSidebar />
      <CandidateJobDetails />
    </div>
  );
};

export default CandidateJobDetailsPage;
