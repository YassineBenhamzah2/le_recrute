import BaseDashboard from "../components/Dashboard/BaseDashboard";
import CandidateDashboard from "../components/Dashboard/CandidateDashboard";
import CandidateSidebar from "../components/Layout/CandidateSidebar";
import CandidateNavbar from "../components/Layout/CandidateNavbar";

const Candidate = () => {

    return (
         <BaseDashboard SideBar={<CandidateSidebar />}>
            <CandidateNavbar />
            <CandidateDashboard />
        </BaseDashboard>
    );
};

export default Candidate;