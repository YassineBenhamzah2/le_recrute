import BaseDashboard from "@/components/Dashboard/BaseDashboard";
import { RecruiterJobsDashboard } from "@/components/Dashboard/RecruiterJobsDashboard";
import RecruiterSidebar from "@/components/Layout/RecruiterSidebar";
import RecruiterFooter from "@/components/Layout/RecruiterFooter";
import RecruiterHeader from "@/components/Layout/RecruiterHeader";

const RecruiterJobs = () => {
  return (
    <BaseDashboard
      SideBar={<RecruiterSidebar />}
      Footer={<RecruiterFooter />}
      Header={<RecruiterHeader />}
    >
      <RecruiterJobsDashboard />
    </BaseDashboard>
  );
};

export default RecruiterJobs;
