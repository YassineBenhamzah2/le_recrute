import React from "react";
import { useNavigate } from "react-router-dom";
import Services from "../components/Landing/Services";

const ServicesPage: React.FC = () => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate("/auth");
  };

  const handleSignIn = () => {
    navigate("/auth");
  };

  return <Services onGetStarted={handleGetStarted} onSignIn={handleSignIn} />;
};

export default ServicesPage;
