import BaseDashboard from "../components/Dashboard/BaseDashboard";
import CandidateSidebar from "../components/Layout/CandidateSidebar";
import CandidateNavbar from "../components/Layout/CandidateNavbar";
import CandidateInterviewsDashboard from "../components/CandidateComponents/CandidateInterviewsDashboard";

const CandidateInterviews = () => {
    return (
        <BaseDashboard SideBar={<CandidateSidebar />}>
            <CandidateNavbar />
            <CandidateInterviewsDashboard />
        </BaseDashboard>
    );
};

export default CandidateInterviews;
