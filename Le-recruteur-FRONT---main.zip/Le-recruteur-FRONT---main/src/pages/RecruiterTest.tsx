import BaseDashboard from "../components/Dashboard/BaseDashboard";
import RecruiterTestDashboard from "../components/Dashboard/RecruiterTestDashboard";
import RecruiterSidebar from "../components/Layout/RecruiterSidebar";
import RecruiterFooter from "../components/Layout/RecruiterFooter";

const RecruiterInterview = () => {

    return (
        <BaseDashboard SideBar={<RecruiterSidebar />} Footer={<RecruiterFooter />}>
            <RecruiterTestDashboard />
        </BaseDashboard>
    );
};

export default RecruiterInterview;