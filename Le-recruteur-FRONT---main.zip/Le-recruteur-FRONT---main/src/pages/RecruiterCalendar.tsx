import BaseDashboard from "../components/Dashboard/BaseDashboard";
import RecruiterCalendar from "../components/Dashboard/RecruiterCalendar";
import RecruiterSidebar from "../components/Layout/RecruiterSidebar";
import RecruiterFooter from "../components/Layout/RecruiterFooter";
import RecruiterHeader from "@/components/Layout/RecruiterHeader";

const RecruiterCalendarPage = () => {
  return (
    <BaseDashboard
      SideBar={<RecruiterSidebar />}
      Footer={<RecruiterFooter />}
      Header={<RecruiterHeader />}
    >
      <RecruiterCalendar />
    </BaseDashboard>
  );
};

export default RecruiterCalendarPage;
