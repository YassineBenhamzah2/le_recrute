import RecruiterSpacePage from "@/components/Landing/RecruiterSpacePage";
import React from "react";

const RecruiterSpace: React.FC = () => {
  return <RecruiterSpacePage />;
};

export default RecruiterSpace;
