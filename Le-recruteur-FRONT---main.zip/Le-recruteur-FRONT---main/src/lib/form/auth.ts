import z from "zod";
import { t } from "@lingui/core/macro";
// import { UserRoleList } from "../types/subtypes/main";

export const LoginSchema = () => z.object({
  email: z.string().email(t({ id: "auth.invalidEmail", message: "Invalid email format" })).min(1, t({ id: "auth.emailRequired", message: "Email is required" })),
  password: z.string().min(1, t({ id: "auth.passwordRequired", message: "Password is required" })),
});

export const RegisterSchema = () => z
  .object({
    firstname: z.string().min(1, t({ id: "auth.firstnameRequired", message: "First name is required" })),
    lastname: z.string().min(1, t({ id: "auth.lastnameRequired", message: "Last name is required" })),
    email: z.string().email(t({ id: "auth.invalidEmail", message: "Invalid email format" })).min(1, t({ id: "auth.emailRequired", message: "Email is required" })),
    password: z
      .string()
      .min(6, t({ id: "auth.passwordMinLength", message: "Password must be at least 6 characters long" }))
      .regex(/[A-Z]/, t({ id: "auth.passwordUppercase", message: "Password must contain at least one uppercase letter" }))
      .regex(/[a-z]/, t({ id: "auth.passwordLowercase", message: "Password must contain at least one lowercase letter" }))
      .regex(
        /[!@#$%^&*(),.?":{}|<>]/,
        t({ id: "auth.passwordSpecialChar", message: "Password must contain at least one special character" })
      ),
    confirmPassword: z.string().min(6, t({ id: "auth.confirmPasswordRequired", message: "Confirm password is required" })),
    // role: z.enum(UserRoleList, {
    //     message: "Role must be one of: CANDIDATE, RECRUITER, ADMIN"
    // }).optional(),
    agreeToTerms: z.boolean().refine((val) => val === true, {
      message: t({ id: "auth.termsAgreement", message: "You must agree to the terms and conditions" }),
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: t({ id: "auth.passwordsMustMatch", message: "Passwords must match" }),
    path: ["confirmPassword"],
  });

export const RecruiterRegisterSchema = () => z
  .object({
    firstname: z.string().min(1, t({ id: "auth.firstnameRequired", message: "First name is required" })),
    lastname: z.string().min(1, t({ id: "auth.lastnameRequired", message: "Last name is required" })),
    email: z.string().email(t({ id: "auth.invalidEmail", message: "Invalid email format" })).min(1, t({ id: "auth.emailRequired", message: "Email is required" })),
    phone: z.string().min(6, "Phone number is required"),
    password: z
      .string()
      .min(6, t({ id: "auth.passwordMinLength", message: "Password must be at least 6 characters long" }))
      .regex(/[A-Z]/, t({ id: "auth.passwordUppercase", message: "Password must contain at least one uppercase letter" }))
      .regex(/[a-z]/, t({ id: "auth.passwordLowercase", message: "Password must contain at least one lowercase letter" }))
      .regex(
        /[!@#$%^&*(),.?":{}|<>]/,
        t({ id: "auth.passwordSpecialChar", message: "Password must contain at least one special character" })
      ),
    confirmPassword: z.string().min(6, t({ id: "auth.confirmPasswordRequired", message: "Confirm password is required" })),
    licenseKey: z
      .string()
      .min(10, t({ id: "auth.licenseKeyRequired", message: "License key is required" }))
      .max(25, t({ id: "auth.licenseKeyTooLong", message: "License key is too long" })),
    position: z.string().optional(),
    entreprise: z.string().min(1, t({ id: "auth.companyNameRequired", message: "Company name is required" })),
    localisation: z.string().min(1, t({ id: "auth.locationRequired", message: "Location is required" })),
    description: z.string().min(1, t({ id: "auth.descriptionRequired", message: "Description is required" })),
    sectorOfActivity: z
      .string()
      .min(1, t({ id: "auth.sectorRequired", message: "Sector of activity is required" }))
      .refine((val) => !isNaN(Number(val)), {
        message: t({ id: "auth.sectorInvalid", message: "Please select a valid sector" }),
      }),
    logo: z.any().refine(
      (file) => {
        if (!file || !(file instanceof File)) {
          return false;
        }
        const allowedTypes = [
          "image/png",
          "image/jpg",
          "image/jpeg",
          "image/webp",
          "image/svg+xml",
        ];
        return allowedTypes.includes(file.type);
      },
      {
        message:
          t({
            id: "auth.logoInvalid",
            message: "Company logo is required and must be a valid image (PNG, JPG, JPEG, WEBP, SVG)",
          }),
      }
    ),
    agreeToTerms: z.boolean().refine((val) => val === true, {
      message: t({ id: "auth.termsAgreement", message: "You must agree to the terms and conditions" }),
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: t({ id: "auth.passwordsMustMatch", message: "Passwords must match" }),
    path: ["confirmPassword"],
  });
