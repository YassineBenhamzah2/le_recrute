import z from "zod";
import { InterviewStatusList, InterviewTypeList } from "../types/subtype/main";

// Define the schema for an interview
export const CreateInterviewSchema = z.object({
    candidatId: z.number().min(1, "Candidat ID must be a positive number"),
    recruiterId: z.number().min(1, "Recruiter ID must be a positive number"),
    scheduledAt: z.string().datetime({ message: "Scheduled date must be a valid date-time string" }),
    type: z.enum(InterviewTypeList, {
        message: "Type must be one of: PHONE, VIDEO, IN_PERSON, TECHNICAL, HR"
    }),
    address: z.string().min(1, "Address is required"),
    description: z.string().optional(),
    statusInterview: z.enum(InterviewStatusList, {
        message: "Status must be one of: SCHEDULED, COMPLETED, CANCELED"
    })
})

export const UpdateInterviewSchema = CreateInterviewSchema.extend({
    id: z.number().min(1, "Interview ID must be a positive number"),
}).partial().required({
    id: true,
});
