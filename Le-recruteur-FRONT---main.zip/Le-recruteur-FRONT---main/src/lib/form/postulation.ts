import z from "zod";
import { StatusApplicationList } from "../types/subtype/main";

export const CreateApplicationSchema = z.object({
    jobOfferId: z.number().min(1, "Job offer ID must be a positive number"),
    cv: z.instanceof(File).refine(file => file.type === "application/pdf", {
        message: "CV must be a PDF file"
    }),
    motivationLetter: z.instanceof(File).refine(file => file.type === "application/pdf", {
        message: "Motivation letter must be a PDF file"
    }),
    other: z.instanceof(File).optional().refine(file => file && file.type === "application/pdf", {
        message: "Other document must be a PDF file"
    }),
})

export const UpdateApplicationStatusSchema = z.object({
    id: z.number().min(1, "Application ID must be a positive number"),
    statusApplication: z.enum(StatusApplicationList, {
        message: "Status must be one of: EN_ATTENTE, ACCEPTED, REJECTED"
    }),
})