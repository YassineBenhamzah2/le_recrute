import z from "zod";
import { ContractTypeList, JobTypeList } from "../types/subtype/main";

export const CreateJobOfferSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  departmentId: z.number().min(1, "Department is required"),
  location: z.string().min(1, "Location is required"),
  jobType: z.enum(JobTypeList, {
    message:
      "Job type must be one of: FULL_TIME, PART_TIME, CONTRACT, INTERNSHIP, FREELANCE",
  }),
  contract: z.enum(ContractTypeList, {
    message:
      "Contract type must be one of: CDI, CDD, CONTRACT_PROJECT, CONTRACT_ANAPEC",
  }),
  jobDeadline: z.string().min(1, "Application deadline is required"),
  currency: z.string().min(1, "Currency is required"),
  minSalary: z.string().default(""),
  maxSalary: z.string().default(""),
  negotiable: z.boolean().default(false),
  bonus: z.string().default(""),
  requirements: z.array(z.string()).default([""]),
  questions: z.array(z.string()).default([""]),
  jobOfferSkills: z.array(z.string()).default([""]),
  jobOfferResponsibilities: z.array(z.string()).default([""]),
  tags: z.array(z.string()).default([]),
});

export const UpdateJobOfferSchema = CreateJobOfferSchema.extend({
  id: z.number().min(1, "Job offer ID must be a positive number"),
})
  .partial()
  .required({
    id: true,
  });

// Type inference from schema
export type CreateJobOfferFormData = z.infer<typeof CreateJobOfferSchema>;
export type UpdateJobOfferFormData = z.infer<typeof UpdateJobOfferSchema>;
