export const settings = {
  IMG_ADDRESS:
    import.meta.env.VITE_DEV_MODE === "true"
      ? import.meta.env.VITE_DEV_SERVER_IMAGE_ADDRESS
      : import.meta.env.VITE_PROD_SERVER_IMAGE_ADDRESS,
  API_ADDRESS:
    import.meta.env.VITE_DEV_MODE === "true"
      ? import.meta.env.VITE_DEV_SERVER_API_ADDRESS
      : import.meta.env.VITE_PROD_SERVER_API_ADDRESS,
  WS_ADDRESS:
    import.meta.env.VITE_DEV_MODE === "true"
      ? import.meta.env.VITE_DEV_SERVER_WS_ADDRESS
      : import.meta.env.VITE_PROD_SERVER_WS_ADDRESS,
  GA_ID: import.meta.env.VITE_GA_ID || null,
  DEFAULT_USER_AVATAR : "/avatars/default.png",
  DEFAULT_COMPANY_AVATAR : "/logo.jpg"
};

// Provide fallback values if environment variables are not set
export const getApiAddress = () => {
  if (settings.API_ADDRESS) {
    return settings.API_ADDRESS;
  }
  // Fallback to localhost if no environment variable is set
  return "http://localhost:8080/api";
};
if (import.meta.env.DEV) {
  console.log("Configuration chargée:", settings);
}
