/* eslint-disable @typescript-eslint/no-explicit-any */
// A simple publish-subscribe emitter for notifications.

type Listener = (notification: any) => void;

const listeners: Listener[] = [];

export const notificationEmitter = {
  subscribe: (listener: Listener) => {
    listeners.push(listener);
    return () => {
      const index = listeners.indexOf(listener);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    };
  },

  emit: (notification: any) => {
    console.log('%c[Emitter] Broadcasting new notification to all listeners.', 'color: purple; font-weight: bold;', notification);
    listeners.forEach(listener => listener(notification));
  },
};