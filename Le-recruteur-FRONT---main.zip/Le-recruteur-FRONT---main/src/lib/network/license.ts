import { api } from "./utils/api";
import { ApiResponse } from "../types/base";
import {
  License,
  CreateLicenseRequest,
  UpdateLicenseRequest,
  LicenseStatistics,
} from "../types/license";

export const licenseService = {
  // Get license statistics
  getStatistics: () =>
    api.getItem<ApiResponse<LicenseStatistics>>("/licenses/statistics"),

  // Public license validation (no auth required)
  validate: (licenseKey: string) =>
    api.post<ApiResponse<{
      reason: string;
      isValid: boolean;
      message: string;
      expirationDate: string;
    }>>(
      "/licenses/validate",
      { licenseKey },
      {
        addAuthHeaders: false,
      }
    ),

  // Get license by key (public endpoint for registration)
  getByKey: (licenseKey: string) =>
    api.getItem<ApiResponse<License>>(`/licenses/key/${licenseKey}`, {
      addAuthHeaders: false,
    }),

  // Admin-only endpoints
  getAll: (params?: { page?: number; limit?: number; search?: string }) => {
    const queryParams = new URLSearchParams();
    if (params?.page) queryParams.append("page", params.page.toString());
    if (params?.limit) queryParams.append("limit", params.limit.toString());
    if (params?.search) queryParams.append("search", params.search);

    const queryString = queryParams.toString();
    const url = queryString ? `/licenses?${queryString}` : "/licenses";
    return api.getItem<ApiResponse<License[]>>(url);
  },

  getById: (id: number) => api.getItem<ApiResponse<License>>(`/licenses/${id}`),

  create: (data: CreateLicenseRequest) =>
    api.post<ApiResponse<License>>("/licenses", data),

  update: (id: number, data: UpdateLicenseRequest) =>
    api.put<ApiResponse<License>>(`/licenses/${id}`, data),

  delete: (id: number) => api.delete<ApiResponse<void>>(`/licenses/${id}`),

  getActive: () => api.getItem<ApiResponse<License[]>>("/licenses/active"),

  getByRole: (roleId: number) =>
    api.getItem<ApiResponse<License[]>>(`/licenses/role/${roleId}`),
};
