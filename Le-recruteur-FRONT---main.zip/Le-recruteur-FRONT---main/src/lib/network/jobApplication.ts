import { ApiResponse } from "../types/base";
import {
  GetJobApplicationsQuery,
  JobApplication,
  UpdateJobApplicationRequest,
} from "../types/jobApplication";
import { api } from "./utils/api";
import { buildQueryString } from "./utils/main";

export const jobApplicationService = {

  getJobApplications: (params: GetJobApplicationsQuery = {}) => {
    const queryString = buildQueryString(params);
    return api.getItem<ApiResponse<JobApplication[]>>(
      `/recruiter/job-applications${queryString}`
    );
  },

  // Get job applications for a specific job
  getJobApplicationsByJobId: (
    jobOfferId: number,
    params: Omit<GetJobApplicationsQuery, "jobOfferId"> = {}
  ) => {
    const queryParams = { ...params, jobOfferId };
    const queryString = buildQueryString(queryParams);
    return api.getItem<ApiResponse<JobApplication[]>>(
      `/recruiter/job-applications${queryString}`
    );
  },

  // Get a single job application by ID
  getJobApplicationById: (applicationId: number) =>
    api.getItem<ApiResponse<JobApplication>>(
      `/recruiter/job-applications/${applicationId}`
    ),

  // Update job application status
  updateJobApplication: (
    applicationId: number,
    data: UpdateJobApplicationRequest
  ) =>
    api.put<ApiResponse<JobApplication>>(
      `/recruiter/job-applications/${applicationId}`,
      data
    ),

  // Assign test to job applicants
  assignTestToCandidates: (
    jobOfferId: number,
    data: { candidateIds: number[]; testId: string; dueDate: string }
  ) =>
    api.post<ApiResponse<{ success: boolean; message: string }>>(
      `/recruiter/jobs/${jobOfferId}/candidates/assign-test`,
      data
    ),

  // Get job applications for a specific test
  getJobApplicationsByTestId: (
    testId: string,
    params: Omit<GetJobApplicationsQuery, "testId"> = {}
  ) => {
    const queryParams = { ...params, testId };
    const queryString = buildQueryString(queryParams);
    // Response includes metadata.pagination for pagination information
    return api.getItem<ApiResponse<JobApplication[]>>(
      `/recruiter/job-applications${queryString}`
    );
  },

  // Get job applications stats for a specific job
  getJobApplicationsStats: (jobOfferId: number) =>
    api.getItem<
      ApiResponse<{
        totalApplications: number;
        newApplications: number;
        shortlisted: number;
        interviewed: number;
        testAssigned: number;
        testCompleted: number;
        rejected: number;
      }>
    >(`/recruiter/jobs/${jobOfferId}/applications/stats`),
};
