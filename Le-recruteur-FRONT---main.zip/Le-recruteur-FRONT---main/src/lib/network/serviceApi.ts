import {
  AdminServiceCmsResponse,
  PaginatedCmsServices,
} from "@/lib/types/service";
import { api } from "./utils/api";

export const serviceCmsApi = {
  getCmsServices: async (
    page = 0,
    size = 10
  ): Promise<PaginatedCmsServices> => {
    return api.getItem(`/admin/cms?page=${page}&size=${size}`, {
      addAuthHeaders: false,
    });
  },

  addServiceToCms: async (
    serviceId: number,
    displayOrder: number
  ): Promise<void> => {
    await api.post(
      `/admin/cms?serviceId=${serviceId}&displayOrder=${displayOrder}`
    );
  },

  updateDisplayOrder: async (
    cmsId: number,
    displayOrder: number
  ): Promise<void> => {
    await api.put(`/admin/cms/${cmsId}?displayOrder=${displayOrder}`);
  },

  deleteCmsService: async (cmsId: number): Promise<void> => {
    await api.delete(`/admin/cms/${cmsId}`);
  },

  getAllServices: async (): Promise<AdminServiceCmsResponse[]> => {
    return api.getItem(`/admin/cms/all-services`, {
      addAuthHeaders: false,
    });
  },
};
