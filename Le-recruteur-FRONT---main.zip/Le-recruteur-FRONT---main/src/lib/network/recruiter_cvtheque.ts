import {
  Candidate,
  FilterOptions,
  Filters,
  PaginatedResponse,
} from "@/lib/types/recruiter";
import { api } from "./utils/api";
import { buildQueryString } from "./utils/main";

// We need a specific type for the API parameters
type CandidateApiParams = Omit<Filters, "page" | "size"> & {
  page: number;
  size: number;
};

export const cvthequeService = {
  /**
   * Fetches the dynamic options for the filter dropdowns.
   * This can reuse the same endpoint as the admin panel.
   */
  getFilterOptions: () => {
    return api.getItem<FilterOptions>("/filters_CvTc/options");
  },

  /**
   * Fetches the recruiter's own candidates with server-side filtering and pagination.
   */
  getCandidates: (params: CandidateApiParams) => {
    const adjustedParams = {
      ...params,
      page: params.page > 0 ? params.page - 1 : 0,
    };
    const queryString = buildQueryString(adjustedParams);
    return api.getItem<PaginatedResponse<Candidate>>(
      `/recruiter/cvtheque/candidates${queryString}`
    );
  },

  /**
   * Downloads the CV file for a specific candidate.
   */
  downloadCv: (candidateId: number) => {
    return api.download(`/recruiter/cv/${candidateId}`);
  },
};
