import { ApiResponse, GetCompanysQuery } from "@/lib/types/base";
import { api } from "./utils/api";
import { buildQueryString } from "./utils/main";
import { Company, CompanyDetails } from "@/lib/types/company";

export const companyService = {
  getCompanies: (params: GetCompanysQuery = {}) => {
    const queryString = buildQueryString(params);
    return api.getItem<ApiResponse<Company[]>>(`/companies${queryString}`, {
      addAuthHeaders: false,
    });
  },
  getCompanyById: (id: number) =>
    api.getItem<ApiResponse<CompanyDetails>>(`/companies/${id}`, {
      addAuthHeaders: false,
    }),
  bookmarkCompany: (id: number) =>
    api.post<ApiResponse<void>>(`/companies/${id}/bookmark`),
  bookmarkJob: (id: number) =>
    api.post<ApiResponse<void>>(`/companies/jobs/${id}/bookmark`),
};
