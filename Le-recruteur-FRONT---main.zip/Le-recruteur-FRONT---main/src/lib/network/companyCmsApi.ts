import { Company, PaginatedCmsCompanies } from "@/lib/types/company";
import { api } from "./utils/api";

export const companyCmsApi = {
  getCmsCompanies: (page = 0, size = 10): Promise<PaginatedCmsCompanies> =>
    api.getItem(`/admin/company-cms?page=${page}&size=${size}`, {
      addAuthHeaders: false,
    }),

  addCompanyToCms: (
    companyId: number,
    displayOrder: number,
    destinationLink: string
  ) =>
    api.post(
      `/admin/company-cms?companyId=${companyId}&displayOrder=${displayOrder}&destinationLink=${destinationLink}`
    ),

  updateDisplayOrder: (
    cmsId: number,
    displayOrder: number,
    destinationLink?: string
  ) =>
    api.put(
      `/admin/company-cms/${cmsId}?displayOrder=${displayOrder}&destinationLink=${
        destinationLink || ""
      }`
    ),

  deleteCmsCompany: (cmsId: number) =>
    api.delete(`/admin/company-cms/${cmsId}`),

  getAllCompanies: (): Promise<Company[]> =>
    api.getItem(`/admin/company-cms/all-companies`, {
      addAuthHeaders: false,
    }),
};
