import { ApiResponse } from "../types/base";
import {
  AssignTestRequest,
  AssignTestResponse,
  CreateTestRequest,
  GetTestsQuery,
  Test,
  TestAnalytics,
  TestAssignment,
  TestSpecificAnalytics,
  TestTopPerformer,
  UpdateTestRequest,
} from "../types/test";
import { api } from "./utils/api";
import { buildQueryString } from "./utils/main";

export const testService = {
  // Get all tests with pagination, filtering and search
  getTests: (params: GetTestsQuery = {}) => {
    const queryString = buildQueryString(params);
    // The response will include metadata.pagination with PaginationMetadata
    return api.getItem<ApiResponse<Test[]>>(`/recruiter/tests${queryString}`);
  },

  // Get a single test by ID
  getTestById: (testId: string) =>
    api.getItem<ApiResponse<Test>>(`/recruiter/tests/${testId}`),

  // Get top performers for a specific test
  getTestTopPerformers: (testId: string, limit: number = 5) =>
    api.getItem<ApiResponse<TestTopPerformer[]>>(
      `/recruiter/tests/${testId}/top-performers?limit=${limit}`
    ),

  // Get analytics for a specific test
  getTestSpecificAnalytics: (testId: string) =>
    api.getItem<ApiResponse<TestSpecificAnalytics>>(
      `/recruiter/tests/${testId}/analytics`
    ),

  // Get test assignments for this specific test
  getTestAssignedCandidates: (testId: string) =>
    api.getItem<ApiResponse<TestAssignment[]>>(
      `/recruiter/tests/${testId}/assigned-candidates`
    ),

  // Create a new test
  createTest: (data: CreateTestRequest) =>
    api.post<ApiResponse<Test>>("/recruiter/tests", data),

  // Update an existing test
  updateTest: (testId: string, data: UpdateTestRequest) =>
    api.put<ApiResponse<Test>>(`/recruiter/tests/${testId}`, data),

  // Delete a test
  deleteTest: (testId: string) =>
    api.delete<ApiResponse<boolean>>(`/recruiter/tests/${testId}`),

  // Get test statistics for analytics
  getTestAnalytics: () =>
    api.getItem<ApiResponse<TestAnalytics>>("/recruiter/tests/analytics"),

  // Get all test assignments with pagination
  getTestAssignments: (
    params: {
      testId?: string;
      jobOfferId?: number;
      page?: number;
      limit?: number;
    } = {}
  ) => {
    const queryString = buildQueryString(params);
    return api.getItem<ApiResponse<TestAssignment>>(
      `/recruiter/test-assignments${queryString}`
    );
  },

  // Assign a test to candidates
  assignTest: (data: AssignTestRequest) =>
    api.post<ApiResponse<AssignTestResponse>>(
      "/recruiter/test-assignments",
      data
    ),

  // Get test assignment by ID
  getTestAssignment: (assignmentId: string) =>
    api.getItem<ApiResponse<TestAssignment>>(
      `/recruiter/test-assignments/${assignmentId}`
    ),

  // Delete a test assignment
  deleteTestAssignment: (assignmentId: string) =>
    api.delete<ApiResponse<boolean>>(
      `/recruiter/test-assignments/${assignmentId}`
    ),
};
