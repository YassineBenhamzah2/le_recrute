import { api } from "./utils/api";
import { buildQueryString } from "./utils/main";
import { DashboardStats, Candidate, Recruiter, RecruiterFilters, User, PaginatedResponse, CandidateFilters, UpdateRecruiterRequest, FilterOptionsResponse } from "../types/cvtheque";

export const cvthequeService = {

    /**
     * Fetches the dashboard statistics from the backend.
     */
    getDashboardStats: () => {
        return api.getItem<DashboardStats>('/admin/cvtheque/stats');
    },

    /**
     * Fetches a paginated list of recruiters from the backend.
     * @param params - The filter and pagination options.
     */
    getRecruiters: (params: RecruiterFilters) => {
        const adjustedParams = { ...params, page: params.page > 0 ? params.page - 1 : 0 };
        const queryString = buildQueryString(adjustedParams);
        return api.getItem<PaginatedResponse<Recruiter>>(`/admin/cvtheque/recruiters${queryString}`);
    },

    /**
     * Finds recruiters who do not yet have a CVthèque.
     * Used to populate the "Add to CVthèque" dropdown.
     * @param search - The search term for the recruiter's name or email.
     */
    findRecruitersWithoutCvTc: (search: string) => {
        const queryString = buildQueryString({ search });
        return api.getItem<User[]>(`/admin/cvtheque/recruiters-without-cvtc${queryString}`);
    },

    /**
     * Sends a request to create a new CVthèque for an existing recruiter.
     * @param recruiterId - The ID of the recruiter to enroll.
     */
    createCvThequeForRecruiter: (recruiterId: number) => {
        return api.post<void>('/admin/cvtheque/cvtc', { recruiterId });
    },

    /**
     * Fetches the list of candidates ALREADY ASSIGNED to a specific recruiter.
     * @param params - Contains recruiterId, page, and size.
     */
    getAssignedCandidates: (params: CandidateFilters) => {
        const { recruiterId, ...restOfParams } = params;
        
        const queryParams = {
            ...restOfParams,
            page: params.page > 0 ? params.page - 1 : 0,
        };
        const queryString = buildQueryString(queryParams);
        
        return api.getItem<PaginatedResponse<Candidate>>(`/admin/cvtheque/recruiters/${recruiterId}/candidates${queryString}`);
    },

    /**
     * Fetches the list of candidates AVAILABLE to be assigned to a specific recruiter.
     * @param params - Contains recruiterId, page, and size, plus any advanced filters.
     */
    getAvailableCandidates: (params: CandidateFilters) => {
        const { recruiterId, ...restOfParams } = params;
        const queryParams = {
            ...restOfParams,
            page: params.page > 0 ? params.page - 1 : 0,
        };

        const queryString = buildQueryString(queryParams);
        return api.getItem<PaginatedResponse<Candidate>>(`/admin/cvtheque/recruiters/${recruiterId}/available-candidates${queryString}`);
    },

    /**
     * Sends a request to assign a list of candidates to a recruiter's CVthèque.
     * @param recruiterId - The ID of the recruiter receiving the candidates.
     * @param candidateIds - An array of candidate IDs to be assigned.
     */
    assignCandidatesToRecruiter: (recruiterId: number, candidateIds: number[]) => {
        return api.post<void>(`/admin/cvtheque/recruiters/${recruiterId}/candidates`, { candidateIds });
    },

    /**
     * Sends a request to remove a list of candidates from a recruiter's CVthèque.
     * @param recruiterId - The ID of the recruiter.
     * @param candidateIds - An array of candidate IDs to be removed.
     */
    removeCandidatesFromRecruiter: (recruiterId: number, candidateIds: number[]) => {
        return api.delete<void>(
            `/admin/cvtheque/recruiters/${recruiterId}/candidates`,
            { candidateIds }
        );
    },

    /**
     * Sends a request to remove a recruiter from the CVthèque system.
     * @param recruiterId - The ID of the recruiter to remove.
     */
    removeRecruiterFromCvTheque: (recruiterId: number) => {
        return api.delete<void>(`/admin/cvtheque/recruiters/${recruiterId}`);
    },
    /**
     * Fetches all the dynamic options for the filter dropdowns.
     */
    getFilterOptions: () => {
        return api.getItem<FilterOptionsResponse>('/filters_CvTc/options');
    },
};