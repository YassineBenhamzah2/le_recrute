import { buildQueryString } from "./utils/main";
import { api } from "./utils/api";
import {
  AnalyticsDashboardData,
  AnalyticsQuery,
  GAMetrics,
  WebInteractionData,
  GAPagePathData,
  GAEventDistribution,
} from "../types/analytics";
import { ApiResponse } from "../types/base";

const ANALYTICS_ENDPOINT = "/analytics";

/**
 * Fetches the complete dashboard data for admin analytics
 * @param query Optional query parameters for filtering
 * @returns AnalyticsDashboardData object
 */
export const getDashboardAnalytics = async (
  query?: AnalyticsQuery
): Promise<ApiResponse<AnalyticsDashboardData>> => {
  const queryString = query ? buildQueryString(query) : "";
  return await api.getItem<ApiResponse<AnalyticsDashboardData>>(
    `${ANALYTICS_ENDPOINT}/dashboard${queryString}`
  );
};

/**
 * Fetches Google Analytics data
 * @param query Optional query parameters for filtering
 * @returns GAMetrics object
 */
export const getGoogleAnalyticsData = async (
  query?: AnalyticsQuery
): Promise<ApiResponse<GAMetrics>> => {
  const queryString = query ? buildQueryString(query) : "";
  return await api.getItem<ApiResponse<GAMetrics>>(
    `${ANALYTICS_ENDPOINT}/google-analytics${queryString}`
  );
};

/**
 * Fetches user distribution data
 * @param query Optional query parameters for filtering
 * @returns User distribution data
 */
export const getUserDistribution = async (
  query?: AnalyticsQuery
): Promise<ApiResponse<{ userDistribution: AnalyticsDashboardData["userDistribution"] }>> => {
  const queryString = query ? buildQueryString(query) : "";
  return await api.getItem<
    ApiResponse<{ userDistribution: AnalyticsDashboardData["userDistribution"] }>
  >(`${ANALYTICS_ENDPOINT}/user-distribution${queryString}`);
};

/**
 * Fetches internal activity data
 * @param query Optional query parameters for filtering
 * @returns Internal activity data
 */
export const getInternalActivity = async (
  query?: AnalyticsQuery
): Promise<ApiResponse<AnalyticsDashboardData["internalActivity"]>> => {
  const queryString = query ? buildQueryString(query) : "";
  return await api.getItem<
    ApiResponse<AnalyticsDashboardData["internalActivity"]>
  >(`${ANALYTICS_ENDPOINT}/internal-activity${queryString}`);
};

/**
 * Fetches platform engagement metrics
 * @param query Optional query parameters for filtering
 * @returns Platform engagement metrics
 */
export const getPlatformEngagement = async (
  query?: AnalyticsQuery
): Promise<ApiResponse<AnalyticsDashboardData["platformEngagement"]>> => {
  const queryString = query ? buildQueryString(query) : "";
  return await api.getItem<
    ApiResponse<AnalyticsDashboardData["platformEngagement"]>
  >(`${ANALYTICS_ENDPOINT}/platform-engagement${queryString}`);
};

/**
 * Fetches recruitment activity data
 * @param query Optional query parameters for filtering
 * @returns Recruitment activity data
 */
export const getRecruitmentActivity = async (
  query?: AnalyticsQuery
): Promise<
  ApiResponse<{
    recruitmentActivity: AnalyticsDashboardData["recruitmentActivity"];
  }>
> => {
  const queryString = query ? buildQueryString(query) : "";
  return await api.getItem<
    ApiResponse<{
      recruitmentActivity: AnalyticsDashboardData["recruitmentActivity"];
    }>
  >(`${ANALYTICS_ENDPOINT}/recruitment-activity${queryString}`);
};

/**
 * Fetches web interaction tracking data
 * @param query Optional query parameters for filtering
 * @returns Web interaction data
 */
export const getWebInteractions = async (
  query?: AnalyticsQuery
): Promise<ApiResponse<WebInteractionData>> => {
  const queryString = query ? buildQueryString(query) : "";
  return await api.getItem<ApiResponse<WebInteractionData>>(
    `${ANALYTICS_ENDPOINT}/web-interactions${queryString}`
  );
};

/**
 * Exports analytics data to CSV format
 * @param query Optional query parameters for filtering by date range
 * @returns Blob containing CSV data
 */
export const exportAnalyticsToCSV = async (
  query?: AnalyticsQuery
): Promise<Blob> => {
  const queryString = query ? buildQueryString(query) : "";
  return await api.download(`${ANALYTICS_ENDPOINT}/export/csv${queryString}`);
};

/**
 * Fetches Google Analytics page path data
 * @param query Optional query parameters for filtering
 * @returns Page path and screen class data with usage metrics
 */
export const getGAPagePathData = async (
  query?: AnalyticsQuery
): Promise<ApiResponse<GAPagePathData[]>> => {
  const queryString = query ? buildQueryString(query) : "";
  return await api.getItem<ApiResponse<GAPagePathData[]>>(
    `${ANALYTICS_ENDPOINT}/ga-page-paths${queryString}`
  );
};

/**
 * Fetches Google Analytics event distribution data
 * @param query Optional query parameters for filtering
 * @returns Event name and count distribution
 */
export const getGAEventDistribution = async (
  query?: AnalyticsQuery
): Promise<ApiResponse<GAEventDistribution[]>> => {
  const queryString = query ? buildQueryString(query) : "";
  return await api.getItem<ApiResponse<GAEventDistribution[]>>(
    `${ANALYTICS_ENDPOINT}/ga-events${queryString}`
  );
};

/**
 * Clears the analytics cache on the server
 * @returns Success or error response
 */
export const clearAnalyticsCache = async (): Promise<
  ApiResponse<{ success: boolean }>
> => {
  return await api.post<ApiResponse<{ success: boolean }>>(
    `${ANALYTICS_ENDPOINT}/clear-cache`
  );
};
