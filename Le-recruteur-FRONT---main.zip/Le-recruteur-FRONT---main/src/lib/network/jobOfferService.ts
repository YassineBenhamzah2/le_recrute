// src/services/adminJobOfferService.ts
import { ApiResponse } from "@/lib/types/base";
import { api } from "@/lib/network/utils/api";
import { AdminJobResponse } from "@/lib/types/jobOffer";

export interface PagedResponse<T> {
  content: T[];
  totalPages: number;
  totalElements: number;
  number: number; // page courante
  size: number;
}

export const adminService = {
  // 🔹 Récupérer tous les jobs avec pagination et filtres
  getAllJobs: (
    page: number = 0,
    size: number = 10,
    title?: string,
    sector?: string,
    jobType?: string,
    status?: string,
    location?: string
  ) => {
    // Construire query string avec les filtres
    const params = new URLSearchParams({
      page: page.toString(),
      size: size.toString(),
    });

    if (title) params.append("title", title);
    if (sector) params.append("sector", sector);
    if (jobType) params.append("jobType", jobType);
    if (status) params.append("status", status);
    if (location) params.append("location", location);

    return api.getItem<ApiResponse<PagedResponse<AdminJobResponse>>>(
      `/admin/jobs?${params.toString()}`
    );
  },

  // 🔹 Supprimer un job par ID
  deleteJob: (id: number) => {
    return api.delete<ApiResponse<void>>(`/admin/jobs/${id}`);
  },
};
