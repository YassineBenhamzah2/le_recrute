import { ApiResponse, GetRecruiterInterviewsQuery } from "../types/base";
import { CreateInterviewRequest, Interview, UpdateInterviewStatusRequest, CandidateInterviewsParams, CandidateInterviewsStats } from "../types/interview";
import { api } from "./utils/api";
import { buildQueryString } from "./utils/main";



export const interviewService = {
    // Get Recruiter Interviews Filtered
    getRecruiterInterviews: (params: GetRecruiterInterviewsQuery = {}) => {
        const queryString = buildQueryString(params);
        return api.getItem<ApiResponse<Interview[]>>(`/recruiter/interviews${queryString}`);
    },

    // Create Recruiter New Interview
    createInterview: (data: CreateInterviewRequest) =>
        api.post<ApiResponse<Interview>>("/recruiter/interviews", data),

    // Edit Recruiter Interview
    updateInterview: (interviewId: number, data: CreateInterviewRequest) =>
        api.put<ApiResponse<Interview>>(`/recruiter/interviews/${interviewId}`, data),

    // Update Interview Status
    updateInterviewStatus: (interviewId: number, data: UpdateInterviewStatusRequest) =>
        api.patch<ApiResponse<Interview>>(`/recruiter/interviews/${interviewId}/status`, data),

    // Delete Interview
    deleteInterview: (interviewId: number) =>
        api.delete<ApiResponse<boolean>>(`/recruiter/interviews/${interviewId}`),

    // Get Candidate Interviews
    getCandidateInterviews: (query: CandidateInterviewsParams = {}): Promise<ApiResponse<Interview[]>> => {
    const qs = buildQueryString(query as Record<string, unknown>);
    return api.getItem<ApiResponse<Interview[]>>(`/candidate/interviews${qs}`, { addAuthHeaders: true });
  },

    // Get Candidate stats Interviews
    getCandidateInterviewsStats: (): Promise<ApiResponse<CandidateInterviewsStats>> => {
    return api.getItem<ApiResponse<CandidateInterviewsStats>>("/candidate/interviews/stats", { addAuthHeaders: true});
  },
}