import { ApiResponse } from "../types/base";
import { Department } from "../types/department";
import { api } from "./utils/api";

export const departmentService = {
  getDepartments: () =>
    api.getItem<ApiResponse<Department[]>>("/departments"),
};
