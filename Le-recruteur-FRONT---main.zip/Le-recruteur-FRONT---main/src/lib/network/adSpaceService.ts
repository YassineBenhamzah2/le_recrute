import { ApiResponse } from "../types/base";
import { api } from "./utils/api";
import { AdSpace } from "@/lib/types/adSpace";

export const adSpaceService = {
  getAdSpaces: async (): Promise<AdSpace[]> => {
    const response = await api.getItem<{ data: AdSpace[] }>("/admin/adspaces", {
      addAuthHeaders: false,
    });
    return response.data || [];
  },

  createAdSpace: async (formData: FormData): Promise<AdSpace> => {
    const response = await api.post<ApiResponse<AdSpace>>(
      "/admin/adspaces",
      formData
    );
    return response.data;
  },

  updateAdSpace: async (id: number, formData: FormData): Promise<AdSpace> => {
    const response = await api.put<ApiResponse<AdSpace>>(
      `/admin/adspaces/${id}`,
      formData
    );
    return response.data;
  },

  deleteAdSpace: async (id: number): Promise<void> => {
    await api.delete<ApiResponse<void>>(`/admin/adspaces/${id}`);
  },
};
