import { ApiResponse, GetInterviewsQuery } from "@/lib/types/base";
import {
  DashboardInterview,
  DashboardJobOfferApplication,
  DashboardStatistics,
  InterviewStatistics,
  JobStatistics,
} from "@/lib/types/dashboard/recruiter";
import { DashboardFilter } from "@/lib/types/subtype/main";
import { api } from "../utils/api";
import { buildQueryString } from "../utils/main";

export const recruiterDashboardService = {
  getDashboardStatistics: (filter: DashboardFilter = "all") =>
    api.getItem<ApiResponse<DashboardStatistics>>(
      `/dashboard/recruiter/statistics?filter=${filter}`
    ),
  // Get Recruiter Dashboard Job Offer Application
  getJobOfferApplication: () =>
    api.getItem<ApiResponse<DashboardJobOfferApplication[]>>(
      "/dashboard/recruiter/applications"
    ),
  getDashboardInterviews: (params: GetInterviewsQuery) => {
    const queryString = buildQueryString(params);
    return api.getItem<ApiResponse<DashboardInterview[]>>(
      `/dashboard/recruiter/interviews${queryString}`
    );
  },
  getJobStatistics: () =>
    api.getItem<ApiResponse<JobStatistics>>(
      "/dashboard/recruiter/jobs/statistics"
    ),
  // Get Recruiter Interview Statistics
  getInterviewStatistics: () => {
    return api.getItem<ApiResponse<InterviewStatistics>>(
      `/dashboard/recruiter/interviews/statistics`
    );
  },
};
