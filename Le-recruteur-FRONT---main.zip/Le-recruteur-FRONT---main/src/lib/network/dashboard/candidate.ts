import { api } from "../utils/api";
import { CandidateDashboardResponse, CandidatesResponse, statisticsCandidat } from '../../types/dashboard/candidate';

export const candidateDashboardService = {
  getDashboardData: async (candidateId: number): Promise<CandidateDashboardResponse> => {
    return api.getItem<CandidateDashboardResponse>(`/candidate/dashboard/${candidateId}`);
  },
  
  AllCandidates: async (page: number = 0, size: number = 10): Promise<CandidatesResponse> => {
    return api.getItem<CandidatesResponse>(`/admin/candidates?page=${page}&size=${size}`);
  },

  // Rechercher des candidats par mot-clé avec pagination
  searchCandidates: async (keyword: string, page: number = 0, size: number = 10): Promise<CandidatesResponse> => {
    return api.getItem<CandidatesResponse>(`/admin/candidates/search?keyword=${encodeURIComponent(keyword)}&page=${page}&size=${size}`);
  },

  getCandidateStatistics: async(): Promise<statisticsCandidat>=>{
    return api.getItem<statisticsCandidat>(`/admin/candidates/statistics`);
  },
  
  activateCandidate: async (id: number) => {
  return api.put(`/admin/candidates/${id}/approve`);
  },
  suspendCandidate: async (id: number) => {
    return api.put(`/admin/candidates/${id}/reject`);
  },
};