import { api } from "../utils/api";
import { DashboardDTO } from "../../types/dashboard/adminDashboard";

export const dashboardAdminService = {
  /**
   * Fetches admin dashboard statistics
   * @returns Dashboard statistics data
   */
  getStats: async (): Promise<DashboardDTO> => {
    return await api.getItem<DashboardDTO>("/dashboard_admin/stats");
  },
};
