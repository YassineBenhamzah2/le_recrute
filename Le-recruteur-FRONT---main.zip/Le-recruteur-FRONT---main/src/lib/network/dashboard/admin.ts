import {
    ApiResponse,
    GetBlogsQuery
} from "@/lib/types/base";
import { admin, admins } from "@/lib/types/dashboard/admin";
import { Role } from "@/lib/types/license";
import { api } from "../utils/api";
import { buildQueryString } from "../utils/main";

export const adminService = {
  getAllAdmins: async (page: number = 0, size: number = 10) => {
    return api.getItem<ApiResponse<admins[]>>( // Added array type and fixed URL
      `/admins?page=${page}&size=${size}` // Added missing = after 'page'
    );
  },
  getAdminRoles: async () => {
    return api.getItem<ApiResponse<Role[]>>(`/admins/AdminRoles`);
  },
  createAdmin: async (formData: FormData) => {
    return api.post<ApiResponse<admin>>(`/admins`, formData);
  },

  updateAdmin: async (id: number, formData: FormData) => {
    return api.put<ApiResponse<admin>>(`/admins/${id}`, formData);
  },
  deleteAdmin: async (id: number) => {
    // Fixed parameter name
    return api.delete<ApiResponse<admin>>(`/admins/${id}`);
  },

  searchAdmins: async (keyword: string, params: GetBlogsQuery = {}) => {
    const queryString = buildQueryString({ ...params, keyword });
    return api.getItem<ApiResponse<admins[]>>(`/admins/search${queryString}`);
  },
};
