import { api } from "./utils/api";
import { ApiResponse } from "../types/base";
import { Role, Permission, AssignPermissionsRequest } from "../types/license";

// Role creation request interface
export interface RoleCreateRequest {
  name: string;
  description?: string;
  roleType: "ADMIN" | "RECRUITER" | "CANDIDATE";
}

// Role update request interface
export interface RoleUpdateRequest {
  name?: string;
  description?: string;
}

export const roleService = {
  // Get all roles with their permissions
  getAll: () => api.getItem<ApiResponse<Role[]>>("/roles"),

  // Get specific role with permissions
  getById: (id: number) => api.getItem<ApiResponse<Role>>(`/roles/${id}`),

  // Create new role
  create: (data: RoleCreateRequest) =>
    api.post<ApiResponse<Role>>("/roles", data),

  // Update role
  updateRole: (id: number, data: RoleUpdateRequest) =>
    api.put<ApiResponse<Role>>(`/roles/${id}`, data),

  // Delete role
  deleteRole: (id: number) => api.delete<ApiResponse<null>>(`/roles/${id}`),

  // Assign permissions to role
  assignPermissions: (data: AssignPermissionsRequest) =>
    api.post<ApiResponse<Role>>("/roles/assign-permissions", data),

  // Remove permission from role
  removePermission: (roleId: number, permissionId: number) =>
    api.delete<ApiResponse<Role>>(
      `/roles/${roleId}/permissions/${permissionId}`
    ),

  // Get available permissions for role (not yet assigned) - filtered by role type
  getAvailablePermissions: (roleId: number) =>
    api.getItem<ApiResponse<Permission[]>>(
      `/roles/${roleId}/available-permissions`
    ),

  // Get permissions by role type
  getPermissionsByRoleType: (roleType: string) =>
    api.getItem<ApiResponse<Permission[]>>(
      `/roles/permissions/type/${roleType}`
    ),

  // Get role permissions by role ID
  getRolePermissions: (roleId: number) =>
    api.getItem<ApiResponse<{ role: Role; permissions: Permission[] }>>(
      `/roles/${roleId}/permissions`
    ),
};

export const permissionService = {
  // Get all permissions
  getAll: () => api.getItem<ApiResponse<Permission[]>>("/api/permissions"),

  // Get permission by ID
  getById: (id: number) =>
    api.getItem<ApiResponse<Permission>>(`/api/permissions/${id}`),

  // Get permissions by type
  getByType: (type: string) =>
    api.getItem<ApiResponse<Permission[]>>(`/api/permissions/type/${type}`),

  // Search permissions
  search: (name: string) =>
    api.getItem<ApiResponse<Permission[]>>(
      `/api/permissions/search?name=${encodeURIComponent(name)}`
    ),
};
