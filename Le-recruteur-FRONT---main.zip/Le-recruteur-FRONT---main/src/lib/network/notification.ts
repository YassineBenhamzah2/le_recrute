// Path: src/lib/network/notificationService.ts

import { ApiResponse } from "../types/base";
import { api } from "./utils/api";
import { Notification, UnreadCountResponse } from "../types/notification";
export const notificationService = {
  // --- Recruiter Endpoints ---
  getRecruiterNotifications: (): Promise<ApiResponse<Notification[]>> => {
    return api.getItem<ApiResponse<Notification[]>>("/recruiter/notifications");
  },

  getRecruiterUnreadCount: (): Promise<ApiResponse<UnreadCountResponse>> => {
    return api.getItem<ApiResponse<UnreadCountResponse>>("/recruiter/notifications/unread-count");
  },

  markRecruiterAsRead: (): Promise<ApiResponse<string>> => {
    return api.post<ApiResponse<string>>("/recruiter/notifications/mark-as-read");
  },

  // --- Candidate Endpoints ---
  getCandidateNotifications: (): Promise<ApiResponse<Notification[]>> => {
    return api.getItem<ApiResponse<Notification[]>>("/candidate/notifications");
  },

  getCandidateUnreadCount: (): Promise<ApiResponse<UnreadCountResponse>> => {
    return api.getItem<ApiResponse<UnreadCountResponse>>("/candidate/notifications/unread-count");
  },

  markCandidateAsRead: (): Promise<ApiResponse<string>> => {
    return api.post<ApiResponse<string>>("/candidate/notifications/mark-as-read");
  },
};