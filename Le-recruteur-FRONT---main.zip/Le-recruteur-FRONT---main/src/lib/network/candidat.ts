import { ApiResponse, GetJobCandidatesQuery } from "../types/base";
import { Candidate } from "../types/candidat";
import {
  CandidateScoreRequest,
  CandidateScoreResponse,
} from "../types/interview";
import { api } from "./utils/api";
import { buildQueryString } from "./utils/main";

export const candidatService = {
  getJobCandidates: (params: GetJobCandidatesQuery) => {
    const queryString = buildQueryString({ page: params.page });
    return api.getItem<ApiResponse<Candidate[]>>(
      `/recruiter/jobs/${params.jobOfferId}/candidates${queryString}`
    );
  },
  // Accept Candidate
  acceptCandidate: (jobOfferId: number, candidateId: number) =>
    api.post<ApiResponse<Candidate>>(
      `/recruiter/jobs/${jobOfferId}/candidates/${candidateId}/accept`
    ),

  // Reject Candidate
  rejectCandidate: (jobOfferId: number, candidateId: number) =>
    api.post<ApiResponse<Candidate>>(
      `/recruiter/jobs/${jobOfferId}/candidates/${candidateId}/reject`
    ),

  // Update Candidate Score
  updateCandidateScore: (
    candidateId: number,
    jobOfferId: number,
    data: CandidateScoreRequest
  ) =>
    api.put<ApiResponse<CandidateScoreResponse>>(
      `/recruiter/jobs/${jobOfferId}/candidates/${candidateId}/score`,
      data
    ),

  // Get Candidate Score
  getCandidateScore: (candidateId: number, jobOfferId: number) =>
    api.getItem<ApiResponse<CandidateScoreResponse>>(
      `/recruiter/jobs/${jobOfferId}/candidates/${candidateId}/score`
    ),

  downloadCV: async (candidateId: number, jobOfferId: number): Promise<Blob> =>
    api.download(
      `/recruiter/candidates/${candidateId}/jobOffers/${jobOfferId}/cv/download`
    ),
  // Download Candidate Motivation Letter
  downloadMotivationLetter: async (
    candidateId: number,
    jobOfferId: number
  ): Promise<Blob> =>
    api.download(
      `/recruiter/candidates/${candidateId}/jobOffers/${jobOfferId}/motivation-letter/download`
    ),
};
