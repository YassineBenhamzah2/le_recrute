import { ApiResponse, GetServicesQuesry } from "@/lib/types/base";
import { api } from "../utils/api";
import { buildQueryString } from "../utils/main";
import { Service } from "@/lib/types/service";

export const ServiceCandidat = {
  getAllService: (params: GetServicesQuesry = {}) => {
    const queryString = buildQueryString(params);
    return api.getItem<ApiResponse<Service[]>>(
      `/candidate-services${queryString}`,
      {
        addAuthHeaders: false,
      }
    );
  },
};
