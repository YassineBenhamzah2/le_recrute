import { ApiResponse, GetBlogsQuery } from "@/lib/types/base";
import { api } from "../utils/api";
import { tag } from "@/lib/types/Blog";

export const tagService={
  getTags: () => {
      return api.getItem<ApiResponse<tag[]>>(`/blogs/tags`, {
        addAuthHeaders: false,
      });
  },
  deleteTag:(id:number) =>{
    return api.delete<ApiResponse<void>>(`/blogs/tags${id}`)
  }


}