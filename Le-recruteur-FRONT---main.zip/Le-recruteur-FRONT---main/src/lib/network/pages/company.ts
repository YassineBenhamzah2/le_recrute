import { ApiResponse, GetCompanysQuery } from "@/lib/types/base";
import { api } from "../utils/api";
import { buildQueryString } from "../utils/main";
import { Company, CompanyDetails } from "@/lib/types/company";

export const companyPageService = {
    getCompanies: (params: GetCompanysQuery = {}) => {
        const queryString = buildQueryString(params);
        return api.getItem<ApiResponse<Company[]>>(`/companies${queryString}`);
    },
    getCompanyById: (id: number) =>
        api.getItem<ApiResponse<CompanyDetails>>(`/companies/${id}`),
    bookmarkCompany: (id: number) =>
        api.post<ApiResponse<void>>(`/companies/${id}/bookmark`),
    bookmarkJob: (id: number) =>
        api.post<ApiResponse<void>>(`/companies/jobs/${id}/bookmark`),

}