import { ApiResponse, GetBlogsQuery } from "@/lib/types/base";
import { api } from "../utils/api";
import { buildQueryString } from "../utils/main";
import { BlogCount, BlogDetails } from "@/lib/types/Blog";

export const blogService = {
  getBlogs: (params: GetBlogsQuery = {}) => {
    const queryString = buildQueryString(params);
    return api.getItem<ApiResponse<BlogDetails[]>>(`/blogs${queryString}`, {
      addAuthHeaders: false,
    });
  },
  getBlogById: (id: number) =>
    api.getItem<ApiResponse<BlogDetails>>(`/blogs/${id}`, {
      addAuthHeaders: false,
    }),

  // createBlog: (req: BlogDetails) =>{
  //   api.post<ApiResponse<BlogDetails>>(`/blogs/blog`,req), {
  //     addAuthHeaders: true,
  //   }},

  //la candition de authentifier don't existe
  // updateBlog: (id: number, req: BlogDetails) =>
  //   api.put<ApiResponse<BlogDetails>>(`/blogs/${id}`,req),

  updateBlogContent: (id: number, content: string) =>
    api.put<ApiResponse<BlogDetails>>(`/blogs/content/${id}`, content),

  deleteBlog: (id: number) =>
    api.delete<ApiResponse<BlogDetails>>(`/blogs/${id}`),

  getBlogCounts: () =>
    api.getItem<ApiResponse<BlogCount[]>>(`/blogs/categories/blog-counts`, {
      addAuthHeaders: false,
    }),

  searchBlogByKeyword: (keyword: string, params: GetBlogsQuery = {}) => {
    const queryString = buildQueryString({ ...params, keyword });
    return api.getItem<ApiResponse<BlogDetails[]>>(
      `/blogs/search/keyword${queryString}`,
      {
        addAuthHeaders: true,
      }
    );
  },

  searchBlogByCategory: (category: string, params: GetBlogsQuery = {}) => {
    const queryString = buildQueryString({ ...params, category });
    return api.getItem<ApiResponse<BlogDetails[]>>(
      `/blogs/search/category${queryString}`,
      {
        addAuthHeaders: true,
      }
    );
  },

  searchBlogByTag: (tag: string, params: GetBlogsQuery = {}) => {
    const queryString = buildQueryString({ ...params, tag });
    return api.getItem<ApiResponse<BlogDetails[]>>(
      `/blogs/search/tag${queryString}`,
      {
        addAuthHeaders: true,
      }
    );
  },

  searchBlogByAuthor: (author: string, params: GetBlogsQuery = {}) => {
    const queryString = buildQueryString({ ...params, author });
    return api.getItem<ApiResponse<BlogDetails[]>>(
      `/blogs/search/author${queryString}`,
      {
        addAuthHeaders: true,
      }
    );
  },

  searchBlogByDate: (date: Date, params: GetBlogsQuery = {}) => {
    const queryString = buildQueryString({ ...params, date });
    return api.getItem<ApiResponse<BlogDetails[]>>(
      `/blogs/search/date${queryString}`,
      {
        addAuthHeaders: true,
      }
    );
  },
};
