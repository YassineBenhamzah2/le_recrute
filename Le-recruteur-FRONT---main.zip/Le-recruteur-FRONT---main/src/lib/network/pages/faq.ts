import { ApiResponse } from "@/lib/types/base";
import { api } from "../utils/api";
import {
  FAQ,
  ContactFormRequest,
  ContactFormResponse,
} from "@/lib/types/page/faq";

export const faqPageService = {
  // Get Frequently Asked Questions
  getFAQs: () =>
    api.getItem<ApiResponse<FAQ[]>>("/faq", {
      addAuthHeaders: false,
    }),

  // Get In Touch Form
  submitContactForm: (data: ContactFormRequest) =>
    api.post<ApiResponse<ContactFormResponse>>("/faq/contact", data),
};
