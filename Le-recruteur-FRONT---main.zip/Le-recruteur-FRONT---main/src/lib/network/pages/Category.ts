import { ApiResponse, GetBlogsQuery } from "@/lib/types/base";
import { api } from "../utils/api";
import { category } from "@/lib/types/Blog";

export const categoryService={
  getCategories: () => {
      return api.getItem<ApiResponse<category[]>>(`/blogs/categories`, {
        addAuthHeaders: false,
      });
  },
  deleteCategory:(id:number) =>{
    return api.delete<ApiResponse<void>>(`/blogs/${id}`)
  }


}