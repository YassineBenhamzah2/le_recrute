import { api } from "../utils/api";
import { ApiResponse } from "../../types/base";
import { JobOffer, Report } from "../../types/jobOffer";
import { buildQueryString } from "../utils/main";

export interface GetJobsQuery {
  page?: number; // 1-indexed (backend converts to 0-based internally)
  size?: number;
  title?: string;
  jobType?: string;
  contractType?: string;
  location?: string;
  sector?: string;
}

export const jobOffersService = {
  getAll: (query: GetJobsQuery = {}): Promise<ApiResponse<JobOffer[]>> => {
    const qs = buildQueryString(query as Record<string, unknown>);
    return api.getItem<ApiResponse<JobOffer[]>>(`/jobs${qs}`, { addAuthHeaders: true, authMode: "optional" });
  },
  getById: (id: number): Promise<ApiResponse<JobOffer>> => {
    return api.getItem<ApiResponse<JobOffer>>(`/jobs/${id}`, { addAuthHeaders: true, authMode: "optional" });
  },
  bookmarkJob: (id: number): Promise<ApiResponse<boolean>> => {
    // Toggle bookmark state for the given job offer ID
    return api.post<ApiResponse<boolean>>(`/jobs/bookmarkjob/${id}`, undefined, { addAuthHeaders: true, authMode: "optional" });
  },
  applyToJob: (
    jobOfferId: number,
    formData: FormData
  ): Promise<ApiResponse<{ id: number; candidate_id: number; job_offer_id: number }>> => {
    return api.post<ApiResponse<{ id: number; candidate_id: number; job_offer_id: number }>>(
      `/jobs/apply/${jobOfferId}`,
      formData,
      { addAuthHeaders: true, authMode: "optional" }
    );
  },

  getLocations: (): Promise<ApiResponse<string[]>> => {
    return api.getItem<ApiResponse<string[]>>(`/jobs/locations`, { addAuthHeaders: true, authMode: "optional" });
  },

  createReport: (reportData: Report): Promise<ApiResponse<Report>> => {
  return api.post<ApiResponse<Report>>(`/reportCompany`, reportData , { addAuthHeaders: true});
}
};