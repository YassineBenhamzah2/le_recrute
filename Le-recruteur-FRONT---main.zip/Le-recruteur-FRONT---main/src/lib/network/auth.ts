import { api } from "./utils/api";
import {
  ApiResponse,
  LoginRequest,
  LoginResponse,
  RegisterCandidateRequest,
  RegisterCandidateResponse,
  // RegisterRecruiterRequest // no need for it since we use FormData
  RegisterRecruiterResponse,
} from "../types/base";

export const authService = {
  // Register candidate
  registerCandidate: (data: RegisterCandidateRequest) =>
    api.post<ApiResponse<RegisterCandidateResponse>>(
      "/auth/register-candidate",
      data,
      { addAuthHeaders: false }
    ),

  // Login
  login: (data: LoginRequest) =>
    api.post<ApiResponse<LoginResponse>>("/auth/login", data, {
      addAuthHeaders: false,
    }),

  // Register recruiter (with license key)
  registerRecruiter: (data: FormData) =>
    api.post<ApiResponse<RegisterRecruiterResponse>>(
      "/auth/register-recruiter",
      data,
      { addAuthHeaders: false }
    ),
};
