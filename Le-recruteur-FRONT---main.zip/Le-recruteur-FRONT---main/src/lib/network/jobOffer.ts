import { ApiResponse, GetRecruiterJobsQuery } from "../types/base";
import {
  CreateJobOfferRequest,
  JobOffer,
  UpdateJobOfferRequest,
} from "../types/jobOffer";
import { api } from "./utils/api";
import { buildQueryString } from "./utils/main";

export const jobOfferService = {
  getRecruiterJobs: (params: GetRecruiterJobsQuery = {}) => {
    const queryString = buildQueryString(params);
    return api.getItem<ApiResponse<JobOffer[]>>(
      `/recruiter/jobs${queryString}`
    );
  },
  getJobOffer: (jobOfferId: number) =>
    api.getItem<ApiResponse<JobOffer>>(`/recruiter/jobs/${jobOfferId}`),
  // Create New Job Offer
  createJobOffer: (data: CreateJobOfferRequest) =>
    api.post<ApiResponse<JobOffer>>("/recruiter/jobs", data),

  // Update Job Offer
  updateJobOffer: (jobOfferId: number, data: UpdateJobOfferRequest) =>
    api.put<ApiResponse<JobOffer>>(`/recruiter/jobs/${jobOfferId}`, data),

  // Delete Job Offer
  deleteJobOffer: (jobOfferId: number) =>
    api.delete<ApiResponse<boolean>>(`/recruiter/jobs/${jobOfferId}`),
};
