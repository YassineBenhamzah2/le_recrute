import { ApiResponse } from "../types/base";
import { CandidateTest } from "../types/candidateTests";
import { TestQuestion } from "../types/test";
import { api } from "./utils/api";
import { buildQueryString } from "./utils/main";

export interface GetCandidateTestsQuery {
  status?: string;
  page?: number;
  limit?: number;
  search?: string;
}

export interface CandidateTestStats {
  totalTests: number;
  completedTests: number;
  passedTests: number;
  failedTests: number;
  averageScore: number;
  totalTimeSpent: number;
  upcomingTests: number;
  expiredTests: number;
}

export const candidateTestService = {
  // Get all assigned tests for the candidate
  getTests: (params: GetCandidateTestsQuery = {}) => {
    const queryString = buildQueryString(params);
    return api.getItem<ApiResponse<CandidateTest[]>>(
      `/candidate/tests${queryString}`
    );
  },

  // Get a single test by ID
  getTestById: (testId: string) =>
    api.getItem<ApiResponse<CandidateTest>>(`/candidate/tests/${testId}`),

  // Start a test session
  startTest: (testId: string) =>
    api.post<
      ApiResponse<{
        sessionId: string;
        testId: string;
        startTime: string;
        expiryTime: string;
        questions: TestQuestion[];
      }>
    >(`/candidate/tests/${testId}/start`),

  // Submit an answer for a question
  submitAnswer: (
    sessionId: string,
    questionId: string,
    data: { answer: string; timeSpent: number }
  ) => {
    // Convertir l'ID de question en number
    const numericQuestionId = parseInt(questionId, 10);

    // Convertir la réponse en ID numérique
    let numericAnswer;
    try {
      numericAnswer = parseInt(data.answer, 10);
      if (isNaN(numericAnswer)) {
        // Si ce n'est pas un nombre, utiliser une valeur par défaut
        numericAnswer = 1;
      }
    } catch {
      numericAnswer = 1;
    }

    return api.post<
      ApiResponse<{
        saved: boolean;
        nextQuestionId: string;
      }>
    >(
      `/candidate/tests/sessions/${sessionId}/questions/${numericQuestionId}/answer`,
      {
        answer: numericAnswer,
        timeSpent: data.timeSpent,
      }
    );
  },

  // Submit the entire test
  submitTest: (sessionId: string) =>
    api.post<
      ApiResponse<{
        submitted: boolean;
        score: number;
        passed: boolean;
        message: string;
      }>
    >(`/candidate/tests/sessions/${sessionId}/submit`),

  // Get test results
  getTestResults: (testId: string) =>
    api.getItem<ApiResponse<CandidateTest>>(
      `/candidate/tests/${testId}/results`
    ),

  // Get test statistics for candidate
  getStatistics: () =>
    api.getItem<ApiResponse<CandidateTestStats>>(`/candidate/tests/statistics`),
};
