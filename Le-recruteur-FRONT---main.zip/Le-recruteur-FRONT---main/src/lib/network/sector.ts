import { api } from "./utils/api";
import { ApiResponse, Sector } from "../types/base";

export const sectorsService = {
  getAll: (): Promise<ApiResponse<Sector[]>> =>
    api.getItem<ApiResponse<Sector[]>>("/sectors", { addAuthHeaders: false }),
};
