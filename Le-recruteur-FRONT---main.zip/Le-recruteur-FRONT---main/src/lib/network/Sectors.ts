import { api } from "./utils/api";
import { ApiResponse, Sector } from "../types/base";

export const sectorsService = {
  getAll: async (): Promise<Sector[]> => {
    const response = await api.getItem<ApiResponse<Sector[]>>("/auth/sectors");
    return response.data || [];
  },
};
