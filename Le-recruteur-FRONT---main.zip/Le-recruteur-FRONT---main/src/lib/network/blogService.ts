import { Blog, PaginatedBlogs } from "@/lib/types/blogs";
import { api } from "./utils/api";

export const blogCmsApi = {
  // Récupérer les blogs CMS (paginated)
  getCmsBlogs: async (page = 0, size = 10): Promise<PaginatedBlogs> => {
    return api.getItem(`/admin/blog-cms?page=${page}&size=${size}`, {
      addAuthHeaders: false,
    });
  },

  // Ajouter un blog au CMS
  addBlogToCms: async (
    blogId: number,
    displayOrder: number,
    destinationLink?: string
  ): Promise<void> => {
    const linkParam = destinationLink
      ? `&destinationLink=${encodeURIComponent(destinationLink)}`
      : "";
    await api.post(
      `/admin/blog-cms?blogId=${blogId}&displayOrder=${displayOrder}${linkParam}`
    );
  },

  // Mettre à jour un blog CMS (ordre + destination)
  updateBlogCms: async (
    cmsId: number,
    displayOrder: number,
    destinationLink?: string
  ): Promise<void> => {
    const linkParam = destinationLink
      ? `&destinationLink=${encodeURIComponent(destinationLink)}`
      : "";
    await api.put(
      `/admin/blog-cms/${cmsId}?displayOrder=${displayOrder}${linkParam}`
    );
  },

  // Supprimer un blog CMS
  deleteBlogCms: async (cmsId: number): Promise<void> => {
    await api.delete(`/admin/blog-cms/${cmsId}`);
  },

  // Récupérer tous les blogs (pour sélection)
  getAllBlogs: async (): Promise<Blog[]> => {
    return api.getItem(`/admin/blog-cms/all-blogs`);
  },
};
