import { api } from "./utils/api";
import { ApiResponse } from "../types/base";
import { CandidateJobOffer } from "../types/candidateJobOffer";
import { buildQueryString } from "./utils/main";
import { JobFilters } from "../types/candidateJobOffer";

export interface GetJobsQuery {
  page?: number; // 1-indexed (backend converts to 0-based internally)
  size?: number;
  tab?: "all" | "applied" | "saved";
  jobFilters?: JobFilters;
}


export const jobOffersService = {
  getAll: (query: GetJobsQuery = {}): Promise<ApiResponse<CandidateJobOffer[]>> => {
    const qs = buildQueryString(query as Record<string, unknown>);
    return api.getItem<ApiResponse<CandidateJobOffer[]>>(`/candidate/jobs${qs}`, {addAuthHeaders: true});
  },
 
  bookmarkJob: (id: number): Promise<ApiResponse<boolean>> => {
    // Toggle bookmark state for the given job offer ID
    return api.post<ApiResponse<boolean>>(`/candidate/jobs/bookmarkjob/${id}`, undefined, { addAuthHeaders: true});
  },

  getJobsFilters: (): Promise<ApiResponse<JobFilters>> => {
    return api.getItem<ApiResponse<JobFilters>>(`/jobs/filters`, {addAuthHeaders: true, authMode: "optional" });
  },

};