import { EventCategory, trackEvent, trackPageView } from "./googleAnalytics";

/**
 * WebAnalytics Service - Direct wrapper for Google Analytics
 *
 * This service forwards analytics events directly to Google Analytics
 * and provides a consistent interface for tracking across the application.
 */
class WebAnalytics {
  /**
   * Record a page view
   * @param path Page path
   */
  recordPageView(path: string): void {
    // Send directly to Google Analytics
    trackPageView(path, document.title);
  }

  /**
   * Record an API request
   * @param method HTTP method
   * @param endpoint API endpoint
   * @param category Event category
   */
  recordApiRequest(
    method: string,
    endpoint: string,
    category: EventCategory
  ): void {
    // Track the API call in Google Analytics
    trackEvent(category, `${method} ${endpoint}`, undefined, undefined, false);
  }

  /**
   * Record a custom event
   * @param category Event category
   * @param action Event action
   * @param label Optional event label
   * @param value Optional event value
   */
  recordEvent(
    category: EventCategory | string,
    action: string,
    label?: string,
    value?: number
  ): void {
    trackEvent(category, action, label, value);
  }

  /**
   * Record an error as an event
   * @param error Error object or message
   */
  recordError(error: Error | string): void {
    const errorMessage = error instanceof Error ? error.message : error;
    this.recordEvent(EventCategory.ERROR, "Application Error", errorMessage);
  }
}

// Create singleton instance
export const webAnalytics = new WebAnalytics();
