import { webAnalytics } from "./webAnalytics";
import { initGA } from "./googleAnalytics";
import { settings } from "../settings/main";

/**
 * Initialize analytics services on app load
 * Call this function in your app's entry point
 */
export const initializeAnalytics = (): void => {
  // Always initialize Google Analytics in both dev and production
  const GA_TRACKING_ID = settings.GA_ID; // Replace with your actual GA4 tracking ID
  initGA(GA_TRACKING_ID);
  console.log("[Analytics] Google Analytics initialized");

  // Track initial page view
  const currentPath = window.location.pathname + window.location.search;
  webAnalytics.recordPageView(currentPath);

  console.log("[Analytics] Analytics tracking initialized");
};
