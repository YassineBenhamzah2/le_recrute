import ReactGA from "react-ga4";

/**
 * Initialize Google Analytics
 * @param trackingId Your Google Analytics tracking ID
 */
export const initGA = (trackingId: string): void => {
  ReactGA.initialize(trackingId, {
    testMode: process.env.NODE_ENV !== "production",
    gaOptions: {
      siteSpeedSampleRate: 100, // Collect site speed data for 100% of users
    },
  });
};

/**
 * Track a page view
 * @param path The current page path
 * @param title The current page title
 */
export const trackPageView = (path: string, title?: string): void => {
  ReactGA.send({
    hitType: "pageview",
    page: path,
    title: title,
  });
};

export enum EventCategory {
  WEB_INTERACTION = "web_interaction",
  SEARCH_INTERACTION = "search_interaction",
  WEB_MUTATION = "web_mutation",
  USER_ENGAGEMENT = "user_engagement",
  ERROR = "error",
  TIMING = "timing",
  PAGE_VIEW = "page_view",
}

/**
 * Track an event
 * @param category Event category
 * @param action Event action
 * @param label Optional label
 * @param value Optional value
 * @param nonInteraction Whether this is a non-interaction event
 */
export const trackEvent = (
  category: EventCategory | string,
  action: string,
  label?: string,
  value?: number,
  nonInteraction = false
): void => {
  ReactGA.event({
    category,
    action,
    label,
    value,
    nonInteraction,
  });
};
