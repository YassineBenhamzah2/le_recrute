// Constantes for profile Candidate

export const SKILL_CATEGORIES = {
    TECHNICAL: 'Skills',
    LANGUAGE: 'Languages', 
    SOFT_SKILL: 'Soft Skills'
} as const;
  
export const INDUSTRIES = [
    { value: 'technology', label: 'Technology' },
    { value: 'healthcare', label: 'Healthcare' },
    { value: 'finance', label: 'Finance' },
    { value: 'education', label: 'Education' },
    { value: 'manufacturing', label: 'Manufacturing' },
    { value: 'retail', label: 'Retail' },
    { value: 'consulting', label: 'Consulting' },
    { value: 'media', label: 'Media & Entertainment' },
    { value: 'nonprofit', label: 'Non-Profit' },
    { value: 'government', label: 'Government' }
] as const;

export const JOB_FUNCTIONS = [
    { value: 'development', label: 'Software Development' },
    { value: 'design', label: 'Design' },
    { value: 'marketing', label: 'Marketing' },
    { value: 'sales', label: 'Sales' },
    { value: 'management', label: 'Management' },
    { value: 'finance', label: 'Finance & Accounting' },
    { value: 'hr', label: 'Human Resources' },
    { value: 'operations', label: 'Operations' },
    { value: 'customer-service', label: 'Customer Service' },
    { value: 'data-science', label: 'Data Science' },
    { value: 'product', label: 'Product Management' },
    { value: 'engineering', label: 'Engineering' }
] as const;
  
export const PROFILE_TABS = [
    { id: 'Overview', label: 'Overview' },
    { id: 'Experience', label: 'Experience' },
    { id: 'Education', label: 'Education' },
    { id: 'Skills', label: 'Skills' }
] as const;
  
export const SKILL_LEVELS = {
    BEGINNER: { min: 0, max: 30, label: 'Beginner' },
    INTERMEDIATE: { min: 31, max: 60, label: 'Intermediate' },
    ADVANCED: { min: 61, max: 80, label: 'Advanced' },
    EXPERT: { min: 81, max: 100, label: 'Expert' }
} as const;
  
export const WORKPLACE_RATINGS = [
    { value: 1, label: 'Poor' },
    { value: 2, label: 'Fair' },
    { value: 3, label: 'Good' },
    { value: 4, label: 'Very Good' },
    { value: 5, label: 'Excellent' }
] as const;
  
export const PROFILE_COMPLETION_WEIGHTS = {
    BASIC_INFO: 20,   // Name, email, title, etc.
    OVERVIEW: 15,     // Personal description
    EXPERIENCE: 25,   // Professional Experience
    EDUCATION: 15,    // Education
    SKILLS: 20,       // Skills
    CERTIFICATIONS: 5 // Certifications
} as const;
  
export const QUICK_ACTIONS = [
    {
      id: 'download-resume',
      label: 'Download Resume',
      icon: 'Download'
    },
    {
      id: 'preview-profile',
      label: 'Preview Public Profile',
      icon: 'Eye'
    },
    {
      id: 'profile-review',
      label: 'Get Profile Review',
      icon: 'Star'
    }
] as const;
  
export const DEFAULT_SKILLS = [
    // Technical Skills
    { name: 'JavaScript', category: 'Skills', level: 85 },
    { name: 'React', category: 'Skills', level: 90 },
    { name: 'TypeScript', category: 'Skills', level: 80 },
    { name: 'Node.js', category: 'Skills', level: 75 },
    { name: 'Python', category: 'Skills', level: 70 },
    
    // Languages
    { name: 'English', category: 'Languages', level: 95 },
    { name: 'French', category: 'Languages', level: 80 },
    { name: 'Spanish', category: 'Languages', level: 60 },
    
    // Soft Skills
    { name: 'Communication', category: 'Soft Skills', level: 85 },
    { name: 'Leadership', category: 'Soft Skills', level: 75 },
    { name: 'Problem Solving', category: 'Soft Skills', level: 90 }
] as const;
  
export const FORM_VALIDATION = {
    REQUIRED_FIELDS: {
      SKILL: ['name', 'category'],
      EXPERIENCE: ['position', 'company', 'startDate'],
      EDUCATION: ['title', 'school', 'startDate'],
      CERTIFICATION: ['certificationName', 'issuedBy', 'industry', 'jobFunction']
    },
    MAX_LENGTHS: {
      SKILL_NAME: 50,
      POSITION: 100,
      COMPANY: 100,
      SCHOOL: 100,
      DESCRIPTION: 500
    }
} as const;
  
export const API_ENDPOINTS = {
    PROFILE: '/api/candidate/profile',
    SKILLS: '/api/candidate/skills',
    EXPERIENCE: '/api/candidate/experience',
    EDUCATION: '/api/candidate/education',
    CERTIFICATIONS: '/api/candidate/certifications',
    UPLOAD_RESUME: '/api/candidate/upload-resume',
    DOWNLOAD_CV: '/api/candidate/download-cv'
} as const;