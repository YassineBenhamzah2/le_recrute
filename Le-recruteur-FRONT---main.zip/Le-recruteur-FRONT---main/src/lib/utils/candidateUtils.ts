import { PROFILE_COMPLETION_WEIGHTS, SKILL_LEVELS } from './candidateConstants';
import type { CandidateProfile, Skill, WorkExperience, Education, Certification } from '@/lib/types/candidateProfile';

/**
 * Calculates the profile completion percentage
 */
export const calculateProfileCompletion = (
  profile: Partial<CandidateProfile>,
  skills: Skill[],
  experience: WorkExperience[],
  education: Education[],
  certifications: Certification[]
): number => {
  let totalScore = 0;

  // Informations de base (20%)
  if (profile.firstName && profile.lastName && profile.email && profile.title) {
    totalScore += PROFILE_COMPLETION_WEIGHTS.BASIC_INFO;
  }

  // Overview (15%)
  if (profile.overview && profile.overview.length > 50) {
    totalScore += PROFILE_COMPLETION_WEIGHTS.OVERVIEW;
  }

  // Expérience (25%)
  if (experience.length > 0) {
    totalScore += PROFILE_COMPLETION_WEIGHTS.EXPERIENCE;
  }

  // Éducation (15%)
  if (education.length > 0) {
    totalScore += PROFILE_COMPLETION_WEIGHTS.EDUCATION;
  }

  // Compétences (20%)
  if (skills.length >= 3) {
    totalScore += PROFILE_COMPLETION_WEIGHTS.SKILLS;
  }

  // Certifications (5%)
  if (certifications.length > 0) {
    totalScore += PROFILE_COMPLETION_WEIGHTS.CERTIFICATIONS;
  }

  return Math.min(totalScore, 100);
};

/**
 * Formats a date into a readable string
 */
export const formatDate = (date: Date | string): string => {
  if (!date) return '';
  
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateObj.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long'
  });
};

/**
 * Formats a period (start date - end date)
 */
export const formatPeriod = (startDate: Date | string, endDate?: Date | string): string => {
  const start = formatDate(startDate);
  if (!endDate) return `${start} - Present`;
  const end = formatDate(endDate);
  return `${start} - ${end}`;
};

/**
 * Determines skill level based on percentage
 */
export const getSkillLevel = (percentage: number): string => {
  if (percentage >= SKILL_LEVELS.EXPERT.min) return SKILL_LEVELS.EXPERT.label;
  if (percentage >= SKILL_LEVELS.ADVANCED.min) return SKILL_LEVELS.ADVANCED.label;
  if (percentage >= SKILL_LEVELS.INTERMEDIATE.min) return SKILL_LEVELS.INTERMEDIATE.label;
  return SKILL_LEVELS.BEGINNER.label;
};

/**
 * Generate initials from a full name
 */
export const generateInitials = (firstName: string, lastName: string): string => {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
};

/**
 * Validate an email
 */
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Validate a phone number
 */
export const isValidPhone = (phone: string): boolean => {
  // ✅ FIXED: Removed unnecessary escapes from \( and \)
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 10;
};

/**
 * Truncates a text to a given length
 */
export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};

/**
 * Categorizes skills by type
 */
export const categorizeSkills = (skills: Skill[]) => {
  return {
    technical: skills.filter(skill => skill.category === 'technical'),
    language: skills.filter(skill => skill.category === 'language'),
    softSkill: skills.filter(skill => skill.category === 'soft-skill')
  };
};

/**
 * Calculates total experience in years
 */
export const calculateTotalExperience = (experiences: WorkExperience[]): number => {
  let totalMonths = 0;

  experiences.forEach(exp => {
    const startDate = new Date(exp.startDate);
    const endDate = exp.endDate ? new Date(exp.endDate) : new Date();
    
    const monthsDiff = (endDate.getFullYear() - startDate.getFullYear()) * 12 + 
                      (endDate.getMonth() - startDate.getMonth());
    
    totalMonths += monthsDiff;
  });

  return Math.round(totalMonths / 12 * 10) / 10; // Arrondi à 1 décimale
};

/**
 * Generates a random background color for avatars
 */
export const generateAvatarColor = (name: string): string => {
  const colors = [
    'bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500',
    'bg-purple-500', 'bg-pink-500', 'bg-indigo-500', 'bg-teal-500'
  ];
  
  const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[hash % colors.length];
};

/**
 * Formats statistics (eg: 1234 -> 1.2K)
 */
export const formatStats = (number: number): string => {
  if (number < 1000) return number.toString();
  if (number < 1000000) return `${(number / 1000).toFixed(1)}K`;
  return `${(number / 1000000).toFixed(1)}M`;
};

/**
 * Determines if a date is recent (less than 30 days)
 */
export const isRecentDate = (date: Date | string): boolean => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - dateObj.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays <= 30;
};

/**
 * Generates skill suggestions based on job title
 */
export const suggestSkillsForPosition = (position: string): string[] => {
  const positionLower = position.toLowerCase();
  
  if (positionLower.includes('frontend') || positionLower.includes('react')) {
    return ['React', 'JavaScript', 'HTML', 'CSS', 'TypeScript'];
  }
  
  if (positionLower.includes('backend') || positionLower.includes('node')) {
    return ['Node.js', 'JavaScript', 'Python', 'SQL', 'API Development'];
  }
  
  if (positionLower.includes('fullstack') || positionLower.includes('full stack')) {
    return ['React', 'Node.js', 'JavaScript', 'TypeScript', 'MongoDB'];
  }
  
  if (positionLower.includes('designer') || positionLower.includes('ui') || positionLower.includes('ux')) {
    return ['Figma', 'Adobe XD', 'Sketch', 'Prototyping', 'User Research'];
  }
  
  return [];
};

/**
 * Validates form data
 */
// ✅ FIXED: Replaced 'any' with proper type definition
export const validateFormData = (
  data: Record<string, unknown>, 
  requiredFields: string[]
): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  requiredFields.forEach(field => {
    if (!data[field] || (typeof data[field] === 'string' && (data[field] as string).trim() === '')) {
      errors.push(`${field} is required`);
    }
  });
  
  return {
    isValid: errors.length === 0,
    errors
  };
};