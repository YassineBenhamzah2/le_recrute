import { UserWithPermissions } from "../types/license";

/**
 * Permission checking utilities for the license-based permission system
 */
export class PermissionChecker {
  private user: UserWithPermissions | null;

  constructor(user: UserWithPermissions | null) {
    this.user = user;
  }

  /**
   * Check if user has a specific permission
   * ADMINISTRATOR permission always overrides other permission checks
   */
  hasPermission(permission: string): boolean {
    if (!this.user || !this.user.permissions) {
      return false;
    }

    // ADMINISTRATOR permission overrides all other checks
    if (this.user.permissions.includes("ADMINISTRATOR")) {
      return true;
    }

    return this.user.permissions.includes(permission);
  }

  /**
   * Check if user has any of the provided permissions
   */
  hasAnyPermission(permissions: string[]): boolean {
    return permissions.some((permission) => this.hasPermission(permission));
  }

  /**
   * Check if user has all of the provided permissions
   */
  hasAllPermissions(permissions: string[]): boolean {
    return permissions.every((permission) => this.hasPermission(permission));
  }

  /**
   * Check if user can view licenses
   */
  canViewLicenses(): boolean {
    return this.hasAnyPermission(["ADMINISTRATOR", "VIEWER_LICENSE"]);
  }

  /**
   * Check if user can edit licenses
   */
  canEditLicenses(): boolean {
    return this.hasAnyPermission(["ADMINISTRATOR", "EDITOR_LICENSE"]);
  }

  /**
   * Check if user can view roles
   */
  canViewRoles(): boolean {
    return this.hasAnyPermission(["ADMINISTRATOR", "VIEWER_ROLE"]);
  }

  /**
   * Check if user can edit roles
   */
  canEditRoles(): boolean {
    return this.hasAnyPermission(["ADMINISTRATOR", "EDITOR_ROLE"]);
  }

  /**
   * Check if user can view permissions
   */
  canViewPermissions(): boolean {
    return this.hasAnyPermission(["ADMINISTRATOR", "VIEWER_PERMISSION"]);
  }

  /**
   * Check if user can manage jobs
   */
  canManageJobs(): boolean {
    return this.hasAnyPermission(["ADMINISTRATOR", "EDITOR_JOB"]);
  }

  /**
   * Check if user can view jobs
   */
  canViewJobs(): boolean {
    return this.hasAnyPermission(["ADMINISTRATOR", "VIEWER_JOB", "EDITOR_JOB"]);
  }

  /**
   * Check if user is admin (has ADMINISTRATOR permission)
   */
  isAdmin(): boolean {
    return this.hasPermission("ADMINISTRATOR");
  }

  /**
   * Get user's role type based on permissions
   */
  getUserRoleType(): "ADMIN" | "RECRUITER" | "CANDIDATE" | "UNKNOWN" {
    if (this.isAdmin()) {
      return "ADMIN";
    }

    if (this.user?.role.includes("RECRUITER")) {
      return "RECRUITER";
    }

    if (this.user?.role.includes("CANDIDATE")) {
      return "CANDIDATE";
    }

    return "UNKNOWN";
  }
}

/**
 * Create a permission checker instance for a user
 */
export const createPermissionChecker = (user: UserWithPermissions | null) => {
  return new PermissionChecker(user);
};

/**
 * Permission constants for easy reference
 */
export const PERMISSIONS = {
  // Administrative
  ADMINISTRATOR: "ADMINISTRATOR",

  // License permissions
  VIEWER_LICENSE: "VIEWER_LICENSE",
  EDITOR_LICENSE: "EDITOR_LICENSE",

  // Role permissions
  VIEWER_ROLE: "VIEWER_ROLE",
  EDITOR_ROLE: "EDITOR_ROLE",

  // Permission permissions
  VIEWER_PERMISSION: "VIEWER_PERMISSION",
  EDITOR_PERMISSION: "EDITOR_PERMISSION",

  // Job permissions
  VIEWER_JOB: "VIEWER_JOB",
  EDITOR_JOB: "EDITOR_JOB",

  // User permissions
  VIEWER_USER: "VIEWER_USER",
  EDITOR_USER: "EDITOR_USER",
} as const;

/**
 * Role types for UI filtering
 */
export const ROLE_TYPES = {
  ADMIN: "ADMIN",
  RECRUITER: "RECRUITER",
  CANDIDATE: "CANDIDATE",
} as const;

/**
 * License status types
 */
export const LICENSE_STATUS = {
  ACTIVE: "ACTIVE",
  SUSPENDED: "SUSPENDED",
  EXPIRED: "EXPIRED",
} as const;
