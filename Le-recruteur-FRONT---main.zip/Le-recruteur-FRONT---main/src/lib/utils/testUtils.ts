import { CandidateTest, TestResult, TestStatistics, TestAttempt } from '../lib/types/candidateTests';

export class TestUtils {
  // Calculate test statistics from test data
  static calculateStatistics(tests: CandidateTest[], results: TestResult[]): TestStatistics {
    const completedTests = tests.filter(test => test.status === 'Completed').length;
    const passedTests = results.filter(result => result.status === 'Passed').length;
    const failedTests = results.filter(result => result.status === 'Failed').length;
    const upcomingTests = tests.filter(test => 
      test.status === 'Available' || test.status === 'In Progress'
    ).length;
    const expiredTests = tests.filter(test => test.status === 'Expired').length;
    
    const totalTimeSpent = results.reduce((sum, result) => sum + result.timeSpent, 0);
    const averageScore = results.length > 0 
      ? results.reduce((sum, result) => sum + result.percentage, 0) / results.length 
      : 0;

    return {
      totalTests: tests.length,
      completedTests,
      passedTests,
      failedTests,
      averageScore,
      totalTimeSpent,
      upcomingTests,
      expiredTests
    };
  }

  // Calculate time remaining for a test
  static getTimeRemaining(startTime: string, duration: number): number {
    const start = new Date(startTime).getTime();
    const now = Date.now();
    const elapsed = Math.floor((now - start) / 1000); // seconds
    const totalSeconds = duration * 60;
    return Math.max(0, totalSeconds - elapsed);
  }

  // Format time in MM:SS format
  static formatTime(seconds: number): string {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }

  // Check if a test is due soon (within 7 days)
  static isDueSoon(dueDate?: string): boolean {
    if (!dueDate) return false;
    const due = new Date(dueDate).getTime();
    const now = Date.now();
    const sevenDays = 7 * 24 * 60 * 60 * 1000;
    return (due - now) <= sevenDays && due > now;
  }

  // Check if a test is expired
  static isExpired(dueDate?: string): boolean {
    if (!dueDate) return false;
    return new Date(dueDate).getTime() < Date.now();
  }

  // Calculate completion percentage for a test attempt
  static calculateCompletionPercentage(answers: any[], totalQuestions: number): number {
    const answeredCount = answers.filter(answer => 
      answer.answer && answer.answer.length > 0
    ).length;
    return Math.round((answeredCount / totalQuestions) * 100);
  }

  // Get difficulty color classes for UI
  static getDifficultyColor(difficulty: string): string {
    switch (difficulty.toLowerCase()) {
      case 'easy': return 'bg-green-100 text-green-800 border-green-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'hard': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  }

  // Get status color classes for UI
  static getStatusColor(status: string): string {
    switch (status.toLowerCase()) {
      case 'available': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in progress': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'expired': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  }

  // Validate test attempt data
  static validateTestAttempt(attempt: TestAttempt): boolean {
    if (!attempt.testId || !attempt.candidateId) return false;
    if (!attempt.startTime) return false;
    if (!Array.isArray(attempt.answers)) return false;
    return true;
  }

  // Calculate score from answers and questions
  static calculateScore(
    answers: any[], 
    questions: any[],
    totalPoints?: number
  ): { score: number; percentage: number; correctCount: number } {
    let earnedPoints = 0;
    let maxPoints = totalPoints || 0;
    let correctCount = 0;

    if (!totalPoints) {
      maxPoints = questions.reduce((sum, q) => sum + (q.points || 1), 0);
    }

    answers.forEach(answer => {
      const question = questions.find(q => q.id === answer.questionId);
      if (question && answer.answer === question.correctAnswer) {
        earnedPoints += question.points || 1;
        correctCount++;
      }
    });

    const percentage = maxPoints > 0 ? Math.round((earnedPoints / maxPoints) * 100) : 0;
    
    return {
      score: earnedPoints,
      percentage,
      correctCount
    };
  }

  // Generate performance insights based on results
  static generatePerformanceInsights(result: TestResult, test: CandidateTest): string[] {
    const insights: string[] = [];
    
    if (result.percentage >= 90) {
      insights.push("Outstanding performance! You have excellent mastery of this subject.");
    } else if (result.percentage >= 80) {
      insights.push("Great job! You demonstrate strong understanding of the material.");
    } else if (result.percentage >= 70) {
      insights.push("Good work! You have a solid foundation but could benefit from additional study.");
    } else if (result.percentage >= 60) {
      insights.push("You're on the right track. Focus on areas where you struggled most.");
    } else {
      insights.push("Consider reviewing the material thoroughly before retaking the test.");
    }

    // Time-based insights
    const timeEfficiency = result.timeSpent / test.duration;
    if (timeEfficiency < 0.5) {
      insights.push("You completed the test quickly. Consider double-checking your answers next time.");
    } else if (timeEfficiency > 0.95) {
      insights.push("You used almost all available time. Practice time management for similar tests.");
    }

    // Accuracy insights
    const accuracy = result.correctAnswers / result.totalQuestions;
    if (accuracy >= 0.8) {
      insights.push("Your accuracy rate is excellent.");
    } else if (accuracy < 0.6) {
      insights.push("Focus on understanding concepts rather than memorization.");
    }

    return insights;
  }

  // Sort tests by priority (due date, status, etc.)
  static sortTestsByPriority(tests: CandidateTest[]): CandidateTest[] {
    return tests.sort((a, b) => {
      // Priority order: Available > In Progress > Completed > Expired
      const statusPriority = {
        'Available': 1,
        'In Progress': 2,
        'Completed': 3,
        'Expired': 4
      };

      const aPriority = statusPriority[a.status as keyof typeof statusPriority] || 5;
      const bPriority = statusPriority[b.status as keyof typeof statusPriority] || 5;

      if (aPriority !== bPriority) {
        return aPriority - bPriority;
      }

      // If same status, sort by due date
      if (a.dueDate && b.dueDate) {
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      }

      // If one has due date and other doesn't, prioritize the one with due date
      if (a.dueDate && !b.dueDate) return -1;
      if (!a.dueDate && b.dueDate) return 1;

      // Finally sort by assigned date (newest first)
      return new Date(b.assignedDate).getTime() - new Date(a.assignedDate).getTime();
    });
  }

  // Filter tests based on criteria
  static filterTests(tests: CandidateTest[], filters: {
    search?: string;
    category?: string;
    difficulty?: string;
    status?: string;
  }): CandidateTest[] {
    return tests.filter(test => {
      // Search filter
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        const matchesSearch = 
          test.title.toLowerCase().includes(searchLower) ||
          test.description.toLowerCase().includes(searchLower) ||
          test.tags.some(tag => tag.toLowerCase().includes(searchLower));
        
        if (!matchesSearch) return false;
      }

      // Category filter
      if (filters.category && test.category !== filters.category) {
        return false;
      }

      // Difficulty filter
      if (filters.difficulty && test.difficulty !== filters.difficulty) {
        return false;
      }

      // Status filter
      if (filters.status && test.status !== filters.status) {
        return false;
      }

      return true;
    });
  }

  // Get test progress summary
  static getTestProgressSummary(test: CandidateTest): {
    canStart: boolean;
    canRetake: boolean;
    isExpired: boolean;
    attemptsLeft: number;
    nextAction: string;
  } {
    const isExpired = TestUtils.isExpired(test.dueDate);
    const attemptsLeft = test.maxAttempts - test.attempts;
    const canRetake = test.status === 'Completed' && attemptsLeft > 0 && !isExpired;
    const canStart = (test.status === 'Available' || test.status === 'In Progress') && 
                     attemptsLeft > 0 && !isExpired;

    let nextAction = 'View Details';
    if (canStart) {
      nextAction = test.status === 'In Progress' ? 'Continue Test' : 'Start Test';
    } else if (canRetake) {
      nextAction = 'Retake Test';
    } else if (isExpired) {
      nextAction = 'Expired';
    } else if (attemptsLeft === 0) {
      nextAction = 'No Attempts Left';
    }

    return {
      canStart,
      canRetake,
      isExpired,
      attemptsLeft,
      nextAction
    };
  }
}
