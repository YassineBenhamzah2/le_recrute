/**
 * Utility functions for handling file downloads
 */

/**
 * Downloads a blob as a file with the specified filename
 * @param blob - The blob to download
 * @param filename - The name of the file to download
 */
export const downloadBlob = (blob: Blob, filename: string): void => {
  try {
    // Create a blob URL
    const url = window.URL.createObjectURL(blob);

    // Create a temporary anchor element
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;

    // Add to DOM, click, and remove
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Clean up the blob URL
    window.URL.revokeObjectURL(url);
  } catch (error) {
    console.error("Error downloading file:", error);
    throw new Error("Failed to download file");
  }
};

/**
 * Gets a filename from a blob response's content-disposition header
 * @param response - The fetch response containing the blob
 * @param defaultName - Default filename if none is found in headers
 * @returns The filename to use for the download
 */
export const getFilenameFromResponse = (
  response: Response,
  defaultName: string
): string => {
  const contentDisposition = response.headers.get("content-disposition");
  if (contentDisposition) {
    const filenameMatch = contentDisposition.match(
      /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/
    );
    if (filenameMatch && filenameMatch[1]) {
      return filenameMatch[1].replace(/['"]/g, "");
    }
  }
  return defaultName;
};

/**
 * Sanitizes a filename by removing/replacing invalid characters
 * @param filename - The filename to sanitize
 * @returns A sanitized filename safe for download
 */
export const sanitizeFilename = (filename: string): string => {
  // Remove or replace characters that are invalid in filenames
  return filename
    .replace(/[<>:"/\\|?*]/g, "_") // Replace invalid characters with underscore
    .replace(/\s+/g, "_") // Replace spaces with underscores
    .replace(/_+/g, "_") // Replace multiple underscores with single one
    .trim();
};
