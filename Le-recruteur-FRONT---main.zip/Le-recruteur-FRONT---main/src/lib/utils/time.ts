export const generateTimeOptions = () => {
  const times = [];
  for (let h = 0; h < 24; h++) {
    for (const m of [0, 15, 30, 45]) {
      const hour = String(h).padStart(2, "0");
      const minute = String(m).padStart(2, "0");
      const label = convert24To12(`${hour}:${minute}`);
      times.push({ label, value: `${hour}:${minute}` });
    }
  }
  return times;
};

export const convert24To12 = (time24: string): string => {
  const [hourStr, minute] = time24.split(":");
  const hour = parseInt(hourStr, 10);
  const period = hour < 12 ? "AM" : "PM";
  const hour12 = hour % 12 === 0 ? 12 : hour % 12;
  return `${hour12}:${minute} ${period}`;
};

export function convertToDateInputFormat(dateStr: string): string {
  const [year, month, day] = dateStr.split("-");
  // Return in YYYY-MM-DD format, zero-padding month/day if needed
  return `${year}-${month?.padStart(2, "0")}-${day?.padStart(2, "0")}`;
}
export function convertToDateInputFormatV2(dateStr: string): string {
  const [day, month, year] = dateStr.split("/");
  // Return in YYYY-MM-DD format, zero-padding month/day if needed
  return `${year}-${month?.padStart(2, "0")}-${day?.padStart(2, "0")}`;
}
