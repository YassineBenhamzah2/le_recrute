import { RoleInfo } from "../types/base";

/**
 * Navigation helper function to route users based on their role type
 * @param roleInfo - The role information object
 * @param navigate - Router navigation function
 */
export function navigateBasedOnRole(
  roleInfo: RoleInfo,
  navigate: (path: string) => void
) {
  switch (roleInfo.type) {
    case "ADMIN":
      navigate("/admin");
      break;
    case "RECRUITER":
      navigate("/recruiter");
      break;
    case "CANDIDATE":
      navigate("/candidate");
      break;
    default:
      navigate("/auth/signin");
  }
}

/**
 * Get the default dashboard path for a role type
 * @param roleInfo - The role information object
 * @returns The default dashboard path
 */
export function getDefaultDashboardPath(roleInfo: RoleInfo): string {
  switch (roleInfo.type) {
    case "ADMIN":
      return "/admin";
    case "RECRUITER":
      return "/recruiter";
    case "CANDIDATE":
      return "/candidate";
    default:
      return "/auth/signin";
  }
}

/**
 * Check if user has admin access
 * @param roleInfo - The role information object
 * @returns True if user has admin access
 */
export function hasAdminAccess(roleInfo: RoleInfo): boolean {
  return roleInfo.type === "ADMIN";
}

/**
 * Check if user has recruiter access
 * @param roleInfo - The role information object
 * @returns True if user has recruiter access
 */
export function hasRecruiterAccess(roleInfo: RoleInfo): boolean {
  return roleInfo.type === "RECRUITER";
}

/**
 * Check if user has candidate access
 * @param roleInfo - The role information object
 * @returns True if user has candidate access
 */
export function hasCandidateAccess(roleInfo: RoleInfo): boolean {
  return roleInfo.type === "CANDIDATE";
}

/**
 * Get sign-in page based on role type
 * @param roleInfo - The role information object
 * @returns The appropriate sign-in page path
 */
export function getSignInPath(roleInfo: RoleInfo): string {
  switch (roleInfo.type) {
    case "RECRUITER":
      return "/auth/recruiter-signin";
    case "ADMIN":
    case "CANDIDATE":
    default:
      return "/auth/signin";
  }
}
