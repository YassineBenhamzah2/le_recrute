import { Company } from "./company";
import { JobStatus } from "./subtype/main";

export interface JobOffer {
  id: number;
  title: string;
  description: string;
  location: string;
  contractType: string;
  jobType: string;
  minSalary: number;
  maxSalary: number;
  currency: string;
  negotiable: boolean;
  publicationDate: string;
  deadlineDate: string;
  status: JobStatus;
  isBookmarked: boolean;
  departmentId: number;
  departmentName: string;
  company: Company;
  bonus: string;
  requirements: string[];
  responsibilities: string[];
  bookmarkedBy: number[];
  savedBy: number[];
  appliedBy?: number[];
  skills: string[];
  questions?: string[];
  questionsIds?: number[];
  workMode: string;
  tags?: string[];
}

export interface JobOffersResponse {
  success: boolean;
  code: number;
  message: string;
  data: JobOffer[];
  metadata: {
    pagination: {
      totalItems: number;
      totalPages: number;
      pageSize: number;
      page: number;
    };
  };
}

// Job Creation/Update Types
export interface CreateJobOfferRequest {
  title: string;
  description: string;
  departmentId: number;
  location: string;
  contractType: string;
  jobType: string;
  publicationDate: string;
  deadlineDate: string;
  minSalary: number;
  maxSalary: number;
  currency: string;
  status: "PENDING" | "ACTIVE" | "CLOSED" | "PAUSED";
  negotiable: boolean;
  jobOfferSchedule: string;
  jobOfferRequirements: string[];
  jobOfferQuestions: string[];
  jobOfferSkills: string[];
  jobOfferResponsibilities: string[];
  tags: string[];
  bonus: string;
}

export interface UpdateJobOfferRequest extends CreateJobOfferRequest {
  id: number;
}

export interface JobOffersLocations {
  locations: string[];
}

export interface JobOffersFilters {
  contractTypes: string[];
  workModes: string[];
  locations: string[];
  sectors: {
    id: number;
    name: string;
  }[];
  requirements: string[];
  companies: {
    id: number;
    name: string;
  }[];
}
export interface AdminJobResponse {
  id: number;
  title: string;
  description?: string;
  location?: string;
  contractType?: string;
  publicationDate?: string;
  numberOfApplications?: number;
  departmentId: number | null; // ✅ null si absent
  minSalary?: number;
  maxSalary?: number;
  negotiable?: boolean;
  currency?: string;
  salaryType?: string;
  status?: "ACTIVE" | "INACTIVE" | "EXPIRED" | "PAUSE" | "PENDING" | "SCHEDULED";
  deadlineDate?: string;
  jobType?: string;
  bonus?: string;
  scheduledAt?: string;
  workMode?: string;
  companyId: number | null; // ✅ null si absent
}

export interface ReportFormData {
  firstName: string;
  lastName:string;
  email: string;
  phone: string;
  reportReason: string;
}

export interface Report extends ReportFormData{
     companyId:number;
     id:number;
}


