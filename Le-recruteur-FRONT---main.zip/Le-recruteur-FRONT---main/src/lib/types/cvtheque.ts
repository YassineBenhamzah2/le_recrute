export interface PaginatedResponse<T> {
    data: T[];
    totalPages: number;
    currentPage: number;
    totalCount: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
}

export interface PerformanceRecruiter {
    candidats_total: number;
    candidats_places: number;
    taux_reussite: number;
}

export interface Recruiter {
    id: number;
    nom: string;
    prenom: string;
    email: string;
    telephone: string;
    region: string;
    secteur: string;
    statut: string;
    rating: number;
    derniere_activite: string;
    performance: PerformanceRecruiter;
}

export interface User {
    id: number;
    firstname: string;
    lastname: string;
    email: string;
    profile_pic: string;
}

export interface Candidate {
    id: number;
    name: string;
    currentPosition: string;
    company: string;
    location: string;
    education: string;
    experience: string;
    skills: string[];
    email: string;
    phone: string;
    status: string;
    lastUpdate: string;
}

export interface RecruiterFilters {
    page: number;
    size: number;
    searchTerm: string;
}

export interface CandidateFilters {
    page: number;
    size: number;
    recruiterId: number;
    search?: string;
    [key: string]: any;
}

export interface CandidateFiltersState {
    page: number;
    size: number;
    name?: string;
    positions?: string[];
    [key: string]: any; 
}

export interface DashboardStats {
    totalRecruiters: number;
    activeRecruiters: number;
    totalCandidates: number;
    placedCandidates: number;
    avgSuccessRate: number;
}

export interface Sector {
    id: number;
    name: string;
}

export interface UpdateRecruiterRequest {
    region?: string;
    primarySectorId?: number;
    status?: 'ACTIVE' | 'INACTIVE' | 'SUSPENDED' | 'REPORTED' | 'REJECTED';
}

export interface FilterOptionsResponse {
    positions: string[];
    educationLevels: string[];
    experienceLevels: string[];
    sectors: string[];
    skills: string[];
    companies: string[];
    formations: string[];
    certifications: string[];
    regions: string[];
}