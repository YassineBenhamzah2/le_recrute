import { Key } from "react";
export interface Service{
     title:string;
     description:string;
     imageUrl:string;// src/lib/types/service.ts
}
// Représente un service CMS affiché dans l'admin
export interface AdminServiceCmsResponse {
  cmsId: Key | null | undefined;
  id: number;
  title: string;
  description: string;
  price: number;
  duration?: string;
  brochurePdf?: string;
  deliveryType: "ONLINE" | "OFFLINE";
  status: "ACTIVE" | "INACTIVE";
  createdAt: string;
  updatedAt: string;
  imageUrl?: string;
  displayOrder: number;
  destinationLink?: string;
}
// Pagination pour les services CMS
export interface PaginatedCmsServices {
  content: AdminServiceCmsResponse[]; // CMS existants
  totalPages: number;
  currentPage: number;
  totalCount: number;
  hasNextPage: boolean;
}

