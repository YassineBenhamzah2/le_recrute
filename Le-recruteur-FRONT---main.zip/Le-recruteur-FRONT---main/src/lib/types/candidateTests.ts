export interface CandidateTest {
  id: string;
  title: string;
  description?: string;
  duration: number; // in minutes
  totalQuestions: number;
  passingScore?: number; // percentage
  instructions?: string[];
  score:number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  category?: TestCategory;
  difficulty?: TestDifficulty;
  tags?: string[];
  answerDetails?:AnswerDetail[];
  passed?:string;
  completedAt?:Date;
}

export interface AnswerDetail {
  questionId: number;
  questionText: string;
  selectedOptionId: number;
  pointsEarned: number;
  maxPoints: number;
  options: Option[];
}


export interface Option {
  id: number;
  text: string;
  isCorrect: boolean;
  points: number;
}


export interface TestQuestion {
  id: string;
  testId: string;
  questionText: string;
  questionType: QuestionType;
  options?: string[];
  correctAnswer: string;
  points: number;
  explanation?: string;
  order: number;
  timeLimit?: number; // in seconds, optional per-question time limit
  category?: string;
  difficulty?: QuestionDifficulty;
}

export interface TestAnswer {
  questionId: string;
  answer: string;
  isFlagged: boolean;
  timeSpent: number; // in seconds
  isCorrect?: boolean; // calculated after submission
  pointsEarned?: number;
  submittedAt?: string;
}

export interface TestAttempt {
  id: string;
  testId: string;
  candidateId: string;
  startTime: string;
  endTime: string;
  status: AttemptStatus;
  answers: TestAnswer[];
  timeSpent: number; // in minutes
  flaggedQuestions: string[];
  score?: number; // calculated percentage
  totalPoints?: number;
  earnedPoints?: number;
  isPassed?: boolean;
  reviewNotes?: string;
  submittedAt?: string;
  gradedAt?: string;
  gradedBy?: string;
}

export interface TestTimer {
  remainingTime: number; // in seconds
  isRunning: boolean;
  isPaused: boolean;
  warningThreshold: number; // in seconds
  isWarning?: boolean;
  isCritical?: boolean;
  startTime?: number;
  pausedTime?: number;
}

export interface TestProgress {
  attemptId: string;
  testId: string;
  answers: TestAnswer[];
  flaggedQuestions: string[];
  currentQuestion: number;
  timestamp: number;
  timeRemaining: number;
  isAutoSaved: boolean;
}

export interface TestStatistics {
  totalQuestions: number;
  answeredQuestions: number;
  flaggedQuestions: number;
  unansweredQuestions: number;
  completionPercentage: number;
  averageTimePerQuestion: number;
  timeSpent: number;
  estimatedTimeRemaining: number;
}

export interface QuestionNavigationStatus {
  index: number;
  status:
    | "current"
    | "answered"
    | "flagged"
    | "answered-flagged"
    | "unanswered";
  isAnswered: boolean;
  isFlagged: boolean;
  isCurrent: boolean;
  hasTimeLimit: boolean;
  timeSpent: number;
}

export interface TestConfiguration {
  allowBackNavigation: boolean;
  allowFlagging: boolean;
  showProgress: boolean;
  showTimer: boolean;
  autoSave: boolean;
  autoSaveInterval: number; // in seconds
  warningThreshold: number; // in seconds
  criticalThreshold: number; // in seconds
  maxAttempts: number;
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
  preventCopyPaste: boolean;
  preventTabSwitch: boolean;
  fullScreenMode: boolean;
}

export interface TestValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
  canSubmit: boolean;
  missingAnswers: string[];
  flaggedCount: number;
}

export interface ValidationError {
  type: "missing_answers" | "time_expired" | "technical_error";
  message: string;
  questionIds?: string[];
}

export interface ValidationWarning {
  type: "unanswered_flagged" | "time_warning" | "unsaved_progress";
  message: string;
  questionIds?: string[];
}

// Enums for better type safety
export enum TestCategory {
  TECHNICAL = "technical",
  BEHAVIORAL = "behavioral",
  COGNITIVE = "cognitive",
  LANGUAGE = "language",
  CUSTOM = "custom",
}

export enum TestDifficulty {
  BEGINNER = "beginner",
  INTERMEDIATE = "intermediate",
  ADVANCED = "advanced",
  EXPERT = "expert",
}

export enum QuestionType {
  MULTIPLE_CHOICE = "Multiple Choice",
  TRUE_FALSE = "True/False",
  SHORT_ANSWER = "Short Answer",
  ESSAY = "Essay",
  CODE = "Code",
  MATCHING = "Matching",
  ORDERING = "Ordering",
  FILL_BLANK = "Fill in the Blank",
}

export enum QuestionDifficulty {
  EASY = "easy",
  MEDIUM = "medium",
  HARD = "hard",
}

export enum AttemptStatus {
  NOT_STARTED = "Not Started",
  IN_PROGRESS = "In Progress",
  COMPLETED = "Completed",
  SUBMITTED = "Submitted",
  GRADED = "Graded",
  EXPIRED = "Expired",
  ABANDONED = "Abandoned",
}

// Event types for test interactions
export interface TestEvent {
  type: TestEventType;
  timestamp: string;
  questionId?: string;
  data?: Record<string, string | number | boolean>;
}

export enum TestEventType {
  TEST_STARTED = "test_started",
  QUESTION_VIEWED = "question_viewed",
  ANSWER_CHANGED = "answer_changed",
  QUESTION_FLAGGED = "question_flagged",
  QUESTION_UNFLAGGED = "question_unflagged",
  NAVIGATION = "navigation",
  TIMER_WARNING = "timer_warning",
  AUTO_SAVE = "auto_save",
  TEST_SUBMITTED = "test_submitted",
  TEST_PAUSED = "test_paused",
  TEST_RESUMED = "test_resumed",
  FOCUS_LOST = "focus_lost",
  FOCUS_GAINED = "focus_gained",
}

// API Response types
export interface TestResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  timestamp: string;
}

// Utility types
export type TestQuestionWithAnswer = TestQuestion & {
  userAnswer?: TestAnswer;
  isAnswered: boolean;
  isFlagged: boolean;
  timeSpent: number;
};

export type TestSummary = Pick<
  CandidateTest,
  "id" | "title" | "duration" | "totalQuestions"
> & {
  attemptCount: number;
  bestScore?: number;
  lastAttempt?: string;
  status: AttemptStatus;
};

// Hook return types
export interface UseTestTimerReturn {
  timer: TestTimer;
  formatTime: (seconds: number) => string;
  pauseTimer: () => void;
  resumeTimer: () => void;
  toggleTimer: () => void;
}

export interface UseTestStateReturn {
  questions: TestQuestion[];
  answers: TestAnswer[];
  flaggedQuestions: Set<string>;
  currentQuestion: number;
  isLoading: boolean;
  setCurrentQuestion: (index: number) => void;
  handleAnswerChange: (questionId: string, answer: string) => void;
  handleFlagToggle: (questionId: string) => void;
  getAnsweredCount: () => number;
  getFlaggedCount: () => number;
  getCompletionPercentage: () => number;
  getQuestionStatus: (index: number) => string;
  canSubmitTest: boolean;
  getUnansweredQuestions: () => Array<{
    question: TestQuestion;
    index: number;
  }>;
}
