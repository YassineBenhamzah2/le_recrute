export interface CandidateProfileView {
    id: string;
    name: string;
    email: string;
    phone: string;
    location: string;
    profileImage?: string;
    title: string;
    overview: string;
    memberSince: string;
    workExperience: WorkExperience[];
    education: Education[];
    professionalSkills: ProfessionalSkill[];
    languages: Language[];
    skills: string[];
    diplomas: Diploma[];
    isRemoteFriendly: boolean;
}

export interface WorkExperience {
    id: string;
    company: string;
    position: string;
    location: string;
    startDate: string;
    endDate?: string;
    isPresent?: boolean;
    description?: string;
}
  
export interface Education {
    id: string;
    institution: string;
    degree: string;
    field?: string;
    startYear: string;
    endYear: string;
    description?: string;
}
  
export interface ProfessionalSkill {
    id: string;
    name: string;
    level: number; // 1-10 scale
    percentage: number; // calculated from level
}
  
export interface Language {
    id: string;
    name: string;
    level: number; // 1-10 scale
    percentage: number; // calculated from level
}
  
export interface Diploma {
    id: string;
    name: string;
    type: 'diploma' | 'certificate' | 'course';
}
  
// API response types
export interface CandidateProfileResponse {
    success: boolean;
    data: CandidateProfileView;
    message?: string;
}
  
// Props for components
export interface CandidateProfileHeaderProps {
    candidate: CandidateProfileView;
}
  
export interface CandidateProfileDetailsProps {
    candidate: CandidateProfileView;
}
  
export interface WorkExperienceProps {
    experiences: WorkExperience[];
}
  
export interface EducationProps {
    education: Education[];
}
  
export interface ProfessionalSkillsProps {
    skills: ProfessionalSkill[];
}
  
export interface LanguagesProps {
    languages: Language[];
}
