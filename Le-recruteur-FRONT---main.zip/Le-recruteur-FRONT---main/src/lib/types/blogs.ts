// types/blogs.ts
export interface Blog {
  id: number;
  title: string;
  description: string;
  content: string;
  creator?: string;
  creatorPhoto?: { url: string };
  image?: { url: string };
  createdAt?: string;
  updatedAt?: string;
}

export interface BlogCms {
  cmsId: number;             // ID du blog dans le CMS
  displayOrder: number;      // Ordre d'affichage dans le CMS
  destinationLink?: string;  // Lien pour redirection
  title: string;
  description: string;
  creator?: string;
  creatorPhoto?: { url: string };
  imageUrl?: string;         // URL de l'image, déjà à plat pour le frontend
  createdAt?: string;
}

export interface PaginatedBlogs {
  content: BlogCms[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}
