export interface BlogDetails {
  id: number;
  title: string;
  content: string;
  creator: string;
  image: {
    id: number;
    filename: string;
    url: string;
    created_at: string;
  } | null;
  categories: Array<{
    id: number;
    name: string;
  }>;
  description: string;
  featured: boolean;
  createdAt: string;
  updatedAt: string;
  tags: Array<{
    id: number;
    name: string;
  }>;
  message: string;
}

export interface BlogCount {
  categoryName: string;
  count: number;
}

export interface category {
  id: number;
  name: string;
}

export interface tag {
  id: number;
  name: string;
}
