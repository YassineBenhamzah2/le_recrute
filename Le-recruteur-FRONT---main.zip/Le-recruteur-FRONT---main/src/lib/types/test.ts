// Test Difficulty Level
export type TestDifficulty = "EASY" | "MEDIUM" | "HARD";

// Test Status
export type TestStatus = "INACTIVE" | "DRAFT" | "ACTIVE";

// Test Category
export type TestCategory = "LANGUAGE" | "SKILL" | "PERSONALITY";

// Test Question Option
export interface TestQuestionOption {
  id: string;
  text: string;
  isCorrect: boolean;
  points: number;
}

// Test Question
export interface TestQuestion {
  id: string;
  type: string;
  question: string;
  points: number;
  options: TestQuestionOption[];
}

// Test Details
export interface Test {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  passedTestCount: number;
  category: TestCategory;
  difficulty: TestDifficulty;
  status: TestStatus;
  passingScore: number; // percentage
  created: string;
  lastUpdated: string;
  questions: TestQuestion[];
}

// Test Query Params
export interface GetTestsQuery {
  page?: number;
  limit?: number;
  search?: string;
  category?: TestCategory;
  difficulty?: TestDifficulty;
  status?: TestStatus;
  sortBy?: string;
  sortOrder?: "asc" | "desc";
}

// Test Create Request
export interface CreateTestRequest {
  title: string;
  description: string;
  duration: number;
  category: TestCategory;
  difficulty: TestDifficulty;
  status: TestStatus;
  passingScore: number;
  questions: Omit<TestQuestion, "id">[];
}

// Test Update Request
export interface UpdateTestRequest {
  title?: string;
  description?: string;
  duration?: number;
  category?: TestCategory;
  difficulty?: TestDifficulty;
  status?: TestStatus;
  passingScore?: number;
  questions?: TestQuestion[];
}

// Test Analytics
export interface TestAnalytics {
  totalTests: number;
  activeTests: number;
  draftTests: number;
  inactiveTests: number;
  averageScore: number;
  upcomingTests: number;
  totalAssignedTests: number;
  totalCompletedTests: number;
}

// Specific Test Analytics
export interface TestSpecificAnalytics {
  totalAttempts: number;
  avgCompletionTime: number; // in minutes
  completionRate: number; // percentage
  passRate: number; // percentage
  averageScore: number; // percentage
  questionPerformance: QuestionPerformance[];
}

// Question Performance Analytics
export interface QuestionPerformance {
  questionId: string;
  questionNumber: number;
  correctPercentage: number; // percentage of candidates who answered correctly
  avgTimeSpent: number; // average time in seconds
  totalResponses: number;
}

// Test Assignment
export interface TestAssignment {
  id: string;
  testId: string;
  candidateId: number;
  jobOfferId: number;
  assignedDate: string;
  dueDate: string;
  status: "ASSIGNED" | "IN_PROGRESS" | "COMPLETED" | "EXPIRED";
  score?: number;
}

// Test Assignment Request
export interface AssignTestRequest {
  testId: string;
  candidateIds: number[];
  jobOfferId: number;
  dueDate: string;
}

// Test Assignment Response
export interface AssignTestResponse {
  success: boolean;
  message: string;
  assignedTests: TestAssignment[];
}

// Test Top Performer
export interface TestTopPerformer {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  score: number; // percentage
  completionTime: number; // in minutes
  completedAt: string; // ISO date string
  avatar?: string; // optional avatar URL
}
