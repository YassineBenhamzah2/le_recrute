// Candidate Types
export interface Candidate {
    id: number;
    name: string;
    email: string;
    whatsapp_number: string;
    cv: string;
    motivationLetter: string;
    status: "EN_COURS" | "ACCEPTEE" | "REFUSEE";
    createdAt: string;
}
