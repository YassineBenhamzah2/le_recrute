import { Candidate } from "./candidat";
import { JobOffer } from "./jobOffer";

export interface JuryFeedback {
  observations: string;
  decision: "pending" | "approved" | "rejected";
}

// Extended Interview interface for the component (compatible with API)
export interface Interview {
  id: number;
  name: string;
  position: string;
  status:
    | "Scheduled"
    | "Completed"
    | "Cancelled"
    | "Pending"
    | "SCHEDULED"
    | "COMPLETED"
    | "CANCELLED";
  type: string;
  date: string;
  time: string;
  interviewers: string[];
  meetingLink: string;
  showActions: boolean;
  notes?: string;
  juryFeedback?: JuryFeedback;
  jobOffer?: JobOffer;
  candidate: Candidate;

  candidateName: string;
  jobTitle?: string;
  scheduledAt: string;
  endedAt: string;
  interviewType: string;
  address: string;
  myStatus: "SCHEDULED" | "COMPLETED" | "CANCELLED";
  interviewTitle: string;
  companyName: string;
  companyLogo: string;
  videoLink: string;
  round: string;
  cancelReason: string;
  duration: string;
}

export interface CreateInterviewRequest {
  // Required fields (used in the code)
  title: string;
  jobOfferId: number;
  candidateId: number;
  scheduledAt: string;
  endedAt: string;
  interviewType: string;
  interviewers: string[];
  juryDecision: string;
  address: string;
  observations: string;
  notes: string;
  status: string;
  duration: string;

  // Optional fields (not used in the provided code snippets)
  companyName?: string;
  companyLogo?: string;
  videoLink?: string;
  type?: string;
  round?: string;
  cancelReason?: string;
  date?: string;
  time?: string;
  jobOffer?: JobOffer;
  candidate?: Candidate;
}

export interface CandidateInterviewsParams {
  page?: number;
  size?: number;
  tab?: "SCHEDULED" | "CANCELLED" | "COMPLETED";
  search?: string;
}

export interface CandidateInterviewsStats {
  scheduled: number;
  completed: number;
  cancelled: number;
}

export interface CandidateScoreRequest {
  candidateId: number;
  diplomaScore: number;
  experienceScore: number;
  technicalSkillScore: number;
  softSkillScore: number;
}
export interface CandidateScoreResponse {
  diplomaScore: number;
  experienceScore: number;
  technicalSkillScore: number;
  softSkillScore: number;
  overAllScore: number;
}

export interface UpdateInterviewStatusRequest {
  status: "SCHEDULED" | "COMPLETED" | "CANCELLED";
}
