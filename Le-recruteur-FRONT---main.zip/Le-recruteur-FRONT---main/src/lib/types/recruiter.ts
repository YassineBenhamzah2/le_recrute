export interface Candidate {
  id: number;
  name: string;
  currentPosition: string;
  company: string;
  education: string;
  experience: string;
  location: string;
  skills: string[];
  certifications: string[];
  phone: string;
  email: string;
  status: string;
  lastUpdate: string;
  hasCV: boolean;
  cvId: number | null;
}

export interface Filters {
  name: string;
  positions: string[];
  educationLevels: string[];
  experienceLevels: string[];
  jobTypes: string[];
  sectors: string[];
  skills: string[];
  regions: string[];
  companies: string[];
  formations: string[];
  certifications: string[];
  cvStatus: string[];
  email: string;
  phone: string;
  address: string;
}

export interface FilterOptions {
  positions: string[];
  educationLevels: string[];
  experienceLevels: string[];
  jobTypes: string[];
  sectors: string[];
  skills: string[];
  regions: string[];
  companies: string[];
  formations: string[];
  certifications: string[];
}

export interface PaginatedResponse<T> {
  data: T[];
  totalPages: number;
  currentPage: number;
  totalCount: number;
}

export interface Document {
  id: number;
  filename: string;
  url: string;
  createdAt: string;
}