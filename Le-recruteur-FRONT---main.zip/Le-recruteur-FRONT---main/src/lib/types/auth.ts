/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  RegisterCandidateRequest,
  RegisterRecruiterRequest,
  RoleInfo,
} from "./base";

export interface User {
  id: number;
  email: string;
  firstname: string;
  lastname: string;
  role: RoleInfo; // Changed from string to RoleInfo object
  profilePicture?: string | null;
  accessToken: string;
  refreshToken: string;
  // Candidate specific fields
  candidateId?: number;
  profilePic?: string | null;
  // Recruiter specific fields
  recruiterId?: number;
  companyId?: number;
  companyLogoUrl?: string;
  phone?: string;
}

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: "full-time" | "part-time" | "contract" | "internship";
  salary: string;
  description: string;
  requirements: string[];
  postedBy: string;
  postedAt: string;
  status: "active" | "closed" | "draft";
  applicationsCount: number;
}

export interface Application {
  id: string;
  jobId: string;
  candidateId: string;
  candidateName: string;
  candidateEmail: string;
  status: "pending" | "reviewing" | "shortlisted" | "rejected" | "hired";
  appliedAt: string;
  resume?: string;
  coverLetter?: string;
}

export interface AuthContextType {
  sectors: Array<{ id: number; name: string }>;
  user: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<User>;
  logout: () => void;
  isLoading: boolean;
  registerCandidate: (data: RegisterCandidateRequest) => Promise<any>;
  registerRecruiter: (
    data: RegisterRecruiterRequest
  ) => Promise<{ user: User; accessToken: string; refreshToken: string }>;
  loadSectors: () => Promise<Array<{ id: number; name: string }>>;
  // Permission functions
  hasPermission: (permissionName: string) => boolean;
  hasAnyPermission: (permissionNames: string[]) => boolean;
  hasAllPermissions: (permissionNames: string[]) => boolean;
  isAdmin: () => boolean;
  isRecruiter: () => boolean;
  isCandidate: () => boolean;
}

export interface CompanyData {
  id: number;
  name: string;
  website: string;
  logo: string;
  about: string;
  responsibilities: Responsibility[];
  tags: Tag[];

  info: {
    industry: Sector;
    employeeCount: number;
    founded: string;
    status: string;
    score: number;
  };
  contact: {
    phone: string;
    email: string;
  };
  location: Location;
}

export interface Sector {
  id: number;
  name: string;
}

export interface Location {
  lat: number;
  lng: number;
  city: string;
  country: string;
  addriss: string;
}

export interface Tag {
  id: number;
  name: string;
}

export interface Responsibility {
  id: number | string;
  name: string;
}
