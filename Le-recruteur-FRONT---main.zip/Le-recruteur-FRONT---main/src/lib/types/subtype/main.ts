export const UserRoleList = ["CANDIDAT", "RECRUITER", "ADMIN"] as const;
export type UserRole = (typeof UserRoleList)[number];

export const InterviewTypeList = [
  "PHONE",
  "VIDEO",
  "IN_PERSON",
  "TECHNICAL",
  "HR",
] as const;
export type InterviewType = (typeof InterviewTypeList)[number];

export const InterviewStatusList = [
  "SCHEDULED",
  "COMPLETED",
  "CANCELLED",
] as const;
export type InterviewStatus = (typeof InterviewStatusList)[number];

export const JobTypeList = [
  "FULL_TIME",
  "PART_TIME",
  "CONTRACT",
  "INTERNSHIP",
  "FREELANCE",
] as const;
export type JobType = (typeof JobTypeList)[number];

export const JobStatusList = [
  "ACTIVE",
  "INACTIVE",
  "EXPIRED",
  "PAUSE",
  "PENDING",
] as const;
export type JobStatus = (typeof JobStatusList)[number];

export const ContractTypeList = [
  "CDI",
  "CDD",
  "CONTRACT_PROJECT",
  "CONTRACT_ANAPEC",
] as const;
export type ContractType = (typeof ContractTypeList)[number];

export const WorkModeList = ["PRESENTIEL", "HYBRID", "REMOTE"] as const;
export type WorkMode = (typeof WorkModeList)[number];

export const StatusApplicationList = [
  "EN_ATTENTE",
  "ACCEPTED",
  "REJECTED",
] as const;
export type StatusApplication = (typeof StatusApplicationList)[number];

export const DashboardFilterList = ["week", "all", "month"] as const;
export type DashboardFilter = (typeof DashboardFilterList)[number];
