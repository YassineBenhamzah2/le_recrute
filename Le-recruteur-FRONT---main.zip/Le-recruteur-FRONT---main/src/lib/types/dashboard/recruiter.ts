// Recruiter Dashboard Types
export interface DashboardStatistics {
    totalJobOffers: number;
    totalActiveJobOffers: number;
    scheduledInterviews: number;
    candidateRating: number;
    hiringSuccess: number;
    avgResponseTime: string;
}

export interface DashboardJobOfferApplication {
    title: string;
    numberOfApplications: number;
}

export interface DashboardInterview {
    id: number;
    candidateName: string;
    scheduledAt: string;
    endedAt: string;
    status: "SCHEDULED" | "COMPLETED" | "CANCELLED";
}

export interface JobStatistics {
    totalJobs: number;
    activeJobs: number;
    pausedJobs: number;
    totalApplications: number;
}

export interface InterviewStatistics {
    totalInterviews: number;
    interviewsScheduled: number;
    interviewsCompleted: number;
    interviewsToday: number;
}