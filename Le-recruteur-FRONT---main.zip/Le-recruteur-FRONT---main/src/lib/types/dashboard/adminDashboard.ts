import { ReactNode } from "react";

export interface AnalyticsCardProps {
  title: string;
  value: string;
  subtitle: string;
  trend: number;
  icon: ReactNode;
  gradient: string;
  chartColor: string;
}

export interface SpendingCardProps {
  title: string;
  amount: string;
  period: string;
  trend: number;
  gradient: string;
}

export interface ServiceItemProps {
  name: string;
  percentage: string;
  amount: string;
  color: string;
}

export interface AdminDashboardProps {
  section?: string;
}

export type AnalyticsCardDTO = { title: string; value: string };

export type TopServiceDTO = {
  serviceName: string;
  totalRevenue: number | string;
  percentageOfTotal: number;
};

export type DashboardDTO = {
  totalUsers?: AnalyticsCardDTO;
  revenue?: AnalyticsCardDTO;
  activeJobs?: AnalyticsCardDTO;
  growthRate?: AnalyticsCardDTO;
  jobsSpendingThisMonth?: string | number;
  actualSpendThisMonth?: string | number;
  averageDailyCost?: string | number;
  yesterdaySpend?: string | number;
  lastMonthSpend?: string | number;
  currencyYearly?: string | number;
  topServices?: TopServiceDTO[];
  postStatistics?: Record<string, number>;
  totalActiveUsers?: number;
} | null;
