import { ZodNumberCheck } from "zod";

export interface CandidateDashboardTotals {
  totalTests: number;
  testsLastWeek: number;
  totalInterviews: number;
  scheduledInterviews: number;
  profileCompletion: number;
}

export interface UpcomingInterview {
  interviewTitle: string;
  companyName: string;
  duration: string;
  scheduledAt: string;
}

export interface RecentApplication {
  title: string;
  companyLogo: string;
  companyName: string;
  jobType: 'FULL_TIME' | 'PART_TIME' | 'FREELANCE' | 'INTERNSHIP';
  location: string;
  publicationDate: string;
  minSalary: number;
  maxSalary: number;
}

export interface CandidateDashboardData {
  totals: CandidateDashboardTotals;
  upcomingInterviews: UpcomingInterview[];
  recentApplications: RecentApplication[];
}

export interface CandidateDashboardResponse {
  success: boolean;
  code: number;
  message: string;
  data: CandidateDashboardData;
}

export interface Preference{
   role_type:string;
   desired_role:string;
}

export interface Postulation {
  status: string;
  appliedDate: string;
  jobOffer?: {
    title: string;
    // autres propriétés de l'offre d'emploi si nécessaire
  };
}

export interface Experience {
  id: number;
  role: string;
  company: string;
  startDate: string;
  endDate: string;
  currentWork:boolean;
  ExperienceLevel:string;
}

export interface Candidate {
  id: number;
  firstname: string;
  lastname: string;
  email: string;
  phone: string;
  status:string;
  experiences:Experience[]; 
}

export interface CandidatesResponse {
  success: boolean;
  message: string;
  data: Candidate[];
  metadata?: {
    page: number;
    size: number;
    totalElements: number;
    totalPages: number;
}
}

export interface statisticsCandidat{
   totalCandidates: number;
   totalCandidatesTrend:number;
   newApplications:number;
   newApplicationsTrend:number;
   pendingDecisions:number;
   approvalRate:number;
   approvalRateTrend:number

}