import { Role } from "../license";

export interface Admins {
  firstname: string;
  lastname: string;
  email: string;
  phone: string;
  location: string;
  profile_pic: string;
  status: "active" | "inactive";
  role: Role;
}

export interface Admin extends Admins {
  password: string;
  roleId: number;
  createdAt: string;
}
