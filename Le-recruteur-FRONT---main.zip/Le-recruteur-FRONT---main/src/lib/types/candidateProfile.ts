// Types for profile Candidate
export interface CandidateProfile {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    location: string;
    title: string;
    profileImage?: string;
    linkedinUrl?: string;
    overview: string;
    careerHighlights: string[];
    profileViews: number;
    applicationsCount: number;
    profileCompletion: number;
}

// Types for Skills
export interface Skill {
    id: string;
    name: string;
    level: number; // 0-100
    category: 'technical' | 'language' | 'soft-skill';
    createdAt: Date;
}
  
export interface SkillCategory {
    technical: Skill[];
    language: Skill[];
    softSkill: Skill[];
}
  
// Types for Education
export interface Education {
    id: string;
    title: string;
    institution: string;
    location: string;
    startDate: Date;
    endDate?: Date;
    description?: string;
    logo?: string;
}
  
// Types for Certifications
export interface Certification {
    id: string;
    name: string;
    issuedBy: string;
    industry: string;
    jobFunction: string;
    credentialId?: string;
    credentialUrl?: string;
    issueDate: Date;
    expirationDate?: Date;
}
  
// Types for professional Experience
export interface WorkExperience {
    id: string;
    position: string;
    company: string;
    location: string;
    startDate: Date;
    endDate?: Date;
    isCurrent: boolean;
    industry: string;
    jobFunction: string;
    description: string;
    workplaceRating?: number; // 1-5 stars
    skills: string[];
    achievements: string[];
}
  
// Types for Forms
export interface SkillFormData {
    name: string;
    category: 'Skills' | 'Languages' | 'Soft Skills';
    level: number;
}
  
export interface EducationFormData {
    title: string;
    school: string;
    location: string;
    startDate: string;
    endDate: string;
}
  
export interface CertificationFormData {
    certificationName: string;
    issuedBy: string;
    industry: string;
    jobFunction: string;
    credentialId: string;
    issueDate: string;
    expirationDate: string;
}
  
export interface ExperienceFormData {
    position: string;
    company: string;
    industry: string;
    jobFunction: string;
    location: string;
    startDate: string;
    endDate: string;
    description: string;
}
  
// Types for profile stats
export interface ProfileStats {
    views: number;
    applications: number;
    completionPercentage: number;
    lastUpdated: Date;
}
  
// Type for tabs
  export type ProfileTab = 'Overview' | 'Experience' | 'Education' | 'Skills';
  
// Types for quick Action
export interface QuickAction {
    id: string;
    label: string;
    icon: React.ReactNode;
    action: () => void;
    variant?: 'primary' | 'secondary' | 'outline';
}