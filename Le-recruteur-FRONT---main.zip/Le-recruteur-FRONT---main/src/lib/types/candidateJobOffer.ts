export interface CandidateJobOffer {
    id: number;
    title: string;
    description: string;
    location: string;
    contractType: string;
    jobType: string;
    workMode: string;
    minSalary: number;
    maxSalary: number;
    currency: string;
    negotiable: boolean;
    publicationDate: string;
    deadlineDate: string;
    status: string;
    isBookmarked: boolean;
    isApplied: boolean; 
    bonus: string;
    requirements: string[];
    questions: string[];
    questionsIds: number[];
    company: {
      id: number;
      name: string;
      sector: string | null;
      logo: string | null;
      address: string | null;
      phone: string | null;
      numEmployees: number | null;
      location: string | null;
      website: string | null;
      country: string | null;
      city: string | null;
      description: string | null;
      logoUrl: string | null;
      lat: number | null;
      lng: number | null;
      score: number | null;
      createdAt: string | null;
      jobOffers: any[] | null;
      saved: boolean;
    };
  }

  export interface JobFilters {
    keyword: string;
    contractTypes: string[];
    salaryRanges: string[];
    jobCategories: string[];
    industries: string[];
    educationLevels: string[];
    experienceLevels: string[];
    locations: string[];
    companyName: string;
    requiredLanguages: string[];
    workplaceTypes: string[];
    applicationDeadline: string;
    startDateAvailabilities: string[];
    mobilityRequirements: string[];
    numberOfVacancies: string[];
  }