import { InterviewStatus } from "./subtype/main";

// Base API Response Types
export interface ApiResponse<T> {
  success: boolean;
  code: number;
  data: T;
  metadata?: {
    pagination?: PaginationMetadata;
  };
  message?:string;
  totalCount?: number,
  totalPages?: number,
  hasNextPage?: boolean,
  hasPreviousPage?: boolean


}
export interface ApiError {
  success: false;
  code: number;
  error: {
    message: string;
  };
}

// Auth-specific types
export interface RoleInfo {
  id: number; // Role ID for fetching permissions
  name: string; // Display name of the role (e.g., "SUPER_ADMIN", "RECRUITER_PREMIUM")
  type: "ADMIN" | "RECRUITER" | "CANDIDATE"; // Navigation type
  permissions?: PermissionInfo[]; // User's permissions
}

export interface PermissionInfo {
  id: number;
  name: string;
  description?: string;
  permissionType: "ADMIN" | "RECRUITER" | "CANDIDATE";
}

export interface User {
  id: number;
  firstname: string;
  lastname: string;
  email: string;
  role: RoleInfo; // Changed from UserRole to RoleInfo object
  createdAt?: string;
}

export type UserRole = "CANDIDATE" | "RECRUITER" | "ADMIN";

// Auth request types
export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterCandidateRequest {
  firstname: string;
  lastname: string;
  email: string;
  password: string;
}

export interface RegisterRecruiterRequest {
  firstname: string;
  lastname: string;
  email: string;
  phone: string;
  password: string;
  licenseKey: string; // Required for recruiters
  position?: string;
  entreprise: string;
  localisation: string;
  description: string;
  sectorOfActivity: string;
  logo: File;
  agreeToTerms: boolean;
}

// Auth response types
export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface LoginResponse extends AuthTokens {
  user: User;
}

export interface RegisterCandidateResponse extends AuthTokens {
  userId: number;
}

export interface RegisterRecruiterResponse extends AuthTokens {
  recruiterId: number;
  firstname: string;
  lastname: string;
  email: string;
  companyLogoUrl?: string;
}

// Sector types
export interface Sector {
  id: number;
  name: string;
}

export interface PaginationMetadata {
  page: number;
  pageSize: number;
  totalPages: number;
  totalItems: number;
}

// Common Query Parameters
export interface PaginationQuery {
  search?: string;
  page?: number;
  paginated?: boolean;
}

export interface GetRecruiterJobsQuery extends PaginationQuery {
  jobType?: string;
  status?: string;
  location?: string;
}

export interface GetInterviewsQuery {
  startTime?: string;
  endTime?: string;
}

export interface GetRecruiterInterviewsQuery {
  status?: InterviewStatus;
  datetime?: string;
}

export interface GetJobCandidatesQuery {
  jobOfferId: number;
  page?: number;
}
// Request Types for Landing Page
export interface GetCompanysQuery extends PaginationQuery {
  sector?: string;
  address?: string;
  jobTypes?: string;
  contractTypes?: string;
  tags?: string;
}

export interface GetBlogsQuery {
  page?: number;
  size?: number;
  categoryId?: number;
  tagId?: number;
  status?: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  featured?: boolean;
  search?: string;
  sortBy?: "createdAt" | "updatedAt" | "title";
  sortOrder?: "asc" | "desc";
}

export interface GetServicesQuesry {
  page?: number;
  size?: number;
  featured?: boolean;
  search?: string;
  sortBy?: "createdAt" | "updatedAt" | "title";
  sortOrder?: "asc" | "desc";
}
