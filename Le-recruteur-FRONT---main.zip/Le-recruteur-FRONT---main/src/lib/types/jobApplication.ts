import { Candidate } from "./candidat";
import { JobOffer } from "./jobOffer";

// Job Application interfaces
export interface JobApplication {
  id: number;
  candidate: Candidate;
  jobOffer: JobOffer;
  status: JobApplicationStatus;
  appliedDate: string;
  cvUrl?: string;
  motivationLetterUrl?: string;
  score?: number;
  testAssignments?: JobApplicationTestAssignment[];
}

export type JobApplicationStatus =
  | "APPLIED"
  | "UNDER_REVIEW"
  | "SHORTLISTED"
  | "TEST_ASSIGNED"
  | "TEST_COMPLETED"
  | "INTERVIEW_SCHEDULED"
  | "INTERVIEW_COMPLETED"
  | "OFFER_SENT"
  | "OFFER_ACCEPTED"
  | "OFFER_DECLINED"
  | "REJECTED";

export interface JobApplicationTestAssignment {
  id: string;
  testId: string;
  testName: string;
  assignedDate: string;
  dueDate: string;
  status: "ASSIGNED" | "IN_PROGRESS" | "COMPLETED" | "EXPIRED";
  score?: number;
}

// Job Application Query Parameters
export interface GetJobApplicationsQuery {
  jobOfferId?: number;
  status?: JobApplicationStatus;
  page?: number;
  limit?: number;
  search?: string;
  sortBy?: string;
  sortOrder?: "asc" | "desc";
}

// Update job application request
export interface UpdateJobApplicationRequest {
  status?: JobApplicationStatus;
  score?: number;
}
