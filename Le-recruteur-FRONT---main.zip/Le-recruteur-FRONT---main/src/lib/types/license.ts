// License-related types
export interface License {
  id: number;
  licenseKey: string;
  name: string;
  description?: string;
  price: number;
  status: LicenseStatus;
  createdAt: string;
  updatedAt: string;
  expirationDate: string;
  role: Role;
  assignedUser?: {
    id: number;
    firstname: string;
    lastname: string;
    email: string;
  };
}

// License statistics from API
export interface LicenseStatistics {
  totalLicenses: number;
  activeLicenses: number;
  expiredLicenses: number;
  suspendedLicenses: number;
  assignedLicenses: number;
  unassignedLicenses: number;
  totalRevenue: number;
  monthlyRevenue: number;
  expiringThisMonth: number;
  recentActivity: number;
}

export type LicenseStatus = "ACTIVE" | "SUSPENDED" | "EXPIRED";

// Role-related types
export interface Role {
  id: number;
  name: string;
  description?: string;
  roleType: RoleType;
  permissions: Permission[];
}

export type RoleType = "ADMIN" | "RECRUITER" | "CANDIDATE";

// Permission-related types
export interface Permission {
  id: number;
  name: string;
  description?: string;
  permissionType: PermissionType;
}

export type PermissionType = "ADMIN" | "RECRUITER" | "CANDIDATE";

// License validation types
export interface LicenseValidationRequest {
  licenseKey: string;
}

export interface LicenseValidationResponse {
  isValid: boolean;
  license?: License;
  message: string;
}

// License management requests
export interface CreateLicenseRequest {
  name: string;
  description?: string;
  price: number;
  roleId: number;
  expirationDate: string;
}

export interface UpdateLicenseRequest extends Partial<CreateLicenseRequest> {
  id: number;
  status?: LicenseStatus;
}

// Role permission management
export interface AssignPermissionsRequest {
  roleId: number;
  permissionIds: number[];
}

// Enhanced user type with permissions
export interface UserWithPermissions {
  id: number;
  email: string;
  firstname: string;
  lastname: string;
  role: string;
  permissions: string[];
  licenseKey?: string;
  license?: License;
  profilePicture?: string | null;
  accessToken: string;
  refreshToken: string;
  candidateId?: number;
  recruiterId?: number;
  companyId?: number;
}

// Enhanced registration request for recruiters
export interface RegisterRecruiterWithLicenseRequest {
  firstname: string;
  lastname: string;
  email: string;
  phone: string;
  password: string;
  licenseKey: string; // Required for recruiters
  position?: string;
  companyName: string;
  location: string;
  companyDescription: string;
  companySectorId: number;
  logo: File;
}
