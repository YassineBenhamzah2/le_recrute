export interface AdSpace {
  id: number;
  title: string;
  description: string;
  link: string;
  imageUrl: string;
}

export interface PaginatedAdSpaces {
  content: AdSpace[];
  totalElements: number;
  totalPages: number;
  page: number;
  size: number;
}
