export interface FAQ {
    id: number;
    question: string;
    answer: string;
    type: "GENERAL" | "JOB" | "PAYMENT";
}
export interface ContactFormRequest {
    name: string;
    email: string;
    subject: string;
    message: string;
}
export interface ContactFormResponse {
    id: number;
    name: string;
    email: string;
    subject: string;
    message: string;
}
