export interface CompanyJobOffer {
    id: number;
    title: string;
    description: string;
    location: string;
    salary: string;
    jobType: string;
    workMode: string;
    publicationDate: string;
    minSalary: string;
    maxSalary: string;
    salaryType: string;
    tags: string[];
    isBookmarked: boolean;
}