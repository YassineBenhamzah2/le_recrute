// Analytics data types

// Platform engagement metrics
export interface PlatformEngagement {
  uniqueVisitors: number;
  averageSessionDuration: string; // Format: "3m 45s"
  peakActivityWindow: string; // Format: "14:00 - 16:00"
  returningUsers: number; // As percentage
  totalInteractions: number;
  averagePageViews: number;
  deviceDistribution: {
    desktop: number; // As percentage
    mobile: number; // As percentage
  };
  bounceRate: number; // As percentage
}

// User distribution by location
export interface UserDistribution {
  region: string;
  city: string;
  registeredUsers: number;
  percentageOfTotal: number;
  mostCommonRole: string;
}

// Internal activity (employee performance)
export interface InternalActivity {
  name: string;
  role: string;
  tasksCompleted: number;
  avgResponseTime: string; // Format: "1h 30m"
  engagementScore: number;
  lastActivity: string; // Format: "Jul 22, 2024 - 11:45"
}

// Recruitment activity chart data
export interface RecruitmentActivity {
  monthlyTrends: {
    month: string;
    applications: number;
    jobs: number;
  }[];
  totalJobsPosted: number;
  totalApplications: number;
  applicationToJobRatio: number;
  conversionRate: number;
  mostActiveCategory: string;
}

// Complete analytics dashboard data
export interface AnalyticsDashboardData {
  platformEngagement: PlatformEngagement;
  recruitmentActivity: RecruitmentActivity;
  userDistribution: UserDistribution[];
  internalActivity: InternalActivity[];
  lastUpdated: string; // ISO date string
}

// Analytics query parameters
export interface AnalyticsQuery {
  startDate?: string; // ISO date string
  endDate?: string; // ISO date string
  region?: string;
  filterBy?: string;
}

// Google Analytics specific metrics
export interface GAMetrics {
  pageViews: number;
  uniquePageViews: number;
  avgTimeOnPage: number;
  entrances: number;
  bounceRate: number;
  exitRate: number;
}

// Web interaction tracking data
export interface WebInteractionData {
  totalApiCalls: number;
  searchInteractions: number;
  webMutations: number;
  mostAccessedEndpoints: {
    endpoint: string;
    count: number;
  }[];
  averageResponseTime: number; // in milliseconds
}

// Google Analytics Page Path Data
export interface GAPagePathData {
  pagePath: string;
  screenClass: string;
  activeUsers: number;
  views: number;
}

// Google Analytics Event Distribution
export interface GAEventDistribution {
  eventName: string;
  count: number;
}
