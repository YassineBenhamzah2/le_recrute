// Response types for candidate data
export interface QuestionAnswerResponse {
  questionId: number;
  question: string;
  answer: string;
}

export interface SkillResponse {
  id: number;
  name: string;
  level?: string; // e.g. "Beginner", "Intermediate", "Expert"
  years?: number;
}

export interface EducationResponse {
  id: number;
  institution: string;
  degree: string;
  fieldOfStudy: string;
  startDate: string;
  endDate?: string;
  description?: string;
  isCurrentlyStudying?: boolean;
}

export interface ExperienceResponse {
  id: number;
  company: string;
  position: string;
  location?: string;
  startDate: string;
  endDate?: string;
  description?: string;
  isCurrentPosition?: boolean;
}

export interface CertificationResponse {
  id: number;
  name: string;
  issuingOrganization: string;
  issueDate?: string;
  expirationDate?: string;
  credentialId?: string;
  credentialUrl?: string;
}

export interface LanguageResponse {
  id: number;
  language: string;
  proficiencyLevel: string; // e.g. "Beginner", "Intermediate", "Advanced", "Native"
}

// Main candidate interface matching the backend structure
export interface CandidateResponse {
  id: number;
  name: string;
  email: string;
  whatsapp_number?: string;

  // Application-specific info
  cv?: string;
  motivationLetter?: string;
  status?: string; // "EN_COURS", "ACCEPTEE", or "REFUSEE"
  createdAt: string;

  // Additional candidate profile info
  nationality?: string;
  familyStatus?: string;
  childrenNumber?: number;
  address?: string;
  city?: string;
  region?: string;
  country?: string;
  linkedIn?: string;
  bio?: string;
  experienceLevel?: string;
  availability?: string;
  mobility?: string;
  profileCompletion?: number;
  overview?: string;

  // Candidate's answers to job offer questions
  answers?: QuestionAnswerResponse[];

  // Skills, education, experience
  skills?: SkillResponse[];
  education?: EducationResponse[];
  experiences?: ExperienceResponse[];
  certifications?: CertificationResponse[];
  languages?: LanguageResponse[];

  // Application score if available
  score?: number;
}
