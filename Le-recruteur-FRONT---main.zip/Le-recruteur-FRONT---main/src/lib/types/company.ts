import { JobOffer } from "./jobOffer";

export interface Company {
  id: number;
  name: string;
  sector: string;
  logo: string;
  address: string;
  numEmployees: number;
  location: string | null;
  phone: string;
  website: string | null;
  country: string | null;
  city: string | null;
  description: string;
  logoUrl: string | null;
  lat: number;
  lng: number;
  score: number;
  createdAt: string;
  jobOffers: JobOffer[] | null;
  saved: boolean;
  order?: number;
}

export interface CompanyDetails extends Company {
  website: string | null;
  description: string;
  responsibilities: string[];
  experience: string;
  phone: string;
  email: string;
  lat: number;
  lng: number;
  isSaved: boolean;
  jobOffers: JobOffer[] | null;
}

// src/lib/types/company.ts

export interface AdminCompanyCmsResponse {
  id: string | number | readonly string[] | undefined;
  cmsId: number;        // ID du CMS (CompanyCms)
  companyId: number;    // ID réel de la Company
  name: string;
  description?: string;
  logoUrl?: string | null;
  displayOrder: number;
  destinationLink?: string;
}

export interface PaginatedCmsCompanies {
  content: AdminCompanyCmsResponse[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}