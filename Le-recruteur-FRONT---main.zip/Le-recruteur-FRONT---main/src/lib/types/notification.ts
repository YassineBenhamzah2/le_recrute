export interface Notification {
  id: number;
  notificationType: string;
  title: string;
  description: string;
  isRead: boolean;
  createdAt: string;
}

// We can also add a type for the unread count response for consistency
export interface UnreadCountResponse {
  count: number;
}