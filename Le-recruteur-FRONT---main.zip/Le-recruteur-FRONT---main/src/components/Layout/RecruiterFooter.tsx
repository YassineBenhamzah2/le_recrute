import { Trans } from '@lingui/macro';
import React from 'react';

const RecruiterFooter: React.FC = () => {
    const currentYear = new Date().getFullYear();
    
    return (
        <footer className="bg-white text-gray-800 py-4 text-center w-full border-t">
            <div className="container mx-auto">
                <p>
                    <Trans id="footer.copyright">
                        © {currentYear} EHX RECRUITE. All Rights Reserved.
                    </Trans>
                </p>
            </div>
        </footer>
    );
};

export default RecruiterFooter;