import { Trans, t } from "@lingui/macro";
import { ChevronDown, LogOut } from "lucide-react";
import React, { useEffect, useRef, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { useLocale } from "../../contexts/LocaleContext";
import { settings } from "@/lib/settings/main";

const AdminHeader: React.FC = () => {
  const { user, logout } = useAuth();
  const { locale, setLocale, supportedLocales } = useLocale();
  const [isSigningOut, setIsSigningOut] = useState(false);
  const [languageDropdown, setLanguageDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const currentLanguage = supportedLocales[locale];

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setLanguageDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Handles the sign-out process
  const handleSignOut = async () => {
    setIsSigningOut(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      await logout();
    } catch (error) {
      console.error("Logout error:", error);
      setIsSigningOut(false);
    }
  };

  return (
    <div className="flex items-center justify-end w-full">
      <div className="flex items-center space-x-6">
        {/* Language Selector */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setLanguageDropdown(!languageDropdown)}
            className="flex items-center space-x-2 p-3 text-gray-600 hover:text-[#238D94] hover:bg-gray-50 rounded-xl transition-colors duration-200"
          >
            <img
              src={currentLanguage.flag}
              alt={currentLanguage.name}
              className="w-5 h-5 rounded-sm object-cover"
            />
            <span className="text-sm font-medium">{currentLanguage.code}</span>
            <ChevronDown
              size={16}
              className={`transition-transform duration-200 ${
                languageDropdown ? "rotate-180" : ""
              }`}
            />
          </button>

          {/* Language Dropdown */}
          {languageDropdown && (
            <div className="absolute right-0 top-full mt-2 w-40 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-50">
              {Object.values(supportedLocales).map((language) => (
                <button
                  key={language.code}
                  className={`w-full text-left px-4 py-3 text-sm hover:bg-gray-50 flex items-center space-x-3 transition-colors ${
                    locale === language.code
                      ? "bg-[#238D94]/10 text-[#238D94]"
                      : "text-gray-700"
                  }`}
                  onClick={() => {
                    setLocale(language.code);
                    setLanguageDropdown(false);
                  }}
                >
                  <img
                    src={language.flag}
                    alt={language.name}
                    className="w-5 h-5 rounded-sm object-cover"
                  />
                  <span className="font-medium">{language.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* User Profile Section */}
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <p className="text-base font-semibold text-gray-900">
              {user?.firstname ||
                t({ id: "admin.header.default_admin", message: "Admin" })}{" "}
              {user?.lastname ||
                t({ id: "admin.header.default_user", message: "User" })}
            </p>
            <p className="text-sm text-gray-500">
              {user?.role.name ||
                t({
                  id: "admin.header.default_role",
                  message: "Super Administrator",
                })}
            </p>
          </div>

          {/* Profile Dropdown */}
          <div className="relative group">
            <div className="w-10 h-10 rounded-full overflow-hidden shadow-lg">
              <img
                src={
                  user?.profilePicture
                    ? `${settings.IMG_ADDRESS}${user.profilePicture}`
                    : settings.DEFAULT_USER_AVATAR
                }
                alt="Profile image"
                onError={(e) => {
                  e.currentTarget.src = settings.DEFAULT_USER_AVATAR ;
                }}
                className="w-full h-full object-cover"
              />
            </div>


            {/* Dropdown Menu - appears on hover */}
            <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-gray-100 py-3 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
              <button
                onClick={handleSignOut}
                disabled={isSigningOut}
                className="flex items-center w-full text-left space-x-3 px-6 py-3 text-sm text-red-600 hover:bg-red-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSigningOut ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-600"></div>
                ) : (
                  <LogOut size={16} />
                )}
                <span>
                  {isSigningOut ? (
                    <Trans id="admin.header.signing_out">Signing Out...</Trans>
                  ) : (
                    <Trans id="admin.header.sign_out">Sign Out</Trans>
                  )}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminHeader;
