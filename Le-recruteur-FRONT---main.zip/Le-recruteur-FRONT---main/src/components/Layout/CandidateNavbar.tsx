import { settings } from "@/lib/settings/main";
import { Home, LogOut, User } from "lucide-react";
import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import CandidateNotificationBell from "../CandidateComponents/CandidateNotificationBell";
import { Trans } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { ChevronDown } from "lucide-react";
import { useLocale } from "../../contexts/LocaleContext";

const CandidateNavbar: React.FC = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isSigningOut, setIsSigningOut] = useState(false);
  const { locale, setLocale, supportedLocales } = useLocale();
  const [languageDropdown, setLanguageDropdown] = useState(false);
  const languageDropdownRef = useRef<HTMLDivElement>(null);

  const currentLanguage = supportedLocales[locale];

  const dropdownRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { i18n } = useLingui();
  const isRTL = i18n.locale === "ar"; // Vérifie si la langue est arabe
  const { user, logout } = useAuth();
  const fullname = user?.firstname + " " + user?.lastname;
  console.log(user);
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  //close languages when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        languageDropdownRef.current &&
        !languageDropdownRef.current.contains(event.target as Node)
      ) {
        setLanguageDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Handle sign out
  const handleSignOut = async () => {
    setIsSigningOut(true);
    try {
      // Add 1 second delay to show the animation
      await new Promise((resolve) => setTimeout(resolve, 1000));
      await logout();
    } catch (error) {
      console.error("Logout error:", error);
      setIsSigningOut(false);
    }
  };

  return (
    <nav
      className={`bg-white border-b border-gray-100 px-6 py-3 ${
        isRTL ? "mr-[7%]" : "ml-[7%]"
      } max-w-[93%]`}
    >
      <div
        className={`flex items-center justify-between ${
          isRTL ? "flex-row-reverse" : ""
        }`}
      >
        {/* Left side - Back/Home + Search (droite pour arabe) */}
        <div
          className={`flex items-center gap-3 flex-1 ${
            isRTL ? "justify-end" : ""
          }`}
        >
          {isRTL ? (
            // Pour l'arabe: Profil à gauche
            <div className="flex items-center space-x-3">
              {/* Language Selector */}
              <div className="relative" ref={languageDropdownRef}>
                <button
                  onClick={() => setLanguageDropdown(!languageDropdown)}
                  className="flex items-center space-x-2 p-2 text-gray-600 hover:text-[#238D94] hover:bg-gray-50 rounded-md transition-colors duration-200"
                >
                  <img
                    src={currentLanguage.flag}
                    alt={currentLanguage.name}
                    className="w-5 h-5 rounded-sm object-cover"
                  />
                  <span className="text-sm font-medium">
                    {currentLanguage.code}
                  </span>
                  <ChevronDown
                    size={16}
                    className={`transition-transform duration-200 ${
                      languageDropdown ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {languageDropdown && (
                  <div className="absolute right-0 top-full mt-2 w-40 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-50">
                    {Object.values(supportedLocales).map((language) => (
                      <button
                        key={language.code}
                        className={`w-full text-left px-4 py-3 text-sm hover:bg-gray-50 flex items-center space-x-3 transition-colors ${
                          locale === language.code
                            ? "bg-[#238D94]/10 text-[#238D94]"
                            : "text-gray-700"
                        }`}
                        onClick={() => {
                          setLocale(language.code);
                          setLanguageDropdown(false);
                        }}
                      >
                        <img
                          src={language.flag}
                          alt={language.name}
                          className="w-5 h-5 rounded-sm object-cover"
                        />
                        <span className="font-medium">{language.name}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <CandidateNotificationBell />

              {/* Profile with Dropdown */}
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="flex items-center space-x-2 p-1 text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
                >
                  <div className="w-8 h-8 overflow-hidden rounded-[5px]">
                    <img
                      src={
                        user?.profilePicture
                          ? `${settings.IMG_ADDRESS}${user.profilePicture}`
                          : ""
                      }
                      alt="Profile"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-sm font-medium">
                    {fullname || <Trans>candidate user</Trans>}
                  </span>
                </button>

                {/* Dropdown Menu */}
                {isDropdownOpen && (
                  <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-100 py-1 z-50">
                    <button className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                      <User className="h-4 w-4 mr-3" />
                      <Trans>View Profile</Trans>
                    </button>
                    <hr className="my-1 border-gray-200 mx-2" />
                    <button
                      className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      onClick={handleSignOut}
                      disabled={isSigningOut}
                    >
                      {isSigningOut ? (
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-600 mr-3"></div>
                      ) : (
                        <LogOut className="h-4 w-4 mr-3" />
                      )}
                      {isSigningOut ? (
                        <Trans>Signing Out...</Trans>
                      ) : (
                        <Trans>Sign Out</Trans>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            // Pour les autres langues: Home à gauche
            <div className="flex items-center mr-2">
              <button
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors"
                onClick={() => navigate("/")}
                aria-label="Home"
              >
                <Home className="h-5 w-5 text-gray-600" />
              </button>
            </div>
          )}
        </div>

        {/* Right side - Actions (gauche pour arabe) */}
        <div
          className={`flex items-center space-x-3 ${
            isRTL ? "flex-row-reverse" : ""
          }`}
        >
          {isRTL ? (
            // Pour l'arabe: Home à droite
            <div className="flex items-center mr-2">
              <button
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors"
                onClick={() => navigate("/")}
                aria-label="Home"
              >
                <Home className="h-5 w-5 text-gray-600" />
              </button>
            </div>
          ) : (
            // Pour les autres langues: Profil à droite
            <>
              {/* Language Selector */}
              <div className="relative" ref={languageDropdownRef}>
                <button
                  onClick={() => setLanguageDropdown(!languageDropdown)}
                  className="flex items-center space-x-2 p-2 text-gray-600 hover:text-[#238D94] hover:bg-gray-50 rounded-md transition-colors duration-200"
                >
                  <img
                    src={currentLanguage.flag}
                    alt={currentLanguage.name}
                    className="w-5 h-5 rounded-sm object-cover"
                  />
                  <span className="text-sm font-medium">
                    {currentLanguage.code}
                  </span>
                  <ChevronDown
                    size={16}
                    className={`transition-transform duration-200 ${
                      languageDropdown ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {languageDropdown && (
                  <div className="absolute right-0 top-full mt-2 w-40 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-50">
                    {Object.values(supportedLocales).map((language) => (
                      <button
                        key={language.code}
                        className={`w-full text-left px-4 py-3 text-sm hover:bg-gray-50 flex items-center space-x-3 transition-colors ${
                          locale === language.code
                            ? "bg-[#238D94]/10 text-[#238D94]"
                            : "text-gray-700"
                        }`}
                        onClick={() => {
                          setLocale(language.code);
                          setLanguageDropdown(false);
                        }}
                      >
                        <img
                          src={language.flag}
                          alt={language.name}
                          className="w-5 h-5 rounded-sm object-cover"
                        />
                        <span className="font-medium">{language.name}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <CandidateNotificationBell />

              {/* Profile with Dropdown */}
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="flex items-center space-x-2 p-1 text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
                >
                  <span className="text-sm font-medium">
                    {user?.firstname + " " + user?.lastname || (
                      <Trans>candidate user</Trans>
                    )}
                  </span>
                  <div className="w-8 h-8 overflow-hidden rounded-[5px]">
                    <img
                      src={
                        user?.profilePicture
                          ? `${settings.IMG_ADDRESS}${user.profilePicture}`
                          : settings.DEFAULT_USER_AVATAR
                      }
                      alt="Profile"
                      onError={(e) => {
                        e.currentTarget.src = settings.DEFAULT_USER_AVATAR ;
                      }}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </button>

                {/* Dropdown Menu */}
                {isDropdownOpen && (
                  <div className="absolute  'right-0' mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-100 py-1 z-50">
                    <button
                      className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                      onClick={() => navigate("profile")}
                    >
                      <User className="h-4 w-4 mr-3" />
                      <Trans>View Profile</Trans>
                    </button>
                    <hr className="my-1 border-gray-200 mx-2" />
                    <button
                      className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      onClick={handleSignOut}
                      disabled={isSigningOut}
                    >
                      {isSigningOut ? (
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-600 mr-3"></div>
                      ) : (
                        <LogOut className="h-4 w-4 mr-3" />
                      )}
                      {isSigningOut ? (
                        <Trans>Signing Out...</Trans>
                      ) : (
                        <Trans>Sign Out</Trans>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default CandidateNavbar;
