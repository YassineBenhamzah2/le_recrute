import {
  BarChart3,
  Calendar,
  FileText,
  Home,
  User,
  Presentation,
  Users,
} from "lucide-react";
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Trans } from "@lingui/macro";
import { useLingui } from "@lingui/react";
import { useAuth } from "@/contexts/AuthContext";

const RecruiterSidebar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const currentPathname = location.pathname;
  const { i18n } = useLingui();
  const { user, hasPermission } = useAuth();
  const isRTL = i18n.locale === "ar";
  console.log("User :", user);

  // Define all menu items with their required permissions
  const allMenuItems = [
    {
      id: "",
      icon: Home,
      label: <Trans>Dashboard</Trans>,
      requiredPermissions: [], // Dashboard is always visible
    },
    {
      id: "profile",
      icon: User,
      label: <Trans>Profile</Trans>,
      requiredPermissions: [], // Profile is always visible
    },
    {
      id: "jobs",
      icon: BarChart3,
      label: <Trans>Jobs</Trans>,
      requiredPermissions: ["VIEWER_JOB"], // Need to view job offers
    },
    {
      id: "interviews",
      icon: Presentation,
      label: <Trans>Interview</Trans>,
      requiredPermissions: ["VIEWER_INTERVIEW"], // Need to view applications for interviews
    },
    {
      id: "calendar",
      icon: Calendar,
      label: <Trans>Calendar</Trans>,
      requiredPermissions: ["VIEWER_INTERVIEW"], // Calendar can be visible to all (for now)
    },
    {
      id: "cvtheque",
      icon: Users,
      label: <Trans>CVthèque</Trans>,
      requiredPermissions: ["VIEWER_CVTC"], // Need CV theque viewer permission
    },
    {
      id: "tests",
      icon: FileText,
      label: <Trans>Tests</Trans>,
      requiredPermissions: ["VIEWER_TEST"], // Tests can be visible to all (for now)
    },
  ];

  // Filter menu items based on user permissions
  const menuItems = allMenuItems.filter((item) => {
    // If no permissions required, show the item
    if (item.requiredPermissions.length === 0) {
      return true;
    }

    // Check if user has at least one of the required permissions
    const hasRequiredPermission = item.requiredPermissions.some((permission) =>
      hasPermission(permission)
    );

    // Debug log to help track permission checks
    console.log(
      `Menu item "${item.id}" requires [${item.requiredPermissions.join(
        ", "
      )}] - Accessible: ${hasRequiredPermission}`
    );

    return hasRequiredPermission;
  });

  const handleNavigation = (itemId: string) => {
    navigate(`/recruiter/${itemId}`);
  };

  // ClipPath pour la sidebar droite (RTL)
  const rtlClipPath =
    "polygon(100% 0, 100% 100%, 25% 100%, 0% 85%, 15% 70%, 0% 50%, 10% 35%, 0% 15%, 15% 0)";

  // ClipPath pour la sidebar gauche (LTR)
  const ltrClipPath =
    "polygon(0 0, 85% 0, 100% 15%, 90% 35%, 100% 50%, 85% 70%, 100% 85%, 75% 100%, 0 100%)";

  return (
    <div
      className={`fixed top-0 h-[70vh] w-20 bg-gradient-to-b from-teal-500 via-teal-600 to-cyan-600 shadow-2xl z-10 ${
        isRTL ? "right-0 " : "left-0 "
      }`}
      style={{
        clipPath: isRTL ? rtlClipPath : ltrClipPath,
      }}
    >
      <div className="flex flex-col items-center py-8 h-full">
        {/* Logo */}
        <div className="mb-8">
          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-lg">
            <div className="w-6 h-6 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-md"></div>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex flex-col space-y-4 flex-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.id === ""
                ? currentPathname === "/recruiter" ||
                  currentPathname === "/recruiter/"
                : currentPathname.startsWith(`/recruiter/${item.id}`);

            return (
              <button
                key={item.id}
                onClick={() => handleNavigation(item.id)}
                className={`relative group p-3 rounded-xl transition-all duration-300 ${
                  isActive
                    ? "bg-white bg-opacity-20 scale-110 shadow-lg"
                    : "hover:bg-white hover:bg-opacity-10 hover:scale-105"
                }`}
                title={typeof item.label === "string" ? item.label : undefined}
              >
                <Icon
                  size={20}
                  className={`transition-colors duration-300 ${
                    isActive
                      ? "text-white"
                      : "text-white text-opacity-80 group-hover:text-white"
                  }`}
                />

                {/* Tooltip avec position conditionnelle pour RTL */}
                <div
                  className={`absolute top-1/2 transform -translate-y-1/2 bg-gray-900 text-white px-2 py-1 rounded-md text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none whitespace-nowrap z-50 ${
                    isRTL
                      ? "right-16" // Tooltip à gauche pour RTL
                      : "left-16" // Tooltip à droite pour LTR
                  }`}
                >
                  {item.label}
                </div>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};

export default RecruiterSidebar;
