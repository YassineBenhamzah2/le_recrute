import {
  Briefcase,
  Building2,
  ChevronDown,
  CreditCard,
  Database,
  Globe,
  Key,
  LayoutDashboard,
  Menu,
  MessageSquare,
  Settings,
  UserCheck,
  Users,
  X,
  BarChart3,
} from "lucide-react";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Trans, t } from "@lingui/macro";
import { useAuth } from "@/contexts/AuthContext";

interface MenuItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  hasSubmenu?: boolean;
  submenu?: Array<{
    label: string;
    requiredPermissions: string[];
  }>;
  requiredPermissions: string[];
}

export default function AdminSidebar() {
  const { hasPermission, hasAnyPermission } = useAuth();

  // All menu items configuration with permissions
  const allMenuItems: MenuItem[] = [
    {
      id: "dashboard",
      label: t({ id: "admin.sidebar.dashboard", message: "Dashboard" }),
      icon: <LayoutDashboard size={20} />,
      requiredPermissions: [], // Dashboard always visible for admins
    },
    {
      id: "admins",
      label: t({ id: "admin.sidebar.admins", message: "Admins" }),
      icon: <Users size={20} />,
      requiredPermissions: ["ADMINISTRATOR"], // Only full admins can manage other admins
    },
    {
      id: "analytics",
      label: t({ id: "admin.sidebar.analytics", message: "Analytics" }),
      icon: <BarChart3 size={20} />,
      requiredPermissions: ["VIEWER_REPORTS"], // Analytics requires reports viewing
    },
    {
      id: "employees",
      label: t({ id: "admin.sidebar.employees", message: "Employees" }),
      icon: <UserCheck size={20} />,
      hasSubmenu: true,
      requiredPermissions: ["VIEWER_EMPLOYEES"], // Need employee viewing permission
      submenu: [
        {
          label: t({
            id: "admin.sidebar.all_employees",
            message: "All Employees",
          }),
          requiredPermissions: ["VIEWER_EMPLOYEES"],
        },
        {
          label: t({
            id: "admin.sidebar.reported_employees",
            message: "Reported Employees",
          }),
          requiredPermissions: ["VIEWER_EMPLOYEES"], // Same permission for now
        },
      ],
    },
    {
      id: "candidates",
      label: t({ id: "admin.sidebar.candidates", message: "Candidates" }),
      icon: <Building2 size={20} />,
      requiredPermissions: ["VIEWER_ADMIN_CANDIDATES"],
    },
    {
      id: "jobs",
      label: t({ id: "admin.sidebar.jobs", message: "Jobs" }),
      icon: <Briefcase size={20} />,
      requiredPermissions: ["VIEWER_ADMIN_JOBS"],
    },
    {
      id: "licenses",
      label: t({
        id: "admin.sidebar.license_management",
        message: "License Management",
      }),
      icon: <Key size={20} />,
      hasSubmenu: true,
      requiredPermissions: ["VIEWER_ROLE"], // Need role viewing for license management
      submenu: [
        {
          label: t({
            id: "admin.sidebar.license_dashboard",
            message: "License Dashboard",
          }),
          requiredPermissions: ["VIEWER_ROLE"],
        },
        {
          label: t({
            id: "admin.sidebar.role_permissions",
            message: "Role Permissions",
          }),
          requiredPermissions: ["VIEWER_ROLE"],
        },
        {
          label: t({
            id: "admin.sidebar.permission_browser",
            message: "Permission Browser",
          }),
          requiredPermissions: ["VIEWER_ROLE"],
        },
      ],
    },
    {
      id: "cvtheque",
      label: t({ id: "admin.sidebar.cvtheque", message: "CVtheque" }),
      icon: <Database size={20} />,
      requiredPermissions: ["VIEWER_CVTC_ADMIN"],
    },
    {
      id: "service",
      label: t({ id: "admin.sidebar.service", message: "Service" }),
      icon: <Settings size={20} />,
      requiredPermissions: ["EDITOR_SERVICES"],
    },
    {
      id: "front-cms",
      label: t({ id: "admin.sidebar.front_cms", message: "Front CMS" }),
      icon: <Globe size={20} />,
      requiredPermissions: ["EDITOR_CMS"],
    },
    {
      id: "blogs",
      label: t({ id: "admin.sidebar.blogs", message: "Blogs" }),
      icon: <MessageSquare size={20} />,
      requiredPermissions: ["EDITOR_BLOG"],
    },
    {
      id: "payments",
      label: t({ id: "admin.sidebar.payments", message: "Payments" }),
      icon: <CreditCard size={20} />,
      requiredPermissions: ["VIEWER_PAYMENTS"],
    },
  ];

  // Filter menu items based on user permissions
  const menuItems = allMenuItems
    .filter((item) => {
      // If user has ADMINISTRATOR permission, show everything
      if (hasPermission("ADMINISTRATOR")) {
        return true;
      }

      // If no permissions required, show the item
      if (item.requiredPermissions.length === 0) {
        return true;
      }

      // Check if user has at least one of the required permissions
      const hasRequiredPermission = hasAnyPermission(item.requiredPermissions);

      // If item has submenu, check if at least one submenu item is accessible
      if (item.hasSubmenu && item.submenu) {
        const hasAccessibleSubmenu = item.submenu.some((subItem) => {
          return hasAnyPermission(subItem.requiredPermissions);
        });

        // Only show parent if at least one submenu item is accessible
        return hasRequiredPermission && hasAccessibleSubmenu;
      }

      // Debug log to help track permission checks
      console.log(
        `Admin menu item "${item.id}" requires [${item.requiredPermissions.join(
          ", "
        )}] - Accessible: ${hasRequiredPermission}`
      );

      return hasRequiredPermission;
    })
    .map((item) => {
      // If user has ADMINISTRATOR permission, return item as-is
      if (hasPermission("ADMINISTRATOR")) {
        return item;
      }

      // Create a copy and filter submenu items if needed
      const itemCopy = { ...item };

      if (item.hasSubmenu && item.submenu) {
        itemCopy.submenu = item.submenu.filter((subItem) => {
          return hasAnyPermission(subItem.requiredPermissions);
        });
      }

      return itemCopy;
    });
  const navigate = useNavigate();
  const location = useLocation();
  const [activeSection, setActiveSection] = useState("dashboard");

  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [logoError, setLogoError] = useState(false);

  const toggleExpanded = (itemId: string) => {
    setExpandedItems((prev) =>
      prev.includes(itemId)
        ? prev.filter((id) => id !== itemId)
        : [...prev, itemId]
    );
  };

  // Helper to map submenu item labels to their activeSection identifiers
  const getSubmenuActiveState = (subItem: {
    label: string;
    requiredPermissions: string[];
  }): string => {
    const allEmployeesText = t({
      id: "admin.sidebar.all_employees",
      message: "All Employees",
    });
    const reportedEmployeesText = t({
      id: "admin.sidebar.reported_employees",
      message: "Reported Employees",
    });
    const licenseDashboardText = t({
      id: "admin.sidebar.license_dashboard",
      message: "License Dashboard",
    });
    const rolePermissionsText = t({
      id: "admin.sidebar.role_permissions",
      message: "Role Permissions",
    });
    const permissionBrowserText = t({
      id: "admin.sidebar.permission_browser",
      message: "Permission Browser",
    });

    switch (subItem.label) {
      case allEmployeesText:
        return "employees";
      case reportedEmployeesText:
        return "reported-employees";
      case licenseDashboardText:
        return "licenses";
      case rolePermissionsText:
        return "roles";
      case permissionBrowserText:
        return "permissions";
      default:
        return "";
    }
  };

  // Cleaned up navigation handler
  const handleNavigation = (
    itemId: string,
    subItem?: { label: string; requiredPermissions: string[] }
  ) => {
    // Default navigation for parent items
    const navigateTo = (path: string, section: string) => {
      navigate(path);
      setActiveSection(section);
    };

    if (subItem) {
      // Handle submenu navigation
      const allEmployeesText = t({
        id: "admin.sidebar.all_employees",
        message: "All Employees",
      });
      const reportedEmployeesText = t({
        id: "admin.sidebar.reported_employees",
        message: "Reported Employees",
      });
      const licenseDashboardText = t({
        id: "admin.sidebar.license_dashboard",
        message: "License Dashboard",
      });
      const rolePermissionsText = t({
        id: "admin.sidebar.role_permissions",
        message: "Role Permissions",
      });
      const permissionBrowserText = t({
        id: "admin.sidebar.permission_browser",
        message: "Permission Browser",
      });

      switch (subItem.label) {
        case allEmployeesText:
          return navigateTo("/admin/employees", "employees");
        case reportedEmployeesText:
          return navigateTo("/admin/reported-employees", "reported-employees");
        case licenseDashboardText:
          return navigateTo("/admin/licenses", "licenses");
        case rolePermissionsText:
          return navigateTo("/admin/roles", "roles");
        case permissionBrowserText:
          return navigateTo("/admin/permissions", "permissions");
        default:
          return;
      }
    } else {
      // Handle main menu navigation
      switch (itemId) {
        case "dashboard":
          return navigateTo("/admin", "dashboard");
        case "admins":
          return navigateTo("/admin/allAdmins", "admins");
        case "analytics":
          return navigateTo("/admin/analytics", "analytics");
        case "candidates":
          return navigateTo("/admin/allCandidates", "allCandidates");
        case "employees":
          return navigateTo("/admin/employees", "employees");
        case "cvtheque":
          return navigateTo("/admin/cvtheque", "cvtheque");
        case "payments":
          return navigateTo("/admin/payments", "payments");
        case "service":
          return navigateTo("/admin/services", "service");
        case "licenses":
          return navigateTo("/admin/licenses", "licenses");
        case "front-cms":
          return navigateTo("/admin/cms", "front-cms");
        case "jobs":
          return navigateTo("/admin/jobs", "jobs");
        case "blogs":
          return navigateTo("/admin/blogs", "blogs");
        default:
          setActiveSection(itemId);
      }
    }
  };

  // Improved useEffect to set active state from URL
  useEffect(() => {
    const path = location.pathname;

    // Check for more specific paths first
    if (path.includes("/admin/reported-employees")) {
      setActiveSection("reported-employees");
    } else if (path.includes("/admin/employees")) {
      setActiveSection("employees");
    } else if (path.includes("/admin/analytics")) {
      setActiveSection("analytics");
    } else if (path.includes("/admin/roles")) {
      setActiveSection("roles");
    } else if (path.includes("/admin/permissions")) {
      setActiveSection("permissions");
    } else if (path.includes("/admin/licenses")) {
      setActiveSection("licenses");
    } else if (path.includes("/admin/cvtheque")) {
      setActiveSection("cvtheque");
    } else if (path.includes("/admin/services")) {
      setActiveSection("service");
    } else if (path.includes("/admin/payments")) {
      setActiveSection("payments");
    } else if (path.includes("/admin/allCandidates")) {
      setActiveSection("candidates");
    } else if (path.includes("/admin/allAdmins")) {
      setActiveSection("admins");
    } else if (path.includes("/admin/jobs")) {
      setActiveSection("jobs");
    } else if (path.includes("/admin/cms")) {
      setActiveSection("front-cms");
    } else if (path.includes("/admin/blogs")) {
      setActiveSection("blogs");
    } else if (path === "/admin") {
      setActiveSection("dashboard");
    }
  }, [location]);

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsMobileOpen(!isMobileOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-white rounded-lg shadow-lg border border-gray-200"
      >
        {isMobileOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Overlay */}
      {isMobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div
        className={`
        fixed lg:static inset-y-0 left-0 z-40 w-72 bg-white flex-1  border-r border-gray-100 flex flex-col
        transform transition-transform duration-300 ease-in-out overflow-y-auto max-h-screen
        ${isMobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
      `}
      >
        {/* Header */}
        <div className="p-8 border-b border-gray-100">
          <div className="flex items-center space-x-4">
            {/* Logo */}
            <div>
              {!logoError ? (
                <img
                  src="/logo.png" // Use absolute path from public folder
                  alt={t({
                    id: "admin.sidebar.logo_alt",
                    message: "AdminHub Logo",
                  })}
                  className="h-10 w-auto object-contain"
                  onError={() => setLogoError(true)}
                />
              ) : (
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">
                    <Trans id="admin.sidebar.logo_title">AdminHub</Trans>
                  </h1>
                  <p className="text-sm text-gray-500">
                    <Trans id="admin.sidebar.logo_subtitle">
                      Management Portal
                    </Trans>
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-6 space-y-2 overflow-y-auto">
          {menuItems.map((item) => (
            <div key={item.id}>
              <button
                onClick={() => {
                  handleNavigation(item.id);
                  if (item.hasSubmenu) {
                    toggleExpanded(item.id);
                  }
                  setIsMobileOpen(false);
                }}
                // Updated className for parent item highlighting
                className={`w-full flex items-center justify-between p-4 rounded-xl text-left transition-all duration-200 group ${
                  activeSection === item.id ||
                  (item.submenu &&
                    item.submenu
                      .map(getSubmenuActiveState)
                      .includes(activeSection))
                    ? "bg-gradient-to-r from-[#238D94] to-[#1a6b72] text-white shadow-lg transform scale-105"
                    : "text-gray-700 hover:bg-slate-50 hover:text-[#238D94]"
                }`}
              >
                <div className="flex items-center space-x-4">
                  <div
                    // Updated className for icon highlighting
                    className={`transition-colors duration-200 ${
                      activeSection === item.id ||
                      (item.submenu &&
                        item.submenu
                          .map(getSubmenuActiveState)
                          .includes(activeSection))
                        ? "text-white"
                        : "text-gray-500 group-hover:text-[#238D94]"
                    }`}
                  >
                    {item.icon}
                  </div>
                  <span className="font-medium text-base">{item.label}</span>
                </div>
                {item.hasSubmenu && (
                  <div
                    className={`transition-transform duration-200 ${
                      expandedItems.includes(item.id) ? "rotate-180" : ""
                    }`}
                  >
                    <ChevronDown size={16} />
                  </div>
                )}
              </button>

              {item.hasSubmenu && expandedItems.includes(item.id) && (
                <div className="ml-8 mt-2 space-y-1">
                  {item.submenu?.map((subItem, index) => (
                    <button
                      key={index}
                      // Updated className for sub-item highlighting
                      className={`w-full text-left p-3 text-sm transition-colors duration-200 rounded-lg ${
                        activeSection === getSubmenuActiveState(subItem)
                          ? "text-[#238D94] bg-slate-50 font-medium"
                          : "text-gray-600 hover:text-[#238D94] hover:bg-slate-50"
                      }`}
                      onClick={() => {
                        handleNavigation(item.id, subItem);
                        setIsMobileOpen(false);
                      }}
                    >
                      {subItem.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
      </div>
    </>
  );
}
