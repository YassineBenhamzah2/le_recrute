import React from "react";
import AdminBaseDashboard from "../Dashboard/AdminBaseDashboard";
import AdminSidebar from "../Layout/AdminSidebar";
import AdminHeader from "./AdminHeader";
import AdminFooter from "./AdminFooter";

interface AdminLayoutProps {
  children: React.ReactNode;
}

const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  return (
    <AdminBaseDashboard
      SideBar={<AdminSidebar />}
      Header={<AdminHeader />}
      Footer={<AdminFooter />}
    >
      {children}
    </AdminBaseDashboard>
  );
};

export default AdminLayout;
