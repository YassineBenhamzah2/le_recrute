import { Trans } from '@lingui/macro';

const AdminFooter = () => (
  <div className="flex items-center justify-between text-sm text-gray-500">
    <div>
      <Trans id="admin.footer.copyright">© 2025 Le Recruteur. All rights reserved.</Trans>
    </div>
    <div className="flex items-center space-x-4">
      <span>
        <Trans id="admin.footer.version">Version 1.0.0</Trans>
      </span>
      <span>•</span>
      <a href="#" className="hover:text-[#238D94] transition-colors">
        <Trans id="admin.footer.support">Support</Trans>
      </a>
      <span>•</span>
      <a href="#" className="hover:text-[#238D94] transition-colors">
        <Trans id="admin.footer.documentation">Documentation</Trans>
      </a>
      |
    </div>
  </div>
);

export default AdminFooter;