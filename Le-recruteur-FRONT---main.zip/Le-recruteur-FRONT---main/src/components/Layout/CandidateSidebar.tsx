import {
  BookCheck,
  Calendar,
  FileText,
  LayoutDashboard,
  Presentation,
  User,
} from "lucide-react";
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Trans } from '@lingui/macro';
import { useLingui } from '@lingui/react';

const CandidateSidebar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { i18n } = useLingui();
  const isRTL = i18n.locale === 'ar'; // Vérifie si la langue est arabe

  

  const menuItems = [
    {
      id: "dashboard",
      icon: LayoutDashboard,
      label: <Trans>Dashboard</Trans>,
      path: "/candidate",
      active: location.pathname === "/candidate",
    },
    {
      id: "profile",
      icon: User,
      label: <Trans>Profile</Trans>,
      path: `/candidate/profile`,
      active: location.pathname === "/candidate/profile",
    },
    {
      id: "tests",
      icon: BookCheck,
      label: <Trans>Tests</Trans>,
      path: "/candidate/tests",
      active: location.pathname.startsWith("/candidate/tests"),
    },
    {
      id: "applications",
      icon: FileText,
      label: <Trans>Applications</Trans>,
      path: "/candidate/applications",
      active: location.pathname.startsWith("/candidate/applications"),
    },
    {
      id: "calendar",
      icon: Presentation,
      label: <Trans>Interviews</Trans>,
      path: "/candidate/interviews",
      active: location.pathname === "/candidate/interviews",
    },
    {
      id: "calendrier",
      icon: Calendar,
      label: <Trans>Calendar</Trans>,
      path: "/candidate/calendrier",
      active: location.pathname === "/candidate/calendrier",
    },
  ];

  const handleNavigation = (path: string) => {
    navigate(path);
  };

  return (
    <div
      className={`fixed top-1/2 -translate-y-1/2 z-10 min-w-[10%] h-[550px] bg-no-repeat bg-center flex items-center justify-center ${
        isRTL ? 'right-[-2rem]' : 'left-[-2rem]'
      }`}
      style={{
        backgroundImage: "url('/Frame sidebar rec.svg')",
        backgroundSize: "100% 100%",
        transform: isRTL ? "scaleX(-1) translateY(-50%)" : "translateY(-50%)",
      }}
    >
      <div 
        className="flex flex-col items-center px-1"
        style={{ transform: isRTL ? "scaleX(-1)" : "none" }}
      >
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          const hasActiveAbove = menuItems
            .slice(0, index)
            .some((prevItem) => prevItem.active);

          return (
            <div
              key={item.id}
              className={`flex flex-col items-center mb-5 transition-all duration-500 ease-out relative ${
                index === 0 ? "" : "mt-[-10px]"
              }`}
              style={{
                transform: hasActiveAbove
                  ? "translateY(30px)"
                  : "translateY(0px)",
              }}
            >
              <button
                className={`group p-3 rounded-xl transition-all duration-300 ${
                  item.active
                    ? "bg-white shadow-lg"
                    : "bg-white/20 hover:bg-white/30"
                }`}
                onClick={() => handleNavigation(item.path)}
              >
                <Icon
                  size={22}
                  className={`transition-colors duration-300 ${
                    item.active
                      ? "text-teal-600"
                      : "text-white group-hover:text-white"
                  }`}
                />

                {!item.active && (
                  <span 
                    className={`absolute top-1/2 -translate-y-1/2 text-[11px] font-medium whitespace-nowrap transition-all duration-300 text-sm text-white p-2 rounded-lg bg-[#238d94] opacity-0 group-hover:opacity-100 pointer-events-none ${
                      isRTL ? 'right-full mr-3' : 'left-full ml-3'
                    }`}
                  >
                    {item.label}
                  </span>
                )}
              </button>

              {item.active && (
                <span className="text-[11px] font-medium mt-3 mb-[-15px] text-white opacity-100 transition-all duration-300">
                  {item.label}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CandidateSidebar;