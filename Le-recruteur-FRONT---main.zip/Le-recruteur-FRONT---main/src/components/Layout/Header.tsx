import { ChevronDown, Menu, X } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { Trans } from "@lingui/macro";
import { useLocale } from "../../contexts/LocaleContext";

interface HeaderProps {
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (isOpen: boolean) => void;
  onSignIn?: () => void;
  onGetStarted?: () => void;
}

type NavItem = {
  key: string;
  name: React.ReactNode;
  href: string;
  exact?: boolean;
  hasDropdown?: boolean;
  dropdownItems?: { name: React.ReactNode; href: string }[];
};

export default function Header({
  isMobileMenuOpen,
  setIsMobileMenuOpen,
  onSignIn,
  onGetStarted,
}: HeaderProps) {
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [languageDropdown, setLanguageDropdown] = useState(false);
  const headerRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  // Get the real locale state and functions from the context
  const { locale, setLocale, supportedLocales } = useLocale();
  // We can get the current language's info directly from the context
  const currentLanguage = supportedLocales[locale];

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        headerRef.current &&
        !headerRef.current.contains(event.target as Node)
      ) {
        setOpenDropdown(null);
        setLanguageDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const location = useLocation();

  const navItems = [
    {
      key: "home",
      name: <Trans id="header.nav.home">Home</Trans>,
      href: "/",
      exact: true,
    },
    {
      key: "about",
      name: <Trans id="header.nav.about">About Us</Trans>,
      href: "/about",
    },
    {
      key: "jobs",
      name: <Trans id="header.nav.jobs">Jobs</Trans>,
      href: "/jobs",
    },
    {
      key: "companies",
      name: <Trans id="header.nav.companies">Companies</Trans>,
      href: "/entreprises",
    },
    {
      key: "services", // Unique key for the dropdown
      name: <Trans id="header.nav.services">Services</Trans>,
      href: "#",
      hasDropdown: true,
      dropdownItems: [
        {
          name: (
            <Trans id="header.nav.service_candidate">Candidate Service</Trans>
          ),
          href: "/candidat-service",
        },
        {
          name: <Trans id="header.nav.service_pricing">Pricing</Trans>,
          href: "/pricing",
        },
      ],
    },
    {
      key: "blog",
      name: <Trans id="header.nav.blog">Blog</Trans>,
      href: "/blog",
    },
    {
      key: "contact",
      name: <Trans id="header.nav.contact">Contact</Trans>,
      href: "/faq",
    },
    {
      key: "recruiter_space",
      name: <Trans id="header.nav.recruiter_space">Recruiter Space</Trans>,
      href: "/recruiter-space",
    },
  ];

  const isActive = (item: NavItem) => {
    if (item.href === "/") {
      return location.pathname === "/" || location.pathname === "/home";
    }

    if (item.hasDropdown && item.dropdownItems) {
      const isChildActive = item.dropdownItems.some(
        (childItem) => location.pathname.startsWith(childItem.href)
      );
      if (isChildActive) {
        return true;
      }
    }

    const pathWithoutHash = item.href.split('#')[0];
    if (!pathWithoutHash) return false;

    return item.exact
      ? location.pathname === pathWithoutHash
      : location.pathname.startsWith(pathWithoutHash);
  };

  return (
    <header
      className="bg-white shadow-sm border-b border-gray-200 font-poppins"
      ref={headerRef}
    >
      <div className=" mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <img
                src="/logo.png"
                alt="EHC - Experts Human Capital"
                className="h-16"
              />
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6">
            {navItems.map((item) => (
              <div key={item.href} className="relative">
                {item.hasDropdown ? (
                  <button
                    onClick={() => {
                      setOpenDropdown(
                        openDropdown === item.key ? null : item.key
                      );
                    }}
                    className={`flex items-center px-3 py-2 text-sm font-semibold transition-colors duration-200 ${
                      isActive(item)
                        ? "text-ehc-green border-b-2 border-ehc-green"
                        : "text-black hover:text-ehc-green"
                    }`}
                  >
                    {item.name}
                    {item.hasDropdown && (
                      <ChevronDown className="w-4 h-4 ml-1" />
                    )}
                  </button>
                ) : (
                  <Link
                    to={item.href}
                    className={`flex items-center px-3 py-2 text-sm font-semibold transition-colors duration-200 ${
                      isActive(item)
                        ? "text-ehc-green border-b-2 border-ehc-green"
                        : "text-black hover:text-ehc-green"
                    }`}
                  >
                    {item.name}
                  </Link>
                )}
                {/* Dropdown Menu remains unchanged */}
                {item.hasDropdown && openDropdown === item.key && (
                  <div className="absolute top-full left-0 mt-1 w-48 bg-white rounded-md shadow-lg border border-gray-200 py-1 z-50">
                    {item.dropdownItems?.map((dropdownItem) => (
                      <Link
                        key={dropdownItem.href}
                        to={dropdownItem.href}
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors duration-200"
                      >
                        {dropdownItem.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="relative">
              <button
                onClick={() => setLanguageDropdown(!languageDropdown)}
                className="flex items-center text-sm text-black hover:text-ehc-green gap-1"
              >
                <img
                  src={currentLanguage.flag}
                  alt={currentLanguage.name}
                  className="w-4 h-4"
                />
                <span>{currentLanguage.code}</span> 
                <ChevronDown className="w-4 h-4" />
              </button>

              {/* Language Dropdown */}
              {languageDropdown && (
                <div className="absolute top-full right-0 mt-1 w-32 bg-white rounded-md shadow-lg border border-gray-200 py-1 z-50">
                  {Object.values(supportedLocales).map((language) => (
                    <button
                      key={language.code}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
                      onClick={() => {
                        setLocale(language.code);
                        setLanguageDropdown(false);
                      }}
                    >
                      <img
                        src={language.flag}
                        alt={language.name}
                        className="w-5 h-5"
                      />
                      <span>{language.code}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              className={
                user
                  ? "px-4 py-2 text-sm font-medium bg-ehc-green text-white rounded-md hover:bg-ehc-green-dark transition-colors duration-200"
                  : "px-4 py-2 text-sm font-medium text-ehc-green hover:text-ehc-green-dark border border-ehc-green rounded-md hover:bg-gray-50 transition-colors duration-200"
              }
              onClick={onSignIn}
            >
              {user ? (
                <Trans id="header.button.dashboard">Dashboard</Trans>
              ) : (
                <Trans id="header.button.login">Login</Trans>
              )}
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-ehc-green hover:text-ehc-green-dark transition-colors duration-200"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-gray-200 py-4">
            <div className="space-y-2">
              {navItems.map((item) => (
                <div key={item.key} className="block">
                  <button
                    onClick={() => {
                      if (item.hasDropdown) {
                        setOpenDropdown(
                          openDropdown === item.key ? null : item.key
                        );
                      }
                    }}
                    className={`flex items-center justify-between w-full px-3 py-2 text-sm font-semibold transition-colors duration-200 ${
                      isActive(item)
                        ? "text-ehc-green bg-gray-50"
                        : "text-black hover:text-ehc-green hover:bg-gray-50"
                    }`}
                  >
                    <span>{item.name}</span>
                    {item.hasDropdown && <ChevronDown className="w-4 h-4" />}
                  </button>

                  {/* Mobile Dropdown */}
                  {item.hasDropdown && openDropdown === item.key && (
                    <div className="pl-6 mt-2 space-y-1">
                      {item.dropdownItems?.map((dropdownItem) => (
                        <a
                          key={dropdownItem.href}
                          href={dropdownItem.href}
                          className="block px-3 py-2 text-sm text-black hover:text-ehc-green hover:bg-gray-50 transition-colors duration-200"
                        >
                          {dropdownItem.name}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              <div className="pt-4 space-y-2 border-t border-gray-200">
                <div className="px-3 py-2">
                  <button
                    onClick={() => setLanguageDropdown(!languageDropdown)}
                    className="flex items-center text-sm text-black hover:text-ehc-green gap-1"
                  >
                    <img
                      src={currentLanguage.flag}
                      alt={currentLanguage.name}
                      className="w-4 h-4"
                    />
                    <span>{currentLanguage.code}</span>
                    <ChevronDown className="w-4 h-4" />
                  </button>

                  {/* Mobile Language Dropdown */}
                  {languageDropdown && (
                    <div className="mt-2 space-y-1">
                      {Object.values(supportedLocales).map((language) => (
                        <button
                          key={language.code}
                          className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
                          onClick={() => {
                            setLocale(language.code);
                            setLanguageDropdown(false);
                          }}
                        >
                          <img
                            src={language.flag}
                            alt={language.name}
                            className="w-5 h-5"
                          />
                          <span>{language.code}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <button
                  className={
                    user
                      ? "block w-full mx-3 py-2 bg-ehc-green text-white text-sm font-medium rounded-md hover:bg-ehc-green-dark transition-colors duration-200 text-center"
                      : "block w-full text-left px-3 py-2 text-sm font-medium text-black hover:text-ehc-green border border-ehc-green rounded-md mx-3 hover:bg-gray-50 transition-colors duration-200"
                  }
                  onClick={onSignIn}
                >
                  {user ? "Dashboard" : "Connexion"}
                </button>
                <button
                  className="block w-full mx-3 py-2 bg-ehc-green text-white text-sm font-medium rounded-md hover:bg-ehc-green-dark transition-colors duration-200"
                  onClick={onGetStarted}
                >
                  <Trans id="header.button.find_jobs">Find Jobs</Trans>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
