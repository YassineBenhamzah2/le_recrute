import React from 'react';
import { Trans, t } from '@lingui/macro';

const Footer: React.FC = () => {
  const usefulLinks = [
    { name: <Trans id="footer.link.home">Home</Trans>, href: '#' },
    { name: <Trans id="footer.link.jobs">Jobs</Trans>, href: '#' },
    { name: <Trans id="footer.link.companies">Companies</Trans>, href: '#' },
  ];

  const helpfulResources = [
    { name: <Trans id="footer.resource.about">About Us</Trans>, href: '#' },
    { name: <Trans id="footer.resource.contact">Contact Us</Trans>, href: '#' },
    { name: <Trans id="footer.resource.service">Service</Trans>, href: '#' },
    { name: <Trans id="footer.resource.policy">Privacy Policy</Trans>, href: '#' },
    { name: <Trans id="footer.resource.terms">Terms And Conditions</Trans>, href: '#' },
  ];

  return (
    <footer className="bg-[#192335] text-white font-poppins">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info & Newsletter */}
          <div className="lg:col-span-2 space-y-6">
            {/* Logo */}
            <div className="flex items-center">
              <img
                src="/logo.jpg"
                alt={t({ id: "footer.alt.logo", message: "EHC Logo" })}
                className="h-66 w-102  object-cover shadow"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                }}
              />
            </div>

            {/* Newsletter Section */}
            <div className="space-y-4">
              <p className="text-gray-300 text-sm leading-relaxed max-w-sm">
                <Trans id="footer.newsletter.description">
                  Stay Connected with our regular updates by subscribing our newsletter.
                </Trans>
              </p>

              <div className="flex max-w-md">
                <input
                  type="email"
                  placeholder={t({ id: "footer.newsletter.placeholder", message: "Enter your mail" })}
                  className="flex-1 px-4 py-3 rounded-l-lg border-0 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#238D94]"
                />
                <button className="px-6 py-3 bg-[#238D94] text-white font-semibold rounded-r-lg hover:bg-[#1a6b75] transition-colors duration-200">
                  <Trans id="footer.newsletter.submit">SUBMIT</Trans>
                </button>
              </div>
            </div>
          </div>

          {/* Useful Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4">
              <Trans id="footer.useful_links">Useful Links</Trans>
            </h3>
            <ul className="space-y-3">
              {usefulLinks.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-300 hover:text-white transition-colors duration-200 text-sm"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Helpful Resources */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4">
              <Trans id="footer.helpful_resources">Helpful Resources</Trans>
            </h3>
            <ul className="space-y-3">
              {helpfulResources.map((resource, index) => (
                <li key={index}>
                  <a
                    href={resource.href}
                    className="text-gray-300 hover:text-white transition-colors duration-200 text-sm"
                  >
                    {resource.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-600 mt-12 pt-8">
          <div className="text-center">
            <p className="text-gray-300 text-sm">
              <Trans id="footer.copyright">© 2025 All Right Reserved EHC</Trans>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
