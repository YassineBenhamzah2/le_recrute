import React from "react";
import { Outlet } from "react-router-dom";
import AdminBaseDashboard from "../Dashboard/AdminBaseDashboard";
import AdminSidebar from "../Layout/AdminSidebar";
import AdminFooter from "./AdminFooter";
import AdminHeader from "./AdminHeader";

const AdminDashboardWrapper: React.FC = () => {
  return (
    <AdminBaseDashboard
      SideBar={<AdminSidebar />}
      Header={<AdminHeader />}
      Footer={<AdminFooter />}
    >
      <Outlet />
    </AdminBaseDashboard>
  );
};

export default AdminDashboardWrapper;