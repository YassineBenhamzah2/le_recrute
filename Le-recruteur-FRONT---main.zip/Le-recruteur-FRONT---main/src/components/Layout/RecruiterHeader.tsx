import { useAuth } from "@/contexts/AuthContext";
import { useLocale } from "@/contexts/LocaleContext";
import { settings } from "@/lib/settings/main";
import { Trans } from "@lingui/macro";
import { ChevronDown, LogOut, User } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import NotificationBell from "../Dashboard/recruiterComponents/RecruiterNotificationBell";

const RecruiterHeader = () => {
  const { user, logout } = useAuth();
  const { locale, setLocale, supportedLocales } = useLocale();
  const [languageDropdown, setLanguageDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const currentLanguage = supportedLocales[locale];


  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setLanguageDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleLogout = () => {
    logout();
  };

  const userDisplayName =
    user?.firstname && user?.lastname ? (
      `${user.firstname} ${user.lastname}`
    ) : (
      <Trans>HR Manager</Trans>
    );

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h1 className="text-xl font-semibold text-gray-900">
            <Trans>Welcome back, {userDisplayName}</Trans>
          </h1>
        </div>

        <div className="flex items-center space-x-4">
          {/* Language Selector */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setLanguageDropdown(!languageDropdown)}
              className="flex items-center space-x-2 p-2 text-gray-600 hover:text-[#238D94] hover:bg-gray-50 rounded-lg transition-colors duration-200"
            >
              <img
                src={currentLanguage.flag}
                alt={currentLanguage.name}
                className="w-5 h-5 rounded-sm object-cover"
              />
              <span className="text-sm font-medium">
                {currentLanguage.code}
              </span>
              <ChevronDown
                size={16}
                className={`transition-transform duration-200 ${
                  languageDropdown ? "rotate-180" : ""
                }`}
              />
            </button>

            {/* Language Dropdown */}
            {languageDropdown && (
              <div className="absolute right-0 top-full mt-2 w-40 bg-white rounded-lg shadow-xl border border-gray-100 py-2 z-50">
                {Object.values(supportedLocales).map((language) => (
                  <button
                    key={language.code}
                    className={`w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 flex items-center space-x-3 transition-colors ${
                      locale === language.code
                        ? "bg-[#238D94]/10 text-[#238D94] font-medium"
                        : "text-gray-700"
                    }`}
                    onClick={() => {
                      setLocale(language.code);
                      setLanguageDropdown(false);
                    }}
                  >
                    <img
                      src={language.flag}
                      alt={language.name}
                      className="w-5 h-5 rounded-sm object-cover"
                    />
                    <span>{language.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Notification Bell */}
          <NotificationBell />

          {/* Profile Dropdown */}
          <div className="relative group">
            <button className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <div className="w-8 h-8 overflow-hidden rounded">
                <img
                  src={
                    user?.profilePicture
                      ? `${settings.IMG_ADDRESS}${user.profilePicture}`
                      : settings.DEFAULT_USER_AVATAR
                  }
                  alt="Profile image"
                  onError={(e) => {
                    e.currentTarget.src = settings.DEFAULT_USER_AVATAR ;
                  }}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-left">
                <p className="text-sm font-medium text-gray-700">
                  {userDisplayName}
                </p>
                <p className="text-xs text-gray-500">
                  <Trans>Recruiter</Trans>
                </p>
              </div>
            </button>

            <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-gray-100 py-3 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-30">
              <Link
                to="/recruiter/profile"
                className="flex items-center space-x-3 px-6 py-3 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
              >
                <User size={16} />
                <span>
                  <Trans>View Profile</Trans>
                </span>
              </Link>

              <hr className="my-2 mx-3" />
              <button
                onClick={handleLogout}
                className="w-full flex items-center space-x-3 px-6 py-3 text-sm text-red-600 hover:bg-red-50 transition-colors"
              >
                <LogOut size={16} />
                <span>
                  <Trans>Sign Out</Trans>
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default RecruiterHeader;
