import React from "react";
import { useAuth } from "../../contexts/AuthContext";

interface PermissionGuardProps {
  permissions?: string | string[];
  requireAll?: boolean;
  roleTypes?: ("ADMIN" | "RECRUITER" | "CANDIDATE")[];
  fallback?: React.ReactNode;
  children: React.ReactNode;
}

export const PermissionGuard: React.FC<PermissionGuardProps> = ({
  permissions,
  requireAll = false,
  roleTypes,
  fallback = null,
  children,
}) => {
  const { user, hasAnyPermission, hasAllPermissions } = useAuth();

  // Check role type first if specified
  if (roleTypes && roleTypes.length > 0) {
    const userRoleType = user?.role?.type;
    const hasRequiredRole = userRoleType && roleTypes.includes(userRoleType);
    if (!hasRequiredRole) {
      return <>{fallback}</>;
    }
  }

  // If no permissions specified and role check passed, render children
  if (!permissions || permissions.length === 0) {
    return <>{children}</>;
  }

  // Convert single permission to array
  const permissionArray = Array.isArray(permissions)
    ? permissions
    : [permissions];

  // Check permissions
  let hasAccess = false;

  if (requireAll) {
    hasAccess = hasAllPermissions(permissionArray);
  } else {
    hasAccess = hasAnyPermission(permissionArray);
  }

  return hasAccess ? <>{children}</> : <>{fallback}</>;
};
