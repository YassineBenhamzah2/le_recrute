import React, { useState } from "react";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { AlertCircle, CheckCircle, Loader2 } from "lucide-react";
import { licenseService } from "../../lib/network/license";
import { License } from "../../lib/types/license";
import { Trans } from "@lingui/react/macro";
import { t } from "@lingui/core/macro";

interface LicenseKeyInputProps {
  value: string;
  onChange: (value: string) => void;
  onLicenseValidated?: (license: License | null) => void;
  error?: string;
  required?: boolean;
}

export const LicenseKeyInput: React.FC<LicenseKeyInputProps> = ({
  value,
  onChange,
  onLicenseValidated,
  error,
  required = false,
}) => {
  const [licenseInfo, setLicenseInfo] = useState<License | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [validationError, setValidationError] = useState<string>("");

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = e.target.value;
    onChange(formatted);

    // Clear previous validation if user is typing
    if (licenseInfo) {
      setLicenseInfo(null);
      setValidationError("");
      onLicenseValidated?.(null);
    }
  };

  const validateLicenseKey = async (key: string) => {
    // Basic length check - allow reasonable license key lengths
    if (key.length < 10 || key.length > 25) {
      setValidationError(t({ id: "license.error_invalid_key", message: "Please enter a valid license key" }));
      return;
    }

    setIsValidating(true);
    setValidationError("");

    try {
      // Validate license key
      const validationResponse = await licenseService.validate(key);

      if (validationResponse.success && validationResponse.data && validationResponse.data.isValid) {
        // Get license details
        const licenseResponse = await licenseService.getByKey(key);

        if (licenseResponse.success && licenseResponse.data) {
          setLicenseInfo(licenseResponse.data);
          onLicenseValidated?.(licenseResponse.data);
        } else {
          setValidationError(t({ id: "license.error_failed_details", message: "Failed to retrieve license details" }));
          onLicenseValidated?.(null);
        }
      } else {
        setValidationError(t({ id: "license.error_invalid_or_expired", message: "Invalid or expired license key" }));
        setLicenseInfo(null);
        onLicenseValidated?.(null);
      }
    } catch (error) {
      console.error("License validation error:", error);
      setValidationError(t({ id: "license.error_validation_failed", message: "Error validating license key. Please try again." }));
      setLicenseInfo(null);
      onLicenseValidated?.(null);
    } finally {
      setIsValidating(false);
    }
  };

  const handleBlur = () => {
    if (value && value.length >= 15) {
      validateLicenseKey(value);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusColors = {
      ACTIVE: "bg-green-100 text-green-800",
      SUSPENDED: "bg-yellow-100 text-yellow-800",
      EXPIRED: "bg-red-100 text-red-800",
    };

    return (
      <span
        className={`px-2 py-1 rounded-full text-xs font-medium ${
          statusColors[status as keyof typeof statusColors] ||
          "bg-gray-100 text-gray-800"
        }`}
      >
        {status}
      </span>
    );
  };

  return (
    <div className="space-y-3">
      <div>
        <Label htmlFor="licenseKey" className="flex items-center gap-2">
          <Trans id="license.license_key_label">License Key</Trans>
           {required && <span className="text-red-500">*</span>}
        </Label>
        <div className="relative">
          <Input
            id="licenseKey"
            type="text"
            value={value}
            onChange={handleInputChange}
            onBlur={handleBlur}
            placeholder={t({ id: "license.placeholder", message: "XXXXXX-XXXXX-XXXXXX" })}
            className={`mt-1 ${
              error || validationError ? "border-red-500" : ""
            } ${licenseInfo ? "border-green-500" : ""}`}
            maxLength={20}
            required={required}
          />

          {isValidating && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
              <Loader2 className="h-4 w-4 animate-spin text-gray-400" />
            </div>
          )}

          {licenseInfo && !isValidating && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
              <CheckCircle className="h-4 w-4 text-green-500" />
            </div>
          )}

          {(error || validationError) && !isValidating && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
              <AlertCircle className="h-4 w-4 text-red-500" />
            </div>
          )}
        </div>

        {(error || validationError) && (
          <p className="text-sm text-red-600 mt-1">
            {error || validationError}
          </p>
        )}
      </div>

      {licenseInfo && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            <Trans id="license.info_heading">License Information</Trans>
          </h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">
                <Trans id="license.name_label">Name:</Trans>
              </span>
              <span className="font-medium">{licenseInfo.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">
                <Trans id="license.role_label">Role:</Trans>
              </span>
              <span className="font-medium">{licenseInfo.role.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">
                <Trans id="license.status_label">Status:</Trans>
              </span>
              {getStatusBadge(licenseInfo.status)}
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">
                <Trans id="license.features_label">Features:</Trans>
              </span>
              <span className="font-medium">
                {licenseInfo.role.permissions.length} {t({ id: "license.permissions_plural", message: "permissions" })}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">
                <Trans id="license.price_label">Price:</Trans>
              </span>
              <span className="font-medium">${licenseInfo.price}/
                <Trans id="license.price_year">year</Trans>
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">
                <Trans id="license.expires_label">Expires:</Trans>
              </span>
              <span className="font-medium">
                {new Date(licenseInfo.expirationDate).toLocaleDateString()}
              </span>
            </div>
          </div>

          {licenseInfo.role.permissions.length > 0 && (
            <div className="mt-3">
              <p className="text-xs text-gray-600 mb-2">
                <Trans id="license.included_permissions">Included Permissions:</Trans>
              </p>
              <div className="flex flex-wrap gap-1">
                {licenseInfo.role.permissions.slice(0, 5).map((permission) => (
                  <span
                    key={permission.id}
                    className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs"
                  >
                    {permission.name
                      .replace("VIEWER_", "")
                      .replace("EDITOR_", "")}
                  </span>
                ))}
                {licenseInfo.role.permissions.length > 5 && (
                  <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
                    +{licenseInfo.role.permissions.length - 5} {t({ id: "license.more_label", message: "more" })}
                  </span>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
