import { useState } from "react";
import { Mail, Lock, Eye, EyeOff } from "lucide-react";
import { useLogin } from "./hooks/useAuthOperations";
import { t, Trans } from "@lingui/macro";
import { useLocale } from "@/contexts/LocaleContext";
import { Link } from "react-router-dom";

export default function LoginForm() {
  const [showPassword, setShowPassword] = useState(false);
  const { form, onSubmit, authError, isLoading } = useLogin();

  const { localeInfo } = useLocale();
  const isRTL = localeInfo.direction === "rtl";

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = form;

  // Conditional classes for input padding
  const emailInputPadding = isRTL ? "pr-10 pl-4" : "pl-10 pr-4";
  const passwordInputPadding = isRTL ? "pr-10 pl-10" : "pl-10 pr-10"; // for password with eye icon

  // Conditional classes for icon positioning
  const iconPrefixPosition = isRTL ? "right-3" : "left-3"; // Icon inside at the logical start
  const iconSuffixPosition = isRTL ? "left-3" : "right-3"; // Icon inside at the logical end

  return (
    <div className="bg-white p-8 w-full max-w-md mx-auto">
      <div className="text-center mb-8">
        <div className="w-20 h-20 mx-auto mb-4 flex items-center justify-center">
          <img
            src="/logo.jpg"
            alt={t({
              id: "login.logoAlt",
              message: "EHC - Experts Human Capital",
            })}
            className="w-20 h-20 rounded-full object-cover shadow-lg"
          />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          <Trans id="login.welcomeBack">Welcome Back</Trans>
        </h2>
        <p className="text-gray-600 text-sm">
          <Trans id="login.signInPrompt">Sign in to your account</Trans>
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* Error message above the email field */}
        <div style={{ minHeight: "40px" }}>
          {authError && (
            <div className="p-3 bg-red-50 border border-red-300 rounded-md mb-2">
              <p className="text-sm text-red-600">{authError}</p>
            </div>
          )}
        </div>
        {/* Email */}
        <div>
          <label
            htmlFor="email"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            <Trans id="login.emailLabel">Email Address</Trans>
          </label>
          <div className="relative">
            <Mail
              className={`absolute top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 ${iconPrefixPosition}`}
            />
            <input
              id="email"
              type="email"
              autoComplete="email"
              {...register("email")}
              className={`w-full ${emailInputPadding} py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
                errors.email ? "border-red-300" : "border-gray-300"
              }`}
              placeholder={t({
                id: "login.emailPlaceholder",
                message: "Enter your email",
              })}
            />
          </div>
          {errors.email && (
            <p className="mt-1 text-xs text-red-600">{errors.email.message}</p>
          )}
        </div>

        {/* Password */}
        <div>
          <label
            htmlFor="password"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            <Trans id="login.passwordLabel">Password</Trans>
          </label>
          <div className="relative">
            <Lock
              className={`absolute top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 ${iconPrefixPosition}`}
            />
            <input
              id="password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              {...register("password")}
              className={`w-full ${passwordInputPadding} py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
                errors.password ? "border-red-300" : "border-gray-300"
              }`}
              placeholder={t({
                id: "login.passwordPlaceholder",
                message: "Enter your password",
              })}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className={`absolute top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 ${iconSuffixPosition}`}
            >
              {showPassword ? (
                <EyeOff className="w-4 h-4" />
              ) : (
                <Eye className="w-4 h-4" />
              )}
            </button>
          </div>
          {errors.password && (
            <p className="mt-1 text-xs text-red-600">
              {errors.password.message}
            </p>
          )}
        </div>

        {/* Remember me and Forgot password */}
        <div
          className={`flex items-center justify-between ${
            isRTL ? "flex-row-reverse" : ""
          }`}
        >
          <div
            className={`flex items-center ${isRTL ? "flex-row-reverse" : ""}`}
          >
            <input
              id="remember-me"
              name="remember-me"
              type="checkbox"
              defaultChecked={false}
              className={`w-4 h-4 text-[#238D94] border-gray-300 rounded focus:ring-[#238D94] ${
                isRTL ? "ml-2" : "mr-2"
              }`}
            />
            <label
              htmlFor="remember-me"
              className={`${
                isRTL ? "mr-2" : "ml-2"
              } block text-sm text-gray-900`}
            >
              <Trans id="login.rememberMe">Remember me</Trans>
            </label>
          </div>
          <div className="text-sm">
            <a
              href="#"
              className="font-medium text-[#238D94] hover:text-[#1a6b75] transition-colors duration-200"
            >
              <Trans id="login.forgotPassword">Forgot password?</Trans>
            </a>
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-[#238D94] text-white py-3 px-4 rounded-md font-medium hover:bg-[#1a6b75] focus:ring-4 focus:ring-[#238D94] focus:ring-opacity-20 transition-all duration-200 text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              <Trans id="login.signingIn">Signing In...</Trans>
            </>
          ) : (
            <Trans id="login.signIn">Sign In</Trans>
          )}
        </button>

        {/* Sign Up Link */}
        <p className="text-center text-sm text-gray-600">
          <Trans id="login.noAccount">Don't have an account?</Trans>{" "}
          <Link
            to="/auth/signup"
            className="text-[#238D94] hover:text-[#1a6b75] font-medium transition-colors duration-200"
          >
            <Trans id="login.signUpNow">Sign up now</Trans>
          </Link>
        </p>
      </form>
    </div>
  );
}
