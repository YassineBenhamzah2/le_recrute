import {
  Building,
  Eye,
  EyeOff,
  FileImage,
  Lock,
  Mail,
  Phone,
  User,
} from "lucide-react";
import { useEffect, useState } from "react";
import { GetCountries, GetState } from "react-country-state-city";
import { Country, State } from "react-country-state-city/dist/esm/types";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { toast } from "sonner";
import { FieldPath } from "react-hook-form";
import { useRegisterRecruiter, RecruiterRegisterFormValues } from "./hooks/useAuthOperations";
import { LicenseKeyInput } from "./LicenseKeyInput";
import { Trans } from "@lingui/react/macro";
import { t } from "@lingui/core/macro";
import { Link } from "react-router-dom";

export default function RegisterRecruiterForm() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [step, setStep] = useState(1);

  const {
    form,
    onSubmit,
    authError,
    isLoading,
    sectors,
    sectorsLoading,
    sectorsError,
  } = useRegisterRecruiter();

  const [location, setLocation] = useState<string[]>(["", ""]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [states, setStates] = useState<State[]>([]);
  const [country, setCountry] = useState<Country | null>(null);
  const [state, setState] = useState<State | null>(null);

  const {
    register,
    formState: { errors },
    setValue,
    watch,
    trigger,
  } = form;

  // Update form localisation field when location array changes
  useEffect(() => {
    const locationString = location.filter(Boolean).join(", ");
    if (locationString && location.filter(Boolean).length === 2) {
      setValue("localisation", locationString);
    } else {
      setValue("localisation", "");
    }
  }, [location, setValue]);

  // Load countries on mount
  useEffect(() => {
    GetCountries().then(setCountries);
  }, []);

  // Load states when country changes
  useEffect(() => {
    if (country) {
      GetState(country.id).then(setStates);
    } else {
      setStates([]);
      setState(null);
    }
  }, [country]);

  // Handle location change
  const handleLocationChange = (
    countryVal: Country | null,
    stateVal: State | null = null
  ) => {
    if (countryVal) {
      if (stateVal) {
        setLocation([countryVal.name, stateVal.name]);
      } else {
        setLocation([countryVal.name, ""]);
      }
    } else {
      setLocation(["", ""]);
    }
  };

  // Handle license validation
  const handleLicenseValidated = () => {
    // setValidatedLicense(license);
  };

  // Handle logo file upload
  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setValue("logo", e.target.files[0], { shouldValidate: true });
      trigger("logo");
    } else {
      setValue("logo", null, { shouldValidate: true });
      trigger("logo");
    }
  };

  const handleNext = async () => {
    const step1Fields: FieldPath<RecruiterRegisterFormValues>[] = [
      "firstname",
      "lastname",
      "email",
      "phone",
      "licenseKey",
      "password",
      "confirmPassword",
    ];

    // Trigger validation for only the fields in step 1
    const isStep1Valid = await trigger(step1Fields);

    if (isStep1Valid) {
      // If validation is successful, move to the next step
      setStep(2);
    } else {
      // If validation fails, show a toast notification
      toast.error(
        t({
          id: "register.step1_error",
          message: "Please fill in all required fields correctly before continuing.",
        })
      );
    }
  };

  // Step 1 fields
  const step1Fields = (
    <>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="firstname"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            <Trans id="register.firstname_label">First Name</Trans>
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              id="firstname"
              {...register("firstname")}
              className={`w-full pl-10 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
                errors.firstname ? "border-red-300" : "border-gray-300"
              }`}
              placeholder={t({
                id: "register.firstname_placeholder",
                message: "First name",
              })}
            />
          </div>
          {errors.firstname && (
            <p className="mt-1 text-xs text-red-600">
              {errors.firstname.message as string}
            </p>
          )}
        </div>
        <div>
          <label
            htmlFor="lastname"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            <Trans id="register.lastname_label">Last Name</Trans>
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              id="lastname"
              {...register("lastname")}
              className={`w-full pl-10 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
                errors.lastname ? "border-red-300" : "border-gray-300"
              }`}
              placeholder={t({
                id: "register.lastname_placeholder",
                message: "Last name",
              })}
            />
          </div>
          {errors.lastname && (
            <p className="mt-1 text-xs text-red-600">
              {errors.lastname.message as string}
            </p>
          )}
        </div>
      </div>
      <div>
        <label
          htmlFor="email"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          <Trans id="register.email_label">Email Address</Trans>
        </label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="email"
            id="email"
            {...register("email")}
            className={`w-full pl-10 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
              errors.email ? "border-red-300" : "border-gray-300"
            }`}
            placeholder={t({
              id: "register.email_placeholder",
              message: "Enter your email",
            })}
          />
        </div>
        {errors.email && (
          <p className="mt-1 text-xs text-red-600">
            {errors.email.message as string}
          </p>
        )}
      </div>
      <div>
        <label
          htmlFor="phone"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          <Trans id="register.phone_label">Phone Number</Trans>
        </label>
        <div className="relative">
          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="tel"
            id="phone"
            {...register("phone")}
            className={`w-full pl-10 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
              errors.phone ? "border-red-300" : "border-gray-300"
            }`}
            placeholder={t({
              id: "register.phone_placeholder",
              message: "Enter your phone number",
            })}
          />
        </div>
        {errors.phone && (
          <p className="mt-1 text-xs text-red-600">
            {errors.phone.message as string}
          </p>
        )}
      </div>
      <div>
        <LicenseKeyInput
          value={watch("licenseKey") || ""}
          onChange={(value) =>
            setValue("licenseKey", value, { shouldValidate: true })
          }
          onLicenseValidated={handleLicenseValidated}
          error={errors.licenseKey?.message as string}
          required={true}
        />
      </div>
      <div>
        <label
          htmlFor="password"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          <Trans id="register.password_label">Password</Trans>
        </label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type={showPassword ? "text" : "password"}
            id="password"
            {...register("password")}
            className={`w-full pl-10 pr-10 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
              errors.password ? "border-red-300" : "border-gray-300"
            }`}
            placeholder={t({
              id: "register.password_placeholder",
              message: "Create a password",
            })}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            {showPassword ? (
              <EyeOff className="w-4 h-4" />
            ) : (
              <Eye className="w-4 h-4" />
            )}
          </button>
        </div>
        {errors.password && (
          <p className="mt-1 text-xs text-red-600">
            {errors.password.message as string}
          </p>
        )}
      </div>
      <div>
        <label
          htmlFor="confirmPassword"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          <Trans id="register.confirmPassword_label">Confirm Password</Trans>
        </label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type={showConfirmPassword ? "text" : "password"}
            id="confirmPassword"
            {...register("confirmPassword")}
            className={`w-full pl-10 pr-10 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
              errors.confirmPassword ? "border-red-300" : "border-gray-300"
            }`}
            placeholder={t({
              id: "register.confirmPassword_placeholder",
              message: "Confirm your password",
            })}
          />
          <button
            type="button"
            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            {showConfirmPassword ? (
              <EyeOff className="w-4 h-4" />
            ) : (
              <Eye className="w-4 h-4" />
            )}
          </button>
        </div>
        {errors.confirmPassword && (
          <p className="mt-1 text-xs text-red-600">
            {errors.confirmPassword.message as string}
          </p>
        )}
      </div>
    </>
  );

  // Step 2 fields
  const step2Fields = (
    <>
      <div>
        <label
          htmlFor="entreprise"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          <Trans id="register.company_label">Company Name</Trans>
        </label>
        <div className="relative">
          <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            id="entreprise"
            {...register("entreprise")}
            className={`w-full pl-10 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
              errors.entreprise ? "border-red-300" : "border-gray-300"
            }`}
            placeholder={t({
              id: "register.company_placeholder",
              message: "Company Name",
            })}
          />
        </div>
        {errors.entreprise && (
          <p className="mt-1 text-xs text-red-600">
            {errors.entreprise.message as string}
          </p>
        )}
      </div>
      <div>
        <label
          htmlFor="localisation"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          <Trans id="register.location_label">Location</Trans>
        </label>
        <div className="flex gap-2">
          {/* Country Select */}
          <Select
            value={country?.id?.toString()}
            onValueChange={(id) => {
              if (id === "all") {
                setCountry(null);
                setState(null);
                handleLocationChange(null);
              } else {
                const selected = countries.find((c) => c.id.toString() === id);
                setCountry(selected!);
                setState(null);
                handleLocationChange(selected!, null);
              }
            }}
          >
            <SelectTrigger className="w-1/2">
              <SelectValue
                placeholder={t({
                  id: "register.country_placeholder",
                  message: "Country",
                })}
              />
            </SelectTrigger>
            <SelectContent>
              <SelectItem key="all" value="all">
                {t({ id: "register.all_countries", message: "All Countries" })}
              </SelectItem>
              {countries.map((c) => (
                <SelectItem key={c.id} value={c.id.toString()}>
                  <img
                    alt={c.name}
                    src={`http://purecatamphetamine.github.io/country-flag-icons/3x2/${c.iso2}.svg`}
                    className="w-6 h-4 inline-block mr-2"
                  />
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* State Select */}
          <Select
            disabled={!country}
            value={state?.id?.toString()}
            onValueChange={(id) => {
              const selected = states.find((s) => s.id.toString() === id);
              setState(selected!);
              handleLocationChange(country, selected);
            }}
          >
            <SelectTrigger className="w-1/2">
              <SelectValue
                placeholder={t({
                  id: "register.state_placeholder",
                  message: "State",
                })}
              />
            </SelectTrigger>
            <SelectContent>
              {states.map((s) => (
                <SelectItem key={s.id} value={s.id.toString()}>
                  {s.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {errors.localisation && (
          <p className="mt-1 text-xs text-red-600">
            {errors.localisation.message as string}
          </p>
        )}
        {location.filter(Boolean).length === 2 && (
          <p className="mt-1 text-xs text-green-600">
            <Trans id="register.selected_location">
              Selected: {location.join(", ")}
            </Trans>
          </p>
        )}
      </div>
      <div>
        <label
          htmlFor="description"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          <Trans id="register.description_label">Description</Trans>
        </label>
        <textarea
          id="description"
          {...register("description")}
          className={`w-full pl-4 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
            errors.description ? "border-red-300" : "border-gray-300"
          }`}
          placeholder={t({
            id: "register.description_placeholder",
            message: "Describe your company...",
          })}
          rows={3}
        />
        {errors.description && (
          <p className="mt-1 text-xs text-red-600">
            {errors.description.message as string}
          </p>
        )}
      </div>
      <div>
        <label
          htmlFor="sectorOfActivity"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          <Trans id="register.sector_label">Sector of Activity</Trans>
        </label>
        {sectorsLoading ? (
          <div className="text-sm text-gray-500">
            {t({
              id: "register.loading_sectors",
              message: "Loading sectors...",
            })}
          </div>
        ) : sectorsError ? (
          <div className="text-sm text-red-600">{sectorsError}</div>
        ) : Array.isArray(sectors) && sectors.length > 0 ? (
          <select
            id="sectorOfActivity"
            {...register("sectorOfActivity", { required: true })}
            className={`w-full pl-4 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
              errors.sectorOfActivity ? "border-red-300" : "border-gray-300"
            }`}
            defaultValue=""
          >
            <option value="" disabled>
              {t({
                id: "register.choose_sector",
                message: "Choose sector of activity",
              })}
            </option>
            {sectors.map((sector) => (
              <option key={sector.id} value={String(sector.id)}>
                {sector.name}
              </option>
            ))}
          </select>
        ) : (
          <div className="text-sm text-red-600">
            {t({
              id: "register.no_sectors",
              message: "No sectors found. Please try again later.",
            })}
          </div>
        )}
        {errors.sectorOfActivity && (
          <p className="mt-1 text-xs text-red-600">
            {errors.sectorOfActivity.message as string}
          </p>
        )}
      </div>
      <div>
        <label
          htmlFor="logo"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          <Trans id="register.logo_label">Company Logo</Trans>
        </label>
        <div className="relative">
          <FileImage className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="file"
            id="logo"
            accept=".png,.jpg,.jpeg,.webp,.svg"
            onChange={handleLogoChange}
            className={`w-full pl-10 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm bg-white ${
              errors.logo ? "border-red-300" : "border-gray-300"
            }`}
          />
        </div>
        {errors.logo && (
          <p className="mt-1 text-xs text-red-600">
            {errors.logo.message as string}
          </p>
        )}
        {watch("logo") && watch("logo") instanceof File && (
          <div className="mt-1 text-xs text-gray-600 flex items-center gap-2">
            <span className="bg-green-100 text-green-800 px-2 py-1 rounded">
              ✓ Selected: {watch("logo")?.name} (
              {Math.round((watch("logo")?.size || 0) / 1024)}KB)
            </span>
          </div>
        )}
      </div>
      <div>
        <label className="flex items-start space-x-3 cursor-pointer">
          <input
            type="checkbox"
            {...register("agreeToTerms")}
            className="mt-0.5 w-4 h-4 text-[#238D94] border-gray-300 rounded focus:ring-[#238D94]"
          />
          <span className="text-sm text-gray-600">
            <Trans id="register.agree_terms">
              I agree to the <a>Terms of Service</a> and <a>Privacy Policy</a>
            </Trans>
          </span>
        </label>
        {errors.agreeToTerms && (
          <p className="mt-1 text-xs text-red-600">
            {errors.agreeToTerms.message as string}
          </p>
        )}
      </div>
    </>
  );

  return (
    <div className="w-full max-w-xl mx-auto">
      <div className="text-center mb-8">
        <div className="w-20 h-20 mx-auto mb-4 flex items-center justify-center">
          <img
            src="/logo.jpg"
            alt="EHC - Experts Human Capital"
            className="w-20 h-20 rounded-full object-cover shadow-lg"
          />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          <Trans id="register.heading">Create Account</Trans>
        </h2>
        <p className="text-gray-600 text-sm">
          <Trans id="register.subheading">
            Post jobs. Hire faster. Join JobHub today
          </Trans>
        </p>
      </div>

      <form onSubmit={onSubmit} className="space-y-4">
        {authError && (
          <div className="p-3 bg-red-50 border border-red-300 rounded-md">
            <p className="text-sm text-red-600">{authError}</p>
          </div>
        )}

        {step === 1 && (
          <>
            {step1Fields}
            <button
              type="button"
              className="w-full bg-[#238D94] text-white py-3 px-4 rounded-md font-medium hover:bg-[#1a6b75] focus:ring-4 focus:ring-[#238D94] focus:ring-opacity-20 transition-all duration-200 text-sm flex items-center justify-center"
              onClick={handleNext}
            >
              <Trans id="register.next_button">Next →</Trans>
            </button>
            <p className="text-center text-sm text-gray-600">
              <Trans id="register.already_have_account">
                Already have an account?{" "}
                <Link
                  to="/auth/recruiter-signin"
                  className="text-[#238D94] hover:text-[#1a6b75] font-medium"
                >
                  Sign in here
                </Link>
              </Trans>
            </p>
          </>
        )}

        {step === 2 && (
          <>
            {step2Fields}
            <div className="flex justify-between">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="bg-gray-200 text-gray-700 py-3 px-6 rounded-md font-medium hover:bg-gray-300 transition-all duration-200 text-sm"
              >
                <Trans id="register.back_button">← Back</Trans>
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="bg-[#238D94] text-white py-3 px-6 rounded-md font-medium hover:bg-[#1a6b75] focus:ring-4 focus:ring-[#238D94] focus:ring-opacity-20 transition-all duration-200 text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    <Trans id="register.create_account_loading">
                      Create account...
                    </Trans>
                  </>
                ) : (
                  <Trans id="register.create_account_button">
                    Create account
                  </Trans>
                )}
              </button>
            </div>
            <p className="text-center text-sm text-gray-600">
              <Trans id="register.already_have_account">
                Already have an account?{" "}
                <a
                  href="/auth/recruiter-signin"
                  className="text-[#238D94] hover:text-[#1a6b75] font-medium"
                >
                  Sign in here
                </a>
              </Trans>
            </p>
          </>
        )}
      </form>
    </div>
  );
}
