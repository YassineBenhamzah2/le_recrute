import { useState } from 'react';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { LoginSchema } from '../../lib/form/auth';
import z from 'zod';
import { useNavigate } from 'react-router-dom';
import { Trans } from "@lingui/react/macro";
import { t } from "@lingui/core/macro";

type FormValues = z.infer<ReturnType<typeof LoginSchema>>;

export default function RecruiterLoginForm() {
  const { login } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(LoginSchema()),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const onSubmit = async (data: FormValues) => {
    setAuthError(null);
    setIsLoading(true);
    try {
      await login(data.email, data.password);
    } catch (error: any) {
      let msg = t({
                  id: 'recruiterLogin.invalidCredentials',
                  message: 'Invalid email or password.'
                });
      if (error?.response?.data?.error?.message) {
        msg = error.response.data.error.message;
      } else if (error?.message) {
        msg = error.message;
      }
      setAuthError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="rounded-xl p-6 w-full flex flex-col items-center">
      <div className="w-full max-w-md mx-auto">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {/* Error message above the email field */}
          <div>
            {authError && (
              <div className="p-2 bg-red-50 border border-red-300 rounded-md mb-2">
                <p className="text-sm text-red-600">{authError}</p>
              </div>
            )}
          </div>
          {/* Email */}
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
              <Trans id="recruiterLogin.emailLabel">Email Address</Trans>
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                id="email"
                type="email"
                autoComplete="email"
                {...register('email')}
                className={`w-full pl-10 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${errors.email ? 'border-red-300' : 'border-gray-300'}`}
                placeholder={t({ id: 'recruiterLogin.emailPlaceholder', message: 'Enter your email' })}
              />
            </div>
            {errors.email && (
              <p className="mt-1 text-xs text-red-600">{errors.email.message}</p>
            )}
          </div>
          {/* Password */}
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
              <Trans id="recruiterLogin.passwordLabel">Password</Trans>
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                {...register('password')}
                className={`w-full pl-10 pr-10 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${errors.password ? 'border-red-300' : 'border-gray-300'}`}
                placeholder={t({ id: 'recruiterLogin.passwordPlaceholder', message: 'Enter your password' })}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {errors.password && (
              <p className="mt-1 text-xs text-red-600">{errors.password.message}</p>
            )}
          </div>
          {/* Remember me and Forgot password */}
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <input
                id="remember-me"
                name="remember-me"
                type="checkbox"
                checked={rememberMe}
                onChange={() => setRememberMe(!rememberMe)}
                className="w-4 h-4 text-[#238D94] border-gray-300 rounded focus:ring-[#238D94]"
              />
              <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
                <Trans id="recruiterLogin.rememberMe">Remember me</Trans>
              </label>
            </div>
            <div className="text-sm">
              <a href="#" className="font-medium text-[#238D94] hover:text-[#1a6b75] transition-colors duration-200">
                <Trans id="recruiterLogin.forgotPassword">Forgot password?</Trans>
              </a>
            </div>
          </div>
          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-[#238D94] text-white py-3 px-4 rounded-md font-medium hover:bg-[#1a6b75] focus:ring-4 focus:ring-[#238D94] focus:ring-opacity-20 transition-all duration-200 text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                <Trans id="recruiterLogin.signingIn">Sign In...</Trans>
              </>
            ) : (
              <Trans id="recruiterLogin.signIn">Sign In</Trans>
            )}
          </button>
          {/* Sign Up Button */}
          <button
            type="button"
            onClick={() => navigate('/auth/recruiter-signup')}
            className="w-full mt-2 bg-[#004d4f] text-white/60 py-3 px-4 rounded-md hover:bg-[#003133] focus:ring-4 focus:ring-[#004d4f] focus:ring-opacity-20 transition-all duration-200 text-sm"
          >
            <Trans id="recruiterLogin.noAccount">
              Don't have an account? <span className="font-semibold ml-1 text-white">Sign up now</span>
            </Trans>
          </button>
        </form>
      </div>
    </div>
  );
}