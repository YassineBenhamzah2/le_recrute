/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../../contexts/AuthContext";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  LoginSchema,
  RegisterSchema,
  RecruiterRegisterSchema,
} from "../../../lib/form/auth";
import { navigateBasedOnRole } from "../../../lib/utils/navigation";
import z from "zod";
import { t } from "@lingui/macro";

// Form types
type LoginFormValues = z.infer<ReturnType<typeof LoginSchema>>;
type RegisterFormValues = z.infer<ReturnType<typeof RegisterSchema>>;
export type RecruiterRegisterFormValues = z.infer<ReturnType<typeof RecruiterRegisterSchema>>;

// Hook for login operations
export const useLogin = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [authError, setAuthError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(LoginSchema()),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginFormValues) => {
    setAuthError(null);
    setIsLoading(true);
    try {
      const user = await login(data.email, data.password);
      // Navigate based on role type after successful login
      navigateBasedOnRole(user.role, navigate);
    } catch (error: any) {
      let msg = t({ id: "login.invalidEmailOrPassword", message: "Invalid email or password." });
      if (error?.response?.data?.error?.message) {
        msg = error.response.data.error.message;
      } else if (error?.message) {
        msg = error.message;
      }
      setAuthError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    form,
    onSubmit,
    authError,
    isLoading,
    setAuthError,
  };
};

// Hook for candidate registration
export const useRegisterCandidate = () => {
  const { registerCandidate } = useAuth();
  const navigate = useNavigate();
  const [authError, setAuthError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<RegisterFormValues>({
    resolver: zodResolver(RegisterSchema()),
    defaultValues: {
      firstname: "",
      lastname: "",
      email: "",
      password: "",
      confirmPassword: "",
      agreeToTerms: false,
    },
  });

  const onSubmit = async (data: RegisterFormValues) => {
    setAuthError(null);
    setIsLoading(true);
    try {
      const result = await registerCandidate({
        firstname: data.firstname,
        lastname: data.lastname,
        email: data.email,
        password: data.password,
      });
      // Navigate based on role type after successful registration
      navigateBasedOnRole(result.user.role, navigate);
    } catch (error: any) {
      let msg = t({ id: "register.registrationFailed", message: "Registration failed. Please try again." });
      if (error?.response?.data?.error?.message) {
        msg = error.response.data.error.message;
      } else if (error?.message) {
        msg = error.message;
      }
      setAuthError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    form,
    onSubmit: form.handleSubmit(onSubmit),
    authError,
    isLoading,
    setAuthError,
  };
};

// Hook for recruiter registration with sectors
export const useRegisterRecruiter = () => {
  const { registerRecruiter, sectors, loadSectors } = useAuth();
  const navigate = useNavigate();
  const [authError, setAuthError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [sectorsLoading, setSectorsLoading] = useState(true);
  const [sectorsError, setSectorsError] = useState<string | null>(null);

  // Load sectors when hook is used
  useEffect(() => {
    const fetchSectors = async () => {
      setSectorsLoading(true);
      try {
        await loadSectors();
        setSectorsError(null);
      } catch {
        setSectorsError(t({ id: "register.sectorsLoadFailed", message: "Failed to load sectors. Please try again later." }));
      } finally {
        setSectorsLoading(false);
      }
    };

    // Only load sectors if they haven't been loaded yet
    if (sectors.length === 0) {
      fetchSectors();
    } else {
      setSectorsLoading(false);
    }
  }, [loadSectors, sectors.length]);

  // Update sectors error based on sectors state
  useEffect(() => {
    if (sectors && sectors.length > 0) {
      setSectorsError(null);
    } else if (sectors && sectors.length === 0 && !sectorsLoading) {
      setSectorsError(t({ id: "register.noSectorsFound", message: "No sectors found. Please try again later." }));
    }
  }, [sectors, sectorsLoading]);

  const form = useForm<RecruiterRegisterFormValues>({
    resolver: zodResolver(RecruiterRegisterSchema()),
    defaultValues: {
      firstname: "",
      lastname: "",
      email: "",
      phone: "",
      password: "",
      confirmPassword: "",
      licenseKey: "",
      position: "",
      entreprise: "",
      localisation: "",
      description: "",
      sectorOfActivity: "",
      agreeToTerms: false,
    },
  });

  const onSubmit = async (data: RecruiterRegisterFormValues) => {
    setAuthError(null);
    setIsLoading(true);
    console.log("Submitting recruiter form data:", data);
    try {
      const result = await registerRecruiter({
        firstname: data.firstname,
        lastname: data.lastname,
        email: data.email,
        phone: data.phone,
        password: data.password,
        licenseKey: data.licenseKey,
        position: data.position,
        entreprise: data.entreprise,
        localisation: data.localisation,
        description: data.description,
        sectorOfActivity: data.sectorOfActivity,
        logo: data.logo,
        agreeToTerms: data.agreeToTerms,
      });
      // Navigate based on role type after successful registration
      navigateBasedOnRole(result.user.role, navigate);
    } catch (error: any) {
      let msg = t({ id: "register.registrationFailed", message: "Registration failed. Please try again." });
      if (error?.response?.data?.error?.message) {
        msg = error.response.data.error.message;
      } else if (error?.message) {
        msg = error.message;
      }
      setAuthError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    form,
    onSubmit: form.handleSubmit(onSubmit),
    authError,
    isLoading,
    sectors,
    sectorsLoading,
    sectorsError,
    setAuthError,
  };
};
