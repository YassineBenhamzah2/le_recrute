/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";
import { Eye, EyeOff, User, Mail, Lock } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { RegisterSchema } from "../../lib/form/auth";
import z from "zod";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { navigateBasedOnRole } from "../../lib/utils/navigation";
import { Trans, t } from "@lingui/macro";

const FormSchema = RegisterSchema;

type FormValues = z.infer<ReturnType<typeof FormSchema>>;

export default function RegisterForm() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { registerCandidate } = useAuth();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(FormSchema()),
    defaultValues: {
      firstname: "",
      lastname: "",
      email: "",
      password: "",
      confirmPassword: "",
      agreeToTerms: false,
    },
  });

  const onSubmit = async (data: FormValues) => {
    setSubmitError(null);
    setIsLoading(true);
    try {
      const resData = await registerCandidate({
        firstname: data.firstname,
        lastname: data.lastname,
        email: data.email,
        password: data.password,
      });
      // Navigate based on role type after successful registration
      navigateBasedOnRole(resData.user.role, navigate);
    } catch (error: any) {
      let msg = t({
        id: "register.error",
        message: "Registration failed. Please try again.",
      });
      if (error?.response?.data?.error?.message) {
        msg = error.response.data.error.message;
      } else if (error?.message) {
        msg = error.message;
      }
      setSubmitError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Logo and Title */}
      <div className="text-center mb-8">
        <div className="w-20 h-20 mx-auto mb-4 flex items-center justify-center">
          <img
            src="/logo.jpg"
            alt={t({
              id: "register.logoAlt",
              message: "EHC - Experts Human Capital",
            })}
            className="w-20 h-20 rounded-full object-cover shadow-lg"
          />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          <Trans id="register.title">Create Account</Trans>
        </h2>
        <p className="text-gray-600 text-sm">
          <Trans id="register.subtitle">
            Join JobHub and find your perfect job
          </Trans>
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* Registration Error */}
        {submitError && (
          <div className="p-3 bg-red-50 border border-red-300 rounded-md">
            <p className="text-sm text-red-600">{submitError}</p>
          </div>
        )}

        {/* Name Fields */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="firstname"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              <Trans id="register.firstname.label">First Name</Trans>
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                id="firstname"
                {...register("firstname")}
                className={`w-full pl-10 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
                  errors.firstname ? "border-red-300" : "border-gray-300"
                }`}
                placeholder={t({
                  id: "register.firstname.placeholder",
                  message: "First name",
                })}
              />
            </div>
            {errors.firstname && (
              <p className="mt-1 text-xs text-red-600">
                {errors.firstname.message}
              </p>
            )}
          </div>

          <div>
            <label
              htmlFor="lastname"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              <Trans id="register.lastname.label">Last Name</Trans>
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                id="lastname"
                {...register("lastname")}
                className={`w-full pl-10 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
                  errors.lastname ? "border-red-300" : "border-gray-300"
                }`}
                placeholder={t({
                  id: "register.lastname.placeholder",
                  message: "Last name",
                })}
              />
            </div>
            {errors.lastname && (
              <p className="mt-1 text-xs text-red-600">
                {errors.lastname.message}
              </p>
            )}
          </div>
        </div>

        {/* Email */}
        <div>
          <label
            htmlFor="email"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            <Trans id="register.email.label">Email Address</Trans>
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="email"
              id="email"
              {...register("email")}
              className={`w-full pl-10 pr-4 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
                errors.email ? "border-red-300" : "border-gray-300"
              }`}
              placeholder={t({
                id: "register.email.placeholder",
                message: "Enter your email",
              })}
            />
          </div>
          {errors.email && (
            <p className="mt-1 text-xs text-red-600">{errors.email.message}</p>
          )}
        </div>

        {/* Password */}
        <div>
          <label
            htmlFor="password"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            <Trans id="register.password.label">Password</Trans>
          </label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type={showPassword ? "text" : "password"}
              id="password"
              {...register("password")}
              className={`w-full pl-10 pr-10 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
                errors.password ? "border-red-300" : "border-gray-300"
              }`}
              placeholder={t({
                id: "register.password.placeholder",
                message: "Create a password",
              })}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? (
                <EyeOff className="w-4 h-4" />
              ) : (
                <Eye className="w-4 h-4" />
              )}
            </button>
          </div>
          {errors.password && (
            <p className="mt-1 text-xs text-red-600">
              {errors.password.message}
            </p>
          )}
        </div>

        {/* Confirm Password */}
        <div>
          <label
            htmlFor="confirmPassword"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            <Trans id="register.confirm.label">Confirm Password</Trans>
          </label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type={showConfirmPassword ? "text" : "password"}
              id="confirmPassword"
              {...register("confirmPassword")}
              className={`w-full pl-10 pr-10 py-2.5 border rounded-md focus:ring-2 focus:ring-[#238D94] focus:border-transparent transition-all duration-200 text-sm ${
                errors.confirmPassword ? "border-red-300" : "border-gray-300"
              }`}
              placeholder={t({
                id: "register.confirm.placeholder",
                message: "Confirm your password",
              })}
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showConfirmPassword ? (
                <EyeOff className="w-4 h-4" />
              ) : (
                <Eye className="w-4 h-4" />
              )}
            </button>
          </div>
          {errors.confirmPassword && (
            <p className="mt-1 text-xs text-red-600">
              {errors.confirmPassword.message}
            </p>
          )}
        </div>

        {/* Terms Agreement */}
        <div>
          <label className="flex items-start space-x-3 cursor-pointer">
            <input
              type="checkbox"
              {...register("agreeToTerms")}
              className="mt-0.5 w-4 h-4 text-[#238D94] border-gray-300 rounded focus:ring-[#238D94]"
            />
            <span className="text-sm text-gray-600">
              <Trans id="register.agree">I agree to the</Trans>{" "}
              <a
                href="#"
                className="text-[#238D94] hover:text-[#1a6b75] font-medium"
              >
                <Trans id="register.terms">Terms of Service</Trans>
              </a>{" "}
              <Trans id="register.and">and</Trans>{" "}
              <a
                href="#"
                className="text-[#238D94] hover:text-[#1a6b75] font-medium"
              >
                <Trans id="register.privacy">Privacy Policy</Trans>
              </a>
            </span>
          </label>
          {errors.agreeToTerms && (
            <p className="mt-1 text-xs text-red-600">
              {errors.agreeToTerms.message}
            </p>
          )}
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-[#238D94] text-white py-3 px-4 rounded-md font-medium hover:bg-[#1a6b75] focus:ring-4 focus:ring-[#238D94] focus:ring-opacity-20 transition-all duration-200 text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              <Trans id="register.button.loading">Create Account…</Trans>
            </>
          ) : (
            <Trans id="register.button">Create Account</Trans>
          )}
        </button>

        {/* Sign In Link */}
        <p className="text-center text-sm text-gray-600">
          <Trans id="register.already">Already have an account?</Trans>{" "}
          <Link
            to="/auth/signin"
            className="text-[#238D94] hover:text-[#1a6b75] font-medium"
          >
            <Trans id="register.signin">Sign in here</Trans>
          </Link>
        </p>
      </form>
    </div>
  );
}
