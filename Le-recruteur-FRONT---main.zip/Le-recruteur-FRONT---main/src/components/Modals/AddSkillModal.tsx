import React, { useState } from "react";
import { X, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import { Trans, t } from "@lingui/macro";
import { useAuth } from "@/contexts/AuthContext";

interface AddSkillModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSkillAdded: (newSkill: SkillResponse) => void;
  onLanguageAdded: (newLanguage: LanguageResponse) => void;
}

interface SkillResponse {
  id: number;
  name: string;
  level: number;
  type: "SOFTSKILL" | "HARDSKILL";
}

interface SkillRequest {
  name: string;
  level: number;
  type: "SOFTSKILL" | "HARDSKILL";

  candidateId: number;
}

interface LanguageRequest {
  name: string;
  level: number;
  candidateId: number;
}

interface LanguageResponse {
  id: number;
  name: string;
  level: number;
}

const LANGUAGE_OPTIONS = [
  { value: "ENGLISH", label: "English" },
  { value: "FRENCH", label: "French" },
  { value: "ARABIC", label: "Arabic" },
  { value: "SPANISH", label: "Spanish" },
  { value: "GERMAN", label: "German" },
  { value: "ITALIAN", label: "Italian" },
  { value: "PORTUGUESE", label: "Portuguese" },
  { value: "RUSSIAN", label: "Russian" },
  { value: "CHINESE", label: "Chinese" },
  { value: "JAPANESE", label: "Japanese" },
  { value: "KOREAN", label: "Korean" },
];

const AddSkillModal: React.FC<AddSkillModalProps> = ({
  isOpen,
  onClose,
  onSkillAdded,
  onLanguageAdded,
}) => {
  const [skillLanguageName, setSkillLanguageName] = useState("");
  const [category, setCategory] = useState("Hard Skills");
  const [proficiencyLevel, setProficiencyLevel] = useState(50);
  const [selectedLanguage, setSelectedLanguage] = useState("");

  const { user } = useAuth();
  const candidateId = user?.id;
  if (!isOpen) return null;

  const resetForm = () => {
    setSkillLanguageName("");
    setSelectedLanguage("");
    setProficiencyLevel(50);
    setCategory("Hard Skills");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (category !== "Languages") {
      // Handle skill submission
      if (!skillLanguageName.trim()) {
        toast.error(t`Please enter a skill name`);
        return;
      }

      const skill: SkillRequest = {
        name: skillLanguageName,
        level: proficiencyLevel,
        type: category === "Hard Skills" ? "HARDSKILL" : "SOFTSKILL",
        candidateId: candidateId as number, // Ensure candidateId is a number
      };

      api
        .post<SkillResponse>(`/candidate/profile/addSkill`, skill)
        .then((newSkill) => {
          onSkillAdded(newSkill);
          toast.success(t`Skill added successfully`);
          resetForm();
          onClose();
        })
        .catch(() => toast.error(t`Error adding skill`));
    } else {
      // Handle language submission
      if (!selectedLanguage) {
        toast.error(t`Please select a language`);
        return;
      }

      const language: LanguageRequest = {
        name: selectedLanguage,
        level: proficiencyLevel,
        candidateId: candidateId as number, // Ensure candidateId is a number
      };

      api
        .post<LanguageResponse>(`/candidate/profile/addLanguage`, language)
        .then((newLanguage) => {
          onLanguageAdded(newLanguage);
          toast.success(t`Language added successfully`);
          resetForm();
          onClose();
        })
        .catch(() => toast.error(t`Error adding language`));
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 ">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h3 className="text-xl font-semibold text-gray-900">
              {category === "Languages" ? (
                <Trans>Add New Language</Trans>
              ) : (
                <Trans>Add New Skill</Trans>
              )}
            </h3>
            <p className="text-gray-600 text-sm mt-1">
              <Trans>Expand your professional profile</Trans>
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Category using Select component */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Category</Trans>
            </label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder={t`Select a category`} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Hard Skills">
                  <Trans>Hard Skills</Trans>
                </SelectItem>
                <SelectItem value="Languages">
                  <Trans>Languages</Trans>
                </SelectItem>
                <SelectItem value="Soft Skills">
                  <Trans>Soft Skills</Trans>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Skill Name using Input component or Language dropdown */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {category === "Languages" ? (
                <Trans>Language</Trans>
              ) : (
                <Trans>Skill Name</Trans>
              )}
            </label>

            {category === "Languages" ? (
              <Select
                value={selectedLanguage}
                onValueChange={setSelectedLanguage}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder={t`Select a language`} />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGE_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Input
                type="text"
                value={skillLanguageName}
                onChange={(e) => setSkillLanguageName(e.target.value)}
                placeholder={t`e.g., Python, Leadership`}
                required
              />
            )}
          </div>

          {/* Proficiency Level */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Proficiency Level</Trans>
            </label>
            <div className="space-y-4">
              <input
                type="range"
                min="0"
                max="100"
                value={proficiencyLevel}
                onChange={(e) => setProficiencyLevel(Number(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                style={{
                  background: `linear-gradient(to right, #14b8a6 0%, #14b8a6 ${proficiencyLevel}%, #e5e7eb ${proficiencyLevel}%, #e5e7eb 100%)`,
                }}
              />
              <div className="text-center">
                <span className="text-2xl font-bold text-teal-600">
                  {proficiencyLevel}%
                </span>
              </div>
            </div>
          </div>

          {/* Preview */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-gray-700 mb-3">
              <Trans>Preview</Trans>
            </h4>
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium text-gray-900">
                {skillLanguageName || t`Skill Name`}
              </span>
              <span className="text-sm text-gray-500">{proficiencyLevel}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-teal-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${proficiencyLevel}%` }}
              ></div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              <Trans>Cancel</Trans>
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-teal-600 hover:bg-teal-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              {category === "Languages" ? (
                <Trans>Add Language</Trans>
              ) : (
                <Trans>Add Skill</Trans>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddSkillModal;
