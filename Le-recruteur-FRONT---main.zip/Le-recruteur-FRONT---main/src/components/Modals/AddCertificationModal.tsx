import React, { useState,useEffect } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { api } from '@/lib/network/utils/api';
import {toast} from "sonner" ;
import AsyncSelect from 'react-select/async';
import { Trans, t } from '@lingui/macro';


interface AddCertificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCertificationAdded: (newCertification: CertificationItem) => void; 

}


interface CertificationItem {
  id: number;
  name: string;
}

interface SectorResponse {
  id : number ;
  name : string  ;
}



interface SelectOption {
    value: number;
    label: string;
}


const initialFormData = {
    certificationName: '',
    issuedBy: '' ,
    industry: null as SelectOption | null,
    credentialId_Url: '',
    issueDate: '',
    expirationDate: ''
};


const AddCertificationModal: React.FC<AddCertificationModalProps> = ({ isOpen, onClose,onCertificationAdded }) => {
    
  // id candidate
  const storedUser = localStorage.getItem("userData");
  let candidateId : number ;
  if(storedUser){
    const parsedUser = JSON.parse(storedUser) ;
    candidateId = parsedUser.id;
  }


    const [isLoading, setIsLoading] = useState(false);

    const [formData, setFormData] = useState(initialFormData);

  useEffect(() => {
    if (isOpen) setFormData(initialFormData);
  }, [isOpen]);

  if (!isOpen) return null;



  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSelectChange = (field: string, option: SelectOption | null) => {
    setFormData(prev => ({ ...prev, [field]: option }));
  };



  const loadSectorOptions = (inputValue: string): Promise<SelectOption[]> => {
    return api.getItem<SectorResponse[]>(`/candidate/profile/sectors/search?q=${inputValue}`)
      .then(res => res.map(s => ({ value: s.id, label: s.name })));
  };


  
  const handleSaveCertification = (e: React.FormEvent) => {
    e.preventDefault();
    
    setIsLoading(true);


    const payload = {
        ...formData,
        industry: formData.industry?.value, // Envoie l'ID
        candidateId: candidateId,
    };

    api.post<CertificationItem>(`/candidate/profile/addCertification`, payload)
      .then((newCertification) => {
         onCertificationAdded(newCertification);
         onClose();
         toast.success(t`Certification added successfully`);
      })
      .catch(() => toast.error(t`Error adding certification: ` ))
      .finally(() => setIsLoading(false));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 sticky top-0 bg-white">
          <h3 className="text-xl font-semibold text-gray-900"><Trans>Add Certification</Trans></h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form */}
        <form  className="p-6 space-y-6">
          {/* Certification Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Certification Name </Trans><span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.certificationName}
              onChange={(e) => handleInputChange('certificationName', e.target.value)}
              placeholder={t`e.g., AWS Certified Developer`}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              required
            />
          </div>

          {/* Issued By */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Issued By</Trans><span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.issuedBy}
              onChange={(e) => handleInputChange('issuedBy', e.target.value)}
              placeholder={t`e.g., TechCorp Inc.`}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              required
            />
             
          </div>

          {/* Industry and Job Function */}
          
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Trans>Industry </Trans><span className="text-red-500">*</span>
              </label>
             <AsyncSelect
                  cacheOptions
                  defaultOptions
                  loadOptions={loadSectorOptions}
                  value={formData.industry}
                  onChange={(option) => handleSelectChange('industry', option)}
                  placeholder={t`Search for an industry...`}
              />
            </div>

            
          

          {/* Credential ID */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Credential ID or URL</Trans><span className="text-gray-500"><Trans>(optional)</Trans></span>
            </label>
            <input
              type="text"
              value={formData.credentialId_Url}
              onChange={(e) => handleInputChange('credentialId_Url', e.target.value)}
              placeholder={t`e.g., link to certificate`}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
            />
          </div>

          {/* Issue Date and Expiration Date */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Trans>Issue Date</Trans><span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={formData.issueDate}
                  onChange={(e) => handleInputChange('issueDate', e.target.value)}
                  placeholder="--------- ----"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Trans>Expiration Date </Trans><span className="text-gray-500"><Trans>(optional)</Trans></span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={formData.expirationDate}
                  onChange={(e) => handleInputChange('expirationDate', e.target.value)}
                  placeholder="--------- ----"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                />
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end pt-6">
            <Button
              type="button"
              className="bg-teal-600 hover:bg-teal-700 text-white px-8"
              disabled={isLoading}

              onClick={handleSaveCertification}
            >
              {isLoading ? t`Saving...` : t`Save Now`}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddCertificationModal;