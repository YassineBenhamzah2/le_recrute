/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useRef, useEffect } from "react";
import { useFileDrop } from "./hooks/useFileDrop";
import { X, Upload, FileText, Star, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { jobOffersService } from "@/lib/network/pages/jobOffers";
import { Trans } from "@lingui/macro";
import { t } from "@lingui/core/macro";

interface ApplyJobFormProps {
  isOpen: boolean;
  onClose: () => void;
  jobId?: number;
  jobTitle?: string;
  questions?: string[];
  questionIds?: number[];
  onApplied?: (jobId: number) => void;
}

export default function ApplyJobForm({
  isOpen,
  onClose,
  jobId,
  jobTitle,
  questions,
  questionIds,
  onApplied,
}: ApplyJobFormProps) {
  const [formData, setFormData] = useState({
    cv: null as File | null,
    motivationLetter: null as File | null,
  });
  const [submitting, setSubmitting] = useState(false);
  const { user, isCandidate: checkIsCandidate } = useAuth();
  const [formError, setFormError] = useState<string | null>(null);
  const [cvError, setCvError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Normalize and keep answers aligned to provided questions
  const visibleQuestions = (questions || [])
    .map((q) => String(q ?? "").trim())
    .filter((q) => q.length > 0);
  const [answers, setAnswers] = useState<string[]>([]);
  useEffect(() => {
    setAnswers(Array(visibleQuestions.length).fill(""));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visibleQuestions.length]);

  const cvInputRef = useRef<HTMLInputElement>(null);
  const motivationInputRef = useRef<HTMLInputElement>(null);
  const fileAcceptRegex = /\.(pdf|doc|docx)$/i;

  const cvDrop = useFileDrop({
    acceptRegex: fileAcceptRegex,
    onDropFile: (file) => handleFileUpload("cv", file),
    manageGlobalDrop: isOpen,
  });

  const motivationDrop = useFileDrop({
    acceptRegex: fileAcceptRegex,
    onDropFile: (file) => handleFileUpload("motivationLetter", file),
  });

  const handleFileUpload = (
    field: "cv" | "motivationLetter",
    file: File | null
  ) => {
    setFormData((prev) => ({
      ...prev,
      [field]: file,
    }));
    if (field === "cv" && file) {
      setCvError(null);
    }
  };

  const resetForm = () => {
    setFormData({ cv: null, motivationLetter: null });
    setAnswers(Array(visibleQuestions.length).fill(""));
    if (cvInputRef.current) cvInputRef.current.value = "";
    if (motivationInputRef.current) motivationInputRef.current.value = "";
    setFormError(null);
    setCvError(null);
  };

  // Reset when modal closes
  useEffect(() => {
    if (!isOpen) {
      resetForm();
    }
  }, [isOpen]);

  const handleSubmit = async () => {
    setFormError(null);
    setCvError(null);
    if (!jobId) {
      setFormError(t`Missing job information. Please refresh and try again.`);
      return;
    }

    const isCandidate = checkIsCandidate();
    const candidateId = user?.id;
    if (!isCandidate) {
      // Guard: must be candidate
      setFormError(
        t`Only candidates can apply. Please sign in with a candidate account.`
      );
      return;
    }

    if (!formData.cv) {
      setCvError(t`Resume is required`);
      return;
    }

    try {
      setSubmitting(true);
      const fd = new FormData();
      fd.append("candidateId", String(candidateId));
      fd.append("cv", formData.cv);
      if (formData.motivationLetter) {
        fd.append("motivationLetter", formData.motivationLetter);
      }
      // Build answers payload; fallback uses index-based question_id when IDs are not available
      const answersPayload = (answers || [])
        .map((ans, idx) => ({
          question_id:
            questionIds && questionIds[idx]
              ? Number(questionIds[idx])
              : idx + 1,
          answer: ans,
        }))
        .filter((entry) => String(entry.answer).trim().length > 0);
      if (answersPayload.length > 0) {
        fd.append("answers", JSON.stringify(answersPayload));
      }

      const res = await jobOffersService.applyToJob(jobId, fd);
      if (res?.success) {
        console.log("Application submitted:", res);
        resetForm();
        if (jobId != null) {
          try {
            onApplied?.(jobId);
          } catch (error) {
            console.error("Error calling onApplied callback:", error);
          }
        }
        setSuccessMessage(t`Application submitted successfully!`);
        // Auto-dismiss success overlay and close modal
        setTimeout(() => {
          setSuccessMessage(null);
          onClose();
        }, 2000);
      } else {
        const serverMsg = (res as any)?.error?.message || (res as any)?.message;
        setFormError(
          serverMsg || (
            <Trans>Failed to submit application. Please try again.</Trans>
          )
        );
      }
    } catch (err) {
      const message = (err as any)?.error?.message || (err as any)?.message || (
        <Trans>
          An unexpected error occurred while submitting your application.
        </Trans>
      );
      setFormError(message);
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-ehc-green rounded-lg flex items-center justify-center">
              <Star className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-800 font-poppins">
                <Trans id="apply_job.title">
                  Apply to "{jobTitle || "New Job"}"
                </Trans>
              </h2>
              <p className="text-sm text-gray-600 font-poppins">
                <Trans id="apply_job.info">Fill in the job information</Trans>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-red-500 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form Content */}
        <div className="p-6 space-y-6">
          {formError && (
            <div
              className="border border-red-200 bg-red-50 text-red-700 rounded-md p-3 text-sm font-poppins"
              role="alert"
              aria-live="polite"
            >
              {formError}
            </div>
          )}
          {/* Basic Information Section */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <FileText className="w-5 h-5 text-gray-600" />
              <h3 className="text-lg font-semibold text-gray-800 font-poppins">
                <Trans id="apply_job.basic_info">Basic Information</Trans>
              </h3>
            </div>

            {/* CV Upload */}
            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2 font-poppins">
                <Upload className="w-4 h-4" />
                <Trans id="apply_job.cv_label">Upload Resume</Trans>
              </label>
              <div
                className={`border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-ehc-green transition-colors cursor-pointer ${
                  cvDrop.active ? "border-ehc-green bg-green-50" : ""
                }`}
                onClick={() => cvInputRef.current?.click()}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    cvInputRef.current?.click();
                  }
                }}
                onDragOver={cvDrop.onDragOver}
                onDragEnter={cvDrop.onDragEnter}
                onDragLeave={cvDrop.onDragLeave}
                onDrop={cvDrop.onDrop}
              >
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mb-3">
                    <FileText className="w-6 h-6 text-gray-400" />
                  </div>
                  <p className="text-sm text-gray-600 font-poppins mb-2">
                    <Trans id="apply_job.cv_instructions">
                      Click to upload or drag and drop
                    </Trans>
                  </p>
                  <p className="text-xs text-gray-500 font-poppins">
                    <Trans id="apply_job.cv_format">
                      PDF, DOC, DOCX (Max 5MB)
                    </Trans>
                  </p>
                </div>
                {formData.cv && (
                  <p className="mt-3 text-sm text-gray-700 font-poppins">
                    <Trans>Selected: {formData.cv.name}</Trans>
                  </p>
                )}
                <input
                  ref={cvInputRef}
                  type="file"
                  accept=".pdf,.doc,.docx"
                  className="hidden"
                  onChange={(e) =>
                    handleFileUpload("cv", e.target.files?.[0] || null)
                  }
                />
              </div>
              {cvError && (
                <p className="mt-2 text-sm text-red-600 font-poppins">
                  {cvError}
                </p>
              )}
            </div>

            {/* Motivation Letter Upload */}
            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2 font-poppins">
                <Upload className="w-4 h-4" />
                <Trans id="apply_job.motivation_label">
                  Upload Motivation Letter
                </Trans>
              </label>
              <div
                className={`border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-ehc-green transition-colors cursor-pointer ${
                  motivationDrop.active ? "border-ehc-green bg-green-50" : ""
                }`}
                onClick={() => motivationInputRef.current?.click()}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    motivationInputRef.current?.click();
                  }
                }}
                onDragOver={motivationDrop.onDragOver}
                onDragEnter={motivationDrop.onDragEnter}
                onDragLeave={motivationDrop.onDragLeave}
                onDrop={motivationDrop.onDrop}
              >
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mb-3">
                    <FileText className="w-6 h-6 text-gray-400" />
                  </div>
                  <p className="text-sm text-gray-600 font-poppins mb-2">
                    <Trans id="apply_job.cv_instructions">
                      Click to upload or drag and drop
                    </Trans>
                  </p>
                  <p className="text-xs text-gray-500 font-poppins">
                    <Trans id="apply_job.cv_format">
                      PDF, DOC, DOCX (Max 5MB)
                    </Trans>
                  </p>
                </div>
                {formData.motivationLetter && (
                  <p className="mt-3 text-sm text-gray-700 font-poppins">
                    <Trans>Selected: {formData.motivationLetter.name}</Trans>
                  </p>
                )}
                <input
                  ref={motivationInputRef}
                  type="file"
                  accept=".pdf,.doc,.docx"
                  className="hidden"
                  onChange={(e) =>
                    handleFileUpload(
                      "motivationLetter",
                      e.target.files?.[0] || null
                    )
                  }
                />
              </div>
            </div>
          </div>

          {/* Conditional Application Form */}
          <div className="border border-gray-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-800 font-poppins mb-6">
              <Trans id="apply_job.form_title">
                Conditional Application Form
              </Trans>
            </h3>

            {visibleQuestions.length === 0 ? (
              <div className="text-sm text-gray-500 font-poppins">
                <Trans id="apply_job.no_questions">
                  No additional questions for this offer.
                </Trans>
              </div>
            ) : (
              <div className="space-y-6">
                {visibleQuestions.map((q, idx) => (
                  <div key={idx}>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs">✓</span>
                      </div>
                      <label className="text-sm font-medium text-gray-700 font-poppins">
                        {q}
                      </label>
                    </div>
                    <input
                      type="text"
                      value={answers[idx] || ""}
                      onChange={(e) => {
                        const next = [...answers];
                        next[idx] = e.target.value;
                        setAnswers(next);
                      }}
                      className="border border-gray-400 rounded w-3/4 h-8 p-2"
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex justify-between items-center p-6 border-t border-gray-200">
          <Button
            variant="outline"
            onClick={onClose}
            className="px-8 py-2 font-poppins"
          >
            <Trans id="apply_job.cancel">Cancel</Trans>
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={submitting}
            className="bg-ehc-green hover:bg-ehc-green/90 text-white px-8 py-2 font-poppins disabled:opacity-60"
          >
            {submitting ? (
              <Trans id="apply_job.submitting">Submitting...</Trans>
            ) : (
              <Trans id="apply_job.apply">Apply Job</Trans>
            )}
          </Button>
        </div>
      </div>
      {/* Success Overlay */}
      {successMessage && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60]">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-sm text-center">
            <div className="flex justify-center mb-3">
              <div className="rounded-full bg-green-100 p-2">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </div>
            <p className="text-green-700 font-medium font-poppins">
              {successMessage}
            </p>
            <div className="mt-4">
              <Button
                className="bg-ehc-green hover:bg-ehc-green/90 text-white px-6 py-2 font-poppins"
                onClick={() => {
                  setSuccessMessage(null);
                  onClose();
                }}
              >
                <Trans id="apply_job.ok">OK</Trans>
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
