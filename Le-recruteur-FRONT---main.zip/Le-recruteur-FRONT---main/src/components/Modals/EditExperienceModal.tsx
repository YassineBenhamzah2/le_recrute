import React, { useState, useEffect } from "react";
import { X, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import AsyncSelect from "react-select/async";
import { Country, City } from "country-state-city";
import { settings } from "@/lib/settings/main";
import { Trans, t } from "@lingui/macro";

interface Experience {
  id: number;
  position: string;
  company: Company;
  industry: Industry;
  startDate: string;
  endDate: string;
  current: boolean;
  location: string;
  workplaceRating: string;
  description: string;
}

interface LocationOption {
  value: string; // Le code ISO
  label: string; // Le nom
}

interface Company {
  id: number;
  name: string;
  logo: string;
}

interface Industry {
  id: number;
  name: string;
}

interface SelectOption {
  value: number;
  label: string;
  logo?: string;
}

interface CompanySelectOption {
  value: number;
  label: string;
  logo: string | undefined;
}

// Make sure LocationOption remains compatible with react-select
interface LocationOption {
  value: string;
  label: string;
  isoCode?: string;
  countryCode?: string;
}

interface EditExperienceModalProps {
  isOpen: boolean;
  onClose: () => void;
  experience: Experience | null;
  onExperienceUpdated: (updatedExperience: Experience) => void;
}

interface SectorResponse {
  id: number;
  name: string;
}

interface CompanyResponse {
  id: number;
  name: string;
  logo: string | null;
}

interface FormDataType {
  position: string;
  company: CompanySelectOption | null;
  workplaceRating: number;
  industry: SelectOption | null;
  country: LocationOption | null;
  city: LocationOption | null;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
}

const EditExperienceModal: React.FC<EditExperienceModalProps> = ({
  isOpen,
  onClose,
  experience,
  onExperienceUpdated,
}) => {
  const [formData, setFormData] = useState<FormDataType | null>(null);

  useEffect(() => {
    if (experience) {
      const locationParts = experience.location
        .split(",")
        .map((part) => part.trim());
      // Since we've removed region, assume we only have city and country
      const cityName = locationParts[0] || "";
      const countryName = locationParts.length > 1 ? locationParts[1] : "";

      const country = Country.getAllCountries().find(
        (c) => c.name === countryName
      );

      // We don't need region anymore
      const countryOption = country
        ? { value: country.isoCode, label: country.name }
        : null;

      // City is now just based on name
      const cityOption = cityName ? { value: cityName, label: cityName } : null;

      setFormData({
        position: experience.position,
        company: {
          value: experience.company.id,
          label: experience.company.name,
          logo: experience.company.logo,
        } as CompanySelectOption,
        workplaceRating: Number(experience.workplaceRating),
        industry: {
          value: experience.industry.id,
          label: experience.industry.name,
        },
        country: countryOption,
        city: cityOption,
        startDate: experience.startDate,
        endDate: experience.endDate,
        current: experience.current,
        description: experience.description,
      });
    }
  }, [experience]);

  if (!isOpen || !formData) return null;

  const handleInputChange = <T extends keyof FormDataType>(
    field: T,
    value: FormDataType[T]
  ) => {
    setFormData((prev) => (prev ? { ...prev, [field]: value } : null));
  };

  const loadCompanyOptions = (
    inputValue: string,
    callback: (options: CompanySelectOption[]) => void
  ) => {
    setTimeout(() => {
      api
        .getItem<CompanyResponse[]>(
          `/candidate/profile/companies/search?q=${inputValue}`
        )
        .then((res) => {
          const options = res.map((c) => {
            if (c.logo && c.logo.startsWith("uploads/")) {
              c.logo = `${settings.IMG_ADDRESS}${c.logo}`;
            } else if (!c.logo) {
              c.logo = settings.DEFAULT_COMPANY_AVATAR ;
            }

            return {
              value: c.id,
              label: c.name,
              logo: c.logo,
            };
          });

          callback(options);
        })
        .catch(() => callback([]));
    }, 600);
  };

  const loadSectorOptions = (
    inputValue: string,
    callback: (options: SelectOption[]) => void
  ) => {
    setTimeout(() => {
      api
        .getItem<SectorResponse[]>(
          `/candidate/profile/sectors/search?q=${inputValue}`
        )
        .then((res) => {
          const options = res.map((c) => ({ value: c.id, label: c.name }));
          callback(options);
        })
        .catch(() => callback([]));
    }, 700);
  };

  const handleCurrentWorkChange = (isChecked: boolean) => {
    setFormData((prev) =>
      prev
        ? {
            ...prev,
            current: isChecked,
            endDate: isChecked ? "" : prev.endDate,
          }
        : null
    );
  };

  const handleSelectChange = <T extends keyof FormDataType>(
    field: T,
    option: FormDataType[T]
  ) => {
    setFormData((prev) => {
      if (!prev) return null;
      const newState = { ...prev, [field]: option };
      if (field === "country") {
        newState.city = null;
      }
      return newState;
    });
  };

  const loadCountryOptions = (
    inputValue: string,
    callback: (options: LocationOption[]) => void
  ) => {
    setTimeout(() => {
      const countries = Country.getAllCountries().map((c) => ({
        value: c.isoCode,
        label: c.name,
        isoCode: c.isoCode,
      }));
      callback(
        countries.filter((c) =>
          c.label.toLowerCase().includes(inputValue.toLowerCase())
        )
      );
    }, 300);
  };

  const loadCityOptions = (
    inputValue: string,
    callback: (options: LocationOption[]) => void
  ) => {
    setTimeout(() => {
      if (!formData?.country?.value) {
        callback([]);
        return;
      }

      try {
        // For each country, provide a list of major cities
        const countryCode = formData.country.value;

        // Try to get cities from the API
        try {
          const citiesFromLib = City.getCitiesOfCountry(countryCode);
          if (citiesFromLib && citiesFromLib.length > 0) {
            // Map cities to the format we need
            const cities = citiesFromLib.map((city) => ({
              value: city.name,
              label: city.name,
            }));

            // Filter by input text if provided
            const filteredCities = inputValue
              ? cities.filter((city) =>
                  city.label.toLowerCase().includes(inputValue.toLowerCase())
                )
              : cities;

            callback(filteredCities);
            return;
          }
        } catch (e) {
          console.warn("Error getting cities from library", e);
        }

        // Fallback with some common cities based on country
        let cities: LocationOption[] = [];
        if (countryCode === "US") {
          cities = [
            "New York",
            "Los Angeles",
            "Chicago",
            "Houston",
            "Phoenix",
          ].map((c) => ({ value: c, label: c }));
        } else if (countryCode === "GB") {
          cities = [
            "London",
            "Manchester",
            "Birmingham",
            "Glasgow",
            "Liverpool",
          ].map((c) => ({ value: c, label: c }));
        } else if (countryCode === "FR") {
          cities = ["Paris", "Marseille", "Lyon", "Toulouse", "Nice"].map(
            (c) => ({ value: c, label: c })
          );
        } else if (countryCode === "MA") {
          cities = ["Casablanca", "Rabat", "Marrakech", "Fes", "Tangier"].map(
            (c) => ({ value: c, label: c })
          );
        }

        // If country isn't in our fallback list, allow for free text input
        if (cities.length === 0 && inputValue.length > 0) {
          cities = [{ value: inputValue, label: inputValue }];
        }

        // Filter by input text if provided
        if (inputValue) {
          cities = cities.filter((city) =>
            city.label.toLowerCase().includes(inputValue.toLowerCase())
          );
        }

        callback(cities);
      } catch (error) {
        console.error("Error loading cities:", error);
        // Allow free text input as a fallback
        if (inputValue.length > 0) {
          callback([{ value: inputValue, label: inputValue }]);
        } else {
          callback([]);
        }
      }
    }, 300);
  };

  const renderStarRating = () => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => handleInputChange("workplaceRating", star)}
            className="transition-colors"
          >
            <Star
              className={`w-5 h-5 ${
                star <= formData.workplaceRating
                  ? "fill-yellow-400 text-yellow-400"
                  : "text-gray-300 hover:text-yellow-400"
              }`}
            />
          </button>
        ))}
      </div>
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!experience) return;

    const locationString = [formData.city?.label, formData.country?.label]
      .filter(Boolean)
      .join(", ");

    const payload = {
      position: formData.position,
      companyId: formData.company?.value,
      workplaceRating: String(formData.workplaceRating),
      industryId: formData.industry?.value,
      location: locationString,
      startDate: formData.startDate,
      endDate: formData.current ? "" : formData.endDate,
      current: formData.current,
      description: formData.description,
    };

    api
      .put<Experience>(
        `/candidate/profile/experiences/${experience.id}`,
        payload
      )
      .then((updatedExperience) => {
        onExperienceUpdated(updatedExperience);
        onClose();
        toast.success(t`Experience updated successfully!`);
      })
      .catch(() => toast.error(t`Failed to update experience.`));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 font-sans">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        {/* En-tête */}
        <div className="flex-shrink-0 flex items-center justify-between p-6 border-b border-gray-200 sticky top-0 bg-white">
          <h3 className="text-xl font-semibold text-gray-900">
            <Trans>Edit Experience</Trans>
          </h3>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-600 rounded-full"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Formulaire */}

        <form
          onSubmit={handleSubmit}
          className="flex-grow overflow-y-auto p-6 space-y-6"
        >
          {/* Position */}
          <div>
            <label
              htmlFor="position-edit"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans>Position</Trans> <span className="text-red-500">*</span>
            </label>
            <input
              id="position-edit"
              type="text"
              value={formData.position}
              onChange={(e) => handleInputChange("position", e.target.value)}
              placeholder={t`e.g., Senior Software Engineer`}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              required
            />
          </div>

          {/* Company */}
          <div>
            <label
              htmlFor="company-edit"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans>Current Employer/Company</Trans>{" "}
              <span className="text-red-500">*</span>
            </label>
            <AsyncSelect
              cacheOptions
              defaultOptions
              loadOptions={loadCompanyOptions}
              value={formData.company}
              onChange={(opt) =>
                handleSelectChange("company", opt as CompanySelectOption)
              }
              placeholder={t`Search and select a company...`}
              classNamePrefix="select"
              formatOptionLabel={(option: CompanySelectOption) => (
                <div className="flex items-center">
                  <img
                    src={option.logo}
                    alt={option.label}
                    className="w-7 h-7 rounded-full mr-2 object-cover"
                  />
                  <span>{option.label}</span>
                </div>
              )}
              styles={{
                option: (provided) => ({
                  ...provided,
                  paddingLeft: 2,
                }),
                singleValue: (provided) => ({
                  ...provided,
                  marginLeft: 0,
                }),
              }}
            />
          </div>

          {/* Rating */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Workplace Quality Rating </Trans>
              <span className="text-red-500">*</span>
            </label>
            {renderStarRating()}
          </div>

          {/* Industry & Job Function */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="industry-edit"
                className="block text-sm font-medium text-gray-700 mb-2"
              >
                <Trans>Industry </Trans>
                <span className="text-red-500">*</span>
              </label>
              <AsyncSelect
                cacheOptions
                defaultOptions
                loadOptions={loadSectorOptions}
                value={formData.industry}
                onChange={(opt) =>
                  handleSelectChange("industry", opt as SelectOption)
                }
                placeholder={t`Search and select a sector...`}
                classNamePrefix="select"
              />
            </div>
          </div>

          {/* Location & Dates */}
          <div>
            <label
              htmlFor="location-edit"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans>Location</Trans>
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Country */}
              <AsyncSelect
                cacheOptions
                defaultOptions
                loadOptions={loadCountryOptions}
                value={formData.country}
                onChange={(option) =>
                  handleSelectChange("country", option as LocationOption)
                }
                placeholder={t`Country`}
                classNamePrefix="select"
              />
              {/* City */}
              <AsyncSelect
                cacheOptions
                defaultOptions
                key={`city-${formData.country?.value || "none"}`}
                loadOptions={loadCityOptions}
                value={formData.city}
                onChange={(option) =>
                  handleSelectChange("city", option as LocationOption)
                }
                isDisabled={!formData.country}
                placeholder={t`City`}
                classNamePrefix="select"
                noOptionsMessage={() => t`Type to search for a city`}
              />
            </div>
          </div>

          {/* <div className="grid grid-cols-1 md:grid-cols-2 gap-4"> */}
          <div>
            <label
              htmlFor="start-date-edit"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans>Start Date </Trans>
              <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                id="start-date-edit"
                type="date"
                value={formData.startDate}
                onChange={(e) => handleInputChange("startDate", e.target.value)}
                placeholder={t`YYYY-MM-DD`}
                className="w-full p-3  border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                required
              />
            </div>
          </div>

          <div>
            {/* --- CASE À COCHER --- */}
            <div className="flex items-center mb-2">
              <input
                id="isCurrent"
                type="checkbox"
                checked={formData.current}
                onChange={(e) => handleCurrentWorkChange(e.target.checked)}
                className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
              />
              <label
                htmlFor="isCurrent"
                className="ml-2 block text-sm text-gray-900"
              >
                <Trans>I currently work here</Trans>
              </label>
            </div>

            {!formData.current && (
              <div>
                <label
                  htmlFor="endDate"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  <Trans>End Date</Trans>
                </label>
                <input
                  id="endDate"
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => handleInputChange("endDate", e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg "
                />
              </div>
            )}
          </div>

          {/* Description */}
          <div>
            <label
              htmlFor="description-edit"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans>Description</Trans>
            </label>
            <textarea
              id="description-edit"
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              placeholder={t`Describe your responsibilities and achievements...`}
              rows={4}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end pt-6">
            <Button
              type="submit"
              className="bg-teal-600 hover:bg-teal-700 text-white px-8"
            >
              <Trans>Save Changes</Trans>
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditExperienceModal;
