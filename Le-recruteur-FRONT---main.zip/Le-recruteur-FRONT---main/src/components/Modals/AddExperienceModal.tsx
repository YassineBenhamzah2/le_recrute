import { useState, useEffect } from "react";
import { X, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import AsyncSelect from "react-select/async";
import { Country, City } from "country-state-city";
import { Trans, t } from "@lingui/macro";
import { settings } from "@/lib/settings/main";

interface AddExperienceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExperienceAdded: (newExperience: AddExperienceResponse) => void;
}

interface LocationOption {
  value: string;
  label: string;
  isoCode?: string;
  countryCode?: string;
}

interface AddExperienceRequest {
  position: string;
  companyId: number | undefined;
  workplaceRating: string;
  industryId: number | undefined;
  location: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;

  candidateId: number;
}

interface AddExperienceResponse {
  id: number;
  position: string;
  company: Company;
  industry: Industry;
  startDate: string;
  endDate: string;
  current: boolean;
  location: string;
  workplaceRating: string;
  description: string;
}

interface Company {
  id: number;
  name: string;
  logo: string;
}

interface Industry {
  id: number;
  name: string;
}

interface SectorResponse {
  id: number;
  name: string;
}

interface CompanyResponse {
  id: number;
  name: string;
  logo: string | null;
}

interface SelectOption {
  value: number;
  label: string;
}

interface CompanySelectOption {
  value: number;
  label: string;
  logo: string | undefined;
}

interface FormDataType {
  position: string;
  company: CompanySelectOption | null;
  workplaceRating: number;
  industry: SelectOption | null;
  country: LocationOption | null;
  city: LocationOption | null;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
}

const initialFormData: FormDataType = {
  position: "",
  company: null,
  workplaceRating: 0,
  industry: null,
  country: null,
  city: null,
  startDate: "",
  endDate: "",
  current: false,
  description: "",
};

const AddExperienceModal: React.FC<AddExperienceModalProps> = ({
  isOpen,
  onClose,
  onExperienceAdded,
}) => {
  // id candidate
  const storedUser = localStorage.getItem("userData");
  let candidateId: number;
  if (storedUser) {
    const parsedUser = JSON.parse(storedUser);
    candidateId = parsedUser.id;
  }

  const [formData, setFormData] = useState(initialFormData);

  useEffect(() => {
    if (isOpen) {
      setFormData(initialFormData);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Construit la chaîne de localisation à partir des champs sélectionnés
    const locationString = [formData.city?.label, formData.country?.label]
      .filter(Boolean)
      .join(", "); // Ex: "Paris, France"

    const payload: AddExperienceRequest = {
      position: formData.position,
      companyId: formData.company?.value,
      workplaceRating: String(formData.workplaceRating),
      industryId: formData.industry?.value,
      location: locationString,
      startDate: formData.startDate,
      endDate: formData.current ? "" : formData.endDate,
      current: formData.current,
      description: formData.description,
      candidateId: Number(candidateId),
    };

    api
      .post<AddExperienceResponse>(`/candidate/profile/addExperience`, payload)
      .then((newExperience) => {
        onExperienceAdded(newExperience);
        onClose();
        toast.success(t`Experience added successfully`);
      })
      .catch(() => toast.error(t`Error adding experience`));
  };

  const loadCompanyOptions = (
    inputValue: string,
    callback: (options: CompanySelectOption[]) => void
  ) => {
    setTimeout(() => {
      api
        .getItem<CompanyResponse[]>(
          `/candidate/profile/companies/search?q=${inputValue}`
        )
        .then((res) => {
          const options = res.map((c) => {
            if (c.logo && c.logo.startsWith("uploads/")) {
              c.logo = `${settings.IMG_ADDRESS}${c.logo}`;
            } else if (!c.logo) {
              c.logo = settings.DEFAULT_COMPANY_AVATAR ;
            }

            return {
              value: c.id,
              label: c.name,
              logo: c.logo,
            };
          });

          callback(options);
        })
        .catch(() => callback([]));
    }, 600);
  };

  const loadSectorOptions = (
    inputValue: string,
    callback: (options: SelectOption[]) => void
  ) => {
    setTimeout(() => {
      api
        .getItem<SectorResponse[]>(
          `/candidate/profile/sectors/search?q=${inputValue}`
        )
        .then((res) => {
          const options = res.map((c) => ({ value: c.id, label: c.name }));
          callback(options);
        })
        .catch(() => callback([]));
    }, 600);
  };

  const handleCurrentWorkChange = (isChecked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      current: isChecked,
      endDate: isChecked ? "" : prev.endDate,
    }));
  };

  const handleInputChange = <T extends keyof FormDataType>(
    field: T,
    value: FormDataType[T]
  ) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSelectChange = <T extends keyof FormDataType>(
    field: T,
    option: FormDataType[T]
  ) => {
    if (field === "country") {
      setFormData((prev) => ({
        ...prev,
        [field]: option,
        city: null,
      }));
    } else {
      setFormData((prev) => ({ ...prev, [field]: option }));
    }
  };

  const loadCountryOptions = (
    inputValue: string,
    callback: (options: LocationOption[]) => void
  ) => {
    setTimeout(() => {
      const countries = Country.getAllCountries().map((c) => ({
        value: c.isoCode,
        label: c.name,
        isoCode: c.isoCode,
      }));
      callback(
        countries.filter((c) =>
          c.label.toLowerCase().includes(inputValue.toLowerCase())
        )
      );
    }, 300);
  };

  const loadCityOptions = (
    inputValue: string,
    callback: (options: LocationOption[]) => void
  ) => {
    setTimeout(() => {
      if (!formData.country?.value) {
        callback([]);
        return;
      }

      try {
        // For each country, provide a list of major cities
        const countryCode = formData.country.value;
        let cities: LocationOption[] = [];

        // Get cities from the country-state-city library
        const citiesFromLib = City.getCitiesOfCountry(countryCode) || [];

        // Map cities to the format we need
        cities = citiesFromLib.map((city) => ({
          value: city.name,
          label: city.name,
        }));

        // If no cities found or there's an error, provide some common cities as fallback
        if (cities.length === 0) {
          // Fallback with some common cities based on country
          if (countryCode === "US") {
            cities = [
              "New York",
              "Los Angeles",
              "Chicago",
              "Houston",
              "Phoenix",
            ].map((c) => ({ value: c, label: c }));
          } else if (countryCode === "GB") {
            cities = [
              "London",
              "Manchester",
              "Birmingham",
              "Glasgow",
              "Liverpool",
            ].map((c) => ({ value: c, label: c }));
          } else if (countryCode === "FR") {
            cities = ["Paris", "Marseille", "Lyon", "Toulouse", "Nice"].map(
              (c) => ({ value: c, label: c })
            );
          } else if (countryCode === "MA") {
            cities = ["Casablanca", "Rabat", "Marrakech", "Fes", "Tangier"].map(
              (c) => ({ value: c, label: c })
            );
          } else {
            // If country isn't in our fallback list, allow for free text input
            if (inputValue.length > 0) {
              cities = [{ value: inputValue, label: inputValue }];
            }
          }
        }

        // Filter by input text if provided
        if (inputValue) {
          cities = cities.filter((city) =>
            city.label.toLowerCase().includes(inputValue.toLowerCase())
          );
        }

        callback(cities);
      } catch (error) {
        console.error("Error loading cities:", error);
        // Allow free text input as a fallback if there's an error
        if (inputValue.length > 0) {
          callback([{ value: inputValue, label: inputValue }]);
        } else {
          callback([]);
        }
      }
    }, 300);
  };

  const renderStarRating = () => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => handleInputChange("workplaceRating", star)}
            className="transition-colors"
          >
            <Star
              className={`w-5 h-5 ${
                star <= formData.workplaceRating
                  ? "fill-yellow-400 text-yellow-400"
                  : "text-gray-300 hover:text-yellow-400"
              }`}
            />
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto ">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 sticky top-0 bg-white">
          <h3 className="text-xl font-semibold text-gray-900">
            <Trans>Add Experience</Trans>
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Position */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Position </Trans>
              <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.position}
              onChange={(e) => handleInputChange("position", e.target.value)}
              placeholder={t`e.g., Senior Software Engineer`}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              required
            />
          </div>
          {/* Current Employer/Company */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Employer/Company</Trans>{" "}
              <span className="text-red-500">*</span>
            </label>
            <AsyncSelect
              cacheOptions
              defaultOptions
              loadOptions={loadCompanyOptions}
              value={formData.company}
              onChange={(option) => handleSelectChange("company", option)}
              placeholder={t`Search and select a company...`}
              classNamePrefix="select"
              formatOptionLabel={(option: CompanySelectOption) => (
                <div className="flex items-center">
                  <img
                    src={option.logo}
                    alt={option.label}
                    className="w-7 h-7 rounded-full mr-2 object-cover"
                  />
                  <span>{option.label}</span>
                </div>
              )}
              styles={{
                option: (provided) => ({
                  ...provided,
                  paddingLeft: 2,
                }),
                singleValue: (provided) => ({
                  ...provided,
                  marginLeft: 0,
                }),
              }}
            />
          </div>
          {/* Workplace Quality Rating */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans> Workplace Quality Rating </Trans>
              <span className="text-red-500">*</span>
            </label>
            {renderStarRating()}
          </div>
          {/* Industry */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Industry </Trans>
              <span className="text-red-500">*</span>
            </label>
            <AsyncSelect
              cacheOptions
              defaultOptions
              loadOptions={loadSectorOptions}
              value={formData.industry}
              onChange={(option) => handleSelectChange("industry", option)}
              placeholder={t`Search and select a sector...`}
              classNamePrefix="select"
            />
          </div>
          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Location</Trans>
            </label>
            {/* Conteneur grid pour aligner horizontalement */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Country Select */}
              <AsyncSelect
                cacheOptions
                defaultOptions
                loadOptions={loadCountryOptions}
                value={formData.country}
                onChange={(option) =>
                  handleSelectChange("country", option as LocationOption)
                }
                placeholder={t`Country`}
                classNamePrefix="select"
                isClearable={false}
              />

              {/* City Select */}
              <AsyncSelect
                cacheOptions
                defaultOptions
                key={`city-${formData.country?.value || "none"}`}
                loadOptions={loadCityOptions}
                value={formData.city}
                onChange={(option) =>
                  handleSelectChange("city", option as LocationOption)
                }
                isDisabled={!formData.country}
                placeholder={t`City`}
                classNamePrefix="select"
                noOptionsMessage={() => t`Type to search for a city`}
              />
            </div>
          </div>{" "}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Start Date </Trans>
              <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="date"
                value={formData.startDate}
                onChange={(e) => handleInputChange("startDate", e.target.value)}
                placeholder="--------- ----"
                className="w-full p-3 pr-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                required
              />
            </div>
          </div>
          <div>
            {/* --- CASE À COCHER --- */}
            <div className="flex items-center mb-2">
              <input
                id="isCurrent"
                type="checkbox"
                checked={formData.current}
                onChange={(e) => handleCurrentWorkChange(e.target.checked)}
                className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
              />
              <label
                htmlFor="isCurrent"
                className="ml-2 block text-sm text-gray-900"
              >
                <Trans> I currently work here</Trans>
              </label>
            </div>

            {!formData.current && (
              <div>
                <label
                  htmlFor="endDate"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  <Trans>End Date</Trans>
                </label>
                <input
                  id="endDate"
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => handleInputChange("endDate", e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg "
                />
              </div>
            )}
          </div>
          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Description</Trans>
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              placeholder={t`Describe your responsibilities and achievements...`}
              rows={4}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 resize-none"
            />
          </div>
          {/* Actions */}
          <div className="flex justify-end pt-6">
            <Button
              type="submit"
              className="bg-teal-600 hover:bg-teal-700 text-white px-8"
            >
              <Trans>Save Now</Trans>
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddExperienceModal;
