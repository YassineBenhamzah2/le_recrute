import React, { useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { toast } from "sonner";
import { roleService, RoleCreateRequest } from "../../lib/network/roles";
import { RoleType } from "../../lib/types/license";
import { Trans, t } from '@lingui/macro';

interface CreateRoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRoleCreated?: () => void;
}

export const CreateRoleModal: React.FC<CreateRoleModalProps> = ({
  isOpen,
  onClose,
  onRoleCreated,
}) => {
  const [formData, setFormData] = useState<RoleCreateRequest>({
    name: "",
    description: "",
    roleType: "RECRUITER",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{
    name?: string;
    roleType?: string;
  }>({});

  const validateForm = (): boolean => {
    const newErrors: { name?: string; roleType?: string } = {};

    if (!formData.name.trim()) {
      newErrors.name = t({ id: "create_role_modal.validation.name_required", message: "Role name is required" });
    }

    if (!formData.roleType) {
      newErrors.roleType = t({ id: "create_role_modal.validation.type_required", message: "Role type is required" });
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await roleService.create({
        name: formData.name.trim(),
        description: formData.description?.trim() || undefined,
        roleType: formData.roleType,
      });

      if (response.success) {
        toast.success(t({ 
          id: "create_role_modal.success.role_created", 
          message: "Role \"{roleName}\" created successfully",
          values: { roleName: formData.name }
        }));
        handleClose();
        onRoleCreated?.();
      } else {
        toast.error(t({ id: "create_role_modal.errors.creation_failed", message: "Failed to create role" }));
      }
    } catch (error: unknown) {
      console.error("Error creating role:", error);

      // Handle specific error messages from backend
      if (error && typeof error === "object" && "response" in error) {
        const apiError = error as {
          response?: { data?: { message?: string } };
        };
        if (apiError.response?.data?.message) {
          toast.error(apiError.response.data.message);
        } else {
          toast.error(t({ id: "create_role_modal.errors.generic_error", message: "Failed to create role. Please try again." }));
        }
      } else if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error(t({ id: "create_role_modal.errors.generic_error", message: "Failed to create role. Please try again." }));
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setFormData({
      name: "",
      description: "",
      roleType: "RECRUITER",
    });
    setErrors({});
    onClose();
  };

  const handleInputChange = (field: keyof RoleCreateRequest, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));

    // Clear error for this field when user starts typing
    if (errors[field as keyof typeof errors]) {
      setErrors((prev) => ({
        ...prev,
        [field]: undefined,
      }));
    }
  };

  const roleTypeOptions: {
    value: RoleType;
    label: string;
    description: string;
  }[] = [
    {
      value: "ADMIN",
      label: t({ id: "create_role_modal.role_types.admin.label", message: "Admin" }),
      description: t({ id: "create_role_modal.role_types.admin.description", message: "Full system access and management capabilities" }),
    },
    {
      value: "RECRUITER",
      label: t({ id: "create_role_modal.role_types.recruiter.label", message: "Recruiter" }),
      description: t({ id: "create_role_modal.role_types.recruiter.description", message: "Job posting, candidate management, and hiring tools" }),
    },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px] bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 border-slate-200 dark:border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-ehc-green">
            <Trans id="create_role_modal.header.title">Create New Role</Trans>
          </DialogTitle>
          <DialogDescription className="text-slate-600 dark:text-slate-400">
            <Trans id="create_role_modal.header.description">
              Create a new role with specific permissions and access levels.
            </Trans>
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Role Name */}
          <div className="space-y-2">
            <Label htmlFor="name" className="text-ehc-green font-medium">
              <Trans id="create_role_modal.form.name_label">Role Name</Trans>{" "}
              <span className="text-red-500">*</span>
            </Label>
            <Input
              id="name"
              placeholder={t({ id: "create_role_modal.form.name_placeholder", message: "Enter role name (e.g., Senior Recruiter, HR Manager)" })}
              value={formData.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
              className={
                errors.name
                  ? "border-red-500 focus:ring-red-500"
                  : "border-slate-300 focus:border-ehc-green focus:ring-ehc-green"
              }
            />
            {errors.name && (
              <p className="text-sm text-red-600">{errors.name}</p>
            )}
          </div>

          {/* Role Type */}
          <div className="space-y-2">
            <Label htmlFor="roleType" className="text-ehc-green font-medium">
              <Trans id="create_role_modal.form.type_label">Role Type</Trans>{" "}
              <span className="text-red-500">*</span>
            </Label>
            <Select
              value={formData.roleType}
              onValueChange={(value: RoleType) =>
                handleInputChange("roleType", value)
              }
            >
              <SelectTrigger
                className={
                  errors.roleType
                    ? "border-red-500 focus:ring-red-500"
                    : "border-slate-300 focus:border-ehc-green focus:ring-ehc-green"
                }
              >
                <SelectValue placeholder={t({ id: "create_role_modal.form.type_placeholder", message: "Select role type" })} />
              </SelectTrigger>
              <SelectContent className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                {roleTypeOptions.map((option) => (
                  <SelectItem
                    key={option.value}
                    value={option.value}
                    className="cursor-pointer"
                  >
                    <div className="flex flex-col">
                      <span className="font-medium">{option.label}</span>
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        {option.description}
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.roleType && (
              <p className="text-sm text-red-600">{errors.roleType}</p>
            )}
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" className="text-ehc-green font-medium">
              <Trans id="create_role_modal.form.description_label">Description (Optional)</Trans>
            </Label>
            <Textarea
              id="description"
              placeholder={t({ id: "create_role_modal.form.description_placeholder", message: "Describe the role's responsibilities, access levels, and permissions..." })}
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              rows={4}
              className="resize-none border-slate-300 focus:border-ehc-green focus:ring-ehc-green"
            />
            <p className="text-xs text-slate-500 dark:text-slate-400">
              <Trans id="create_role_modal.form.description_help">
                Provide a detailed description to help identify this role's
                purpose and capabilities
              </Trans>
            </p>
          </div>

          <DialogFooter className="pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={isSubmitting}
              className="border-slate-300 text-slate-700 hover:bg-slate-100 dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700"
            >
              <Trans id="create_role_modal.form.cancel_button">Cancel</Trans>
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-ehc-green hover:bg-ehc-green-dark text-white"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  <Trans id="create_role_modal.form.creating_button">Creating...</Trans>
                </>
              ) : (
                <Trans id="create_role_modal.form.create_button">Create Role</Trans>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
