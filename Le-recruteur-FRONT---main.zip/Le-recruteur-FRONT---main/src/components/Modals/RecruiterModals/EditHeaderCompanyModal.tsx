/* eslint-disable @typescript-eslint/no-explicit-any */
import { api } from "@/lib/network/utils/api";
import React, { useEffect, useState } from "react";
import { toast } from "sonner";

import { Tag } from "@/lib/types/auth";
import { UploadCloud, X } from "lucide-react";
import { settings } from "@/lib/settings/main";

interface CompanyData {
  id: number;
  name: string;
  website: string;
  logo: string;
  about: string;
  tags: Tag[];
}

interface EditHeaderCompanyModalProps {
  companyInfo: CompanyData;
  onSave: (newCompanyInfo: CompanyData) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const EditHeaderCompanyModal: React.FC<EditHeaderCompanyModalProps> = ({
  isOpen,
  onClose,
  onSave,
  companyInfo,
}) => {
  const [formData, setFormData] = useState<CompanyData>(companyInfo);

  const [tagInput, setTagInput] = useState("");

  const [logoFile, setLogoFile] = useState<File | null>(null);

  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setFormData(companyInfo);
      setPreviewUrl(companyInfo.logo);
      setLogoFile(null);
    }
  }, [isOpen, companyInfo]);

  if (!isOpen) return null;

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files ? e.target.files[0] : null;

    setLogoFile(file);

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setPreviewUrl(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const dataToSend = new FormData();

    const jsonData = {
      name: formData.name,
      website: formData.website,
      about: formData.about,
      tags: formData.tags.map((tag) => tag.name),
    };
    dataToSend.append(
      "data",
      new Blob([JSON.stringify(jsonData)], { type: "application/json" })
    );

    if (logoFile) {
      dataToSend.append("logoFile", logoFile);
    }

    try {
      const updatedCompany = await api.put<CompanyData>(
        `/recruiter/company/${companyInfo.id}/headerInfos`,
        dataToSend
      );

      toast.success("Company information updated successfully!");
      onSave(updatedCompany);
      onClose();
    } catch (err: any) {
      // 5. Gère les erreurs
      console.error("Failed to update company header:", err);
      toast.error(err.message || "An error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() !== "") {
      const newTag: Tag = {
        id: Date.now(),
        name: tagInput.trim(),
      };
      setFormData((prev) => ({
        ...prev,
        tags: [...prev.tags, newTag],
      }));
      setTagInput("");
    }
  };

  const handleRemoveTag = (idToRemove: number | string) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.filter((tag) => tag.id !== idToRemove),
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[95vh] flex flex-col">
        <div className="flex-shrink-0 flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-800">
            Edit Company Information
          </h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-gray-400 hover:text-gray-600"
          >
            <X size={24} />
          </button>
        </div>

        <form
          onSubmit={handleSubmit}
          className="flex-grow overflow-y-auto p-6 space-y-6"
        >
          <div>
            <label
              htmlFor="name"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Company Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                                focus:outline-none focus:ring-2 focus:ring-cyan-600"
              placeholder="Enter the full legal or brand name of the company."
            />
          </div>

          <div>
            <label
              htmlFor="website"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Company Website
            </label>
            <input
              type="text"
              id="website"
              name="website"
              value={formData.website}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                                focus:outline-none focus:ring-2 focus:ring-cyan-600"
              placeholder="Add the company's official website URL (include https://)"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Company Logo
            </label>
            <div className="flex items-center p-3 gap-4 border-2 border-gray-200 border-dashed">
              <div className="relative group w-20 h-20 flex-shrink-0">
                <img
                  src={previewUrl || settings.DEFAULT_COMPANY_AVATAR}
                  alt="Company Logo Preview"
                  onError={(e) => {
                    e.currentTarget.src = settings.DEFAULT_COMPANY_AVATAR ;
                  }}
                  className="w-full h-full rounded-full object-cover border-2 border-gray-200"
                />

                <div
                  className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 
                             rounded-full flex items-center justify-center 
                             cursor-pointer transition-all duration-300"
                  onClick={() =>
                    document.getElementById("file-upload")?.click()
                  }
                >
                  <UploadCloud
                    className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 
                               transform group-hover:scale-110 transition-all duration-300"
                  />
                </div>
              </div>

              {/* Texte et bouton d'upload */}
              <div className="text-sm">
                <label
                  htmlFor="file-upload"
                  className="font-semibold text-cyan-600 hover:text-cyan-500 cursor-pointer"
                >
                  Click to upload a new logo
                  <input
                    id="file-upload"
                    type="file"
                    className="sr-only"
                    onChange={handleFileChange}
                    accept="image/png, image/jpeg, image/gif, image/svg+xml"
                  />
                </label>
                <p className="text-xs text-gray-500 mt-1">
                  SVG, PNG, JPG, GIF (Recommended: 200x200px)
                </p>

                {logoFile && (
                  <div className="mt-2 flex items-center gap-2 text-xs font-semibold text-green-700  px-2 py-1">
                    {logoFile.name}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div>
            <label
              htmlFor="about"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              About the Company
            </label>
            <textarea
              id="about"
              name="about"
              value={formData.about}
              onChange={handleInputChange}
              rows={5}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                                focus:outline-none focus:ring-2 focus:ring-cyan-600"
              placeholder="Write a short, engaging description about the company."
            />
          </div>

          <div>
            <label
              htmlFor="tags"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Company Tags
            </label>
            <div className="flex items-center gap-2">
              <input
                id="tags"
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                                focus:outline-none focus:ring-2 focus:ring-cyan-600"
                placeholder="Add a tag and press Enter"
              />
              <button
                type="button"
                onClick={handleAddTag}
                className="px-4 py-2 text-sm font-semibold bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.tags.map((tag) => (
                <div
                  key={tag.id}
                  className="bg-gray-200 text-gray-800 text-sm pl-3 pr-2 py-1 rounded-full flex items-center gap-2"
                >
                  <span>{tag.name}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(tag.id)}
                    className="rounded-full hover:bg-gray-300"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </form>

        <div className="flex-shrink-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50">
          <button
            type="button"
            disabled={isLoading}
            onClick={onClose}
            className="px-5 py-2 text-sm font-semibold bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={isLoading}
            onClick={handleSubmit}
            className="px-5 py-2 text-sm font-semibold text-white bg-cyan-600 rounded-md shadow-sm hover:bg-cyan-700"
          >
            {isLoading ? "Saving..." : "Save"}{" "}
          </button>
        </div>
      </div>
    </div>
  );
};
