import React, { useState,useRef,useEffect } from 'react';
import { X,FileText ,Camera} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { api } from '@/lib/network/utils/api';
import { toast } from 'sonner';
import { Trans, t } from '@lingui/macro';


interface AdditionalInfoModalProps {
  isOpen: boolean;
  profileData : ProfileData ;
  onClose: () => void;
  onSave: (data: ProfileData) => void;
}


interface ProfileData {
  firstName: string;
  lastName : string ;
  role: string;
  joined: string;
  pack: string;
  phone: string;
  email: string;
  companyName: string;
  avatarUrl: string;
  

}




export const RecruiterInfoModal: React.FC<AdditionalInfoModalProps> = ({ isOpen, onClose, onSave,profileData }) => {
  

    const [avatarFile, setAvatarFile] = useState<File | null>(null); 
    
    const fileInputRef = useRef<HTMLInputElement>(null);

    const [tempProfileData, setTempProfileData] = useState<ProfileData>(profileData);

    const [isLoading, setIsLoading] = useState(false);

      // id recruiter
    const storedUser = localStorage.getItem("userData");
    let recruiterId : number ;
    if(storedUser){
      const parsedUser = JSON.parse(storedUser) ;
      recruiterId = parsedUser.id;
    }


    useEffect(() => {
      if (isOpen) {
        setTempProfileData(profileData);
      }
    }, [isOpen, profileData]);

      if (!isOpen) return null;



    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { id, value } = e.target;
        setTempProfileData(prevData => ({
            ...prevData,
            [id]: value
        }));
    };



  const handleSubmit = async (e: React.FormEvent) => {

    e.preventDefault();

    setIsLoading(true);

    const formData = new FormData();

    const jsonData = {
        firstName: tempProfileData.firstName,
        lastName: tempProfileData.lastName,
        role: tempProfileData.role, 
        phone: tempProfileData.phone,
        email: tempProfileData.email,
    };

    formData.append('data', new Blob([JSON.stringify(jsonData)], { type: 'application/json' }));

    if (avatarFile) {
        formData.append('avatarFile', avatarFile);
    }


    try {

        const updatedProfile = await api.put<ProfileData>(`/recruiter/${recruiterId}/infos`, formData);

        
        toast.success(t`Profile updated successfully!`);
        onSave(updatedProfile); 
        onClose(); 
    } catch (err: any) {
        console.error("Failed to update profile:", err);
        toast.error(t`An error occurred while updating.`);
    } finally {
        setIsLoading(false);
    }
   
  };

  
  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleAvatarChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (file) {
        setAvatarFile(file);
  
        const reader = new FileReader();
        reader.onload = (e) => {
          const newAvatarPreviewUrl = e.target?.result as string;
          setTempProfileData(prev => ({ ...prev, avatarUrl : newAvatarPreviewUrl }));
        };
        reader.readAsDataURL(file);
      }
    };
  

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 font-sans">
      <div className="bg-gray-50 rounded-xl shadow-2xl w-full max-w-3xl max-h-[95vh] flex flex-col">
        {/* En-tête de la Modale */}
        <div className="flex-shrink-0 flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 flex items-center justify-center bg-cyan-100 rounded-full text-cyan-700">
              <FileText size={20} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800"><Trans>Profile Information</Trans></h2>
              <p className="text-sm text-gray-500"><Trans>Fill in the job information</Trans></p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full"
            aria-label="Close modal"
          >
            <X size={24} />
          </button>
        </div>

        {/* Formulaire avec défilement */}
        <form onSubmit={handleSubmit} className="flex-grow overflow-y-auto p-8">
          <div className="space-y-8">

            {/* Section Avatar */}
            <div className="flex flex-col items-center mb-6">
              <div className="relative group mb-4">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center shadow-lg overflow-hidden">
                  <img 
                    src={tempProfileData.avatarUrl}
                    alt={`${tempProfileData.firstName} ${tempProfileData.lastName}`}
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                <div onClick={handleAvatarClick} className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 rounded-full flex items-center justify-center cursor-pointer transition-all">
                  <Camera className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
              <Button type="button" variant="outline" size="sm" onClick={handleAvatarClick} className="text-sm">
                <Camera className="w-4 h-4 mr-2" /><Trans> Change Photo</Trans>
              </Button>
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
            </div>

              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Champ First Name */}
                  <div className="flex flex-col">
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1.5">
                      <Trans>First Name</Trans>
                    </label>
                    <input
                      id="firstName"
                      placeholder={t`Enter your given name.`}
                      value={tempProfileData.firstName}
                      onChange={handleInputChange} 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                                focus:outline-none focus:ring-2 focus:ring-cyan-600 placeholder-gray-400"
                    />
                  </div>

                  {/* Champ Last Name */}
                  <div className="flex flex-col">
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1.5">
                      <Trans>Last Name</Trans>
                    </label>
                    <input
                      id="lastName"
                      placeholder={t`Enter your family name or surname.`}
                      value={tempProfileData.lastName}
                      onChange={handleInputChange} 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm
                                focus:outline-none focus:ring-2 focus:ring-cyan-600 placeholder-gray-400"
                    />
                  </div>
                </div>



                <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1.5"><Trans>Job title in company</Trans></label>
                  <input
                    id="role"
                    value={tempProfileData.role}
                    onChange={handleInputChange} 
                    placeholder={t`Enter your family name or surname.`}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-600 focus:border-transparent placeholder-gray-400"
                  />

                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1.5"><Trans>Phone</Trans></label>
                  <input
                    id="phone"
                    value={tempProfileData.phone}
                    onChange={handleInputChange} 
                    placeholder={t`Enter your phone number .`}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-600 focus:border-transparent placeholder-gray-400"
                  />


                 <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1.5"><Trans>Email</Trans></label>
                  <input
                    id="email"
                    value={tempProfileData.email}
                    onChange={handleInputChange} 
                    placeholder={t`Enter your email .`}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-600 focus:border-transparent placeholder-gray-400"
                  /> 


              </div>
          </div>
        </form>
        
        {/* Pied de page de la Modale */}
        <div className="flex-shrink-0 flex items-center justify-end gap-3 px-8 py-4 border-t border-gray-200 bg-gray-100">
          <button
            type="button"
            onClick={onClose}
            disabled={isLoading}
            className="px-5 py-2.5 text-sm font-semibold text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-601"
          >
            <Trans>Cancel</Trans>
          </button>
          <button
            type="submit"
            onClick={handleSubmit}
            disabled={isLoading}
            className="px-5 py-2.5 text-sm font-semibold text-white bg-cyan-700 rounded-md shadow-sm hover:bg-cyan-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-701"
          >
            {isLoading ? t`Saving...` : t`Save`}
          </button>
        </div>
      </div>
    </div>
  );
};
