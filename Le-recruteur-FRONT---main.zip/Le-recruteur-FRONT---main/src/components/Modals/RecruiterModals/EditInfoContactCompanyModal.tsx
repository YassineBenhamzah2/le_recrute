// EditInfoContactModal.tsx
import React, { useState, useEffect } from "react";
import AsyncSelect from "react-select/async";
import { X, Building, Phone } from "lucide-react";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import { Sector } from "@/lib/types/auth";

interface EditInfoContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: CompanyInfoContactEditData) => void;
  initialData: CompanyInfoContactEditData;
}

interface CompanyInfoContactEditData {
  sector: Sector | null;
  employeeCount: number;
  founded: string;

  phone: string;
  email: string;
}

export const EditInfoContactModal: React.FC<EditInfoContactModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialData,
}) => {
  const [formData, setFormData] =
    useState<CompanyInfoContactEditData>(initialData);

  useEffect(() => {
    if (isOpen) {
      setFormData(initialData);
    }
  }, [isOpen, initialData]);

  if (!isOpen) return null;

  const loadSectorOptions = (
    inputValue: string,
    callback: (options: Sector[]) => void
  ) => {
    setTimeout(() => {
      api
        .getItem<Sector[]>(`/recruiter/sectors?q=${inputValue}`)
        .then((response) => {
          callback(response);
        })
        .catch((error) => {
          toast.error("Failed to fetch sectors");
          console.error("Failed to fetch sectors:", error);
          callback([]);
        });
    }, 500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSectorChange = (selectedOption: Sector | null) => {
    setFormData((prev) => ({ ...prev, sector: selectedOption }));
  };

  const handleSubmit = () => {
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold">Edit Information & Contact</h2>
          <button onClick={onClose}>
            <X size={24} />
          </button>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto">
          {/* Section Company Information */}
          <section>
            <h3 className="text-lg font-bold flex items-center gap-2 mb-4">
              <Building size={20} /> Company Information
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Industry
                </label>
                <AsyncSelect
                  cacheOptions
                  defaultOptions
                  value={formData.sector}
                  loadOptions={loadSectorOptions}
                  getOptionLabel={(option) => option.name}
                  getOptionValue={(option) => String(option.id)}
                  onChange={handleSectorChange}
                  placeholder="Search for an industry..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Number of Employees
                </label>
                <input
                  type="text"
                  id="employeeCount"
                  name="employeeCount"
                  value={formData.employeeCount}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-600"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Founded
                </label>
                <input
                  type="date"
                  name="founded"
                  value={formData.founded}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-600"
                />
              </div>
            </div>
          </section>

          {/* Section Contact Information */}
          <section>
            <h3 className="text-lg font-bold flex items-center gap-2 mb-4">
              <Phone size={20} /> Contact Information
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className='className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-600'
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className='className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-600'
                />
              </div>
            </div>
          </section>
        </div>

        <div className="flex justify-end gap-3 p-4 border-t bg-gray-50">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white border rounded-md"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="px-4 py-2 bg-cyan-600 text-white rounded-md"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};
