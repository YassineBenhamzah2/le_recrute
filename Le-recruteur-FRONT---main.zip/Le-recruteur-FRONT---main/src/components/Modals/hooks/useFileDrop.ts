import { useCallback, useEffect, useState } from 'react';
import type { DragEvent } from 'react';

/**
 * Options for the useFileDrop hook.
 * - acceptRegex: optional filename regex used to filter accepted files.
 * - onDropFile: callback invoked with the first dropped file.
 * - manageGlobalDrop: when true, adds document-level dragover/drop listeners
 *   that prevent default browser navigation on file drop outside the dropzone.
 */
export type UseFileDropOptions = {
  acceptRegex?: RegExp;
  onDropFile: (file: File) => void;
  manageGlobalDrop?: boolean;
};

/**
 * React hook to add drag-and-drop behavior to a dropzone.
 * Returns handlers and an `active` flag for hover/drag styling.
 */
export function useFileDrop({ acceptRegex, onDropFile, manageGlobalDrop = false }: UseFileDropOptions) {
  const [active, setActive] = useState(false);

  const onDragOver = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'copy';
    setActive(true);
  }, []);

  const onDragEnter = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setActive(true);
  }, []);

  const onDragLeave = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setActive(false);
  }, []);

  const onDrop = useCallback(
    (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      const file = e.dataTransfer?.files?.[0];
      if (file) {
        if (!acceptRegex || acceptRegex.test(file.name)) {
          onDropFile(file);
        }
      }
      setActive(false);
    },
    [acceptRegex, onDropFile]
  );

  // Optionally manage global drag/drop default prevention
  useEffect(() => {
    if (!manageGlobalDrop) return;
    const preventDefaults = (e: Event) => {
      e.preventDefault();
      e.stopPropagation();
    };
    document.addEventListener('dragover', preventDefaults);
    document.addEventListener('drop', preventDefaults);
    return () => {
      document.removeEventListener('dragover', preventDefaults);
      document.removeEventListener('drop', preventDefaults);
    };
  }, [manageGlobalDrop]);

  return { active, onDragOver, onDragEnter, onDragLeave, onDrop };
}
