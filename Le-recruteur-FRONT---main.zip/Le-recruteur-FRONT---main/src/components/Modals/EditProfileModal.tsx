import React, { useState, useRef, useEffect } from "react";
import { X, Save, AlertCircle, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import Select, { ClassNamesConfig } from "react-select";
import { Country, City } from "country-state-city";
import { Trans, t } from "@lingui/macro";

interface ProfileData {
  firstName: string;
  lastName: string;
  title: string;
  country: string;
  city: string;
  address: string;
  email: string;
  phone: string;
  linkedin: string;
  avatar: string;
}

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profileData: ProfileData;
  onSave: (data: ProfileData) => void;
}

interface LocationOption {
  value: string;
  label: string;
}

const initialFormState = {
  firstName: "",
  lastName: "",
  title: "",
  country: null as LocationOption | null,
  city: null as LocationOption | null,
  address: "",
  email: "",
  phone: "",
  linkedin: "",
  avatar: "",
};

const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  profileData,
  onSave,
}) => {
  const [tempProfileData, setTempProfileData] = useState(initialFormState);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // id candidate
  const storedUser = localStorage.getItem("userData");
  let candidateId: number;
  if (storedUser) {
    const parsedUser = JSON.parse(storedUser);
    candidateId = parsedUser.id;
  }

  useEffect(() => {
    if (isOpen && profileData) {
      const country = Country.getAllCountries().find(
        (c) => c.name === profileData.country
      );
      const countryOption = country
        ? { value: country.isoCode, label: country.name }
        : null;

      let cityOption = null;
      if (country) {
        const city = City.getCitiesOfCountry(country.isoCode)?.find(
          (c) => c.name === profileData.city
        );
        cityOption = city ? { value: city.name, label: city.name } : null;
      }

      setTempProfileData({
        firstName: profileData.firstName,
        lastName: profileData.lastName,
        title: profileData.title,
        country: countryOption,
        city: cityOption,
        address: profileData.address,
        email: profileData.email,
        phone: profileData.phone,
        linkedin: profileData.linkedin,
        avatar: profileData.avatar,
      });

      setAvatarFile(null);
    }
  }, [isOpen, profileData]);

  if (!isOpen) return null;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setTempProfileData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (
    field: "country" | "city",
    option: LocationOption | null
  ) => {
    setTempProfileData((prev) => {
      const newState = { ...prev, [field]: option };
      if (field === "country") {
        newState.city = null;
      }
      return newState;
    });
  };

  const loadCountryOptions = (inputValue: string) => {
    return Country.getAllCountries()
      .map((c) => ({ value: c.isoCode, label: c.name }))
      .filter((c) => c.label.toLowerCase().includes(inputValue.toLowerCase()));
  };

  const loadCityOptions = (inputValue: string) => {
    if (!tempProfileData.country) return [];
    return (
      City.getCitiesOfCountry(tempProfileData.country.value)
        ?.map((c) => ({ value: c.name, label: c.name }))
        .filter((c) =>
          c.label.toLowerCase().includes(inputValue.toLowerCase())
        ) || []
    );
  };

  const handleSave = async () => {
    setIsSaving(true);

    const formData = new FormData();

    const profileInfoRequest = {
      firstName: tempProfileData.firstName,
      lastName: tempProfileData.lastName,
      title: tempProfileData.title,
      country: tempProfileData.country?.label,
      city: tempProfileData.city?.label,
      address: tempProfileData.address,
      email: tempProfileData.email,
      phone: tempProfileData.phone,
      linkedin: tempProfileData.linkedin,
    };

    formData.append(
      "request",
      new Blob([JSON.stringify(profileInfoRequest)], {
        type: "application/json",
      })
    );

    if (avatarFile) {
      formData.append("avatarFile", avatarFile);
    }

    api
      .put<ProfileData>(`/candidate/profile/info/${candidateId}`, formData)
      .then((updatedProfile) => {
        toast.success(t`Profile updated successfully!`);
        onSave(updatedProfile);
        onClose();
      })
      .catch((err) => {
        console.error("Erreur mise à jour profil:", (err as Error).message);
        toast.error(t`Failed to update profile.`);
      })
      .finally(() => {
        setIsSaving(false);
      });
  };

  const handleCancel = () => {
    onClose();
  };

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleAvatarChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setAvatarFile(file);

      const reader = new FileReader();
      reader.onload = (e) => {
        const newAvatarPreviewUrl = e.target?.result as string;
        setTempProfileData((prev) => ({
          ...prev,
          avatar: newAvatarPreviewUrl,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const customSelectClassNames: ClassNamesConfig<LocationOption> = {
    control: (state) =>
      `w-full !min-h-[42px] bg-white border ${
        state.isFocused
          ? "border-teal-500 ring-2 ring-teal-500"
          : "border-gray-300"
      } rounded-md shadow-sm`,
    placeholder: () => "text-gray-400",
    input: () => "py-2",
    singleValue: () => "text-gray-900",
    menu: () =>
      "bg-white border border-gray-200 rounded-md shadow-lg mt-1 z-20",
    option: (state) =>
      `px-3 py-2 cursor-pointer ${state.isFocused ? "bg-teal-50" : ""} ${
        state.isSelected ? "bg-teal-100" : ""
      }`,
    indicatorSeparator: () => "hidden",
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] flex flex-col font-sans">
        {/* En-tête */}
        <div className="flex-shrink-0 flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            <Trans>Edit Profile</Trans>
          </h2>
          <button
            onClick={handleCancel}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Contenu du formulaire */}
        <div className="flex-grow p-6 overflow-y-auto">
          {/* Section Avatar */}
          <div className="flex flex-col items-center mb-6">
            <div className="relative group mb-4">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center shadow-lg overflow-hidden">
                <img
                  src={tempProfileData.avatar}
                  alt={`${tempProfileData.firstName} ${tempProfileData.lastName}`}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div
                onClick={handleAvatarClick}
                className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 rounded-full flex items-center justify-center cursor-pointer transition-all"
              >
                <Camera className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleAvatarClick}
              className="text-sm"
            >
              <Camera className="w-4 h-4 mr-2" />
              <Trans> Change Photo</Trans>
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleAvatarChange}
              className="hidden"
            />
          </div>

          {/* Champs du formulaire */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Trans>First Name *</Trans>
                </label>
                <input
                  type="text"
                  name="firstName"
                  value={tempProfileData.firstName}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                  placeholder={t`e.g., John`}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Trans>Last Name *</Trans>
                </label>
                <input
                  type="text"
                  name="lastName"
                  value={tempProfileData.lastName}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                  placeholder={t`e.g., Doe`}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font--medium text-gray-700 mb-2">
                <Trans>Location *</Trans>
              </label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex-grow">
                  <Select
                    options={loadCountryOptions("")}
                    value={tempProfileData.country}
                    onChange={(option) =>
                      handleSelectChange("country", option as LocationOption)
                    }
                    placeholder={t`Country`}
                    isClearable
                    styles={{
                      control: (base) => ({
                        ...base,
                        padding: "0.3rem",
                        borderColor: "#D1D5DB",
                      }),
                    }}
                    classNames={customSelectClassNames}
                  />
                </div>

                <div className="flex-grow">
                  <Select
                    key={`city-${tempProfileData.country?.value || "none"}`}
                    options={loadCityOptions("")}
                    value={tempProfileData.city}
                    onChange={(option) =>
                      handleSelectChange("city", option as LocationOption)
                    }
                    isDisabled={!tempProfileData.country}
                    placeholder={t`City`}
                    isClearable
                    styles={{
                      control: (base) => ({
                        ...base,
                        padding: "0.3rem",
                        borderColor: "#D1D5DB",
                      }),
                    }}
                    classNames={customSelectClassNames}
                  />
                </div>

                <div className="flex-grow">
                  <input
                    type="text"
                    name="address"
                    value={tempProfileData.address}
                    onChange={handleInputChange}
                    className="w-full h-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                    placeholder={t`Address`}
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Trans>Job Title *</Trans>
                </label>
                <input
                  type="text"
                  name="title"
                  value={tempProfileData.title}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                  placeholder={t`e.g., Senior Software Engineer`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Trans>Email Address *</Trans>
                </label>
                <input
                  type="email"
                  name="email"
                  value={tempProfileData.email}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                  placeholder={t`e.g., john@example.com`}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Trans>Phone Number *</Trans>
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={tempProfileData.phone}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                  placeholder={t`e.g., +1 (555) 123-4567`}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Trans>LinkedIn Profile</Trans>
                </label>
                <input
                  type="url"
                  name="linkedin"
                  value={tempProfileData.linkedin}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                  placeholder="https://linkedin.com/in/yourprofile"
                />
              </div>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-blue-800">
                <p className="font-medium mb-1">
                  <Trans>Profile Visibility</Trans>
                </p>
                <p>
                  <Trans>
                    Your contact information will be visible to potential
                    employers when they view your profile. Make sure all details
                    are accurate and professional.
                  </Trans>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Pied de page */}
        <div className="flex-shrink-0 flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-200 bg-gray-50">
          <Button
            variant="outline"
            onClick={handleCancel}
            disabled={isSaving}
            className="px-4 py-2"
          >
            <Trans>Cancel</Trans>
          </Button>
          <Button
            onClick={handleSave}
            disabled={isSaving}
            className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-2"
          >
            {isSaving ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                <Trans>Saving...</Trans>
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                <Trans>Save Changes</Trans>
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default EditProfileModal;
