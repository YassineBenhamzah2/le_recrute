/* eslint-disable @typescript-eslint/no-explicit-any */
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api } from "@/lib/network/utils/api";
import { Trans, t } from "@lingui/macro";
import { City, Country } from "country-state-city";
import { X } from "lucide-react";
import React, { useEffect, useState } from "react";
import { toast } from "sonner";
import CreatableSelect from 'react-select/async-creatable';

const initialFormData = {
  title: "",
  institution: "",
  majorId: "",
  majorName: "",
  countryCode: "",
  countryName: "",
  cityName: "",
  startDate: "",
  endDate: "",
  current: false,
};

interface AddEducationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEducationAdded: (newEducation: EducationResponse) => void;
}

interface MajorResponse {
  id: number;
  name: string;
}

interface EducationResponse {
  id: number;
  title: string;
  institution: string;
  location: string;
  language?: string;
  startedAt: string;
  endedAt: string;
  current: boolean;
}

interface SelectOption {
    value: number | string;
    label: string;
    __isNew__?: boolean; 
}

const AddEducationModal: React.FC<AddEducationModalProps> = ({
  isOpen,
  onClose,
  onEducationAdded,
}) => {
  const [isLoading, setIsLoading] = useState(false);

  const [formData, setFormData] = useState(initialFormData);
  const [countries, setCountries] = useState<any[]>([]);
  const [cities, setCities] = useState<any[]>([]);

  // id candidate
  const storedUser = localStorage.getItem("userData");
  let candidateId: number;
  if (storedUser) {
    const parsedUser = JSON.parse(storedUser);
    candidateId = parsedUser.id;
  }

  useEffect(() => {
    if (isOpen) {
      setFormData(initialFormData);
      // Load countries on modal open
      const allCountries = Country.getAllCountries();
      setCountries(allCountries);
    }
  }, [isOpen]);

  useEffect(() => {
    // Load cities when country changes
    if (formData.countryCode) {
      const countryCities = City.getCitiesOfCountry(formData.countryCode);
      setCities(countryCities || []);
      setFormData((prev) => ({
        ...prev,
        cityName: "",
      }));
    } else {
      setCities([]);
    }
  }, [formData.countryCode]);

  if (!isOpen) return null;

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleCountryChange = (countryCode: string) => {
    const selectedCountry = countries.find((c) => c.isoCode === countryCode);
    setFormData((prev) => ({
      ...prev,
      countryCode: countryCode,
      countryName: selectedCountry?.name || "",
      cityName: "",
    }));
  };

  const handleCityChange = (cityName: string) => {
    setFormData((prev) => ({
      ...prev,
      cityName: cityName,
    }));
  };

  const handleMajorChange = (major : SelectOption) => {
    setFormData((prev) => ({
      ...prev,
      majorId : String(major.value) ,
      majorName : major.label
    })) ;
  }

  const loadMajorOptions = (inputValue: string): Promise<SelectOption[]> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        api.getItem<MajorResponse[]>(`/candidate/profile/majors/search?q=${inputValue}`)
          .then(res => resolve(res.map(m => ({ value: m.id, label: m.name }))));
      }, 400); // délai de 500ms
    });
  };


  const handleCreateMajor = (inputValue: string) => {
    setIsLoading(true);
    toast.info(t`Creating new major: ${inputValue}...`);
    
    api.post<MajorResponse>("/candidate/profile/addMajor", { name: inputValue })
      .then(createdMajor => {
        const newOption: SelectOption = { value: createdMajor.id, label: createdMajor.name };
        handleMajorChange(newOption) ;
        toast.success(t`Major created successfully!`);
      })
      .catch(err => {
        toast.error(t`Failed to create major.`);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  


  const handleCurrentWorkChange = (isChecked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      current: isChecked,
      endDate: isChecked ? "" : prev.endDate,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const payload = {
      title: formData.title,
      institution: formData.institution,
      majorId: formData.majorId ? parseInt(formData.majorId) : null,
      location: [formData.cityName, formData.countryName]
        .filter(Boolean)
        .join(", "),
      startedAt: formData.startDate,
      endedAt: formData.endDate,
      current: formData.current,
      candidateId: candidateId,
    };

    api
      .post<EducationResponse>(`/candidate/profile/addEducation`, payload)
      .then(onEducationAdded)
      .then(() => {
        onClose();
        toast.success(t`Education added successfully!`);
      })
      .catch(() => toast.error(t`Error adding education`))
      .finally(() => setIsLoading(false));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900">
            <Trans>Add Education</Trans>
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Title */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2">
              <Trans>Title</Trans>
            </Label>
            <Input
              type="text"
              value={formData.title}
              onChange={(e) => handleInputChange("title", e.target.value)}
              placeholder={t`e.g., Bachelor of Science in Computer Science`}
              required
            />
          </div>

          {/* School / University */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2">
              <Trans>School / University</Trans>
            </Label>
            <Input
              type="text"
              value={formData.institution}
              onChange={(e) => handleInputChange("institution", e.target.value)}
              placeholder={t`Enter university or school name`}
              required
            />
          </div>

          {/* Major */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2">
              <Trans>Major</Trans>
            </Label>
            
            <CreatableSelect<SelectOption, false>
              cacheOptions
              defaultOptions
              loadOptions={loadMajorOptions}
              value={
                formData.majorId
                  ? { value: formData.majorId, label: formData.majorName }
                  : null
              }
              onChange={(option) => {
                if (option) handleMajorChange(option);
              }}
              onCreateOption={handleCreateMajor}
              placeholder={t`Search or create a major...`}
              isDisabled={isLoading}
              formatCreateLabel={(inputValue) => t`Create "${inputValue}"`}
              classNamePrefix="select" 
            />
          </div>

          {/* Location */}

          <div className="space-y-4 pt-4 border-t">
            <h4 className="text-md font-semibold text-gray-800">
              <Trans>Location</Trans>
            </h4>

            {/* Country */}
            <div>
              <Label className="text-sm font-medium text-gray-700 mb-2">
                <Trans>Country</Trans>
              </Label>
              <Select
                value={formData.countryCode}
                onValueChange={handleCountryChange}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder={t`Select a country`} />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  {countries.map((country) => (
                    <SelectItem key={country.isoCode} value={country.isoCode}>
                      <div className="flex items-center gap-2">
                        <img
                          src={`https://flagsapi.com/${country.isoCode}/flat/16.png`}
                          alt={`${country.name} flag`}
                          className="w-4 h-3"
                          onError={(e) => {
                            (e.target as HTMLImageElement).style.display =
                              "none";
                          }}
                        />
                        {country.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* City */}
            <div>
              <Label className="text-sm font-medium text-gray-700 mb-2">
                <Trans>City</Trans>
              </Label>
              <Select
                value={formData.cityName}
                onValueChange={handleCityChange}
                disabled={!formData.countryCode}
              >
                <SelectTrigger className="w-full">
                  <SelectValue
                    placeholder={
                      !formData.countryCode
                        ? t`Select a country first`
                        : t`Select a city`
                    }
                  />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  {cities.map((city) => (
                    <SelectItem key={city.name} value={city.name}>
                      {city.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Start Date and End Date */}

          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2">
              <Trans>Start Date</Trans> <span className="text-red-500">*</span>
            </Label>
            <Input
              type="date"
              value={formData.startDate}
              onChange={(e) => handleInputChange("startDate", e.target.value)}
              required
            />
          </div>

          <div>
            {/* Current study checkbox */}
            <div className="flex items-center mb-2">
              <input
                id="isCurrent"
                type="checkbox"
                checked={formData.current}
                onChange={(e) => handleCurrentWorkChange(e.target.checked)}
                className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
              />
              <Label
                htmlFor="isCurrent"
                className="ml-2 block text-sm text-gray-900"
              >
                <Trans>I Currently study here</Trans>
              </Label>
            </div>
            {!formData.current && (
              <div>
                <Label className="text-sm font-medium text-gray-700 mb-2">
                  <Trans>End Date</Trans>
                </Label>
                <Input
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => handleInputChange("endDate", e.target.value)}
                />
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex justify-end pt-6">
            <Button
              type="submit"
              className="bg-teal-600 hover:bg-teal-700 text-white px-8"
              disabled={isLoading}
            >
              {isLoading ? t`Saving...` : t`Save Now`}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddEducationModal;
