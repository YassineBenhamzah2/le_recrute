  import React, { useState, useEffect, useMemo } from 'react';
  import { useSearchParams, useNavigate } from 'react-router-dom';
  import TitleSection from './TitleSection';
  import JobFilters from './JobFilters';
  import SortDropdown from './SortDropdown';
  import ApplicationCard from './ApplicationCard';
  import Pagination, { usePaginationWithURL } from './Pagination';
  import { jobOffersService, GetJobsQuery } from '../../lib/network/candidateJobOffer';
  import { CandidateJobOffer } from '../../lib/types/candidateJobOffer';
  import { ApiResponse, PaginationMetadata } from '../../lib/types/base';
  import { Trans } from '@lingui/macro';

  interface JobsApiResponse extends ApiResponse<CandidateJobOffer[]> {
    metadata?: {
      pagination?: PaginationMetadata;
    };
  }

  const CandidateApplicationsDashboard: React.FC = () => {
    const [searchParams, setSearchParams] = useSearchParams();
    const { currentPage } = usePaginationWithURL();
    const navigate = useNavigate();
    
    const [expandedCards, setExpandedCards] = useState<Set<number>>(new Set());
    const [allJobs, setAllJobs] = useState<CandidateJobOffer[]>([]);
    const [filteredJobs, setFilteredJobs] = useState<CandidateJobOffer[]>([]);
    const [sortedJobs, setSortedJobs] = useState<CandidateJobOffer[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [totalPages, setTotalPages] = useState<number>(1);
    
    const jobsPerPage = 5;

    // Validate tab parameter and default to 'all' if invalid
    const getValidatedTab = (tab: string | null): 'all' | 'applied' | 'saved' => {
      if (tab === 'all' || tab === 'applied' || tab === 'saved') {
        return tab;
      }
      return 'all';
    };

    const [activeTab, setActiveTab] = useState<'all' | 'applied' | 'saved'>(
      getValidatedTab(searchParams.get('tab'))
    );

    // Update activeTab when URL params change
    useEffect(() => {
      const tabFromUrl = getValidatedTab(searchParams.get('tab'));
      setActiveTab(tabFromUrl);
    }, [searchParams]);

    // Fetch all jobs efficiently using metadata
    useEffect(() => {
      const fetchAllJobs = async () => {
        setLoading(true);
        setError(null);

        try {
          // First, get just the metadata to know how many items exist
          const metadataQuery: GetJobsQuery = {
            page: 0,
            size: 1, // Minimal data, just to get metadata
            tab: activeTab
          };

          const metadataResponse: JobsApiResponse = await jobOffersService.getAll(metadataQuery);
      
          if (!metadataResponse.success || !metadataResponse.metadata?.pagination) {
            setError('Failed to fetch job metadata');
            return;
          }

          const { totalItems } = metadataResponse.metadata.pagination;
      
          let allFetchedJobs: CandidateJobOffer[] = [];
      
          // If total items is reasonable, fetch all at once
          if (totalItems <= 200) {
            const query: GetJobsQuery = {
              page: 0,
              size: totalItems,
              tab: activeTab
            };
        
            const response: JobsApiResponse = await jobOffersService.getAll(query);
            if (response.success && response.data) {
              allFetchedJobs = response.data;
            }
          } else {
            // For larger datasets, fetch in reasonable chunks
            const pageSize = 50;
            const totalPages = Math.ceil(totalItems / pageSize);
        
            for (let page = 0; page < totalPages; page++) {
              const query: GetJobsQuery = {
                page: page,
                size: pageSize,
                tab: activeTab
              };
          
              const response: JobsApiResponse = await jobOffersService.getAll(query);
              if (response.success && response.data) {
                allFetchedJobs = [...allFetchedJobs, ...response.data];
              }
            }
          }
          setAllJobs(allFetchedJobs);
          setFilteredJobs(allFetchedJobs);
          setSortedJobs(allFetchedJobs);
          setTotalPages(Math.ceil(allFetchedJobs.length / jobsPerPage));
      
        } catch (err: any) {
          setError(err.message || 'An error occurred while fetching job offers');
          console.error('Error fetching job offers:', err);
        } finally {
          setLoading(false);
        }
      };

      fetchAllJobs();
    }, [activeTab]);

    // Apply pagination to sorted jobs
    const paginatedJobs = useMemo(() => {
      const startIndex = (currentPage - 1) * jobsPerPage;
      return sortedJobs.slice(startIndex, startIndex + jobsPerPage);
    }, [sortedJobs, currentPage, jobsPerPage]);

    // Update total pages when filtered jobs change
    useEffect(() => {
      setTotalPages(Math.ceil(filteredJobs.length / jobsPerPage));
    }, [filteredJobs, jobsPerPage]);

    const handleQuickApply = () => {
      console.log('Quick Apply clicked');
    };

    // client-side filtering system
    const handleJobSearch = (filters: any) => {
      console.log('Applying filters:', filters);
      
      let filtered = allJobs.filter(job => {
        // 1. Keyword/Title search - matches job title, description
        const matchesKeyword = !filters.jobTitle || filters.jobTitle.trim() === '' || [
          job.title,
          job.description || ''
        ].some(field => field.toLowerCase().includes(filters.jobTitle.toLowerCase().trim()));

        // 2. Company name filter
        const matchesCompanyName = !filters.companyName || filters.companyName.trim() === '' ||
          (job.company?.name || '').toLowerCase().includes(filters.companyName.toLowerCase().trim());

        // 3. Contract types filter (multi-select)
        const matchesContractTypes = !filters.contractTypes || filters.contractTypes.length === 0 ||
          filters.contractTypes.some((type: string) => 
            job.contractType && job.contractType.toLowerCase().includes(type.toLowerCase())
          );

        // 4. Work modes filter (multi-select) - direct match with job workMode
        const matchesWorkModes = !filters.workModes || filters.workModes.length === 0 ||
          filters.workModes.some((mode: string) => 
            job.workMode && job.workMode.toLowerCase().includes(mode.toLowerCase())
          );

        // 5. Locations filter (multi-select)
        const matchesLocations = !filters.locations || filters.locations.length === 0 ||
          filters.locations.some((location: string) =>
            job.location.toLowerCase().includes(location.toLowerCase())
          );

        // 6. Requirements filter (multi-select) - matches against job requirements
        const matchesRequirements = !filters.requirements || filters.requirements.length === 0 ||
          filters.requirements.some((requirement: string) => {
            const jobRequirements = (job.requirements || []).map(req => req.toLowerCase());
            return jobRequirements.some(req => req.includes(requirement.toLowerCase()));
          });

        // 7. Sectors filter (multi-select)
        const matchesSectors = !filters.sectors || filters.sectors.length === 0 ||
          filters.sectors.some((sector: string) =>
            (job.company?.sector || '').toLowerCase().includes(sector.toLowerCase())
          );

        // 8. Salary ranges filter (multi-select)
        const matchesSalaryRanges = !filters.salaryRanges || filters.salaryRanges.length === 0 ||
          filters.salaryRanges.some((range: string) => {
            if (job.negotiable) return range.includes('Negotiable') || range.includes('25000+');
            
            const jobSalary = job.maxSalary || job.minSalary || 0;
            
            // Parse range like "3000-6000 DH" or "25000+ DH"
            if (range.includes('+')) {
              const minValue = parseInt(range.replace(/[^0-9]/g, ''));
              return jobSalary >= minValue;
            } else if (range.includes('-')) {
              const [min, max] = range.split('-').map(val => parseInt(val.replace(/[^0-9]/g, '')));
              return jobSalary >= min && jobSalary <= max;
            }
            return false;
          });

        // 9. Application deadline filter - show jobs ending on or before selected date
        const matchesDeadline = !filters.applicationDeadline || 
          (job.deadlineDate && new Date(job.deadlineDate) <= new Date(filters.applicationDeadline));

        // 10. Number of vacancies filter (multi-select) - skip since not available in API
        const matchesVacancies = !filters.numberOfVacancies || filters.numberOfVacancies.length === 0;

        // Return true only if ALL filters match (AND logic)
        return matchesKeyword && 
               matchesCompanyName && 
               matchesContractTypes && 
               matchesWorkModes && 
               matchesLocations && 
               matchesRequirements && 
               matchesSectors && 
               matchesSalaryRanges && 
               matchesDeadline && 
               matchesVacancies;
      });
      
      console.log(`Filtered ${filtered.length} jobs from ${allJobs.length} total jobs`);
      setFilteredJobs(filtered);
      
      // Reset to first page when filters change
      setSearchParams(prev => {
        const newParams = new URLSearchParams(prev);
        newParams.set('page', '1');
        return newParams;
      });
    };

    // This handler receives sorted data from SortDropdown
    const handleSortedDataChange = (sortedData: CandidateJobOffer[]) => {
      setSortedJobs(sortedData);
    };

    const handleCardClick = (id: number) => {
      setExpandedCards(prev => {
        const newSet = new Set(prev);
        if (newSet.has(id)) {
          newSet.delete(id);
        } else {
          newSet.add(id);
        }
        return newSet;
      });
    };

    const handleApply = (id: number) => {
      console.log('Apply clicked for job:', id);
    };

    // Update both allJobs and filteredJobs
    const handleBookmark = async (id: number) => {
      // Optimistic update
      setAllJobs(prevJobs => prevJobs.map(job => 
        job.id === id ? { ...job, isBookmarked: !job.isBookmarked } : job
      ));
      
      setFilteredJobs(prevJobs => {
        const updatedJobs = prevJobs.map(job => 
          job.id === id ? { ...job, isBookmarked: !job.isBookmarked } : job
        );
        
        // Immediately remove if unbookmarked in saved tab
        if (activeTab === 'saved' && !updatedJobs.find(job => job.id === id)?.isBookmarked) {
          return updatedJobs.filter(job => job.id !== id);
        }
        
        return updatedJobs;
      });
      
      // API call in background
      try {
        await jobOffersService.bookmarkJob(id);
      } catch (err) {
        console.error('Error toggling bookmark:', err);
        // Revert on error
        setAllJobs(prevJobs => prevJobs.map(job => 
          job.id === id ? { ...job, isBookmarked: !job.isBookmarked } : job
        ));
        
        setFilteredJobs(prevJobs => prevJobs.map(job => 
          job.id === id ? { ...job, isBookmarked: !job.isBookmarked } : job
        ));
      }
    };

    const handleViewMore = (id: number) => {
      navigate(`/candidate/applications/${id}`, {
        state: {
          job: allJobs.find(job => job.id === id)
        }
      });
    };

    const handleTabChange = (tab: string) => {
      const validatedTab = getValidatedTab(tab);
      setActiveTab(validatedTab);
      setExpandedCards(new Set());
      setSearchParams({ 
        page: '1', 
        tab: validatedTab 
      });
    };

    // Map CandidateJobOffer to ApplicationCard props
    const mapJobOfferToCardProps = (job: CandidateJobOffer) => {
      const status: 'applied' | 'not-applied' = job.isApplied ? 'applied' : 'not-applied';
      const saveStatus: 'saved' | 'not-saved' = job.isBookmarked ? 'saved' : 'not-saved';
      
      return {
        id: job.id,
        title: job.title,
        company: job.company?.name || 'Unknown Company',
        location: job.location,
        type: mapJobType(job.jobType),
        salary: {
          min: job.minSalary || 0,
          max: job.maxSalary || 0,
          currency: job.currency || 'DH',
          negotiable: job.negotiable || false
        },
        postedTime: formatPostedTime(job.publicationDate),
        skills: job.requirements || [],
        logo: job.company?.logo || undefined,
        status: status,
        saveStatus: saveStatus,
        description: job.description,
        jobDetails: {
          publicationPeriod: `Du ${formatDate(job.publicationDate)} Au ${formatDate(job.deadlineDate)}`,
          activitySector: job.company?.sector || '',
          function: job.title,
          description: job.description,
          requiredExperience: '',
          educationLevel: '',
          contractType: job.contractType,
          workMode: job.workMode,
          remote: false
        },
        questions: job.questions,
        questionIds: job.questionsIds,
        // Update both allJobs and filteredJobs
        onApplied: (jobId: number) => {
          setAllJobs(prevJobs => prevJobs.map(job => 
            job.id === jobId ? { ...job, isApplied: true } : job
          ));
          setFilteredJobs(prevJobs => prevJobs.map(job => 
            job.id === jobId ? { ...job, isApplied: true } : job
          ));
        }
      };
    };

    // Helper functions
    const mapJobType = (jobType: string): 'Full Time' | 'Part Time' | 'Internship' => {
      switch (jobType) {
        case 'FULL_TIME': return 'Full Time';
        case 'PART_TIME': return 'Part Time';
        case 'INTERNSHIP': return 'Internship';
        case 'FREELANCE': return 'Part Time';
        default: return 'Full Time';
      }
    };

    const formatPostedTime = (dateString: string): string => {
      if (!dateString) return 'Recently';
      const date = new Date(dateString);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      
      if (diffHours < 1) return 'Less than an hour ago';
      if (diffHours < 24) return `${diffHours} hours ago`;
      if (diffDays === 1) return '1 day ago';
      if (diffDays < 7) return `${diffDays} days ago`;
      if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
      return `${Math.floor(diffDays / 30)} months ago`;
    };

    const formatDate = (dateString: string): string => {
      if (!dateString) return '';
      const date = new Date(dateString);
      return date.toLocaleDateString('fr-FR');
    };

    return (
      <div className="p-6 space-y-6 max-w-[93%] ml-[7%]">
        <TitleSection 
          title={<Trans id="homepage.title">Find Your Dream Job</Trans>}
          description={<Trans id="homepage.description">Discover opportunities that match your skills and interests</Trans>}
          button={{
            text: <Trans id="homepage.quickApplyButton">Quick Apply</Trans>,
            onClick: handleQuickApply,
            variant: 'primary'
          }} 
        />
        
        <JobFilters onSearch={handleJobSearch} />
        
        <div className="flex justify-between items-center">
          {/* Left side - Job Tabs */}
          <div className="flex space-x-3">
            <button
              onClick={() => handleTabChange('all')}
              className={`px-6 py-3 text-sm font-medium transition-colors rounded-lg ${
                activeTab === 'all'
                  ? 'bg-teal-600 text-white'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              <Trans>All Offers</Trans>
            </button>
            <button
              onClick={() => handleTabChange('applied')}
              className={`px-6 py-3 text-sm font-medium transition-colors rounded-lg ${
                activeTab === 'applied'
                  ? 'bg-teal-600 text-white'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              <Trans>Applied</Trans>
            </button>
            <button
              onClick={() => handleTabChange('saved')}
              className={`px-6 py-3 text-sm font-medium transition-colors rounded-lg ${
                activeTab === 'saved'
                  ? 'bg-teal-600 text-white'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              <Trans>Saved</Trans>
            </button>
          </div>

          {/* Right side - Sort Dropdown */}
          <SortDropdown
            data={filteredJobs}
            onSortedDataChange={handleSortedDataChange}
            defaultSort="most-recent"
          />
        </div>

        {/* Jobs Section */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          {loading ? (
            <div className="animate-pulse space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-12">
              <p className="text-red-600">{error}</p>
              <button
                onClick={() => window.location.reload()}
                className="mt-2 bg-teal-600 text-white px-4 py-2 rounded-lg text-sm"
              >
                <Trans>Retry</Trans>
              </button>
            </div>
          ) : paginatedJobs.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">
              {activeTab === 'saved' ? (
                <Trans>No saved job offers found.</Trans>
              ) : activeTab === 'applied' ? (
                <Trans>No applied job offers found.</Trans>
              ) : (
                <Trans>No job offers found.</Trans>
              )}
            </p>
            </div>
          ) : (
            <>
              <div className="space-y-4">
                {paginatedJobs.map((job) => (
                  <ApplicationCard
                    key={job.id}
                    {...mapJobOfferToCardProps(job)}
                    isExpandable={true}
                    isExpanded={expandedCards.has(job.id)}
                    onCardClick={handleCardClick}
                    onApply={handleApply}
                    onSave={() => handleBookmark(job.id)}
                    onViewMore={handleViewMore}
                  />
                ))}
              </div>
              
              <Pagination 
                totalPages={totalPages}
                preserveOtherParams={true}
                onPageChange={(page) => {
                  setExpandedCards(new Set());
                  console.log(`Navigated to page ${page} in ${activeTab} tab`);
                }}
              />
            </>
          )}
        </div>
      </div>
    );
  };

  export default CandidateApplicationsDashboard;