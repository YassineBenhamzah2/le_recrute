interface TitleSectionProps {
    title: string;
    description: string;
    className?: string;
    button?: {
        text: string;
        onClick: () => void;
        variant?: 'primary' | 'secondary';
    };
}

const TitleSection = ({ title, description, className = "", button }: TitleSectionProps) => {
    return (
        <div className={`mb-8 mt-2 ${className}`}>
            <div className="flex items-start justify-between">
                <div className="flex-1">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">{title}</h1>
                    <p className="text-lg text-gray-600">{description}</p>
                </div>
                {button && (
                    <button
                        onClick={button.onClick}
                        className={`px-6 py-3 rounded-lg font-medium transition-colors ${
                            button.variant === 'secondary'
                                ? 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                                : 'bg-teal-600 hover:bg-teal-700 text-white'
                        }`}
                    >
                        {button.text}
                    </button>
                )}
            </div>
        </div>
    );
};

export default TitleSection;
