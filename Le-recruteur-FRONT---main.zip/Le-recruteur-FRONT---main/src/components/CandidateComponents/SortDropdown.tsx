// SortDropdown.tsx
import React, { useState, useMemo } from 'react';
import { Trans } from '@lingui/macro';

export interface SortOption {
  value: string;
  label: string;
  sortFn: (a: any, b: any) => number;
}

interface SortDropdownProps<T> {
  data: T[];
  onSortedDataChange?: (sortedData: T[]) => void;
  defaultSort?: string;
  className?: string;
}

// Custom hook for job sorting logic
const useJobSorting = () => {
  const jobSortOptions: SortOption[] = useMemo(() => [
    {
      value: 'most-recent',
      label: 'Most Recent',
      sortFn: (a: any, b: any) => {
        const dateA = new Date(a.publicationDate || 0);
        const dateB = new Date(b.publicationDate || 0);
        return dateB.getTime() - dateA.getTime();
      }
    },
    {
      value: 'oldest',
      label: 'Oldest',
      sortFn: (a: any, b: any) => {
        const dateA = new Date(a.publicationDate || 0);
        const dateB = new Date(b.publicationDate || 0);
        return dateA.getTime() - dateB.getTime();
      }
    },
    {
      value: 'salary-high',
      label: 'Salary: High to Low',
      sortFn: (a: any, b: any) => (b.maxSalary || 0) - (a.maxSalary || 0)
    },
    {
      value: 'salary-low',
      label: 'Salary: Low to High',
      sortFn: (a: any, b: any) => (a.minSalary || 0) - (b.maxSalary || 0)
    },
    {
      value: 'title-az',
      label: 'Title: A to Z',
      sortFn: (a: any, b: any) => (a.title || '').localeCompare(b.title || '')
    },
    {
      value: 'title-za',
      label: 'Title: Z to A',
      sortFn: (a: any, b: any) => (b.title || '').localeCompare(a.title || '')
    }
  ], []);

  return { jobSortOptions };
};

const SortDropdown = <T,>({ 
  data, 
  onSortedDataChange, 
  defaultSort = 'most-recent', 
  className = "" 
}: SortDropdownProps<T>) => {
  const [selectedSort, setSelectedSort] = useState<string>(defaultSort);
  const [isOpen, setIsOpen] = useState(false);
  
  // Use the internal hook
  const { jobSortOptions } = useJobSorting();

  // Find the default sort option
  const defaultSortOption = jobSortOptions.find(option => option.value === defaultSort) || jobSortOptions[0];

  // Apply sorting when data or sort option changes
  const sortedData = useMemo(() => {
    const selectedOption = jobSortOptions.find(option => option.value === selectedSort) || defaultSortOption;
    
    if (!selectedOption || !data || data.length === 0) return data;
    
    try {
      // Create a copy to avoid mutating the original array
      return [...data].sort(selectedOption.sortFn);
    } catch (error) {
      console.error('Error sorting data:', error);
      return data; // Return original data if sorting fails
    }
  }, [data, selectedSort, jobSortOptions, defaultSortOption]);

  // Notify parent when sorted data changes
  React.useEffect(() => {
    if (onSortedDataChange) {
      onSortedDataChange(sortedData);
    }
  }, [sortedData, onSortedDataChange]);

  const handleSortChange = (sortValue: string) => {
    setSelectedSort(sortValue);
    setIsOpen(false);
  };

  const selectedOption = jobSortOptions.find(option => option.value === selectedSort) || defaultSortOption;

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors text-sm font-medium text-gray-700"
      >
        <span className="mr-2">

          <Trans>Sort by:</Trans>
        </span>
        <span className="text-gray-900">
          {selectedOption?.label === 'Most Recent' && <Trans>Most Recent</Trans>}
          {selectedOption?.label === 'Oldest' && <Trans>Oldest</Trans>}
          {selectedOption?.label === 'Salary: High to Low' && <Trans>Salary: High to Low</Trans>}
          {selectedOption?.label === 'Salary: Low to High' && <Trans>Salary: Low to High</Trans>}
          {selectedOption?.label === 'Title: A to Z' && <Trans>Title: A to Z</Trans>}
          {selectedOption?.label === 'Title: Z to A' && <Trans>Title: Z to A</Trans>}

        </span>
        <svg 
          className={`ml-2 w-4 h-4 text-gray-400 transform transition-transform ${isOpen ? 'rotate-180' : ''}`} 
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute right-0 top-full mt-1 w-56 bg-white border border-gray-200 rounded-md shadow-lg z-10">
          <div className="py-1">
            {jobSortOptions.map((option) => (
              <button
                key={option.value}
                onClick={() => handleSortChange(option.value)}
                className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                  selectedSort === option.value 
                    ? 'bg-teal-50 text-teal-700 font-medium' 
                    : 'text-gray-700'
                }`}
              >

                {option.label === 'Most Recent' && <Trans>Most Recent</Trans>}
                {option.label === 'Oldest' && <Trans>Oldest</Trans>}
                {option.label === 'Salary: High to Low' && <Trans>Salary: High to Low</Trans>}
                {option.label === 'Salary: Low to High' && <Trans>Salary: Low to High</Trans>}
                {option.label === 'Title: A to Z' && <Trans>Title: A to Z</Trans>}
                {option.label === 'Title: Z to A' && <Trans>Title: Z to A</Trans>}

              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SortDropdown;