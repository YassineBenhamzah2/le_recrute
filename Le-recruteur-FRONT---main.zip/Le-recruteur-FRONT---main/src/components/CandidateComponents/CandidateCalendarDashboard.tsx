import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import FullCalendar from "@fullcalendar/react";
import { format, isSameDay, parseISO } from "date-fns";
import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { DayPicker } from "react-day-picker";
import { interviewService } from "@/lib/network/interview";
import { Interview } from "@/lib/types/interview"; // This type should be updated to match DetailedInterviewResponse
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import TitleSection from './TitleSection';
import { Trans } from "@lingui/macro";

const CandidateCalendrierDashboard = () => {
  const [selectedDay, setSelectedDay] = useState<Date | undefined>(new Date());
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [loading, setLoading] = useState(true);
  const calendarRef = useRef<FullCalendar | null>(null);

  // Fetch interviews from API (for the candidate)
  const fetchInterviews = useCallback(async () => {
    try {
      setLoading(true);
      
      // The calendar needs all interviews, so we fetch with a large page size.
      // Your service returns ApiResponse<Interview[]>, which we handle here.
      const response = await interviewService.getCandidateInterviews({ page: 0, size: 100 }); 
      
      if (response.success && Array.isArray(response.data)) {
        setInterviews(response.data);
      } else {
        toast.error("Failed to load your interviews");
      }
    } catch (error) {
      console.error("Error fetching interviews:", error);
      toast.error("Error loading your interviews");
    } finally {
      setLoading(false);
    }
  }, []); // Empty dependency array means this function is created once

  useEffect(() => {
    fetchInterviews();
  }, [fetchInterviews]);

  // Convert interviews from API response to the format FullCalendar expects
  const events = useMemo(() => {
    return interviews.map((interview) => ({
      id: interview.id.toString(),
      title: interview.position,
      companyName: interview.companyName || "Unknown Company",
      // Combine the separate date and time fields from your DTO into a valid ISO string
      start: `${interview.date}T${interview.time}`,
      end: `${interview.date}T${interview.time}`, // You can add duration logic here later if needed
      status: interview.status,
    }));
  }, [interviews]);

  // Filter the transformed events for the sidebar daily list
  const filteredEvents = useMemo(() => {
    if (!selectedDay) return [];
    // parseISO correctly handles the "YYYY-MM-DDTHH:mm" format
    return events.filter((e) => isSameDay(parseISO(e.start), selectedDay));
  }, [selectedDay, events]);

  // Custom function to render how each event looks inside the calendar grid
  const renderEventContent = (arg: { event: { id: string } }) => {
    const ev = events.find((e) => e.id === arg.event.id);
    return (
      <div
        className="flex flex-col border border-emerald-200 rounded-md shadow-sm overflow-hidden hover:shadow-md w-full transition"
        style={{ borderLeftWidth: "4px", borderLeftColor: "#065f46" }}
      >
        {ev?.start && ev?.end && (
          <div className="px-2 py-0.5 bg-white border-t border-emerald-100 text-[10px] text-gray-500">
            {new Date(ev.start).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </div>
        )}
        <div className="px-2 py-1 bg-emerald-50">
          <div className="text-[11px] font-semibold text-emerald-900 leading-snug line-clamp-1">
            {ev?.title}
          </div>
          <div className="text-[10px] text-gray-600 line-clamp-1">
            {ev?.companyName}
          </div>
          <div className="text-[9px] text-gray-500 capitalize">
            {ev?.status.toLowerCase()}
          </div>
        </div>
      </div>
    );
  };

  // Handles clicking a day in the sidebar DayPicker
  const handleDaySelect = (date?: Date) => {
    if (!date) return;
    setSelectedDay(date);
    const calendarApi = calendarRef.current?.getApi();
    if (calendarApi) {
      calendarApi.gotoDate(date);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-[93%] ml-[7%]">
      <div className="flex justify-between items-start">
        <TitleSection 
          title={<Trans id="calender.title">My Interview Schedule</Trans>}
          description={<Trans id="calender.description">Keep track of your upcoming interviews</Trans>}
        
        />
        
        <Button
          onClick={fetchInterviews}
          disabled={loading}
          variant="outline"
          size="sm"
          className="flex items-center gap-2"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            <Trans>Refresh</Trans>
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <aside className="w-full md:w-fit bg-white rounded-xl border p-4 shadow-sm">
          <h2 className="text-lg font-bold text-emerald-700 mb-3">
            <Trans>Select Date</Trans>
          </h2>
          <DayPicker
            mode="single"
            selected={selectedDay}
            onSelect={handleDaySelect}
            className="mb-6"
            styles={{
              day_selected: { backgroundColor: "#238D94", color: "white" },
              day_today: { color: "#238D94", fontWeight: "bold" },
            }}
          />
          <h3 className="text-md font-semibold text-gray-700 mb-2">
            <Trans>Interviews on {selectedDay ? format(selectedDay, "MMM dd") : ''}</Trans>
          </h3>
          <div className="space-y-2">
            {loading ? (
              <div className="text-xs text-gray-500"><Trans>Loading interviews...</Trans></div>
            ) : filteredEvents.length > 0 ? (
              filteredEvents.map((ev) => (
                <div
                  key={`${ev.id}-${ev.start}`}
                  className="border border-emerald-300 rounded-lg p-2 bg-emerald-50"
                >
                  <div className="text-sm font-bold text-emerald-800">
                    {ev.title}
                  </div>
                  <div className="text-xs text-gray-600">{ev.companyName}</div>
                  <div className="text-xs text-gray-500">
                    {format(parseISO(ev.start), "HH:mm")}
                  </div>
                  <div className="text-xs text-blue-600 font-medium capitalize">
                    {ev.status.toLowerCase()}
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-gray-500"><Trans>No interviews scheduled</Trans></p>
            )}
          </div>
        </aside>

        {/* Full Calendar */}
        <div className="flex-1 bg-white rounded-xl border shadow-sm p-4">
          <FullCalendar
            plugins={[dayGridPlugin, interactionPlugin]}
            initialView="dayGridMonth"
            events={events}
            ref={calendarRef}
            height="auto"
            dayMaxEventRows={3}
            firstDay={1} // Monday
            eventContent={renderEventContent}
            headerToolbar={{
              left: "title",
              center: "",
              right: "prev,next",
            }}
          />
        </div>
      </div>
    </div>
  );
}

export default CandidateCalendrierDashboard;