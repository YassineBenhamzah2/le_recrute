import React, { useState, useEffect } from 'react';
import { jobOffersService } from '@/lib/network/candidateJobOffer';
import { Trans, t } from '@lingui/macro';

interface JobFiltersProps {
  className?: string;
  onSearch?: (filters: any) => void;
}

const JobFilters: React.FC<JobFiltersProps> = ({ className = "", onSearch }) => {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [openDropdowns, setOpenDropdowns] = useState<Record<string, boolean>>({});
  const [filters, setFilters] = useState({
    jobTitle: '',
    contractTypes: [] as string[],
    workModes: [] as string[],
    locations: [] as string[],
    requirements: [] as string[],
    sectors: [] as string[],
    salaryRanges: [] as string[],
    // Advanced filters
    companyName: '',
    applicationDeadline: '',
    numberOfVacancies: [] as string[]
  });

  // API data - using any to avoid type conflicts for now
  const [apiFilters, setApiFilters] = useState<any>(null);

  // Fetch filter options from API
  useEffect(() => {
    jobOffersService.getJobsFilters().then(response => {
      if (response.success && response.data) {
        setApiFilters(response.data);
      }
    });
  }, []);

  const handleInputChange = (field: string, value: string) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const handleCheckboxChange = (field: keyof typeof filters, value: string, isChecked: boolean) => {
    setFilters(prev => {
      const currentValues = Array.isArray(prev[field]) ? [...prev[field] as string[]] : [];
      const newValues = isChecked 
        ? [...currentValues, value]
        : currentValues.filter(v => v !== value);
      
      return { ...prev, [field]: newValues };
    });
  };

  // Toggle dropdown visibility
  const handleSearch = () => {
    if (onSearch) {
      onSearch(filters);
    }
  };

  const handleResetAndApply = () => {
    const resetFilters = {
      jobTitle: '',
      contractTypes: [] as string[],
      workModes: [] as string[],
      locations: [] as string[],
      requirements: [] as string[],
      sectors: [] as string[],
      salaryRanges: [] as string[],
      companyName: '',
      applicationDeadline: '',
      numberOfVacancies: [] as string[]
    };
    
    setFilters(resetFilters);
    
    if (onSearch) {
      onSearch(resetFilters);
    }
  };

  const toggleDropdown = (dropdownName: string) => {
    setOpenDropdowns(prev => ({
      ...prev,
      [dropdownName]: !prev[dropdownName]
    }));
  };

  // Render multi-select dropdown
  const renderMultiSelect = (field: keyof typeof filters, options: string[] | { id: number; name: string }[], label: string, placeholder: string) => {
    const isOpen = openDropdowns[field] || false;
    const selectedValues = filters[field] as string[];
    const displayText = selectedValues.length > 0 
      ? t`${selectedValues.length} selected` 
      : placeholder;

    return (
      <div className="relative">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          <Trans>{label}</Trans>
        </label>
        <div className="relative">
          <button
            type="button"
            onClick={() => toggleDropdown(field)}
            className="w-full px-3 py-2.5 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-transparent appearance-none bg-white text-left flex items-center justify-between"
          >
            <span className={selectedValues.length > 0 ? "text-gray-900" : "text-gray-500"}>
              {selectedValues.length > 0 ? (
                <Trans id="filters.selectedCount" values={{ count: selectedValues.length }}>
                  {selectedValues.length} selected
                </Trans>
              ) : (
                <Trans>{placeholder}</Trans>
              )}
            </span>
            <svg 
              className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${isOpen ? 'transform rotate-180' : ''}`} 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          
          {isOpen && (
            <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto">
              {options.length === 0 ? (
                <div className="px-3 py-2 text-sm text-gray-500 italic">
                  <Trans>Loading...</Trans>
                </div>
              ) : (
                options.map((option) => {
                  const value = typeof option === 'string' ? option : option.name;
                  const key = typeof option === 'string' ? option : option.id;
                  const isChecked = selectedValues.includes(value);
                  
                  return (
                    <label key={key} className="flex items-center space-x-2 px-3 py-2 hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => handleCheckboxChange(field, value, e.target.checked)}
                        className="w-4 h-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                      />
                      <span className="text-sm text-gray-700">
                        <Trans id={`filters.option.${value.replace(/\s+/g, '_').toLowerCase()}`}>
                          {value}
                        </Trans>
                      </span>
                    </label>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch();
  };

  // Salary ranges with Trans components
  const salaryRanges = [
    t`0-3000 DH`,
    t`3000-6000 DH`,
    t`6000-10000 DH`,
    t`10000-15000 DH`,
    t`15000-25000 DH`,
    t`25000+ DH`
  ];

  return (
    <div className={`bg-white border border-gray-200 rounded-lg p-4 ${className}`}>
      <form onSubmit={handleSubmit}>
        <div className="flex flex-col space-y-4 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <svg className="w-5 h-5 text-teal-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
              </svg>
              <h2 className="text-lg font-semibold text-gray-900">
                <Trans>Job Filters</Trans>
              </h2>
            </div>
            <div className="flex gap-2">
              <button 
                type="button"
                onClick={handleResetAndApply}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500"
              >
                <Trans>Reset</Trans>
              </button>
              <button 
                type="submit"
                className="px-4 py-2 text-sm font-medium text-white bg-teal-600 border border-transparent rounded-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500"
              >
                <Trans>Apply Filters</Trans>
              </button>
            </div>
          </div>
        </div>

        {/* All Filters Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
          {/* Job Title Search */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Trans>Search by Job Title or Description</Trans>
            </label>
            <div className="relative">
              <svg className="absolute left-2.5 top-1/2 transform -translate-y-1/2 w-3.5 h-3.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder={t`Ex: Manager, software development...`}
                value={filters.jobTitle}
                onChange={(e) => handleInputChange('jobTitle', e.target.value)}
                className="w-full pl-8 pr-3 py-2.5 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />    
            </div>
          </div>

          {/* Contract Types */}
          {renderMultiSelect('contractTypes', apiFilters?.contractTypes || [], t`Contract Types`, t`Select contract types...`)}

          {/* Work Modes */}
          {renderMultiSelect('workModes', apiFilters?.workModes || [], t`Work Modes`, t`Select work modes...`)}

          {/* Locations */}
          {renderMultiSelect('locations', apiFilters?.locations || [], t`Locations`, t`Select locations...`)}

          {/* Company Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Trans>Company Name</Trans>
            </label>
            <div className="relative">
              <svg className="absolute left-2.5 top-1/2 transform -translate-y-1/2 w-3.5 h-3.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
              <input
                type="text"
                placeholder={t`Ex: Orange, L'Oréal...`}
                value={filters.companyName}
                onChange={(e) => handleInputChange('companyName', e.target.value)}
                className="w-full pl-8 pr-3 py-2.5 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Requirements */}
          {renderMultiSelect('requirements', apiFilters?.requirements || [], t`Requirements`, t`Select requirements...`)}

          {/* Sectors */}
          {renderMultiSelect('sectors', apiFilters?.sectors || [], t`Sectors`, t`Select sectors...`)}

          {/* Salary Range */}
          {renderMultiSelect('salaryRanges', salaryRanges, t`Salary Range`, t`Select salary ranges...`)}
        </div>

        {/* Advanced Filters */}
        <div className="flex justify-center">
          <button 
            type="button"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="flex items-center text-sm font-medium text-teal-600 hover:text-teal-800 focus:outline-none"
          >
            {showAdvanced ? (
              <Trans>Hide Advanced Filters</Trans>
            ) : (
              <Trans>Show Advanced Filters</Trans>
            )}
            <svg 
              className={`w-4 h-4 ml-1 transition-transform duration-200 ${showAdvanced ? 'transform rotate-180' : ''}`} 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
        </div>

        <div className={`mt-4 transition-all duration-300 overflow-hidden ${showAdvanced ? 'max-h-screen' : 'max-h-0'}`}>
          <div className="pt-4 border-t border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
              {/* Application Deadline */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Trans>Application Deadline</Trans>
                </label>
                <div className="relative">
                  <svg className="absolute left-2.5 top-1/2 transform -translate-y-1/2 w-3.5 h-3.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <input
                    type="date"
                    placeholder={t`Select a date`}
                    value={filters.applicationDeadline}
                    onChange={(e) => handleInputChange('applicationDeadline', e.target.value)}
                    className="w-full pl-8 pr-3 py-2.5 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Number of Vacancies - UI only, non-functional */}
              <div className="relative">
                <label className="block text-sm font-medium text-gray-400 mb-1">
                  <Trans>Number of Vacancies (UI only)</Trans>
                </label>
                <div className="relative">
                  <button
                    type="button"
                    disabled
                    className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-md bg-gray-50 text-gray-400 cursor-not-allowed flex items-center justify-between"
                  >
                    <span><Trans>Select vacancy options...</Trans></span>
                    <svg 
                      className="w-4 h-4 text-gray-300" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </div>
              
              {/* Add New Filters Placeholder */}
              <div className="relative">
                <label className="block text-sm font-medium text-gray-400 mb-1">
                  <Trans>New filters here</Trans>
                </label>
                <div className="relative">
                  <button
                    type="button"
                    disabled
                    className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-md bg-gray-50 text-gray-400 cursor-not-allowed flex items-center justify-between"
                  >
                    <span><Trans>Select options...</Trans></span>
                    <svg 
                      className="w-4 h-4 text-gray-300" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Additional Placeholder Filter */}
              <div className="relative">
                <label className="block text-sm font-medium text-gray-400 mb-1">
                  <Trans>Coming soon</Trans>
                </label>
                <div className="relative">
                  <button
                    type="button"
                    disabled
                    className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-md bg-gray-50 text-gray-400 cursor-not-allowed flex items-center justify-between"
                  >
                    <span><Trans>More filters...</Trans></span>
                    <svg 
                      className="w-4 h-4 text-gray-300" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}

export default JobFilters;