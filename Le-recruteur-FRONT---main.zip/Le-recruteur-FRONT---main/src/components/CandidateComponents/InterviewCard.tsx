import React from "react";
import { Interview } from "../../lib/types/interview";
import { Trans, t } from "@lingui/macro";

interface InterviewCardProps {
  interview: Interview;
}

const InterviewCard: React.FC<InterviewCardProps> = ({ interview }) => {
  if (!interview) {
    return (
      <div className="border border-gray-200 rounded-lg p-4">
        <p className="text-gray-500">
          <Trans>No interview data available</Trans>
        </p>
      </div>
    );
  }

  return (
    <div className="border border-gray-200 rounded-lg p-4 relative">
      {/* Status and Actions - Top Right (only for upcoming) */}
      {(interview.myStatus === "SCHEDULED" ||
        interview.status === "Scheduled" ||
        interview.status === "SCHEDULED") && (
        <div className="absolute top-4 right-4 flex items-center gap-2">
          <span className="px-3 py-1 text-xs rounded-full font-medium bg-green-100 text-green-700">
            <Trans>Scheduled</Trans>
          </span>
          <div className="w-8 h-8 bg-teal-50 rounded-full flex items-center justify-center">
            <svg
              className="w-4 h-4 text-teal-600"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z"
                clipRule="evenodd"
              />
            </svg>
          </div>
        </div>
      )}

      {/* Completed status indicator */}
      {(interview.myStatus === "COMPLETED" ||
        interview.status === "Completed" ||
        interview.status === "COMPLETED") && (
        <div className="absolute top-4 right-4 flex items-center gap-2">
          <span className="px-3 py-1 text-xs rounded-full font-medium bg-gray-100 text-gray-600">
            <Trans>Completed</Trans>
          </span>
        </div>
      )}

      {/* Cancelled status indicator */}
      {(interview.myStatus === "CANCELLED" ||
        interview.status === "Cancelled" ||
        interview.status === "CANCELLED") && (
        <div className="absolute top-4 right-4 flex items-center gap-2">
          <span className="px-3 py-1 text-xs rounded-full font-medium bg-red-100 text-red-700">
            <Trans>Cancelled</Trans>
          </span>
        </div>
      )}

      <div
        className={`flex items-start gap-4 ${
          interview.myStatus === "SCHEDULED" || interview.status === "Scheduled"
            ? "pr-24"
            : "pr-20"
        }`}
      >
        {interview.companyLogo ? (
          <img
            src={`${import.meta.env.VITE_APP_API_URL || ""}/${
              interview.companyLogo
            }`}
            alt={interview.companyName || "Company"}
            className="w-12 h-12 rounded-lg object-cover"
            onError={(e) => {
              e.currentTarget.src = "/ehc logo.png";
            }}
          />
        ) : (
          <img
            src="/ehc logo.png"
            alt={interview.companyName || "Company"}
            className="w-12 h-12 rounded-lg object-cover"
          />
        )}
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900 mb-1">
            {interview.interviewTitle}
          </h3>
          <p className="text-teal-600 font-medium">{interview.companyName}</p>
          <p className="text-sm text-gray-600 mb-3">
            {interview.jobTitle || interview.position || ""}
          </p>

          <div className="flex items-center gap-6 text-sm text-gray-500 mb-3">
            <span className="flex items-center gap-1">
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
              {interview.date} - {interview.time}
            </span>
            <span className="flex items-center gap-1">
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
              {interview.duration}
            </span>
            <span className="flex items-center gap-1">
              {interview.type === "IN_PERSON" ||
              interview.interviewType === "IN_PERSON" ? (
                <>
                  <svg
                    className="w-4 h-4 flex-shrink-0"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                  </svg>
                  <span className="truncate max-w-[200px]">
                    {interview.address || t`Location not specified`}
                  </span>
                </>
              ) : interview.type === "VIDEO" ||
                interview.interviewType === "VIDEO" ? (
                <>
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
                    />
                  </svg>
                  <span>
                    <Trans>Video Call</Trans>{" "}
                    {interview.address === "Online" && (
                      <span className="text-green-600 ml-1">
                        - {interview.address}
                      </span>
                    )}
                  </span>
                </>
              ) : (
                <>
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                    />
                  </svg>
                  <span>
                    <Trans>Phone Call</Trans>
                  </span>
                </>
              )}
            </span>
          </div>

          <div className="flex items-center gap-4 text-sm text-gray-600 mb-3 flex-wrap">
            <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">
              <Trans>Round</Trans>: {interview.round || t`N/A`}
            </span>
            <span className="flex items-center gap-1 flex-wrap">
              <svg
                className="w-4 h-4 flex-shrink-0"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                />
              </svg>
              {Array.isArray(interview.interviewers) &&
              interview.interviewers.length > 0 ? (
                interview.interviewers.map(
                  (interviewer: string, index: number) => (
                    <span
                      key={`${interviewer}-${index}`}
                      className="whitespace-nowrap"
                    >
                      {interviewer}
                      {index < interview.interviewers.length - 1 ? ", " : ""}
                    </span>
                  )
                )
              ) : (
                <span>
                  <Trans>No interviewers assigned</Trans>
                </span>
              )}
            </span>
          </div>

          {(interview.myStatus === "SCHEDULED" ||
            interview.status === "Scheduled" ||
            interview.status === "SCHEDULED") &&
            (interview.videoLink || interview.meetingLink) && (
              <div className="text-sm bg-blue-100 p-2 rounded-lg max-w-full overflow-hidden">
                <span className="text-blue-600 font-medium">
                  <Trans>Meeting Link</Trans>:{" "}
                </span>
                <a
                  href={
                    (interview.videoLink || interview.meetingLink)?.startsWith(
                      "http"
                    )
                      ? interview.videoLink || interview.meetingLink
                      : `https://${
                          interview.videoLink || interview.meetingLink
                        }`
                  }
                  className="text-blue-600 underline hover:text-blue-800 break-all"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {interview.videoLink || interview.meetingLink}
                </a>
              </div>
            )}

          {(interview.myStatus === "CANCELLED" ||
            interview.status === "Cancelled") &&
            interview.cancelReason && (
              <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                <span className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs">
                  <Trans>Cancel Reason</Trans>: {interview.cancelReason}
                </span>
              </div>
            )}

          {/* Display jury feedback if available */}
          {(interview.myStatus === "COMPLETED" ||
            interview.status === "Completed") &&
            interview.juryFeedback && (
              <div className="mt-3 pt-3 border-t border-gray-200">
                <h4 className="font-medium text-sm text-gray-900 mb-2">
                  <Trans>Feedback</Trans>
                </h4>
                <div className="space-y-2">
                  {interview.juryFeedback.observations && (
                    <p className="text-sm text-gray-600">
                      {interview.juryFeedback.observations}
                    </p>
                  )}
                  {interview.juryFeedback.decision &&
                    interview.juryFeedback.decision !== "pending" && (
                      <div
                        className={`inline-block px-2 py-1 rounded text-xs font-medium
                      ${
                        interview.juryFeedback.decision === "approved"
                          ? "bg-green-100 text-green-700"
                          : "bg-red-100 text-red-700"
                      }`}
                      >
                        <Trans>Decision</Trans>:{" "}
                        {interview.juryFeedback.decision === "approved"
                          ? t`Approved`
                          : t`Rejected`}
                      </div>
                    )}
                </div>
              </div>
            )}

          {/* Notes if available */}
          {interview.notes && interview.notes.trim() !== "" && (
            <div className="mt-3 text-sm text-gray-600 bg-gray-50 p-2 rounded">
              <span className="font-medium">
                <Trans>Notes</Trans>:{" "}
              </span>
              {interview.notes}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default InterviewCard;
