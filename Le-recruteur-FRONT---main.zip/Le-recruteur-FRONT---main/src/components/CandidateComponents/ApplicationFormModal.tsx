// import React, { useState } from 'react';

// interface ApplicationFormModalProps {
//   isOpen: boolean;
//   onClose: () => void;
//   jobTitle: string;
//   company: string;
//   location: string;
//   jobType: string;
//   onSubmit: (formData: any) => void;
// }

// const ApplicationFormModal: React.FC<ApplicationFormModalProps> = ({
//   isOpen,
//   onClose,
//   jobTitle,
//   company,
//   location,
//   jobType,
//   onSubmit
// }) => {
//   const [formData, setFormData] = useState({
//     firstName: '',
//     lastName: '',
//     email: '',
//     phone: '',
//     countryCode: 'US',
//     portfolio: '',
//     github: '',
//     resume: null,
//     coverLetter: '',
//     experience: '',
//     expectedSalary: '',
//     agreeToTerms: false
//   });

//   const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
//     const { name, value, type } = e.target;
//     setFormData(prev => ({
//       ...prev,
//       [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
//     }));
//   };

//   const handleSubmit = (e: React.FormEvent) => {
//     e.preventDefault();
//     onSubmit(formData);
//     onClose();
//   };

//   const handleSaveAsDraft = () => {
//     console.log('Saved as draft:', formData);
//     onClose();
//   };

//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-[-2.5rem] bg-black bg-opacity-50 flex items-center justify-center z-50">
//       <div className="bg-white rounded-lg max-w-[70%] w-full max-h-[90vh] overflow-y-auto">
//         <div className="flex">
//           {/* Left Panel - Job Info */}
//           <div className="w-[40%] bg-gray-50 p-6 border-r">
//             <button
//               onClick={onClose}
//               className="flex items-center text-gray-600 hover:text-gray-800 mb-4"
//             >
//               <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
//               </svg>
//               {jobTitle}
//             </button>

//             <div className="mb-4">
//               <div className="flex items-center text-sm text-gray-600 mb-2">
//                 <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
//                 </svg>
//                 {location} • {jobType} • Hybrid
//               </div>
//             </div>

//             <div className="space-y-4 text-sm">
//               <div>
//                 <h4 className="font-semibold text-gray-700 mb-2">Company Info</h4>
//                 <p className="text-gray-600 pl-6 text-[12px]">{company} - {location} - Hybrid (2 days remote)</p>
//               </div>

//               <div>
//                 <h4 className="font-semibold text-gray-700 mb-2">About the Job</h4>
//                 <p className="text-gray-600 pl-6 text-[12px]">
//                   We're looking for a creative and detail-oriented frontend developer to join our 
//                   growing product team. You'll be responsible for turning beautiful UI/UX designs into 
//                   functional web experiences, optimizing performance, and ensuring cross-browser 
//                   consistency. Collaboration with backend and design teams is essential.
//                 </p>
//               </div>

//               <div>
//                 <h4 className="font-semibold text-gray-700 mb-2">Requirements</h4>
//                 <ul className="text-gray-600 space-y-1 pl-6 text-[12px]">
//                   <li>• 2+ years of experience in frontend development</li>
//                   <li>• Proficiency in HTML, CSS, JavaScript (ES6+)</li>
//                   <li>• Strong knowledge of React</li>
//                   <li>• Experience with version control tools (e.g., Git)</li>
//                   <li>• Familiarity with responsive design and accessibility</li>
//                   <li>• Bonus: Tailwind CSS, Next.js, Figma</li>
//                 </ul>
//               </div>

//               <div>
//                 <h4 className="font-semibold text-gray-700 mb-2">What We Offer</h4>
//                 <ul className="text-gray-600 space-y-1 pl-6 text-[12px]">
//                   <li>• Competitive salary and performance bonus</li>
//                   <li>• Flexible working hours and hybrid work option</li>
//                   <li>• Supportive team culture</li>
//                   <li>• Learning and growth opportunities</li>
//                   <li>• Projects with real-world impact</li>
//                 </ul>
//               </div>

//               <div>
//                 <h4 className="font-semibold text-gray-700 mb-2">Deadline</h4>
//                 <p className="text-gray-600 pl-6 text-[12px]">Applications close on August 30th</p>
//               </div>
//             </div>

//             <button
//               onClick={onClose}
//               className="mt-[8rem] w-1/3 py-2 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-300 hover:border-gray-400 hover:text-gray-900 transition-all duration-200"
//             >
//               Cancel
//             </button>
//           </div>

//           {/* Right Panel - Application Form */}
//           <div className="flex-1 p-6">
//             <h2 className="text-xl font-semibold mb-6">Apply for this Job</h2>
            
//             <form onSubmit={handleSubmit} className="space-y-6">
//               {/* Personal Information */}
//               <div>
//                 <h3 className="font-medium mb-4">Personal Information</h3>
//                 <div className="grid grid-cols-2 gap-4">
//                   <div>
//                     <label className="block text-sm font-medium text-gray-700 mb-1">
//                       First Name*
//                     </label>
//                     <input
//                       type="text"
//                       name="firstName"
//                       value={formData.firstName}
//                       onChange={handleInputChange}
//                       placeholder="Enter your first name"
//                       className="w-[90%] px-3 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
//                       required
//                     />
//                   </div>
//                   <div>
//                     <label className="block text-sm font-medium text-gray-700 mb-1">
//                       Last Name*
//                     </label>
//                     <input
//                       type="text"
//                       name="lastName"
//                       value={formData.lastName}
//                       onChange={handleInputChange}
//                       placeholder="Enter your last name"
//                       className="w-[90%] px-3 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
//                       required
//                     />
//                   </div>
//                 </div>
//               </div>

//               {/* Contact Information */}
//               <div className="grid grid-cols-2 gap-4">
//                 <div>
//                   <label className="block text-sm font-medium text-gray-700 mb-1">
//                     Email Address*
//                   </label>
//                   <input
//                     type="email"
//                     name="email"
//                     value={formData.email}
//                     onChange={handleInputChange}
//                     placeholder="Enter your email"
//                     className="w-[90%] px-3 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
//                     required
//                   />
//                 </div>
//                 <div>
//                   <label className="block text-sm font-medium text-gray-700 mb-1">
//                     Phone Number*
//                   </label>
//                     <input
//                       type="tel"
//                       name="phone"
//                       value={formData.phone}
//                       onChange={handleInputChange}
//                       placeholder="Enter your phone number"
//                       className="w-[90%] px-3 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
//                       required
//                     />
//                 </div>
//               </div>

//               {/* Portfolio and Github */}
//               <div className="grid grid-cols-2 gap-4">
//                 <div>
//                   <label className="block text-sm font-medium text-gray-700 mb-1">
//                     Portfolio
//                   </label>
//                   <input
//                     type="url"
//                     name="portfolio"
//                     value={formData.portfolio}
//                     onChange={handleInputChange}
//                     placeholder="https:// Link goes here"
//                     className="w-[90%] px-3 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
//                   />
//                 </div>
//                 <div>
//                   <label className="block text-sm font-medium text-gray-700 mb-1">
//                     Github
//                   </label>
//                   <input
//                     type="url"
//                     name="github"
//                     value={formData.github}
//                     onChange={handleInputChange}
//                     placeholder="https:// Link goes here"
//                     className="w-[90%] px-3 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
//                   />
//                 </div>
//               </div>

//               {/* Application Documents */}
//               <div>
//                 <h3 className="font-medium mb-4">Application Documents</h3>
//                 <div className="grid grid-cols-2 gap-4">
//                   <div>
//                     <label className="block text-sm font-medium text-gray-700 mb-1">
//                       Resume
//                     </label>
//                     <div className="border-2 border-dashed border-gray-300 rounded-md p-5 text-center">
//                       <input
//                         type="file"
//                         name="resume"
//                         onChange={handleInputChange}
//                         accept=".pdf,.doc,.docx"
//                         className="hidden"
//                         id="resume-upload"
//                       />
//                       <label htmlFor="resume-upload" className="cursor-pointer">
//                         <div className="text-gray-500">
//                           <p>Drop here to attach or <p className='text-teal-500'>upload</p></p>
//                           <p className="text-sm">Max size 5MB</p>
//                         </div>
//                       </label>
//                     </div>
//                   </div>
//                   <div>
//                     <label className="block text-sm font-medium text-gray-700 mb-1">
//                       Cover Letter
//                     </label>
//                     <textarea
//                       name="coverLetter"
//                       value={formData.coverLetter}
//                       onChange={handleInputChange}
//                       placeholder="Tell us why you're a great fit for this role"
//                       rows={4}
//                       className="w-[90%] text-sm px-3 py-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
//                     />
//                   </div>
//                 </div>
//               </div>

//               {/* Additional Questions */}
//               <div>
//                 <h3 className="font-medium mb-4">Additional Questions</h3>
//                 <div className="space-y-4">
//                   <div>
//                     <label className="block text-sm font-medium text-gray-700 mb-1">
//                       How many years of experience do you have with React?*
//                     </label>
//                     <input
//                       type="text"
//                       name="experience"
//                       value={formData.experience}
//                       onChange={handleInputChange}
//                       placeholder="e.g. 2"
//                       className="w-[90%] px-3 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
//                       required
//                     />
//                   </div>
//                   <div>
//                     <label className="block text-sm font-medium text-gray-700 mb-1">
//                       What is your expected salary range?*
//                     </label>
//                     <input
//                       type="text"
//                       name="expectedSalary"
//                       value={formData.expectedSalary}
//                       onChange={handleInputChange}
//                       placeholder="e.g. MAD 10,000"
//                       className="w-[90%] px-3 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
//                       required
//                     />
//                   </div>
//                 </div>
//               </div>

//               {/* Terms Agreement */}
//               <div className="flex items-start">
//                 <input
//                   type="checkbox"
//                   name="agreeToTerms"
//                   checked={formData.agreeToTerms}
//                   onChange={handleInputChange}
//                   className="mt-1 mr-2"
//                   required
//                 />
//                 <label className="text-sm text-gray-600">
//                   I accept the{' '}
//                   <a href="#" className="text-teal-600 hover:underline">privacy policy</a>{' '}
//                   and{' '}
//                   <a href="#" className="text-teal-600 hover:underline">terms of use</a>
//                 </label>
//               </div>

//               {/* Action Buttons */}
//               <div className="flex gap-4 pt-[42px] justify-center">
//                 <button
//                   type="button"
//                   onClick={handleSaveAsDraft}
//                   className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-teal-100 hover:border-gray-400 hover:text-gray-900 transition-all duration-200"
//                 >
//                   Save as a Draft
//                 </button>
//                 <button
//                   type="submit"
//                   disabled={!formData.agreeToTerms}
//                   className="px-6 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
//                 >
//                   Submit Application
//                 </button>
//               </div>
//             </form>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ApplicationFormModal;

// *******************************************
// *******************************************
// ********* NOT USED/ NOT NEEDED *************
// *******************************************
// *******************************************