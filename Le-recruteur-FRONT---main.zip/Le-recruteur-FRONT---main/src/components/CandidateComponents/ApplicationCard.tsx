import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ApplicationFormModal from '../Modals/applyJobForm';
import { settings } from '@/lib/settings/main';
import { Trans } from '@lingui/macro';

interface ApplicationCardProps {
  id: number;
  title: string;
  company: string;
  location: string;
  type: 'Full Time' | 'Part Time' | 'Internship';
  salary: {
    min: number;
    max: number;
    currency?: string;
    negotiable?: boolean;
  };
  postedTime: string;
  skills: string[];
  logo?: string;
  status: 'not-applied' | 'applied';
  
  // Save status
  saveStatus?: 'saved' | 'not-saved';
  
  // Expandable features
  isExpandable?: boolean;
  description?: string;
  isExpanded?: boolean;
  onCardClick?: (id: number) => void;
  onApply?: (id: number) => void;
  
  // Save functionality
  isSaved?: boolean;
  onSave?: (id: number) => void;
  bookmarkable?: boolean;
  onViewMore?: (id: number) => void;
  
  // Additional details for expanded view
  jobDetails?: {
    publicationPeriod?: string;
    description?: string;
    activitySector?: string;
    function?: string;
    requiredExperience?: string;
    educationLevel?: string;
    contractType?: string;
    workMode?: string;
    remote?: boolean;
  };
  questions?: string[];
  questionIds?: number[];
  onApplied?: (jobId: number) => void;
}

const ApplicationCard: React.FC<ApplicationCardProps> = ({
  id,
  title,
  company,
  location,
  type,
  salary,
  postedTime,
  skills = [],
  logo,
  status,
  saveStatus = 'not-saved',
  isExpandable = false,
  isExpanded = false,
  onCardClick,
  onApply,
  jobDetails,
  onSave,
  onViewMore,
  bookmarkable = true,
  questions,
  questionIds,
  onApplied
}) => {
  const [showApplicationModal, setShowApplicationModal] = useState(false);
  const [currentSaveStatus, setCurrentSaveStatus] = useState(saveStatus);
  const navigate = useNavigate();

  const formatSalary = () => {
    if (salary.negotiable) {
      return <Trans>Negotiable</Trans>;
    }
    const currency = salary.currency || '$';
    if (salary.min === 0 && salary.max === 0) {
      return <Trans>Negotiable</Trans>;
    }
    return `${currency}${salary.min.toLocaleString()} - ${currency}${salary.max.toLocaleString()}`;
  };

  const getStatusButton = () => {
    if (status === 'applied') {
      return (
        <button 
          disabled
          className="bg-gray-100 text-gray-600 px-6 py-2 rounded-lg text-sm font-medium cursor-not-allowed"
        >
          <Trans>Applied</Trans>
        </button>
      );
    } else {
      return (
        <button 
          onClick={(e) => {
            e.stopPropagation();
            setShowApplicationModal(true);
          }}
          className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-2 rounded-lg text-sm font-medium transition-colors"
        >
          <Trans>Apply Now</Trans>
        </button>
      );
    }
  };

  const handleApplicationSubmit = () => {
    onApply?.(id);
  };

  const handleSaveClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const newSaveStatus = currentSaveStatus === 'saved' ? 'not-saved' : 'saved';
    setCurrentSaveStatus(newSaveStatus);
    onSave?.(id);
  };

  const cardContent = (
    <div className={`bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4 shadow-[2px_2px_8px_rgba(0,0,0,0.1)] hover:shadow-[4px_4px_16px_rgba(0,0,0,0.15)] transition-all duration-300 ${isExpanded ? 'shadow-[4px_4px_16px_rgba(0,0,0,0.2)]' : ''}`}>
      <div className="flex items-start justify-between">
        {/* Left side - Company logo and job info */}
        <div className="flex items-start gap-4 flex-1">
          {/* Company Logo */}
          <div className="w-14 h-14 bg-white rounded-lg flex items-center justify-center flex-shrink-0 border border-gray-200">
            <img 
              src={`${settings.IMG_ADDRESS}${logo}` || ""}
              alt={company} 
              className="w-10 h-10 object-contain"
            />
          </div>
          
          {/* Job Details */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-2">
              <h3 className="text-lg font-semibold text-teal-600 hover:text-teal-700 cursor-pointer">
                {title || <Trans>Offer Title</Trans>}
              </h3>
              <span className="inline-block px-3 py-1 text-xs font-medium text-white bg-teal-600 rounded-md">
                {type || <Trans>Offer Type</Trans>}
              </span>
            </div>
            
            <p className="text-sm text-gray-600 mb-3">{company || <Trans>Company Name</Trans>}</p>
            
            <div className="flex items-center gap-6 text-sm text-gray-500 mb-3">
              <span className="flex items-center gap-1">
                <svg className="w-4 h-4 text-teal-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                {location || <Trans>Location</Trans>}
              </span>
              <span className="flex items-center gap-1">
                <svg className="w-4 h-4 text-teal-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <Trans>Posted</Trans> {postedTime || <Trans>Posted Time</Trans>}
              </span>
            </div>
            
            {/* Skills Tags, in fact if displays requirements */}
            {/* <div className="flex flex-wrap gap-2">
              {(skills || []).slice(0, 4).map((skill, index) => (
                <span key={index} className="inline-block px-3 py-1 text-xs bg-teal-100 text-teal-700 rounded-md font-medium">
                  {skill}
                </span>
              ))}
            </div> */}
          </div>
        </div>
        
        {/* Right side - Salary and Apply button */}
        <div className="text-right flex flex-col items-end justify-between ml-4">
          {bookmarkable ? (
            <button 
              onClick={handleSaveClick}
              className="p-1 hover:bg-gray-100 rounded-full"
            >
              <svg 
                className={`w-5 h-5 transition-colors ${
                  currentSaveStatus === 'saved' 
                    ? 'text-teal-600' 
                    : 'text-gray-400 hover:text-teal-500'
                }`} 
                fill={currentSaveStatus === 'saved' ? "currentColor" : "none"} 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
              </svg>
            </button>
          ) : (
            <div className="h-11"></div>
          )}
          <p className="text-lg font-semibold text-teal-600 mb-4">{formatSalary()}</p>
          {getStatusButton()}
        </div>
      </div>
      
      {/* Expandable detailed job information */}
      {isExpandable && isExpanded && (
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
            <h4 className="text-lg font-semibold text-teal-600">
              <Trans>Details Jobs</Trans> :
            </h4>
          </div>
          
          <div className="space-y-3 text-sm">
            {jobDetails?.publicationPeriod && (
              <div>
                <span className="font-medium text-gray-700">
                  <Trans>Publication</Trans> : 
                </span>
                <span className="text-gray-600">{jobDetails.publicationPeriod}</span>
              </div>
            )}
            
            {jobDetails?.description && (
              <div>
                <span className="font-medium text-gray-700">
                  <Trans>Description</Trans> : 
                </span>
                <span className="text-gray-600">{jobDetails.description}</span>
              </div>
            )}
            
            {jobDetails?.activitySector && (
              <div>
                <span className="font-medium text-gray-700">
                  <Trans>Activity Sector</Trans> : 
                </span>
                <span className="text-gray-600">{jobDetails.activitySector}</span>
              </div>
            )}
            
            {jobDetails?.function && (
              <div>
                <span className="font-medium text-gray-700">
                  <Trans>Function</Trans> : 
                </span>
                <span className="text-gray-600">{jobDetails.function}</span>
              </div>
            )}
            
            {jobDetails?.requiredExperience && (
              <div>
                <span className="font-medium text-gray-700">
                  <Trans>Required Experience</Trans> : 
                </span>
                <span className="text-gray-600">{jobDetails.requiredExperience}</span>
              </div>
            )}
            
            {jobDetails?.educationLevel && (
              <div>
                <span className="font-medium text-gray-700">
                  <Trans>Education Level Required</Trans> : 
                </span>
                <span className="text-gray-600">{jobDetails.educationLevel}</span>
              </div>
            )}
            
            {jobDetails?.contractType && (
              <div>
                <span className="font-medium text-gray-700">
                  <Trans>Contract Type Proposed</Trans> : 
                </span>
                <span className="text-gray-600">{jobDetails.contractType}</span>
              </div>
            )}

            {jobDetails?.workMode && (
              <div>
                <span className="font-medium text-gray-700">
                  <Trans>Work Mode</Trans> : 
                </span>
                <span className="text-gray-600">{jobDetails.workMode}</span>
              </div>
            )}
          </div>
          
          {/* View More Button */}
          <div className="flex justify-end mt-6">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/candidate/applications/${id}`);
              }}
              className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-2 rounded-lg text-sm font-medium transition-colors"
            >
              <Trans>View More</Trans>
            </button>
          </div>
        </div>
      )}
    </div>
  );

  if (isExpandable) {
    return (
      <>
        <div onClick={() => onCardClick?.(id)} className="cursor-pointer">
          {cardContent}
        </div>
        
        {/* Application Form Modal */}
        <div>
        <ApplicationFormModal
          isOpen={showApplicationModal}
          onClose={() => setShowApplicationModal(false)}
          jobId={id}
          jobTitle={title}
          questions={questions}
          questionIds={questionIds}
          onApplied={onApplied}
        />
        </div>
      </>
    );
  }

  return (
    <>
      {cardContent}
      
      {/* Application Form Modal */}
      <ApplicationFormModal
        isOpen={showApplicationModal}
        onClose={() => setShowApplicationModal(false)}
        jobId={id}
        jobTitle={title}
        questions={questions}
        questionIds={questionIds}
        onApplied={onApplied}
      />
    </>
  );
};

export default ApplicationCard;