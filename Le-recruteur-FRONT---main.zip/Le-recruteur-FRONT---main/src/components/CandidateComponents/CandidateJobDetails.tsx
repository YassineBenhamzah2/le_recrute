import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  MapPin,
  Building2,
  Share,
  Bookmark,
  MessageCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import ApplyJobForm from "@/components/Modals/applyJobForm";
import { jobOffersService } from "@/lib/network/pages/jobOffers";
import type { JobOffer } from "@/lib/types/jobOffer";
import { toast } from "sonner";
import { settings } from "@/lib/settings/main";
import { useAuth } from "@/contexts/AuthContext";
import { Trans } from "@lingui/macro";

const CandidateJobDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [jobData, setJobData] = useState<JobOffer | null>(null);
  const [loading, setLoading] = useState(true);
  const [isApplyFormOpen, setIsApplyFormOpen] = useState(false);
  const [currentSaveStatus, setCurrentSaveStatus] = useState<
    "saved" | "not-saved"
  >("not-saved");
  const [hasApplied, setHasApplied] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const fetchJobDetails = async () => {
      if (!id) return;

      try {
        setLoading(true);
        const response = await jobOffersService.getById(parseInt(id));
        if (response.data) {
          setJobData(response.data);
          setCurrentSaveStatus(
            user?.id && response.data.bookmarkedBy?.includes(user.id)
              ? "saved"
              : "not-saved"
          );
          setHasApplied(
            !!(user?.id && response.data.appliedBy?.includes(user.id))
          );
        }
      } finally {
        setLoading(false);
      }
    };

    fetchJobDetails();
  }, [id]);

  const handleBack = () => {
    navigate("/candidate/applications");
  };

  const handleSave = async (jobId: number) => {
    try {
      const response = await jobOffersService.bookmarkJob(jobId);
      if (response.success) {
        const newSaveStatus =
          currentSaveStatus === "saved" ? "not-saved" : "saved";
        setCurrentSaveStatus(newSaveStatus);
        // Update the job data with new bookmark status
        if (jobData) {
          setJobData({
            ...jobData,
            isBookmarked: newSaveStatus === "saved",
          });
        }
      }
    } catch (error) {
      console.error("Error toggling bookmark:", error);
    }
  };

  const handleApply = () => {
    if (!jobData) return;

    toast.success(<Trans>Application submitted</Trans>);
    setHasApplied(true);
  };

  const formatSalary = () => {
    if (!jobData) return "";
    if (jobData.negotiable) return <Trans>Negotiable</Trans>;
    if (jobData.minSalary === 0 && jobData.maxSalary === 0) return <Trans>Negotiable</Trans>;
    const currency = jobData.currency || "MAD";
    return `${currency} ${jobData.minSalary.toLocaleString()} - ${currency} ${jobData.maxSalary.toLocaleString()}`;
  };

  const formatDate = (dateString: string): string => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString("fr-FR");
  };

  const mapJobType = (
    jobType: string
  ): string => {
    switch (jobType) {
      case "FULL_TIME":
        return <Trans>Full Time</Trans>;
      case "PART_TIME":
        return <Trans>Part Time</Trans>;
      case "INTERNSHIP":
        return <Trans>Internship</Trans>;
      case "FREELANCE":
        return <Trans>Part Time</Trans>;
      default:
        return <Trans>Full Time</Trans>;
    }
  };

  const handleReport = () => {
    console.log("Report clicked");
  };

  const handleShareJob = async () => {
    if (!jobData) return;

    const jobUrl = `${window.location.origin}/jobs/${jobData.id}`;

    try {
      await navigator.clipboard.writeText(jobUrl);
      setCopied(true);
      toast.success(<Trans>Link copied to clipboard</Trans>);

      // Reset copied state after 2 seconds
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy:", err);
      toast.error(<Trans>Failed to copy link</Trans>);
    }
  };

  const handleBookmark = () => {
    if (!jobData) return;
    handleSave(jobData.id);
  };

  // Requirements handling with proper types
  const requirements =
    jobData?.requirements?.map((req: string, i: number) => (
      <li key={i} className="flex items-start">
        <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 mr-3 flex-shrink-0"></span>
        {req}
      </li>
    )) || [];

  // Responsibilities with null check
  const responsibilities =
    jobData?.responsibilities?.map((resp: string, i: number) => (
      <li key={i} className="flex items-start">
        <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 mr-3 flex-shrink-0"></span>
        {resp}
      </li>
    )) || [];

  // Company details with fallbacks
  const companyDetails = [
    { label: <Trans>Company</Trans>, value: jobData?.company?.name || <Trans>Not specified</Trans> },
    { label: <Trans>Sector</Trans>, value: jobData?.company?.sector || <Trans>Not specified</Trans> },
    { label: <Trans>Address</Trans>, value: jobData?.company?.address || <Trans>Not specified</Trans> },
    { label: <Trans>Phone</Trans>, value: jobData?.company?.phone || <Trans>Not specified</Trans> },
    { label: <Trans>Job Location</Trans>, value: jobData?.location || <Trans>Not specified</Trans> },
  ];

  const skills = jobData?.skills?.map((skill: string, index: number) => (
    <span
      key={index}
      className="inline-block px-3 py-1 text-sm bg-teal-100 text-teal-700 rounded-md font-medium"
    >
      {skill}
    </span>
  ));

  if (loading) {
    return (
      <div className="p-6 space-y-6 max-w-[93%] ml-[7%]">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600 mx-auto"></div>
            <p className="mt-4 text-gray-600"><Trans>Loading job details...</Trans></p>
          </div>
        </div>
      </div>
    );
  }

  if (!jobData) {
    return (
      <div className="p-6 space-y-6 max-w-[93%] ml-[7%]">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">
              <Trans>Job Not Found</Trans>
            </h2>
            <p className="text-gray-600 mb-6">
              <Trans>The job you're looking for doesn't exist or has been removed.</Trans>
            </p>
            <button
              onClick={handleBack}
              className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
            >
              <Trans>Back to Jobs</Trans>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-[93%] ml-[7%]">
      {/* Back Button */}
      <div className="mb-6">
        <button
          onClick={handleBack}
          className="flex items-center text-teal-600 hover:text-teal-700 font-medium"
        >
          <svg
            className="w-5 h-5 mr-2"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M10 19l-7-7m0 0l7-7m-7 7h18"
            />
          </svg>
          <Trans>Back to Jobs</Trans>
        </button>
      </div>

      {/* Company Profile Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="bg-teal-600 py-4 rounded-t-lg">
          <h2 className="text-xl font-bold text-white font-poppins ml-6">
            <Trans>Company Profile</Trans>
          </h2>
        </div>

        {/* Job Information Grid */}
        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column - Job Information */}
            <div className="lg:pr-8">
              {/* Job Title */}
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-teal-600 font-poppins leading-tight">
                  {jobData.title}
                </h3>
              </div>

              {/* Company Details */}
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3">
                  <Building2 className="w-4 h-4 text-teal-500 flex-shrink-0" />
                  <div className="text-sm">
                    <span className="font-semibold text-gray-700 font-poppins">
                      <Trans>Company:</Trans>{" "}
                    </span>
                    <span className="text-gray-600 font-poppins">
                      {companyDetails[0].value}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <MapPin className="w-4 h-4 text-teal-500 flex-shrink-0" />
                  <div className="text-sm">
                    <span className="font-semibold text-gray-700 font-poppins">
                      <Trans>Location:</Trans>{" "}
                    </span>
                    <span className="text-gray-600 font-poppins">
                      {jobData.location}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-3">
                <Button
                  onClick={handleReport}
                  className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-md font-poppins font-medium flex items-center gap-2 text-sm"
                >
                  <MessageCircle className="w-4 h-4" />
                  <Trans>Report</Trans>
                </Button>

                <Button
                  onClick={handleShareJob}
                  variant="outline"
                  className="border-2 border-teal-600 text-teal-600 hover:bg-teal-600 hover:text-white px-4 py-2 rounded-md font-poppins font-medium flex items-center gap-2 text-sm"
                >
                  <Share className="w-4 h-4" />
                  <Trans>Share Offer</Trans>
                </Button>

                <Button
                  onClick={handleBookmark}
                  variant="outline"
                  className={`border-2 px-3 py-2 rounded-md font-poppins font-medium transition-colors ${
                    currentSaveStatus === "saved"
                      ? "border-teal-600 bg-teal-50 text-teal-600"
                      : "border-teal-600 text-teal-600 hover:bg-teal-600 hover:text-white"
                  }`}
                >
                  <Bookmark
                    className={`w-4 h-4 ${
                      currentSaveStatus === "saved" ? "fill-current" : ""
                    }`}
                  />
                </Button>
              </div>
            </div>

            {/* Right Column - Company Logo */}
            <div className="flex justify-center lg:justify-end items-start">
              <div className="bg-gray-100 rounded-lg shadow-lg border border-gray-200 w-64 h-48 flex items-center justify-center">
                <img
                  src={
                    `${settings.IMG_ADDRESS}${jobData.company?.logo}` ||
                    "/ehc logo.png"
                  }
                  alt="Company Logo"
                  className="w-32 h-32 object-contain"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Job Details Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="bg-teal-600 py-4 rounded-t-lg">
          <h2 className="text-xl font-bold text-white font-poppins ml-6">
            <Trans>Job Details</Trans>
          </h2>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Job Description */}
            <div className="lg:col-span-2 space-y-6">
              {/* Description */}
              <div>
                <h3 className="text-base font-semibold text-teal-600 font-poppins mb-3 flex items-center">
                  <span className="w-2 h-2 bg-teal-500 rounded-full mr-2"></span>
                  <Trans>Description:</Trans>
                </h3>
                <p className="text-gray-700 font-poppins text-sm leading-relaxed">
                  {jobData.description}
                </p>
              </div>

              {/* Key Responsibilities */}
              {jobData.responsibilities &&
                jobData.responsibilities.length > 0 && (
                  <div>
                    <h3 className="text-base font-semibold text-teal-600 font-poppins mb-3 flex items-center">
                      <span className="w-2 h-2 bg-teal-500 rounded-full mr-2"></span>
                      <Trans>Responsibilities:</Trans>
                    </h3>
                    <ul className="space-y-2 text-gray-700 font-poppins text-sm">
                      {responsibilities}
                    </ul>
                  </div>
                )}

              {/* Requirements */}
              {jobData.requirements && jobData.requirements.length > 0 && (
                <div>
                  <h3 className="text-base font-semibold text-teal-600 font-poppins mb-3 flex items-center">
                    <span className="w-2 h-2 bg-teal-500 rounded-full mr-2"></span>
                    <Trans>Requirements:</Trans>
                  </h3>
                  <ul className="text-gray-700 font-poppins text-sm leading-relaxed space-y-2">
                    {requirements}
                  </ul>
                </div>
              )}

              {/* Skills */}
              {jobData.skills && jobData.skills.length > 0 && (
                <div>
                  <h3 className="text-base font-semibold text-teal-600 font-poppins mb-3 flex items-center">
                    <span className="w-2 h-2 bg-teal-500 rounded-full mr-2"></span>
                    <Trans>Required Skills:</Trans>
                  </h3>
                  <div className="flex flex-wrap gap-2">{skills}</div>
                </div>
              )}

              {/* Tags */}
              {jobData.tags && jobData.tags.length > 0 && (
                <div>
                  <h3 className="text-base font-semibold text-teal-600 font-poppins mb-3 flex items-center">
                    <span className="w-2 h-2 bg-teal-500 rounded-full mr-2"></span>
                    <Trans>Tags:</Trans>
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {jobData.tags.map((tag, index) => (
                      <span
                        key={index}
                        className="inline-block px-3 py-1 text-sm bg-green-100 text-green-700 rounded-md font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* About the Offer */}
              <div className="mt-8">
                <h3 className="text-base font-semibold text-teal-600 font-poppins mb-3 flex items-center">
                  <span className="w-2 h-2 bg-teal-500 rounded-full mr-2"></span>
                  <Trans>About the Offer:</Trans>
                </h3>
                <ul className="text-gray-700 font-poppins text-sm space-y-2">
                  {companyDetails.map((detail, index) => (
                    <li key={index} className="flex items-start">
                      <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                      {detail.label}: {detail.value}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Right Column - Job Info Cards */}
            <div className="space-y-4">
              {/* Salary & Location Card */}
              <div
                className="bg-white rounded-xl border border-[#CFE6E7] p-4"
                style={{ boxShadow: "0 0 0 2px #CFE6E7" }}
              >
                <div className="text-center">
                  <div className="text-sm font-semibold text-gray-800 font-poppins mb-1">
                    <Trans>Salary</Trans>
                  </div>
                  <div className="text-lg font-bold text-teal-600 font-poppins mb-1">
                    {formatSalary()}
                  </div>
                  <div className="text-sm text-gray-500 font-poppins">
                    <Trans>Monthly salary</Trans>
                  </div>
                  {jobData.negotiable && (
                    <div className="text-xs text-teal-600 font-poppins mt-1">
                      <Trans>Negotiable</Trans>
                    </div>
                  )}
                </div>
              </div>

              {/* Job Overview Card */}
              <div
                className="bg-white rounded-xl border border-[#CFE6E7] p-4"
                style={{ boxShadow: "0 0 0 2px #CFE6E7" }}
              >
                <h4 className="text-lg font-semibold text-gray-800 font-poppins mb-4">
                  <Trans>Job Overview</Trans>
                </h4>

                <div className="space-y-4">
                  <div>
                    <div className="text-xs text-gray-500 font-poppins uppercase mb-1">
                      <Trans>JOB POSTED:</Trans>
                    </div>
                    <div className="text-sm font-semibold text-gray-800 font-poppins">
                      {formatDate(jobData.publicationDate)}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs text-gray-500 font-poppins uppercase mb-1">
                      <Trans>JOB EXPIRES:</Trans>
                    </div>
                    <div className="text-sm font-semibold text-gray-800 font-poppins">
                      {formatDate(jobData.deadlineDate)}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs text-gray-500 font-poppins uppercase mb-1">
                      <Trans>JOB TYPE:</Trans>
                    </div>
                    <div className="text-sm font-semibold text-gray-800 font-poppins">
                      {mapJobType(jobData.jobType)}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs text-gray-500 font-poppins uppercase mb-1">
                      <Trans>CONTRACT TYPE:</Trans>
                    </div>
                    <div className="text-sm font-semibold text-gray-800 font-poppins">
                      {jobData.contractType}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs text-gray-500 font-poppins uppercase mb-1">
                      <Trans>DEPARTMENT:</Trans>
                    </div>
                    <div className="text-sm font-semibold text-gray-800 font-poppins">
                      {jobData.departmentName}
                    </div>
                  </div>
                </div>
              </div>

              {/* Share this job Card */}
              <div
                className="bg-white rounded-xl border border-[#CFE6E7] p-4 shadow-sm"
                style={{ boxShadow: "0 0 0 2px #CFE6E7" }}
              >
                <h4 className="text-base font-semibold text-gray-800 font-poppins mb-3">
                  <Trans>Share this offer:</Trans>
                </h4>
                <div className="flex items-center gap-3">
                  <button
                    onClick={handleShareJob}
                    disabled={copied}
                    className={`flex items-center gap-2 text-sm font-poppins border border-teal-600 rounded-lg px-3 py-2 ${
                      copied
                        ? "bg-teal-600 text-white"
                        : "text-teal-600 hover:underline"
                    }`}
                    aria-live="polite"
                  >
                    {copied ? (
                      <Trans>Copied ✔</Trans>
                    ) : (
                      <>
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          viewBox="0 0 24 24"
                        >
                          <path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71" />
                          <path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71" />
                        </svg>
                        <Trans>Share Link</Trans>
                      </>
                    )}
                  </button>
                  <div className="flex gap-2">
                    <a
                      href={`https://www.linkedin.com`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-8 h-8 bg-[#0077b5] rounded-lg flex items-center justify-center text-white hover:opacity-80"
                      aria-label={<Trans>Share on LinkedIn</Trans>}
                    >
                      <svg
                        className="w-4 h-4"
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                      </svg>
                    </a>
                    <a
                      href={`https://x.com`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-8 h-8 bg-black rounded-lg flex items-center justify-center text-white hover:opacity-80"
                      aria-label={<Trans>Share on X</Trans>}
                    >
                      <svg
                        className="w-4 h-4"
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                      </svg>
                    </a>
                    <a
                      href={`https://www.facebook.com`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-8 h-8 bg-[#4267B2] rounded-lg flex items-center justify-center text-white hover:opacity-80"
                      aria-label={<Trans>Share on Facebook</Trans>}
                    >
                      <svg
                        className="w-4 h-4"
                        fill="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z" />
                      </svg>
                    </a>
                  </div>
                </div>
              </div>

              {/* Apply Now Button */}
              {hasApplied ? (
                <button
                  disabled
                  className="px-6 w-full py-3 bg-gray-400 text-white font-medium rounded-lg font-poppins cursor-not-allowed"
                >
                  <Trans>Applied</Trans>
                </button>
              ) : (
                <button
                  onClick={() => setIsApplyFormOpen(true)}
                  className="px-6 w-full py-3 bg-teal-600 hover:bg-teal-700 text-white font-medium rounded-lg font-poppins transition-colors"
                >
                  <Trans>Apply Now</Trans>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Application Form Modal */}
      <ApplyJobForm
        isOpen={isApplyFormOpen}
        onClose={() => setIsApplyFormOpen(false)}
        jobId={jobData?.id || 0}
        jobTitle={jobData?.title || ""}
        onApplied={handleApply}
        questions={jobData.questions}
        questionIds={jobData.questionsIds}
      />
    </div>
  );
};

export default CandidateJobDetails;