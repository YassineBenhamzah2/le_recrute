import React, { memo } from 'react';
import { Flag, Send, CheckCircle, AlertCircle } from 'lucide-react';

import { TestQuestion, TestAnswer } from '@/lib/types/candidateTests';
import { Trans } from '@lingui/macro';

interface TestSidebarProps {
  questions: TestQuestion[];
  answers: TestAnswer[];
  currentQuestion: number;
  flaggedQuestions: Set<string>;
  stats: {
    answered: number;
    flagged: number;
    total: number;
    unanswered: number;
  };
  onQuestionSelect: (index: number) => void;
  onSubmit: () => void;
}

export const TestSidebar: React.FC<TestSidebarProps> = memo(({
  questions,
  answers,
  currentQuestion,
  flaggedQuestions,
  stats,
  onQuestionSelect,
  onSubmit
}) => {
  const getQuestionButtonStyle = (index: number) => {
    const answer = answers[index];
    const question = questions[index];
    const isAnswered = answer?.answer?.trim().length > 0;
    const isFlagged = answer?.isFlagged || flaggedQuestions.has(question?.id || '');
    const isCurrent = index === currentQuestion;
    
    if (isCurrent) {
      return 'border-2 border-teal-500 bg-teal-500 text-white shadow-md scale-110';
    }
    
    if (isAnswered && isFlagged) {
      return 'border-2 border-green-300 bg-green-100 text-green-800 relative';
    }
    
    if (isAnswered) {
      return 'border-2 border-green-300 bg-green-100 text-green-800';
    }
    
    if (isFlagged) {
      return 'border-2 border-orange-300 bg-orange-100 text-orange-800';
    }
    
    return 'border-2 border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:bg-gray-50';
  };

  const completionPercentage = (stats.answered / stats.total) * 100;

  return (
    <aside className="w-80 bg-white border-l border-gray-200 p-6 overflow-y-auto">
      <div className="space-y-6">
        {/* Test Progress Header */}
        <div>
          <h3 className="font-semibold text-gray-900 mb-4 text-lg">
            <Trans>Test Progress</Trans>
          </h3>
          
          {/* Progress Bar */}
          <div className="mb-4">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>
                <Trans>Completion</Trans>
              </span>
              <span>{Math.round(completionPercentage)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-teal-500 h-3 rounded-full transition-all duration-500 ease-out"
                style={{ width: `${completionPercentage}%` }}
              />
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gradient-to-r from-teal-50 to-teal-100 p-4 rounded-xl border border-teal-200">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-teal-700">{stats.answered}</div>
                <div className="text-sm text-teal-600 font-medium">
                  <Trans>Answered</Trans>
                </div>
              </div>
              <CheckCircle className="text-teal-500" size={24} />
            </div>
          </div>
          
          <div className="bg-gradient-to-r from-orange-50 to-orange-100 p-4 rounded-xl border border-orange-200">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-orange-700">{stats.flagged}</div>
                <div className="text-sm text-orange-600 font-medium">
                  <Trans>Flagged</Trans>
                </div>
              </div>
              <Flag className="text-orange-500" size={24} />
            </div>
          </div>
        </div>

        {/* Unanswered Questions Alert */}
        {stats.unanswered > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <AlertCircle className="text-amber-500" size={16} />
              <span className="text-sm font-medium text-amber-800">
                <Trans>{stats.unanswered} questions remaining</Trans>
              </span>
            </div>
            <p className="text-xs text-amber-700">
              <Trans>Remember to answer all questions before submitting.</Trans>
            </p>
          </div>
        )}

        {/* Question Navigation Grid */}
        <div>
          <h4 className="font-medium text-gray-900 mb-3">
            <Trans>Question Navigation</Trans>
          </h4>
          <div className="grid grid-cols-5 gap-2">
            {questions.map((_, index) => {
              const answer = answers[index];
              const question = questions[index];
              const isAnswered = answer?.answer?.trim().length > 0;
              const isFlagged = answer?.isFlagged || flaggedQuestions.has(question?.id || '');
              
              return (
                <div key={index} className="relative">
                  <button
                    onClick={() => onQuestionSelect(index)}
                    className={`w-12 h-12 text-sm font-semibold rounded-lg transition-all duration-200 transform hover:scale-105 ${getQuestionButtonStyle(index)}`}
                    title={`Question ${index + 1}${isAnswered ? ' (Answered)' : ''}${isFlagged ? ' (Flagged)' : ''}`}
                  >
                    {index + 1}
                  </button>
                  {isFlagged && (
                    <Flag 
                      size={12} 
                      className="absolute -top-1 -right-1 text-orange-500 fill-current" 
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <div className="text-xs space-y-2">
          <h4 className="font-medium text-gray-900">
            <Trans>Legend:</Trans>
          </h4>
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-teal-500 rounded border-2 border-teal-500"></div>
              <span className="text-gray-600">
                <Trans>Current Question</Trans>
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-green-100 rounded border-2 border-green-300"></div>
              <span className="text-gray-600">
                <Trans>Answered</Trans>
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-orange-100 rounded border-2 border-orange-300"></div>
              <span className="text-gray-600">
                <Trans>Flagged</Trans>
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-white rounded border-2 border-gray-200"></div>
              <span className="text-gray-600">
                <Trans>Unanswered</Trans>
              </span>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-4 border-t border-gray-200">
          <button
            onClick={onSubmit}
            className="w-full bg-gradient-to-r from-teal-500 to-teal-600 text-white px-6 py-4 rounded-xl hover:from-teal-600 hover:to-teal-700 transition-all duration-200 flex items-center justify-center space-x-3 shadow-lg hover:shadow-xl transform hover:scale-105 font-medium"
          >
            <Send size={20} />
            <span>
              <Trans>Submit Test</Trans>
            </span>
          </button>
          
          <p className="text-xs text-gray-500 mt-3 text-center">
            <Trans>
              <strong>{stats.answered}</strong> of <strong>{stats.total}</strong> questions answered
            </Trans>
            {stats.flagged > 0 && (
              <span className="block mt-1">
                <Trans>
                  <strong>{stats.flagged}</strong> questions flagged for review
                </Trans>
              </span>
            )}
          </p>
        </div>
      </div>
    </aside>
  );
});

TestSidebar.displayName = 'TestSidebar';