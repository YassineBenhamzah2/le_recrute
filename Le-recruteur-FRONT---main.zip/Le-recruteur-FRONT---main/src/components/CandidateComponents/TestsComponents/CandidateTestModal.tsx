import React, { useState, useEffect, useCallback, useMemo } from "react";
import { AlertTriangle } from "lucide-react";
import {
  CandidateTest,
  TestAttempt,
  AttemptStatus,
} from "@/lib/types/candidateTests";
import { useTestTimer } from "@/hooks/useTestTimer";
import { useTestState } from "@/hooks/useTestState";
import { candidateTestService } from "@/lib/network/candidateTest";
import { TestHeader } from "./TestHeader";
import { TestContent } from "./TestContent";
import { TestSidebar } from "./TestSidbar";
import { ConfirmationModal } from "./ConfirmationModal";

interface CandidateTestModalProps {
  test: CandidateTest;
  onComplete: (attempt: TestAttempt) => void;
  onClose: () => void;
}

const CandidateTestModal: React.FC<CandidateTestModalProps> = ({
  test,
  onComplete,
  onClose,
}) => {
  // State management
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [attemptId] = useState(
    () => `attempt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  );

  // Custom hooks for complex logic
  const {
    questions,
    answers,
    flaggedQuestions,
    currentQuestion,
    isLoading,
    setCurrentQuestion,
    handleAnswerChange,
    handleFlagToggle,
    getAnsweredCount,
    getFlaggedCount,
    sessionId,
  } = useTestState(test);

  const { timer, formatTime } = useTestTimer({
    duration: test.duration,
    onTimeUp: () => handleSubmitTest(),
  });

  // Memoized calculations
  const progressPercentage = useMemo(() => {
    return ((currentQuestion + 1) / questions.length) * 100;
  }, [currentQuestion, questions.length]);

  const testStats = useMemo(
    () => ({
      answered: getAnsweredCount(),
      flagged: getFlaggedCount(),
      total: questions.length,
      unanswered: questions.length - getAnsweredCount(),
    }),
    [getAnsweredCount, getFlaggedCount, questions.length]
  );

  // Submit test handler
  const handleSubmitTest = useCallback(async () => {
    const timeSpentInMinutes =
      test.duration - Math.floor(timer.remainingTime / 60);
    setShowSubmitConfirm(false);

    try {
      // Get the session ID
      const currentSessionId =
        sessionId || localStorage.getItem("current_test_session_id");

      if (!currentSessionId) {
        throw new Error("No active test session found");
      }

      // Submit answers to API
      const result = await candidateTestService.submitTest(currentSessionId);

      if (!result.success) {
        throw new Error("Failed to submit test");
      }

      // Create an attempt object to maintain compatibility with existing code
      const attempt: TestAttempt = {
        id: attemptId,
        testId: test.id,
        candidateId: "current-user", // Will be determined by the API
        startTime: new Date(
          Date.now() - (test.duration * 60 - timer.remainingTime) * 1000
        ).toISOString(),
        endTime: new Date().toISOString(),
        status: AttemptStatus.COMPLETED,
        answers: answers.map((answer) => ({
          ...answer,
          timeSpent: Math.floor(timeSpentInMinutes / questions.length), // Average time per question
        })),
        timeSpent: timeSpentInMinutes,
        flaggedQuestions: Array.from(flaggedQuestions),
        score: result.data.score,
        isPassed: result.data.passed,
        totalPoints: questions.reduce((sum, q) => sum + q.points, 0),
      };

      // Clean up test progress
      localStorage.removeItem(`test_progress_${test.id}`);
      localStorage.removeItem("current_test_session_id");

      // Complete the test
      onComplete(attempt);
    } catch (error) {
      console.error("Failed to submit test:", error);
      // Could show an error message to the user here

      // Still try to complete with local data in case of API failure
      const attempt: TestAttempt = {
        id: attemptId,
        testId: test.id,
        candidateId: "current-user",
        startTime: new Date(
          Date.now() - (test.duration * 60 - timer.remainingTime) * 1000
        ).toISOString(),
        endTime: new Date().toISOString(),
        status: AttemptStatus.COMPLETED,
        answers: answers.map((answer) => ({
          ...answer,
          timeSpent: Math.floor(timeSpentInMinutes / questions.length),
        })),
        timeSpent: timeSpentInMinutes,
        flaggedQuestions: Array.from(flaggedQuestions),
        totalPoints: questions.reduce((sum, q) => sum + q.points, 0),
      };

      onComplete(attempt);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    attemptId,
    test.id,
    test.duration,
    timer.remainingTime,
    answers,
    flaggedQuestions,
    questions,
    onComplete,
  ]);

  // Navigation handlers
  const handleQuestionNavigation = useCallback(
    (index: number) => {
      if (index >= 0 && index < questions.length) {
        setCurrentQuestion(index);
      }
    },
    [questions.length, setCurrentQuestion]
  );

  const handleNextQuestion = useCallback(() => {
    handleQuestionNavigation(currentQuestion + 1);
  }, [currentQuestion, handleQuestionNavigation]);

  const handlePreviousQuestion = useCallback(() => {
    handleQuestionNavigation(currentQuestion - 1);
  }, [currentQuestion, handleQuestionNavigation]);

  // Modal handlers
  const handleShowSubmitConfirm = useCallback(() => {
    setShowSubmitConfirm(true);
  }, []);

  const handleCloseSubmitConfirm = useCallback(() => {
    setShowSubmitConfirm(false);
  }, []);

  const handleShowExitConfirm = useCallback(() => {
    setShowExitConfirm(true);
  }, []);

  const handleCloseExitConfirm = useCallback(() => {
    setShowExitConfirm(false);
  }, []);

  const handleForceExit = useCallback(() => {
    setShowExitConfirm(false);
    onClose();
  }, [onClose]);

  // Auto-save functionality
  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      // Save current progress to localStorage as backup
      const progressData = {
        attemptId,
        testId: test.id,
        answers,
        flaggedQuestions: Array.from(flaggedQuestions),
        currentQuestion,
        timestamp: Date.now(),
      };

      try {
        localStorage.setItem(
          `test_progress_${test.id}`,
          JSON.stringify(progressData)
        );
      } catch (error) {
        console.warn("Failed to auto-save test progress:", error);
      }
    }, 30000); // Auto-save every 30 seconds

    return () => clearInterval(autoSaveInterval);
  }, [attemptId, test.id, answers, flaggedQuestions, currentQuestion]);

  // Loading state
  if (isLoading || questions.length === 0) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-teal-500 border-t-transparent mx-auto"></div>
          <p className="mt-4 text-center text-gray-600 font-medium">
            Loading test questions...
          </p>
          <p className="mt-2 text-center text-sm text-gray-500">
            Please wait while we prepare your test
          </p>
        </div>
      </div>
    );
  }

  const currentQuestionData = questions[currentQuestion];

  return (
    <>
      {/* Main Test Interface */}
      <div className="fixed inset-0 bg-white z-50 flex flex-col">
        {/* Header with timer and controls */}
        <TestHeader
          test={test}
          timer={timer}
          formatTime={formatTime}
          onShowExitConfirm={handleShowExitConfirm}
        />

        {/* Progress Bar */}
        <div className="bg-gray-200 h-1">
          <div
            className="bg-teal-500 h-1 transition-all duration-500 ease-out"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {/* Question Panel */}
          <TestContent
            currentQuestion={currentQuestion}
            question={currentQuestionData}
            answer={answers.find((a) => a.questionId === currentQuestionData?.id)}
            flaggedQuestions={flaggedQuestions}
            totalQuestions={questions.length}
            onAnswerChange={handleAnswerChange}
            onFlagToggle={handleFlagToggle}
            onPrevious={handlePreviousQuestion}
            onNext={handleNextQuestion}
            canGoPrevious={currentQuestion > 0}
            canGoNext={currentQuestion < questions.length - 1}
            sessionId={sessionId || undefined}
          />

          {/* Sidebar with progress and controls */}
          <TestSidebar
            questions={questions}
            answers={answers}
            currentQuestion={currentQuestion}
            flaggedQuestions={flaggedQuestions}
            stats={testStats}
            onQuestionSelect={handleQuestionNavigation}
            onSubmit={handleShowSubmitConfirm}
          />
        </div>
      </div>

      {/* Submit Confirmation Modal */}
      {showSubmitConfirm && (
        <ConfirmationModal
          title="Submit Test?"
          message={
            <>
              You have answered <strong>{testStats.answered}</strong> out of{" "}
              <strong>{testStats.total}</strong> questions.
              {testStats.unanswered > 0 && (
                <span className="block mt-2 text-amber-600">
                  <AlertTriangle className="inline w-4 h-4 mr-1" />
                  {testStats.unanswered} unanswered questions will be marked as
                  incorrect.
                </span>
              )}
            </>
          }
          confirmText="Submit Test"
          cancelText="Continue Test"
          confirmButtonClass="bg-teal-500 hover:bg-teal-600 text-white"
          onConfirm={handleSubmitTest}
          onCancel={handleCloseSubmitConfirm}
        />
      )}

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <ConfirmationModal
          title="Exit Test?"
          message={
            <>
              <div className="flex items-center space-x-2 mb-3">
                <AlertTriangle
                  className="text-red-500 flex-shrink-0"
                  size={20}
                />
                <span className="font-medium">Your progress will be lost!</span>
              </div>
              <p className="text-gray-600">
                Are you sure you want to exit? All your answers and progress
                will be lost. You can save your progress by submitting the test
                instead.
              </p>
            </>
          }
          confirmText="Exit Test"
          cancelText="Stay in Test"
          confirmButtonClass="bg-red-500 hover:bg-red-600 text-white"
          onConfirm={handleForceExit}
          onCancel={handleCloseExitConfirm}
        />
      )}
    </>
  );
};

export default CandidateTestModal;