import React, { useState, useEffect } from "react";
import { Search, Clock, ChevronLeft, ChevronRight } from "lucide-react";
import { Trans, useLingui } from "@lingui/macro";
import CandidateTestCard from "../TestsComponents/CandidateTestCard";
import TestStatsDashboard from "../TestsComponents/TestStatsDashboard";
import {
  candidateTestService,
  CandidateTestStats,
} from "@/lib/network/candidateTest";
import { TestQuestion } from "@/lib/types/test";
import { useAuth } from "@/contexts/AuthContext";

// Define filters interface locally
interface TestFilters {
  search?: string;
  category?: string;
  difficulty?: string;
  status?: string;
}

// Define answer detail structure for this component
interface LocalAnswerDetail {
  questionId: string | number;
  selectedAnswer?: string | string[];
  isCorrect?: boolean;
  timeSpent?: number;
  [key: string]: unknown;
}

// Define API test structure
interface ApiTest {
  id: string;
  title: string;
  description?: string;
  status?: string;
  bestScore?: number;
  attempts?: number;
  maxAttempts?: number;
  assignedDate?: string;
  lastAttemptDate?: string;
  dueDate?: string;
  category?: string;
  difficulty?: string;
  duration?: number;
  totalQuestions?: number;
  passingScore?: number;
  tags?: string[];
  instructions?: string[];
  job?: { id: string; title: string; company: string };
  questions?: TestQuestion[];
  score?: number;
  correctAnswers?: number;
  timeSpent?: number;
  completedAt?: string | Date;
  answerDetails?: LocalAnswerDetail[];
  passed?: boolean;
}

// Define our own interface for the component
interface ExtendedCandidateTest {
  id: string;
  title: string;
  description?: string;
  status?: string;
  bestScore?: number;
  attempts?: number;
  maxAttempts?: number;
  assignedDate?: string;
  lastAttemptDate?: string;
  dueDate?: string;
  category?: string;
  difficulty?: string;
  duration?: number;
  totalQuestions?: number;
  passingScore?: number;
  tags?: string[];
  isActive?: boolean;
  instructions?: string[];
  job?: { id: string; title: string; company: string };
  completedAt?: Date | null;
  questions?: TestQuestion[];
  createdAt?: string;
  updatedAt?: string;
  score?: number;
  correctAnswers?: number;
  timeSpent?: number;
  answerDetails?: LocalAnswerDetail[];
  passed?: boolean;
}

interface CandidateTestListProps {
  onStartTest: (test: ExtendedCandidateTest) => void;
  refreshTrigger: number;
}

const CandidateTestList: React.FC<CandidateTestListProps> = ({
  onStartTest,
  refreshTrigger,
}) => {
  const { user } = useAuth();
  const fullname = user?.firstname + " " + user?.lastname;
  const [tests, setTests] = useState<ExtendedCandidateTest[]>([]);
  const [filteredTests, setFilteredTests] = useState<ExtendedCandidateTest[]>(
    []
  );
  const [filters, setFilters] = useState<TestFilters>({});
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [testsPerPage] = useState(6);
  const [statistics, setStatistics] = useState<CandidateTestStats | null>(null);
  const { i18n } = useLingui();
  const isRTL = i18n.locale === "ar";

  // Fonction pour normaliser le statut
  const normalizeStatus = (status?: string) => {
    if (!status) return "Available";
    switch (status.toUpperCase()) {
      case "COMPLETED":
        return "Completed";
      case "IN_PROGRESS":
      case "INPROGRESS":
        return "In Progress";
      case "AVAILABLE":
        return "Available";
      case "EXPIRED":
        return "Expired";
      default:
        return status;
    }
  };

  // Fonction pour normaliser la difficulté
  const normalizeDifficulty = (difficulty?: string) => {
    if (!difficulty) return "Medium";
    switch (difficulty.toUpperCase()) {
      case "EASY":
        return "Easy";
      case "MEDIUM":
        return "Medium";
      case "HARD":
        return "Hard";
      default:
        return difficulty;
    }
  };

  // For API integration
  useEffect(() => {
    const fetchTestsAndStatistics = async () => {
      setLoading(true);
      try {
        const testsResponse = await candidateTestService.getTests();
        const statsResponse = await candidateTestService.getStatistics();

        console.log("testsResponse", testsResponse.data);

        if (testsResponse.success && statsResponse.success) {
          // Type assertion to treat the API response as our expected format
          const apiTests = (testsResponse.data || []) as unknown as ApiTest[];

          const formattedTests: ExtendedCandidateTest[] = apiTests.map(
            (test: ApiTest) => ({
              id: test.id.toString(),
              title: test.title,
              description: test.description,
              status: normalizeStatus(test.status),
              bestScore: test.bestScore || 0,
              score: test.score,
              maxAttempts: test.maxAttempts || 3,
              assignedDate: test.assignedDate,
              lastAttemptDate: test.lastAttemptDate,
              dueDate: test.dueDate,
              category: test.category,
              difficulty: normalizeDifficulty(test.difficulty),
              duration: test.duration,
              totalQuestions: test.totalQuestions,
              passingScore: test.passingScore,
              tags: test.tags || [],
              isActive: true,
              instructions: test.instructions || [],
              job: test.job,
              questions: test.questions || [],
              correctAnswers: test.correctAnswers || 0,
              timeSpent: test.timeSpent || 0,
              completedAt: test.completedAt ? new Date(test.completedAt) : null,
              answerDetails: test.answerDetails || [],
              passed:
                test.passed !== undefined
                  ? test.passed
                  : (test.score || test.bestScore || 0) >=
                    (test.passingScore || 70),
            })
          );

          // Ne pas utiliser les données mockées si l'API retourne des données
          setTests(formattedTests);
          setFilteredTests(formattedTests);

          if (statsResponse.data) {
            setStatistics(statsResponse.data);
          } else if (formattedTests.length > 0) {
            // Calculer les statistiques uniquement s'il y a des tests
            const completedTests = formattedTests.filter(
              (test) => test.status === "Completed"
            );

            const passedTests = completedTests.filter(
              (test) =>
                (test.score || test.bestScore || 0) >= (test.passingScore || 70)
            );

            const calculatedStatistics: CandidateTestStats = {
              totalTests: formattedTests.length,
              completedTests: completedTests.length,
              passedTests: passedTests.length,
              failedTests: completedTests.length - passedTests.length,
              averageScore:
                completedTests.length > 0
                  ? completedTests.reduce(
                      (sum, test) => sum + (test.score || test.bestScore || 0),
                      0
                    ) / completedTests.length
                  : 0,
              totalTimeSpent: completedTests.reduce(
                (sum, test) => sum + (test.timeSpent || test.duration || 0),
                0
              ),
              upcomingTests: formattedTests.filter(
                (test) => test.status === "Available"
              ).length,
              expiredTests: formattedTests.filter(
                (test) => test.status === "Expired"
              ).length,
            };

            setStatistics(calculatedStatistics);
          }
        } else {
          // Ne pas utiliser les données mockées si l'API échoue
          setTests([]);
          setFilteredTests([]);
          setStatistics(null);
        }
      } catch (error) {
        console.error("Error fetching tests:", error);
        // En cas d'erreur, ne pas utiliser les données mockées
        setTests([]);
        setFilteredTests([]);
        setStatistics(null);
      } finally {
        setLoading(false);
      }
    };

    fetchTestsAndStatistics();
  }, [refreshTrigger]);

  useEffect(() => {
    let filtered = tests;

    if (filters.search) {
      filtered = filtered.filter(
        (test) =>
          test.title.toLowerCase().includes(filters.search!.toLowerCase()) ||
          test.description
            ?.toLowerCase()
            .includes(filters.search!.toLowerCase()) ||
          false ||
          test.tags?.some((tag) =>
            tag.toLowerCase().includes(filters.search!.toLowerCase())
          ) ||
          false
      );
    }

    if (filters.category) {
      filtered = filtered.filter((test) => test.category === filters.category);
    }

    if (filters.difficulty) {
      filtered = filtered.filter(
        (test) => test.difficulty === filters.difficulty
      );
    }

    if (filters.status) {
      filtered = filtered.filter((test) => test.status === filters.status);
    }

    setFilteredTests(filtered);
    setCurrentPage(1);
  }, [filters, tests]);

  // Pagination logic
  const indexOfLastTest = currentPage * testsPerPage;
  const indexOfFirstTest = indexOfLastTest - testsPerPage;
  const currentTests = filteredTests.slice(indexOfFirstTest, indexOfLastTest);
  const totalPages = Math.ceil(filteredTests.length / testsPerPage);

  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  const handleFilterChange = (filterType: keyof TestFilters, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [filterType]: value === "all" ? undefined : value,
    }));
  };

  const categories = ["Programming", "SKILL", "PERSONALITY"];
  const difficulties = ["Easy", "Medium", "Hard"];
  const statuses = ["Available", "In Progress", "Completed", "Expired"];

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-teal-500"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-[93%] ml-[7%]">
      {" "}
      {/* Header */}
      <div className="mb-8">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              <Trans>Test Management</Trans>
            </h1>
            <p className="text-gray-600">
              <Trans>Take your assigned tests and track your progress.</Trans>
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500">
              <Trans>Welcome back,</Trans>
            </p>
            <p className="text-lg font-semibold text-gray-900">
              {fullname || <Trans>Demo User</Trans>}
            </p>
            <p className="text-sm text-teal-600">
              <Trans>Candidate</Trans>
            </p>
          </div>
        </div>

        {/* Statistics Dashboard - Afficher seulement s'il y a des statistiques */}
        {statistics && <TestStatsDashboard statistics={statistics} />}
      </div>
      {/* Afficher un message si aucun test n'est disponible */}
      {tests.length === 0 && !loading && (
        <div className="bg-white rounded-lg shadow-sm border p-12 text-center mb-6">
          <div className="text-gray-400 mb-4">
            <Clock size={48} className="mx-auto" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            <Trans>No tests available</Trans>
          </h3>
          <p className="text-gray-600">
            <Trans>
              You currently have no assigned tests. Please check back later.
            </Trans>
          </p>
        </div>
      )}
      {/* Afficher les filtres et la liste des tests seulement s'il y a des tests */}
      {tests.length > 0 && (
        <>
          {/* Filters */}
          <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
            <div className="flex flex-wrap gap-4 items-center">
              {/* Search */}
              <div className="relative flex-1 min-w-[300px]">
                <Search
                  className={`absolute ${
                    isRTL ? "right-3" : "left-3"
                  } top-1/2 transform -translate-y-1/2 text-gray-400`}
                  size={20}
                />
                <input
                  type="text"
                  placeholder={i18n._("Search tests...")}
                  className={`w-full ${
                    isRTL ? "pr-10 pl-4" : "pl-10 pr-4"
                  } py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent`}
                  value={filters.search || ""}
                  onChange={(e) => handleFilterChange("search", e.target.value)}
                />
              </div>

              {/* Category Filter */}
              <select
                className={`${
                  isRTL ? "" : "px-4"
                } py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent`}
                value={filters.category || "all"}
                onChange={(e) => handleFilterChange("category", e.target.value)}
              >
                <option value="all">
                  <Trans>All Categories</Trans>
                </option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>

              {/* Difficulty Filter */}
              <select
                className={`${
                  isRTL ? "" : "px-4"
                } py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent`}
                value={filters.difficulty || "all"}
                onChange={(e) =>
                  handleFilterChange("difficulty", e.target.value)
                }
              >
                <option value="all">
                  <Trans>All Difficulties</Trans>
                </option>
                {difficulties.map((difficulty) => (
                  <option key={difficulty} value={difficulty}>
                    <Trans id={`difficulty.${difficulty}`}>{difficulty}</Trans>
                  </option>
                ))}
              </select>

              {/* Status Filter */}
              <select
                className={`${
                  isRTL ? "" : "px-4"
                } py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent`}
                value={filters.status || "all"}
                onChange={(e) => handleFilterChange("status", e.target.value)}
              >
                <option value="all">
                  <Trans>All Statuses</Trans>
                </option>
                {statuses.map((status) => (
                  <option key={status} value={status}>
                    <Trans id={`status.${status.replace(" ", "")}`}>
                      {status}
                    </Trans>
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Test Grid */}
          {currentTests.length === 0 ? (
            <div className="bg-white rounded-lg shadow-sm border p-12 text-center">
              <div className="text-gray-400 mb-4">
                <Clock size={48} className="mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                <Trans>No tests match the filters</Trans>
              </h3>
              <p className="text-gray-600">
                <Trans>Try adjusting your filters to see more tests.</Trans>
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {currentTests.map((test) => (
                <CandidateTestCard
                  key={test.id}
                  test={test}
                  onStartTest={onStartTest}
                />
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center space-x-2">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isRTL ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => (
                  <button
                    key={page}
                    onClick={() => handlePageChange(page)}
                    className={`px-4 py-2 rounded-lg border ${
                      currentPage === page
                        ? "bg-teal-500 text-white border-teal-500"
                        : "border-gray-300 hover:bg-gray-50"
                    }`}
                  >
                    {page}
                  </button>
                )
              )}
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isRTL ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default CandidateTestList;
