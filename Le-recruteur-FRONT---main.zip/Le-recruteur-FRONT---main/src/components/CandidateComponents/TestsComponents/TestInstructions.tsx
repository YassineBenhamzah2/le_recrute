import { Trans } from "@lingui/macro";
import {
  AlertTriangle,
  Award,
  Briefcase,
  CheckCircle,
  Clock,
  FileText,
  Flag,
  Info,
  Play,
  X,
} from "lucide-react";
import React from "react";

// Define our own interface without extending CandidateTest
interface ExtendedCandidateTest {
  id: string;
  title: string;
  description?: string;
  status?: string;
  bestScore?: number;
  maxAttempts?: number;
  assignedDate?: string;
  lastAttemptDate?: string;
  dueDate?: string;
  category?: string;
  difficulty?: string;
  duration?: number;
  totalQuestions?: number;
  passingScore?: number;
  tags?: string[];
  isActive?: boolean;
  instructions?: string[];
  job?: { id: string; title: string; company: string };
  completedAt?: Date | null;
  questions?: unknown[];
  createdAt?: string;
  updatedAt?: string;
  score?: number;
}

interface TestInstructionsProps {
  test: ExtendedCandidateTest;
  onClose: () => void;
  onStartTest?: () => void;
}

const TestInstructions: React.FC<TestInstructionsProps> = ({
  test,
  onClose,
  onStartTest,
}) => {
  const isCompleted = test.status === "Completed";
  const canStartTest = onStartTest && !isCompleted;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 rounded-t-xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                {test.title}
              </h2>
              <p className="text-sm text-gray-600 mt-1">
                {isCompleted ? (
                  <Trans>Test Details & Results</Trans>
                ) : (
                  <Trans>Test Instructions</Trans>
                )}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X size={20} className="text-gray-500" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Test Info */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center text-sm text-gray-700">
                <Clock className="mr-3 text-gray-400" size={18} />
                <div>
                  <span className="font-medium">
                    <Trans>Duration:</Trans>
                  </span>
                  <span className="ml-2">
                    <Trans>{test.duration || 0} minutes</Trans>
                  </span>
                </div>
              </div>
              <div className="flex items-center text-sm text-gray-700">
                <FileText className="mr-3 text-gray-400" size={18} />
                <div>
                  <span className="font-medium">
                    <Trans>Questions:</Trans>
                  </span>
                  <span className="ml-2">{test.totalQuestions}</span>
                </div>
              </div>
              <div className="flex items-center text-sm text-gray-700">
                <Award className="mr-3 text-gray-400" size={18} />
                <div>
                  <span className="font-medium">
                    <Trans>Passing Score:</Trans>
                  </span>
                  <span className="ml-2">
                    <Trans>{test.passingScore || 0}</Trans>
                  </span>
                </div>
              </div>
              <div className="flex items-center text-sm text-gray-700"></div>
            </div>
          </div>

          {/* Test Description */}
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-3">
              <Trans>About This Test</Trans>
            </h3>

            {test.job?.title && (
              <div className="flex items-start">
                <Briefcase className="w-5 h-5 text-teal-500 mr-3 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-gray-500">
                    <Trans>Job Offer</Trans>
                  </p>
                  <p className="text-gray-900 font-medium">{test.job?.title}</p>
                </div>
              </div>
            )}

            <p className="text-gray-700 mb-4 mt-4">{test.description}</p>

            {/* Tags */}
            {test.tags && (
              <div className="flex flex-wrap gap-2">
                {test.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-teal-100 text-teal-700 rounded-full text-sm font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Best Score (for completed tests) */}
          {isCompleted && test.score !== undefined && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <CheckCircle className="text-green-500 mr-3" size={20} />
                  <div>
                    <h4 className="font-medium text-green-800">
                      <Trans>Your Best Performance</Trans>
                    </h4>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-green-600">
                    <Trans>{test.score}</Trans>
                  </div>
                  <div className="text-sm text-green-600">
                    {test.score !== undefined &&
                      test.passingScore !== undefined &&
                      (test.score >= test.passingScore ? (
                        <Trans>Passed</Trans>
                      ) : (
                        <Trans>Failed</Trans>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Instructions */}
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-3 flex items-center">
              <Info className="mr-2 text-blue-500" size={20} />
              {isCompleted ? (
                <Trans>Test Information</Trans>
              ) : (
                <Trans>Important Instructions</Trans>
              )}
            </h3>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <ul className="space-y-2">
                {test.instructions &&
                  test.instructions.map((instruction, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle
                        className="text-blue-500 mr-2 mt-0.5 flex-shrink-0"
                        size={16}
                      />
                      <span className="text-sm text-blue-800">
                        {instruction}
                      </span>
                    </li>
                  ))}
              </ul>
            </div>
          </div>

          {/* Important Notes (for available tests) */}
          {!isCompleted && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
              <h4 className="font-medium text-yellow-800 mb-2 flex items-center">
                <AlertTriangle className="mr-2" size={18} />
                <Trans>Important Notes:</Trans>
              </h4>
              <ul className="text-sm text-yellow-700 space-y-1">
                <li>
                  • <Trans>You cannot pause the test once started</Trans>
                </li>
                <li>
                  •{" "}
                  <Trans>
                    You can navigate between questions and change answers
                  </Trans>
                </li>
                <li>
                  • <Trans>You can flag questions for review if needed</Trans>
                </li>
                <li>
                  • <Trans>Submit the test before time runs out</Trans>
                </li>
                <li>
                  •{" "}
                  <Trans>Make sure you have a stable internet connection</Trans>
                </li>
              </ul>
            </div>
          )}

          {/* Test Features */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                <Flag className="mr-2 text-orange-500" size={18} />
                <Trans>Flag Questions</Trans>
              </h4>
              <p className="text-sm text-gray-600">
                <Trans>
                  Mark questions you want to review before submitting
                </Trans>
              </p>
            </div>
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                <Clock className="mr-2 text-blue-500" size={18} />
                <Trans>Timer Display</Trans>
              </h4>
              <p className="text-sm text-gray-600">
                <Trans>
                  Keep track of remaining time with visual countdown
                </Trans>
              </p>
            </div>
          </div>

          {/* Due Date Warning */}
          {test.dueDate && test.status !== "Completed" && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
              <div className="flex items-center">
                <AlertTriangle className="text-orange-500 mr-3" size={20} />
                <div>
                  <h4 className="font-medium text-orange-800">
                    <Trans>Due Date</Trans>
                  </h4>
                  <p className="text-sm text-orange-700">
                    <Trans>
                      This test must be completed by{" "}
                      {new Date(test.dueDate).toLocaleDateString()}
                    </Trans>
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 rounded-b-xl">
          <div className="flex justify-between items-center">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              {isCompleted ? <Trans>Close</Trans> : <Trans>Cancel</Trans>}
            </button>

            {canStartTest && (
              <button
                onClick={onStartTest}
                className="px-6 py-2 bg-teal-500 text-white rounded-lg hover:bg-teal-600 transition-colors flex items-center"
              >
                <Play size={16} className="mr-2" />
                {test.status === "In Progress" ? (
                  <Trans>Continue Test</Trans>
                ) : (
                  <Trans>Start Test</Trans>
                )}
              </button>
            )}
          </div>

          {canStartTest && (
            <p className="text-xs text-gray-500 mt-2 text-center">
              <Trans>
                Make sure you're ready before starting. The timer will begin
                immediately.
              </Trans>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default TestInstructions;
