import React, { memo } from 'react';
import { X, Clock, AlertTriangle, User } from 'lucide-react';
import { CandidateTest } from '@/lib/types/candidateTests';
import { Trans } from '@lingui/macro';
import { useAuth } from '@/contexts/AuthContext';

interface TestHeaderProps {
  test: CandidateTest;
  timer: {
    remainingTime: number;
    isWarning: boolean;
    isCritical: boolean;
  };
  formatTime: (seconds: number) => string;
  onShowExitConfirm: () => void;
}

export const TestHeader: React.FC<TestHeaderProps> = memo(({ 
  test, 
  timer, 
  formatTime, 
  onShowExitConfirm 
}) => {
  const getTimerStyles = () => {
    if (timer.isCritical) {
      return 'bg-red-100 text-red-700 border border-red-200 animate-pulse';
    }
    if (timer.isWarning) {
      return 'bg-amber-100 text-amber-700 border border-amber-200';
    }
    return 'bg-gray-100 text-gray-700 border border-gray-200';
  };
  const { user } = useAuth();
  const fullname = user?.firstname + " " + user?.lastname;


  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between shadow-sm">
      <div className="flex items-center space-x-4">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">{test.title}</h1>
          <div className="flex items-center space-x-2 mt-1">
            <User size={14} className="text-gray-400" />
            <span className="text-sm text-gray-500"> <Trans>Candidate:</Trans> { fullname || <Trans>Demo User</Trans>}</span>
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        {/* Timer Display */}
        <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${getTimerStyles()}`}>
          <Clock size={16} />
          <span className="font-mono font-semibold text-lg">
            {formatTime(timer.remainingTime)}
          </span>
          {(timer.isWarning || timer.isCritical) && (
            <AlertTriangle size={16} className="text-current" />
          )}
        </div>
        
        {/* Exit button with enhanced styling */}
        <button
          onClick={onShowExitConfirm}
          className="p-2 hover:bg-red-50 hover:text-red-600 rounded-lg transition-all duration-200 group"
          title="Exit test"
        >
          <X size={20} className="text-gray-500 group-hover:text-red-600" />
        </button>
      </div>
    </header>
  );
});

TestHeader.displayName = 'TestHeader';
