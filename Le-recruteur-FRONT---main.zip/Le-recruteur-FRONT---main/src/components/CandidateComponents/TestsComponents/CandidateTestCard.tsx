import { TestQuestion } from "@/lib/types/test";
import { Trans } from "@lingui/macro";
import {
  AlertCircle,
  Award,
  CheckCircle,
  Clock,
  Eye,
  FileText,
  Play,
  RotateCcw,
  Timer,
} from "lucide-react";
import React, { useState } from "react";
import TestInstructions from "../TestsComponents/TestInstructions";

// Define our own interface without extending CandidateTest
interface ExtendedCandidateTest {
  id: string;
  title: string;
  description?: string;
  status?: string;
  bestScore?: number;
  assignedDate?: string;
  lastAttemptDate?: string;
  dueDate?: string;
  category?: string;
  difficulty?: string;
  duration?: number;
  totalQuestions?: number;
  passingScore?: number;
  tags?: string[];
  isActive?: boolean;
  instructions?: string[];
  job?: { id: string; title: string; company: string };
  completedAt?: Date | null;
  questions?: TestQuestion[];
  createdAt?: string;
  updatedAt?: string;
  score?: number;
}

interface CandidateTestCardProps {
  test: ExtendedCandidateTest;
  onStartTest: (test: ExtendedCandidateTest) => void;
}

const CandidateTestCard: React.FC<CandidateTestCardProps> = ({
  test,
  onStartTest,
}) => {
  const [showInstructions, setShowInstructions] = useState(false);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "bg-green-100 text-green-800 border-green-200";
      case "Medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Hard":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Available":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "In Progress":
        return "bg-orange-100 text-orange-800 border-orange-200";
      case "Completed":
        return "bg-green-100 text-green-800 border-green-200";
      case "Expired":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Available":
        return <Play size={16} />;
      case "In Progress":
        return <RotateCcw size={16} />;
      case "Completed":
        return <CheckCircle size={16} />;
      case "Expired":
        return <AlertCircle size={16} />;
      default:
        return <FileText size={16} />;
    }
  };

  const handleStartTest = () => {
    setShowInstructions(true);
  };

  const handleProceedToTest = () => {
    setShowInstructions(false);
    onStartTest(test);
  };

  const isDueSoon =
    test.dueDate &&
    new Date(test.dueDate).getTime() - Date.now() < 7 * 24 * 60 * 60 * 1000; // 7 days

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200 overflow-hidden">
        {/* Card Header */}
        <div className="p-6 pb-4">
          <div className="flex justify-between items-start mb-3">
            <div className="flex items-center space-x-2">
              <span
                className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(
                  test.status || "Unknown"
                )}`}
              >
                <span className="flex items-center space-x-1">
                  {getStatusIcon(test.status || "Unknown")}
                  <span>{test.status || <Trans>Unknown</Trans>}</span>
                </span>
              </span>
              {isDueSoon && test.status !== "Completed" && (
                <span className="px-2 py-1 bg-red-100 text-red-600 rounded-full text-xs font-medium border border-red-200">
                  <Timer size={12} className="inline mr-1" />
                  <Trans>Due Soon</Trans>
                </span>
              )}
            </div>
            <span
              className={`px-2 py-1 rounded-full text-xs font-medium border ${getDifficultyColor(
                test.difficulty ? test.difficulty.toString() : "Unknown"
              )}`}
            >
              {test.difficulty || <Trans>Unknown</Trans>}
            </span>
          </div>

          <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
            {test.title}
          </h3>
          <p className="text-sm text-gray-600 mb-4 line-clamp-2">
            {test.description}
          </p>

          {/* Test Info */}
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="flex items-center text-sm text-gray-600">
              <Clock size={16} className="mr-2 text-gray-400" />
              <span>
                <Trans id="C2EZrZ">{test.duration} min</Trans>
              </span>
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <FileText size={16} className="mr-2 text-gray-400" />
              <span>
                <Trans id="hpZvvn">{test.totalQuestions} questions</Trans>
              </span>
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <Award size={16} className="mr-2 text-gray-400" />
              <span>
                <Trans id="kHq6n2">{test.passingScore} to pass</Trans>
              </span>
            </div>
          </div>

          {/* Best Score for Completed Tests */}
          {test.status === "Completed" && test.score !== undefined && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-green-800">
                  <Trans>Best Score</Trans>
                </span>
                <span className="text-lg font-bold text-green-600">
                  <Trans id="hbO8db">{test.score}%</Trans>
                </span>
              </div>
            </div>
          )}

          {/* Due Date Warning */}
          {test.dueDate && test.status !== "Completed" && (
            <div
              className={`rounded-lg p-3 mb-4 ${
                isDueSoon
                  ? "bg-red-50 border border-red-200"
                  : "bg-blue-50 border border-blue-200"
              }`}
            >
              <p
                className={`text-sm font-medium ${
                  isDueSoon ? "text-red-800" : "text-blue-800"
                }`}
              >
                <Trans id="O8tU/9">
                  Due: {new Date(test.dueDate).toLocaleDateString()}
                </Trans>
              </p>
            </div>
          )}

          {/* Tags */}
          {test.tags && test.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4 ">
              {test.tags.slice(0, 3).map((tag, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs"
                >
                  {tag}
                </span>
              ))}
              {test.tags.length > 3 && (
                <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                  <Trans id="RuXuwk">+{test.tags.length - 3} more</Trans>
                </span>
              )}
            </div>
          )}
        </div>

        {/* Card Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
          <div className="flex space-x-3">
            {test.status === "Completed" ? (
              <button
                onClick={() => setShowInstructions(true)}
                className="flex-1 flex items-center justify-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors duration-200"
              >
                <Eye size={16} className="mr-2" />
                <Trans>View Details</Trans>
              </button>
            ) : (
              <>
                <button
                  onClick={() => setShowInstructions(true)}
                  className="flex items-center justify-center px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
                >
                  <Eye size={16} className="mr-2" />
                  <Trans>Instructions</Trans>
                </button>
                <button
                  onClick={handleStartTest}
                  className={`flex-1 flex items-center justify-center px-4 py-2 rounded-lg transition-colors duration-200 
                        bg-teal-500 text-white hover:bg-teal-600`}
                >
                  {test.status === "In Progress" ? (
                    <>
                      <RotateCcw size={16} className="mr-2" />
                      <Trans>Continue</Trans>
                    </>
                  ) : (
                    <>
                      <Play size={16} className="mr-2" />
                      <Trans>Start Test</Trans>
                    </>
                  )}
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Instructions Modal */}
      {showInstructions && (
        <TestInstructions
          test={test}
          onClose={() => setShowInstructions(false)}
          onStartTest={
            test.status !== "Completed" ? handleProceedToTest : undefined
          }
        />
      )}
    </>
  );
};

export default CandidateTestCard;
