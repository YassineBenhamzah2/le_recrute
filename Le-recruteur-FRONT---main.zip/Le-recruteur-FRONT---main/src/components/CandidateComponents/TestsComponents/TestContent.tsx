import React, { memo, useState, useEffect, useCallback } from "react";
import { ChevronLeft, ChevronRight, Flag } from "lucide-react";
import { TestQuestion, TestAnswer } from "@/lib/types/candidateTests";
import { candidateTestService } from "@/lib/network/candidateTest";

interface TestContentProps {
  currentQuestion: number;
  question: TestQuestion;
  answer: TestAnswer | undefined;
  flaggedQuestions: Set<string>;
  totalQuestions: number;
  onAnswerChange: (
    questionId: string,
    answer: string,
    timeSpent: number
  ) => void;
  onFlagToggle: (questionId: string) => void;
  onPrevious: () => void;
  onNext: () => void;
  canGoPrevious: boolean;
  canGoNext: boolean;
  sessionId?: string;
}

export const TestContent: React.FC<TestContentProps> = memo(
  ({
    currentQuestion,
    question,
    answer,
    flaggedQuestions,
    totalQuestions,
    onAnswerChange,
    onFlagToggle,
    onPrevious,
    onNext,
    canGoPrevious,
    canGoNext,
    sessionId,
  }) => {
    const isCurrentFlagged = question
      ? flaggedQuestions.has(question.id)
      : false;
    const [timeSpent, setTimeSpent] = useState(0);
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Timer pour suivre le temps passé sur la question
    useEffect(() => {
      if (!question) return;

      setTimeSpent(0);
      const timer = setInterval(() => {
        setTimeSpent((prev) => prev + 1);
      }, 1000);

      return () => clearInterval(timer);
    }, [question]);

    const handleAnswerSelection = useCallback(
      async (selectedOptionId: string) => {
        if (!sessionId || !question) {
          console.error("No session ID or question available");
          return;
        }
        console.log("question", question);

        setIsSubmitting(true);
        try {
          console.log("submitAnswer", sessionId, question.id, {
            answer: selectedOptionId, // Send the option ID instead of text
            timeSpent: timeSpent,
          });

          const response = await candidateTestService.submitAnswer(
            sessionId,
            question.id,
            {
              answer: selectedOptionId, // Send the option ID instead of text
              timeSpent: timeSpent,
            }
          );

          if (response.data?.saved) {
            // Mettre à jour l'état local après la sauvegarde réussie
            onAnswerChange(question.id, selectedOptionId, timeSpent);

            // Si l'API retourne une prochaine question, naviguer automatiquement
            if (response.data.nextQuestionId && canGoNext) {
              setTimeout(() => onNext(), 300);
            }
          }
        } catch (error) {
          console.error("Error submitting answer:", error);
          // En cas d'erreur, mettre à jour l'état local quand même
          onAnswerChange(question.id, selectedOptionId, timeSpent);
        } finally {
          setIsSubmitting(false);
        }
      },
      [sessionId, timeSpent, onAnswerChange, onNext, canGoNext, question]
    );

    if (!question) {
      return (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-pulse text-gray-400">
              Loading question...
            </div>
          </div>
        </div>
      );
    }

    return (
      <main className="flex-1 p-6 overflow-y-auto bg-gray-50">
        <div className="max-w-4xl mx-auto">
          {/* Question Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex-1">
              <div className="flex items-center space-x-4 mb-2">
                <h2 className="text-2xl font-semibold text-gray-900">
                  Question {currentQuestion + 1}
                </h2>
                <span className="text-sm text-gray-500">
                  of {totalQuestions}
                </span>
              </div>
              <div className="flex items-center space-x-4">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                  {question.points} {question.points === 1 ? "point" : "points"}
                </span>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">
                  {question.questionType}
                </span>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-800">
                  Time: {timeSpent}s
                </span>
              </div>
            </div>

            {/* Flag Button */}
            <button
              onClick={() => onFlagToggle(question.id)}
              disabled={isSubmitting}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                isCurrentFlagged
                  ? "bg-orange-100 text-orange-700 border border-orange-200 shadow-sm"
                  : "bg-white text-gray-600 border border-gray-200 hover:bg-gray-50 hover:border-gray-300"
              } ${isSubmitting ? "opacity-50 cursor-not-allowed" : ""}`}
              title={isCurrentFlagged ? "Remove flag" : "Flag for review"}
            >
              <Flag
                size={16}
                className={isCurrentFlagged ? "fill-current" : ""}
              />
              <span className="font-medium">
                {isCurrentFlagged ? "Flagged" : "Flag for Review"}
              </span>
            </button>
          </div>

          {/* Question Content */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-8 mb-8">
            <h3 className="text-xl text-gray-900 mb-8 leading-relaxed">
              {question.questionText}
            </h3>

            {/* Answer Options */}
            <div className="space-y-4">
              {question.options?.map((option, index) => {
                // Vérifier si l'option a un ID ou si c'est juste du texte
                const optionId =
                  typeof option === "object" && "id" in option
                    ? option.id.toString()
                    : index.toString();
                const optionText =
                  typeof option === "object" && "text" in option
                    ? option.text
                    : option;

                return (
                  <label
                    key={optionId}
                    className={`flex items-start space-x-4 p-5 border-2 rounded-xl cursor-pointer transition-all duration-200 group ${
                      answer?.answer === optionId
                        ? "border-teal-500 bg-teal-50 shadow-md"
                        : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                    } ${isSubmitting ? "opacity-70 cursor-not-allowed" : ""}`}
                  >
                    <input
                      type="radio"
                      name={`question-${question.id}`}
                      value={optionId}
                      checked={answer?.answer === optionId}
                      onChange={(e) =>
                        !isSubmitting && handleAnswerSelection(e.target.value)
                      }
                      disabled={isSubmitting}
                      className="mt-1 w-5 h-5 text-teal-600 focus:ring-teal-500 focus:ring-2"
                    />
                    <span className="flex-1 text-gray-900 group-hover:text-gray-800 leading-relaxed">
                      {optionText}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between items-center">
            <button
              onClick={onPrevious}
              disabled={!canGoPrevious || isSubmitting}
              className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-all duration-200 ${
                canGoPrevious && !isSubmitting
                  ? "bg-white border-2 border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400 shadow-sm"
                  : "bg-gray-100 border-2 border-gray-200 text-gray-400 cursor-not-allowed"
              }`}
            >
              <ChevronLeft size={18} />
              <span>Previous</span>
            </button>

            <div className="flex-1 flex justify-center">
              <div className="text-sm text-gray-500">
                {answer?.answer ? (
                  <span className="text-green-600 font-medium">✓ Answered</span>
                ) : (
                  <span>Select an answer</span>
                )}
                {isSubmitting && (
                  <span className="ml-3 text-blue-500">Saving...</span>
                )}
              </div>
            </div>

            <button
              onClick={onNext}
              disabled={!canGoNext || isSubmitting}
              className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-all duration-200 ${
                canGoNext && !isSubmitting
                  ? "bg-teal-500 text-white hover:bg-teal-600 shadow-md hover:shadow-lg"
                  : "bg-gray-100 border-2 border-gray-200 text-gray-400 cursor-not-allowed"
              }`}
            >
              <span>Next</span>
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </main>
    );
  }
);

TestContent.displayName = "TestContent";
