import React, { useState } from "react";
import { Trans } from "@lingui/macro";
import {
  X,
  CheckCircle,
  XCircle,
  Clock,
  Target,
  TrendingUp,
  FileText,
  Download,
  BarChart3,
  BookOpen,
  Star,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { CandidateTest, AnswerDetail } from "../../../lib/types/candidateTests";
import { jsPDF } from "jspdf";

interface TestResultsProps {
  result: CandidateTest;
  test: CandidateTest;
  onClose: () => void;
  isRTL?: boolean; // Nouvelle prop pour gérer RTL
}

const TestResults: React.FC<TestResultsProps> = ({
  result,
  test,
  onClose,
  isRTL = false,
}) => {
  const isPassed = result.passed;
  const percentage = result.score || 0;
  const [expandedQuestions, setExpandedQuestions] = useState<number[]>([]);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  // Classes conditionnelles pour RTL
  const directionClass = isRTL ? "rtl" : "ltr";
  const textAlignClass = isRTL ? "text-right" : "text-left";
  const flexDirectionClass = isRTL ? "flex-row-reverse" : "flex-row";
  const spaceXClass = isRTL ? "space-x-reverse" : "space-x";

  const getScoreColor = (percentage: number) => {
    if (percentage >= 80) return "text-green-600";
    if (percentage >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreBgColor = (percentage: number) => {
    if (percentage >= 80) return "bg-green-50 border-green-200";
    if (percentage >= 60) return "bg-yellow-50 border-yellow-200";
    return "bg-red-50 border-red-200";
  };

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return (
        <Trans>
          {hours}h {mins}m
        </Trans>
      );
    }
    return <Trans>{mins} minutes</Trans>;
  };

  const toggleQuestion = (index: number) => {
    if (expandedQuestions.includes(index)) {
      setExpandedQuestions(expandedQuestions.filter((i) => i !== index));
    } else {
      setExpandedQuestions([...expandedQuestions, index]);
    }
  };

  // Fonction pour générer et télécharger le PDF avec les questions et réponses
  const downloadCertificateWithDetails = async () => {
    setIsGeneratingPDF(true);

    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();

      // Add background gradient
      doc.setFillColor(6, 78, 59);
      doc.rect(0, 0, pageWidth, 80, "F");

      // Header
      doc.setFontSize(28);
      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.text("TEST RESULTS CERTIFICATE", pageWidth / 2, 40, {
        align: "center",
      });

      doc.setFontSize(16);
      doc.setTextColor(255, 255, 255, 0.8);
      doc.setFont("helvetica", "normal");
      doc.text("Performance Assessment Report", pageWidth / 2, 55, {
        align: "center",
      });

      // Test info section
      doc.setFillColor(249, 250, 251);
      doc.rect(20, 90, pageWidth - 40, 60, "F");
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(18);
      doc.setFont("helvetica", "bold");
      doc.text(test.title, pageWidth / 2, 105, { align: "center" });

      doc.setFontSize(12);
      doc.setFont("helvetica", "normal");
      doc.text(
        `Completed: ${
          result.completedAt
            ? new Date(result.completedAt).toLocaleDateString()
            : "N/A"
        }`,
        pageWidth / 2,
        120,
        { align: "center" }
      );

      // Score circle
      const centerX = pageWidth / 2;
      const centerY = 170;
      const radius = 30;

      // Draw circle background
      doc.setDrawColor(229, 231, 235);
      doc.setLineWidth(2);
      doc.circle(centerX, centerY, radius, "S");

      // Draw score arc
      const scoreColor = isPassed ? [16, 185, 129] : [239, 68, 68];
      doc.setDrawColor(scoreColor[0], scoreColor[1], scoreColor[2]);
      doc.setLineWidth(3);
      doc.circle(centerX, centerY, radius);

      // Add score text
      doc.setFontSize(24);
      doc.setFont("helvetica", "bold");
      const textColor = isPassed ? [16, 185, 129] : [239, 68, 68];
      doc.setTextColor(textColor[0], textColor[1], textColor[2]);
      doc.text(`${percentage}`, centerX, centerY - 5);

      doc.setFontSize(10);
      doc.setTextColor(107, 114, 128);
      doc.text("SCORE", centerX, centerY + 10);

      // Status badge
      const badgeColor = isPassed ? [220, 252, 231] : [254, 226, 226];
      doc.setFillColor(badgeColor[0], badgeColor[1], badgeColor[2]);
      doc.roundedRect(centerX - 25, centerY + 20, 50, 15, 7.5, 7.5, "F");

      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      const badgeTextColor = isPassed ? [5, 122, 85] : [185, 28, 28];
      doc.setTextColor(badgeTextColor[0], badgeTextColor[1], badgeTextColor[2]);
      doc.text(isPassed ? "PASSED" : "FAILED", centerX, centerY + 28, {
        align: "center",
      });

      // Performance summary
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(0, 0, 0);
      doc.text("PERFORMANCE SUMMARY", 20, 220);

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(107, 114, 128);

      const summaryYStart = 230;
      const summarySpacing = 8;

      doc.text(
        `Difficulty: ${test.difficulty}`,
        20,
        summaryYStart + summarySpacing * 2
      );
      doc.text(
        `Passing Score: ${test.passingScore}`,
        pageWidth - 20,
        summaryYStart,
        { align: "right" }
      );

      // Add page for detailed results if available
      if (result.answerDetails && result.answerDetails.length > 0) {
        doc.addPage();

        doc.setFontSize(16);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(0, 0, 0);
        doc.text("DETAILED RESULTS", 20, 30);

        let yPosition = 40;

        result.answerDetails.forEach((answer: AnswerDetail, index: number) => {
          if (yPosition > pageHeight - 50) {
            doc.addPage();
            yPosition = 20;
          }

          doc.setFontSize(12);
          doc.setFont("helvetica", "bold");
          doc.setTextColor(0, 0, 0);
          doc.text(`${index + 1}. ${answer.questionText}`, 20, yPosition);

          doc.setFontSize(10);
          doc.setTextColor(107, 114, 128);
          doc.text(
            `Points: ${answer.pointsEarned}/${answer.maxPoints}`,
            pageWidth - 20,
            yPosition,
            { align: "right" }
          );

          yPosition += 10;

          // Options
          answer.options.forEach((option, optIndex) => {
            if (yPosition > pageHeight - 30) {
              doc.addPage();
              yPosition = 20;
            }

            const isSelected = answer.selectedOptionId === option.id;
            const isCorrect = option.isCorrect;

            let optionColor = [0, 0, 0];
            let prefix = `${String.fromCharCode(65 + optIndex)}) `;

            if (isSelected && isCorrect) {
              optionColor = [16, 185, 129];
              prefix += "✓ ";
            } else if (isSelected && !isCorrect) {
              optionColor = [239, 68, 68];
              prefix += "✗ ";
            } else if (isCorrect) {
              optionColor = [16, 185, 129];
            }

            doc.setTextColor(optionColor[0], optionColor[1], optionColor[2]);
            doc.text(prefix + option.text, 30, yPosition);

            yPosition += 6;
          });

          yPosition += 10;

          // Separator
          doc.setDrawColor(229, 231, 235);
          doc.line(20, yPosition, pageWidth - 20, yPosition);

          yPosition += 15;
        });
      }

      // Footer
      const totalPages = doc.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(107, 114, 128);
        doc.text(`Page ${i} of ${totalPages}`, pageWidth / 2, pageHeight - 10, {
          align: "center",
        });
        doc.text(
          `Generated on ${new Date().toLocaleDateString()}`,
          pageWidth - 20,
          pageHeight - 10,
          { align: "right" }
        );
      }

      // Sauvegarder le PDF
      const dateString = result.completedAt
        ? new Date(result.completedAt).toISOString().split("T")[0]
        : new Date().toISOString().split("T")[0];

      doc.save(
        `Test_Results_${test.title.replace(/\s+/g, "_")}_${dateString}.pdf`
      );
    } catch (error) {
      console.error("Error generating PDF:", error);
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  return (
    <div
      className={`fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto ${directionClass}`}
    >
      <div className="bg-white rounded-xl shadow-2xl max-w-6xl w-full max-h-[95vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-600 to-blue-600 text-white p-6">
          <div
            className={`flex items-center justify-between ${flexDirectionClass}`}
          >
            <div className={`flex items-center ${spaceXClass}-4`}>
              <div className="p-2 bg-white/20 rounded-lg">
                <BarChart3 size={24} />
              </div>
              <div className={textAlignClass}>
                <h2 className="text-2xl font-bold">
                  <Trans>Test Results</Trans>
                </h2>
                <h3 className="text-lg opacity-90">{test.title}</h3>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            {/* Score Card */}
            <div
              className={`lg:col-span-2 rounded-xl border p-6 ${getScoreBgColor(
                result.score
              )}`}
            >
              <div
                className={`flex flex-col md:${flexDirectionClass} items-center`}
              >
                <div
                  className={`flex-shrink-0 mb-4 md:mb-0 ${
                    isRTL ? "md:ml-6" : "md:mr-6"
                  }`}
                >
                  <div className="relative w-32 h-32">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle
                        className="text-gray-200 stroke-current"
                        strokeWidth="10"
                        cx="50"
                        cy="50"
                        r="40"
                        fill="transparent"
                      />
                      <circle
                        className={`stroke-current ${getScoreColor(
                          result.score
                        )}`}
                        strokeWidth="10"
                        strokeLinecap="round"
                        cx="50"
                        cy="50"
                        r="40"
                        fill="transparent"
                        strokeDasharray={251.2}
                        strokeDashoffset={
                          percentage !== 0
                            ? 251.2 - (percentage / 100) * 251.2
                            : 0
                        }
                        transform="rotate(-90 50 50)"
                      />
                      <text
                        x="50"
                        y="50"
                        dominantBaseline="middle"
                        textAnchor="middle"
                        className={`text-2xl font-bold ${getScoreColor(
                          result.score
                        )}`}
                      >
                        {percentage}
                      </text>
                      <text
                        x="50"
                        y="65"
                        dominantBaseline="middle"
                        textAnchor="middle"
                        className="text-sm fill-gray-500"
                      >
                        <Trans>Score</Trans>
                      </text>
                    </svg>
                  </div>
                </div>

                <div className={`flex-1 text-center md:${textAlignClass}`}>
                  <div
                    className={`flex justify-center md:justify-${
                      isRTL ? "end" : "start"
                    } items-center mb-4`}
                  >
                    {isPassed ? (
                      <CheckCircle
                        className={`${isRTL ? "ml-2" : "mr-2"} text-green-500`}
                        size={24}
                      />
                    ) : (
                      <XCircle
                        className={`${isRTL ? "ml-2" : "mr-2"} text-red-500`}
                        size={24}
                      />
                    )}
                    <h3 className="text-xl font-bold">
                      {isPassed ? (
                        <Trans>Congratulations! You Passed!</Trans>
                      ) : (
                        <Trans>Test Not Passed</Trans>
                      )}
                    </h3>
                  </div>

                  <div className="grid  gap-4">
                    <div className="bg-white p-3 rounded-lg shadow-sm">
                      <div className="text-lg font-semibold text-gray-900">
                        {result.score}
                      </div>
                      <div className="text-sm text-gray-600">
                        <Trans>Total Score</Trans>
                      </div>
                    </div>

                    <div className="bg-white p-3 rounded-lg shadow-sm">
                      <div className="text-lg font-semibold text-gray-900">
                        {test.passingScore}
                      </div>
                      <div className="text-sm text-gray-600">
                        <Trans>Passing Score</Trans>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Test Info Card */}
            <div className="bg-gray-50 rounded-xl p-6">
              <h4
                className={`text-lg font-semibold text-gray-900 mb-4 flex items-center ${flexDirectionClass}`}
              >
                <BookOpen
                  className={`${isRTL ? "ml-2" : "mr-2"} text-teal-500`}
                  size={20}
                />
                <Trans>Test Information</Trans>
              </h4>

              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">
                    <Trans>Category:</Trans>
                  </span>
                  <span className="font-medium">{test.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">
                    <Trans>Duration:</Trans>
                  </span>
                  <span className="font-medium">
                    <Trans>{test.duration} minutes</Trans>
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">
                    <Trans>Time Spent:</Trans>
                  </span>
                  <span className="font-medium">
                    {formatTime(result.duration || 0)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">
                    <Trans>Difficulty:</Trans>
                  </span>
                  <span className="font-medium">{test.difficulty}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">
                    <Trans>Completed:</Trans>
                  </span>
                  <span className="font-medium">
                    {result.completedAt
                      ? new Date(result.completedAt).toLocaleDateString()
                      : "N/A"}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Performance Analysis */}
          <div className="bg-white border border-gray-200 rounded-xl p-6 mb-6">
            <h4
              className={`text-lg font-semibold text-gray-900 mb-4 flex items-center ${flexDirectionClass}`}
            >
              <TrendingUp
                className={`${isRTL ? "ml-2" : "mr-2"} text-teal-500`}
                size={20}
              />
              <Trans>Performance Analysis</Trans>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h5
                  className={`font-medium text-gray-900 mb-3 flex items-center ${flexDirectionClass}`}
                >
                  <Star
                    className={`${isRTL ? "ml-2" : "mr-2"} text-yellow-500`}
                    size={16}
                  />
                  <Trans>Strengths</Trans>
                </h5>
                <div className="space-y-2">
                  {result.score >= 80 && (
                    <div
                      className={`flex items-center p-3 bg-green-50 rounded-lg ${flexDirectionClass}`}
                    >
                      <CheckCircle
                        className={`${isRTL ? "ml-2" : "mr-2"} text-green-500`}
                        size={16}
                      />
                      <span className="text-sm text-green-800">
                        <Trans>Excellent knowledge retention</Trans>
                      </span>
                    </div>
                  )}
                  {(result.duration || 0) <= test.duration * 0.8 && (
                    <div
                      className={`flex items-center p-3 bg-blue-50 rounded-lg ${flexDirectionClass}`}
                    >
                      <Clock
                        className={`${isRTL ? "ml-2" : "mr-2"} text-blue-500`}
                        size={16}
                      />
                      <span className="text-sm text-blue-800">
                        <Trans>Efficient time management</Trans>
                      </span>
                    </div>
                  )}
                  {(result.score || 0) >= 70 && (
                    <div
                      className={`flex items-center p-3 bg-purple-50 rounded-lg ${flexDirectionClass}`}
                    >
                      <Target
                        className={`${isRTL ? "ml-2" : "mr-2"} text-purple-500`}
                        size={16}
                      />
                      <span className="text-sm text-purple-800">
                        <Trans>High accuracy rate</Trans>
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <h5
                  className={`font-medium text-gray-900 mb-3 flex items-center ${flexDirectionClass}`}
                >
                  <TrendingUp
                    className={`${isRTL ? "ml-2" : "mr-2"} text-orange-500`}
                    size={16}
                  />
                  <Trans>Recommendations</Trans>
                </h5>
                <ul className="space-y-2">
                  {result.score < (test.passingScore || 70) && (
                    <li
                      className={`flex items-start p-3 bg-orange-50 rounded-lg ${flexDirectionClass}`}
                    >
                      <span
                        className={`${isRTL ? "ml-2" : "mr-2"} text-orange-500`}
                      >
                        •
                      </span>
                      <span className="text-sm text-orange-800">
                        <Trans>
                          Review the topics covered in this test before retaking
                        </Trans>
                      </span>
                    </li>
                  )}
                  {(result.duration || 0) > test.duration * 0.9 && (
                    <li
                      className={`flex items-start p-3 bg-blue-50 rounded-lg ${flexDirectionClass}`}
                    >
                      <span
                        className={`${isRTL ? "ml-2" : "mr-2"} text-blue-500`}
                      >
                        •
                      </span>
                      <span className="text-sm text-blue-800">
                        <Trans>
                          Work on time management and question prioritization
                        </Trans>
                      </span>
                    </li>
                  )}
                  {result.score >= (test.passingScore || 70) && (
                    <li
                      className={`flex items-start p-3 bg-green-50 rounded-lg ${flexDirectionClass}`}
                    >
                      <span
                        className={`${isRTL ? "ml-2" : "mr-2"} text-green-500`}
                      >
                        •
                      </span>
                      <span className="text-sm text-green-800">
                        <Trans>
                          Great job! Consider taking more advanced tests in this
                          area
                        </Trans>
                      </span>
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </div>

          {/* Question Details */}
          {result.answerDetails && result.answerDetails.length > 0 && (
            <div className="bg-white border border-gray-200 rounded-xl p-6 mb-6">
              <h4
                className={`text-lg font-semibold text-gray-900 mb-4 flex items-center ${flexDirectionClass}`}
              >
                <FileText
                  className={`${isRTL ? "ml-2" : "mr-2"} text-teal-500`}
                  size={20}
                />
                <Trans>Question Details</Trans>
              </h4>

              <div className="space-y-4">
                {result.answerDetails.map(
                  (answer: AnswerDetail, index: number) => (
                    <div
                      key={index}
                      className="border border-gray-200 rounded-lg overflow-hidden"
                    >
                      <button
                        onClick={() => toggleQuestion(index)}
                        className={`w-full p-4 bg-gray-50 hover:bg-gray-100 flex justify-between items-center ${flexDirectionClass}`}
                      >
                        <div
                          className={`flex items-center ${flexDirectionClass}`}
                        >
                          <span
                            className={`font-medium ${isRTL ? "ml-3" : "mr-3"}`}
                          >
                            <Trans>Question {index + 1}</Trans>
                          </span>
                          <span
                            className={`text-sm px-2 py-1 rounded-full ${
                              answer.pointsEarned > 0
                                ? "bg-green-100 text-green-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            <Trans>
                              {answer.pointsEarned}/{answer.maxPoints} points
                            </Trans>
                          </span>
                        </div>
                        {expandedQuestions.includes(index) ? (
                          <ChevronUp size={18} />
                        ) : (
                          <ChevronDown size={18} />
                        )}
                      </button>

                      {expandedQuestions.includes(index) && (
                        <div className="p-4">
                          <h5 className="font-medium mb-3">
                            {answer.questionText}
                          </h5>

                          <div className="space-y-2">
                            {answer.options.map((option, optIndex) => {
                              const isSelected =
                                answer.selectedOptionId === option.id;
                              const isCorrect = option.isCorrect;

                              return (
                                <div
                                  key={optIndex}
                                  className={`p-3 rounded-lg border ${
                                    isSelected && isCorrect
                                      ? "bg-green-50 border-green-200"
                                      : isSelected && !isCorrect
                                      ? "bg-red-50 border-red-200"
                                      : isCorrect
                                      ? "bg-green-50 border-green-200"
                                      : "bg-gray-50 border-gray-200"
                                  }`}
                                >
                                  <div
                                    className={`flex items-center ${flexDirectionClass}`}
                                  >
                                    {isSelected && isCorrect ? (
                                      <CheckCircle
                                        className={`${
                                          isRTL ? "ml-2" : "mr-2"
                                        } text-green-500`}
                                        size={16}
                                      />
                                    ) : isSelected && !isCorrect ? (
                                      <XCircle
                                        className={`${
                                          isRTL ? "ml-2" : "mr-2"
                                        } text-red-500`}
                                        size={16}
                                      />
                                    ) : isCorrect ? (
                                      <CheckCircle
                                        className={`${
                                          isRTL ? "ml-2" : "mr-2"
                                        } text-green-500`}
                                        size={16}
                                      />
                                    ) : null}
                                    <span>{option.text}</span>
                                    {isCorrect && (
                                      <span
                                        className={`${
                                          isRTL ? "mr-auto" : "ml-auto"
                                        } text-sm text-gray-500`}
                                      >
                                        <Trans>+{option.points} points</Trans>
                                      </span>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  )
                )}
              </div>
            </div>
          )}

          {/* Next Steps */}
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">
              <Trans>Next Steps</Trans>
            </h4>

            <div
              className={`flex items-start p-4 bg-blue-50 border border-blue-200 rounded-lg ${flexDirectionClass}`}
            >
              <Download
                className={`${isRTL ? "ml-3" : "mr-3"} text-blue-600 mt-0.5`}
                size={20}
              />
              <div>
                <h5 className="font-medium text-blue-800">
                  <Trans>Download Detailed Results</Trans>
                </h5>
                <p className="text-sm text-blue-700 mt-1">
                  <Trans>
                    Download a professional PDF report with all questions, your
                    answers, and performance analysis.
                  </Trans>
                </p>
                <button
                  onClick={downloadCertificateWithDetails}
                  disabled={isGeneratingPDF}
                  className={`mt-2 text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center ${flexDirectionClass}`}
                >
                  {isGeneratingPDF ? (
                    <Trans>Generating PDF...</Trans>
                  ) : (
                    <Trans>Generate Professional Report</Trans>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-50 border-t border-gray-200 px-6 py-4">
          <div
            className={`flex flex-col md:${flexDirectionClass} justify-between items-center`}
          >
            <p className="text-sm text-gray-600 mb-2 md:mb-0">
              <Trans>Results automatically saved to your profile</Trans>
            </p>

            <div className={`flex ${spaceXClass}-3`}>
              <button
                onClick={downloadCertificateWithDetails}
                disabled={isGeneratingPDF}
                className={`px-4 py-2 border border-teal-500 text-teal-600 rounded-lg hover:bg-teal-50 transition-colors flex items-center ${flexDirectionClass} disabled:opacity-50`}
              >
                <Download size={16} className={isRTL ? "ml-2" : "mr-2"} />
                {isGeneratingPDF ? (
                  <Trans>Generating...</Trans>
                ) : (
                  <Trans>Download Report</Trans>
                )}
              </button>

              <button
                onClick={onClose}
                className="px-6 py-2 bg-teal-500 text-white rounded-lg hover:bg-teal-600 transition-colors"
              >
                <Trans>Close</Trans>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestResults;
