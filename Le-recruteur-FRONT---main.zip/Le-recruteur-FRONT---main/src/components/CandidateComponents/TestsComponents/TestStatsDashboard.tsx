import React from "react";
import {
  CheckCircle,
  Clock,
  Award,
  TrendingUp,
  FileText,
  AlertTriangle,
} from "lucide-react";
import { Trans, useLingui } from "@lingui/macro";

// Define our own interface for TestStatistics based on the data we receive
export interface TestStatistics {
  totalTests: number;
  completedTests: number;
  passedTests: number;
  failedTests: number;
  averageScore: number;
  totalTimeSpent: number;
  upcomingTests: number;
  expiredTests: number;
}

interface TestStatsDashboardProps {
  statistics: TestStatistics;
}

const TestStatsDashboard: React.FC<TestStatsDashboardProps> = ({
  statistics,
}) => {
  const statCards = [
    {
      title: <Trans>Total Tests</Trans>,
      value: statistics.totalTests,
      icon: FileText,
      color: "blue",
      description: <Trans>Assigned to you</Trans>,
    },
    {
      title: <Trans>Completed</Trans>,
      value: statistics.completedTests,
      icon: CheckCircle,
      color: "green",
      description: (
        <Trans>
          {statistics.passedTests} passed tests
        </Trans>
      ),
    },
    {
      title: <Trans>Average Score</Trans>,
      value: `${Math.round(statistics.averageScore)}%`,
      icon: Award,
      color: "yellow",
      description: <Trans>Across all completed tests</Trans>,
    },
    {
      title: <Trans>Upcoming Tests</Trans>,
      value: statistics.upcomingTests,
      icon: Clock,
      color: "teal",
      description: <Trans>Available to take</Trans>,
    },
  ];
  
  const getColorClasses = (color: string) => {
    const colorMap = {
      blue: "bg-blue-50 border-blue-200 text-blue-800",
      green: "bg-green-50 border-green-200 text-green-800",
      yellow: "bg-yellow-50 border-yellow-200 text-yellow-800",
      teal: "bg-teal-50 border-teal-200 text-teal-800",
      red: "bg-red-50 border-red-200 text-red-800",
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.blue;
  };

  const { i18n } = useLingui();
  const isRTL = i18n.locale === 'ar'; // Vérifie si la langue est arabe
  console.log(isRTL);

  const getIconColorClasses = (color: string) => {
    const colorMap = {
      blue: "text-blue-500",
      green: "text-green-500",
      yellow: "text-yellow-500",
      teal: "text-teal-500",
      red: "text-red-500",
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.blue;
  };

  return (
    <div 
      className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6"
      dir={isRTL ? "rtl" : "ltr"}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">
            <Trans>Test Statistics</Trans>
          </h2>
          <p className="text-sm text-gray-600 mt-1">
            <Trans>Your overall test performance overview</Trans>
          </p>
        </div>
        <div className="flex items-center space-x-2 space-x-reverse">
          <TrendingUp className="text-teal-500" size={20} />
          <span className="text-sm font-medium text-teal-600">
            {statistics.completedTests > 0 ? (
              <Trans>Active</Trans>
            ) : (
              <Trans>Getting Started</Trans>
            )}
          </span>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className={`rounded-lg border p-4 transition-all duration-200 hover:shadow-sm ${getColorClasses(
                stat.color
              )}`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="text-left">
                  <div className="text-2xl font-bold">{stat.value}</div>
                </div>
                <Icon className={getIconColorClasses(stat.color)} size={24} />
              </div>
              <div>
                <h3 className="font-medium text-sm mb-1">{stat.title}</h3>
                <p className="text-xs opacity-75">{stat.description}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Alerts */}
      {(statistics.expiredTests > 0 || statistics.upcomingTests === 0) && (
        <div className="mt-6 space-y-3">
          {statistics.expiredTests > 0 && (
            <div className="flex items-center p-3 bg-red-50 border border-red-200 rounded-lg">
              <AlertTriangle className="text-red-500 ml-3" size={20} />
              <div>
                <p className="text-sm font-medium text-red-800">
                  <Trans>
                    {statistics.expiredTests} test has expired
                  </Trans>
                </p>
                <p className="text-xs text-red-600">
                  <Trans>Contact your recruiter to request new assignments</Trans>
                </p>
              </div>
            </div>
          )}

          {statistics.upcomingTests === 0 && statistics.totalTests !== 0 &&
            statistics.completedTests === statistics.totalTests && (
              <div className="flex items-center p-3 bg-green-50 border border-green-200 rounded-lg">
                <CheckCircle className="text-green-500 ml-3" size={20} />
                <div>
                  <p className="text-sm font-medium text-green-800">
                    <Trans>All tests completed! Great job!</Trans>
                  </p>
                  <p className="text-xs text-green-600">
                    <Trans>Check back later for new test assignments</Trans>
                  </p>
                </div>
              </div>
            )}
        </div>
      )}
    </div>
  );
};

export default TestStatsDashboard;