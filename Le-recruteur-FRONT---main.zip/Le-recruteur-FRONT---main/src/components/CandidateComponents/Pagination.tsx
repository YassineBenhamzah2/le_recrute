import { useSearchParams } from 'react-router-dom';

/**
 * Enhanced Pagination Component with URL State Management
 */

interface PaginationProps {
    totalPages: number;
    currentPage?: number; // Made optional for backward compatibility
    className?: string;
    showBorder?: boolean;
    pageParam?: string; // URL parameter name for page (default: 'page')
    preserveOtherParams?: boolean; // Whether to keep other URL params (default: true)
    onPageChange?: (page: number) => void; // Optional callback for additional logic
}

/**
 * Utility hook for pagination with URL state management
 * 
 * This can be used by components that need pagination logic without the UI:
 * 
 * @param pageParam - URL parameter name for page (default: 'page')
 * @param preserveOtherParams - Whether to keep other URL params (default: true)
 * @returns Object with currentPage and handlePageChange function
 */
export const usePaginationWithURL = (pageParam = 'page', preserveOtherParams = true) => {
    const [searchParams, setSearchParams] = useSearchParams();
    
    // Get current page from URL, default to 1
    const currentPage = parseInt(searchParams.get(pageParam) || '1', 10);

    /**
     * Handle page change with URL synchronization
     */
    const handlePageChange = (page: number) => {
        if (preserveOtherParams) {
            // Create new URLSearchParams from current params
            const newParams = new URLSearchParams(searchParams);
            newParams.set(pageParam, page.toString());
            setSearchParams(newParams);
        } else {
            // Only set the page parameter, clear others
            setSearchParams({ [pageParam]: page.toString() });
        }
    };

    return { currentPage, handlePageChange };
};

const Pagination = ({ 
    totalPages,
    currentPage: propCurrentPage,
    className = "",
    showBorder = true,
    pageParam = 'page',
    preserveOtherParams = true,
    onPageChange
}: PaginationProps) => {
    const { currentPage: urlCurrentPage, handlePageChange } = usePaginationWithURL(pageParam, preserveOtherParams);
    
    // Use prop if provided, otherwise fall back to URL param
    const currentPage = propCurrentPage ?? urlCurrentPage;

    // Handle page change with both URL update and callback
    const handlePageClick = (page: number) => {
        handlePageChange(page);
        onPageChange?.(page);
    };
    if (totalPages <= 1) return null;

    return (
        <div className={`flex items-center justify-center gap-2 mt-6 pt-8 ${showBorder ? 'border-t border-gray-200' : ''} ${className}`}>
            <button 
                onClick={() => handlePageClick(currentPage - 1)}
                disabled={currentPage === 1}
                className="flex items-center justify-center w-10 h-10 text-lg font-bold text-gray-600 hover:text-gray-800 disabled:text-gray-300 disabled:cursor-not-allowed"
            >
                «
            </button>

            <div className="flex gap-2">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <button
                        key={page}
                        onClick={() => handlePageClick(page)}
                        className={`flex items-center justify-center w-10 h-10 text-lg font-semibold rounded-xl ${
                            currentPage === page
                                ? 'bg-teal-600 text-white'
                                : 'text-gray-700 hover:bg-gray-100'
                        }`}
                    >
                        {page}
                    </button>
                ))}
            </div>

            <button 
                onClick={() => handlePageClick(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="flex items-center justify-center w-10 h-10 text-lg font-bold text-gray-600 hover:text-gray-800 disabled:text-gray-300 disabled:cursor-not-allowed"
            >
                »
            </button>
        </div>
    );
};

export default Pagination;
