/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { interviewService } from '../../lib/network/interview';
import { Interview, CandidateInterviewsStats } from '../../lib/types/interview';
import InterviewSearch from './InterviewSearch';
import InterviewStats from './InterviewStats';
import InterviewCard from './InterviewCard';
import TitleSection from './TitleSection';
import Pagination, { usePaginationWithURL } from './Pagination';
import { Trans , t } from '@lingui/macro';

export type TabId = 'upcoming' | 'completed' | 'cancelled';

interface TabDefinition {
  id: TabId;
  label: string;
  field: keyof CandidateInterviewsStats;
}

const TAB_DEFINITIONS: TabDefinition[] = [
  { id: 'upcoming', label: "Upcoming", field: 'scheduled' },
  { id: 'completed', label: "Completed", field: 'completed' },
  { id: 'cancelled', label: "Cancelled", field: 'cancelled' },
];

const CandidateInterviewsDashboard: React.FC = () => {
  
  const [searchParams, setSearchParams] = useSearchParams();
  const { currentPage } = usePaginationWithURL();
  
  const [allInterviews, setAllInterviews] = useState<Interview[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<CandidateInterviewsStats>({
    scheduled: 0,
    completed: 0,
    cancelled: 0,
  });
  
  const interviewsPerPage = 3;
  const searchQuery = searchParams.get('search') || '';

  // Get tab from URL or default to 'upcoming'
  const activeTab = useMemo(() => {
    const tab = searchParams.get('tab');
    return tab === 'upcoming' || tab === 'completed' || tab === 'cancelled' 
      ? tab 
      : 'upcoming';
  }, [searchParams]);

  // Status mapping for filtering
  const statusMap = useMemo(() => ({
    upcoming: 'SCHEDULED',
    completed: 'COMPLETED',
    cancelled: 'CANCELLED'
  }), []);

  // Fetch interviews and stats
  const fetchInterviews = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch stats
      const statsResponse = await interviewService.getCandidateInterviewsStats();
      if (statsResponse.success && statsResponse.data) {
        setStats(statsResponse.data);
      }

      // Fetch interviews with search
      const response = await interviewService.getCandidateInterviews({
        page: 0,
        size: 100, // Get all for client-side filtering
        search: searchQuery || undefined
      });
      
      if (response.success && Array.isArray(response.data)) {
        setAllInterviews(response.data);
      }
    } catch (err: any) {
      const errorMsg = err.message || 'Failed to fetch interviews';
      console.error('Error fetching interviews:', err);
      setError(errorMsg);
    } finally {
      setLoading(false);
    }
  }, [searchQuery]);

  // Initial data fetch
  useEffect(() => {
    fetchInterviews();
  }, [fetchInterviews]);

  // Filter and paginate interviews
  const { filteredInterviews, totalPages } = useMemo(() => {
    const filtered = allInterviews.filter(
      interview => interview.status === statusMap[activeTab]
    );
    
    const totalPages = Math.max(1, Math.ceil(filtered.length / interviewsPerPage));
    const startIndex = (currentPage - 1) * interviewsPerPage;
    const paginated = filtered.slice(startIndex, startIndex + interviewsPerPage);
    
    
    return {
      filteredInterviews: paginated,
      totalPages
    };
  }, [allInterviews, activeTab, currentPage, interviewsPerPage, statusMap]);

  // Handle tab change
  const handleTabChange = useCallback((tab: TabId) => {
    const newParams = new URLSearchParams(searchParams);
    newParams.set('tab', tab);
    newParams.set('page', '1');
    // Use setSearchParams to update the URL and trigger a re-render
    setSearchParams(newParams, { replace: true });
  }, [searchParams, setSearchParams]);

  // Handle search
  const handleSearch = useCallback((query: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (query) {
      newParams.set('search', query);
    } else {
      newParams.delete('search');
    }
    newParams.set('page', '1');
    setSearchParams(newParams, { replace: true });
  }, [searchParams, setSearchParams]);

  return (
    <div className="p-6 space-y-6 max-w-[93%] ml-[7%]">
      <TitleSection 
        title={t`My Interviews`}
        description={t`Manage your interview schedule and track your progress`}
      />
      
      <InterviewStats stats={stats} />
      
      <InterviewSearch 
        onSearch={handleSearch}
        initialValue={searchQuery}
      />
      
      {/* Tab Navigation */}
      <div className="flex space-x-3">
        {TAB_DEFINITIONS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => handleTabChange(tab.id)}
            className={`px-6 py-3 text-sm font-medium transition-colors rounded-lg ${
              activeTab === tab.id
                ? 'bg-teal-600 text-white'
                : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            <span className="flex items-center gap-2">
               <Trans>{tab.label}</Trans>
              <span className="inline-flex items-center justify-center px-2 py-0.5 text-xs font-medium rounded-full bg-gray-100 text-gray-800">
                {stats[tab.field]}
              </span>
            </span>
          </button>
        ))}
      </div>

      {/* Interview List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        {loading ? (
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-600">{error}</p>
            <button
              onClick={fetchInterviews}
              className="mt-2 bg-teal-600 text-white px-4 py-2 rounded-lg text-sm"
            >
              <Trans>Retry</Trans>
            </button>
          </div>
        ) : filteredInterviews.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">
            {activeTab === 'upcoming' 
              ? t`No upcoming interviews found.` 
              : activeTab === 'completed'
              ? t`No completed interviews found.`
              : t`No cancelled interviews found.`
            }
          </p>
          </div>
        ) : (
          <>
            <div className="space-y-4">
              {filteredInterviews.map((interview) => (
                <InterviewCard
                  key={interview.id}
                  interview={interview}
                />
              ))}
            </div>
            
            {totalPages > 1 && (
              <div className="mt-6">
                <Pagination 
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={(page) => {
                    const params = new URLSearchParams(searchParams);
                    params.set('page', page.toString());
                    window.history.replaceState(null, '', `?${params.toString()}`);
                  }}
                />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default CandidateInterviewsDashboard;