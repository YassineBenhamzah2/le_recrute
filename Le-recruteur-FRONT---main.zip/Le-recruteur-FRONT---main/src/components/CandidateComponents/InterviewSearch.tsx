import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { Trans , t } from '@lingui/macro';

interface InterviewSearchProps {
  onSearch?: (query: string) => void;
  placeholder?: string;
  initialValue?: string;
}

const InterviewSearch: React.FC<InterviewSearchProps> = ({
  onSearch,
  placeholder,
  initialValue = '',
}) => {
  const [searchQuery, setSearchQuery] = useState(initialValue);

  // Valeur par défaut traduite
  const defaultPlaceholder = t`Search interviews by title, job title or company name...`;
  const actualPlaceholder = placeholder || defaultPlaceholder;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (onSearch) {
      onSearch(searchQuery);
    }
  };

  const handleClear = () => {
    setSearchQuery('');
    if (onSearch) {
      onSearch('');
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
      <form onSubmit={handleSubmit} className="flex items-center justify-between gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={typeof actualPlaceholder === 'string' ? actualPlaceholder : undefined}
            className="w-full pl-10 pr-10 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={handleClear}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-600 font-semibold rounded-xl hover:text-gray-800"
              aria-label={<Trans>Clear search</Trans>}
            >
              ✕
            </button>
          )}
        </div>
        <button 
          type="submit"
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-medium hover:bg-teal-700 transition-colors whitespace-nowrap"
        >
          <Search className="w-4 h-4" />
          <Trans>Search Interviews</Trans>
        </button>
      </form>
    </div>
  );
};

export default InterviewSearch;