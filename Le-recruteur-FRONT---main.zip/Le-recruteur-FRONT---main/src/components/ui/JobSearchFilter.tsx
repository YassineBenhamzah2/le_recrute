import React, { useState, useEffect, useRef } from "react";
import { AdminJobResponse } from "@/lib/types/jobOffer";

interface JobSearchFilterProps {
  onSearch: (query: string) => void;
  onFilterChange: (filters: {
    status?: AdminJobResponse["status"];
    contractType?: AdminJobResponse["contractType"];
    workMode?: AdminJobResponse["workMode"];
  }) => void;
  currentFilters: {
    status?: AdminJobResponse["status"];
    contractType?: AdminJobResponse["contractType"];
    workMode?: AdminJobResponse["workMode"];
  };
}

const JobSearchFilter: React.FC<JobSearchFilterProps> = ({
  onSearch,
  onFilterChange,
  currentFilters,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const filterRef = useRef<HTMLDivElement>(null);

  const statuses: AdminJobResponse["status"][] = [
    "ACTIVE",
    "INACTIVE",
    "EXPIRED",
    "PAUSE",
    "PENDING",
    "SCHEDULED",
  ];
  const contractTypes: AdminJobResponse["contractType"][] = [
    "CDI",
    "CDD",
    "CONTRACT_PROJECT",
    "CONTRACT_ANAPEC",
  ];
  const workModes: AdminJobResponse["workMode"][] = [
    "HYBRID",
    "REMOTE",
    "PRESENTIEL",
  ];

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    onSearch(value);
  };

  const handleFilterToggle = (
    type: "status" | "contractType" | "workMode",
    value: string | number | undefined
  ) => {
    const currentValue = currentFilters[type];
    onFilterChange({
      ...currentFilters,
      [type]: currentValue === value ? undefined : value,
    });
  };

  const clearAllFilters = () => {
    onFilterChange({});
    setSearchQuery("");
    onSearch("");
  };

  const getActiveFiltersCount = () => {
    return Object.values(currentFilters).filter(Boolean).length;
  };

  // Fermer filtre si clic en dehors
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        filterRef.current &&
        !filterRef.current.contains(event.target as Node)
      ) {
        setShowFilters(false);
      }
    };

    if (showFilters) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }

    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showFilters]);

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      ACTIVE: "Actif",
      INACTIVE: "Inactif",
      EXPIRED: "Expiré",
      PAUSE: "En pause",
      PENDING: "En attente",
      SCHEDULED: "Programmé",
    };
    return labels[status] || status;
  };

  const getContractLabel = (contract: string) => {
    const labels: Record<string, string> = {
      CDI: "CDI",
      CDD: "CDD",
      CONTRACT_PROJECT: "Contrat projet",
      CONTRACT_ANAPEC: "Contrat ANAPEC",
    };
    return labels[contract] || contract;
  };

  const getWorkModeLabel = (mode: string) => {
    const labels: Record<string, string> = {
      HYBRID: "Hybride",
      REMOTE: "Télétravail",
      PRESENTIEL: "Présentiel",
    };
    return labels[mode] || mode;
  };

  return (
    <div className="relative">
      {/* Barre de recherche principale avec design moderne */}
      <div className="flex gap-4 mb-4">
        <div className="flex-1 relative">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <svg
              className="h-5 w-5 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              ></path>
            </svg>
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={handleSearchChange}
            placeholder="Rechercher par titre, localisation, société, département..."
            className="w-full pl-12 pr-4 py-4 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all duration-300 text-gray-900 placeholder-gray-500 shadow-sm hover:shadow-md"
          />
          {searchQuery && (
            <button
              onClick={() => {
                setSearchQuery("");
                onSearch("");
              }}
              className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600"
            >
              <svg
                className="h-5 w-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                ></path>
              </svg>
            </button>
          )}
        </div>

        {/* Bouton filtres avec compteur */}
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="relative px-6 py-4 bg-white border border-gray-200 rounded-xl hover:border-teal-300 hover:bg-teal-50 flex items-center gap-3 transition-all duration-300 shadow-sm hover:shadow-md"
        >
          <svg
            className="w-5 h-5 text-gray-600"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.207A1 1 0 013 6.5V4z"
            ></path>
          </svg>
          <span className="font-medium text-gray-700">Filtres</span>
          {getActiveFiltersCount() > 0 && (
            <span className="absolute -top-2 -right-2 bg-teal-600 text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center">
              {getActiveFiltersCount()}
            </span>
          )}
          <svg
            className={`w-4 h-4 text-gray-600 transition-transform duration-300 ${
              showFilters ? "rotate-180" : "rotate-0"
            }`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        {/* Bouton effacer filtres */}
        {(getActiveFiltersCount() > 0 || searchQuery) && (
          <button
            onClick={clearAllFilters}
            className="px-4 py-4 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-xl border border-red-200 hover:border-red-300 transition-all duration-300 flex items-center gap-2"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
              ></path>
            </svg>
            <span className="font-medium">Effacer</span>
          </button>
        )}
      </div>

      {/* Tags des filtres actifs */}
      {getActiveFiltersCount() > 0 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {currentFilters.status && (
            <div className="bg-teal-100 text-teal-800 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-2 border border-teal-200">
              <span>Statut: {getStatusLabel(currentFilters.status)}</span>
              <button
                onClick={() =>
                  handleFilterToggle("status", currentFilters.status)
                }
                className="text-teal-600 hover:text-teal-800"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M6 18L18 6M6 6l12 12"
                  ></path>
                </svg>
              </button>
            </div>
          )}
          {currentFilters.contractType && (
            <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-2 border border-blue-200">
              <span>
                Contrat: {getContractLabel(currentFilters.contractType)}
              </span>
              <button
                onClick={() =>
                  handleFilterToggle(
                    "contractType",
                    currentFilters.contractType
                  )
                }
                className="text-blue-600 hover:text-blue-800"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M6 18L18 6M6 6l12 12"
                  ></path>
                </svg>
              </button>
            </div>
          )}
          {currentFilters.workMode && (
            <div className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-2 border border-purple-200">
              <span>Mode: {getWorkModeLabel(currentFilters.workMode)}</span>
              <button
                onClick={() =>
                  handleFilterToggle("workMode", currentFilters.workMode)
                }
                className="text-purple-600 hover:text-purple-800"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M6 18L18 6M6 6l12 12"
                  ></path>
                </svg>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Panneau de filtres avec design moderne */}
      {showFilters && (
        <div className="absolute top-full left-0 right-0 mt-2 z-50">
          <div
            ref={filterRef}
            className="bg-white rounded-2xl shadow-2xl border border-gray-100 p-6 backdrop-blur-sm"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <svg
                  className="w-5 h-5 text-teal-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.207A1 1 0 013 6.5V4z"
                  ></path>
                </svg>
                Filtres Avancés
              </h3>
              <button
                onClick={() => setShowFilters(false)}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M6 18L18 6M6 6l12 12"
                  ></path>
                </svg>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Status */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                  <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
                  Statut de l'offre
                </h4>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {statuses.map((s) => (
                    <button
                      key={s}
                      onClick={() => handleFilterToggle("status", s)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all duration-200 ${
                        currentFilters.status === s
                          ? "bg-teal-100 text-teal-800 border border-teal-300 font-medium"
                          : "bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      {getStatusLabel(s || "")}
                    </button>
                  ))}
                </div>
              </div>

              {/* Type de contrat */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  Type de contrat
                </h4>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {contractTypes.map((c) => (
                    <button
                      key={c}
                      onClick={() => handleFilterToggle("contractType", c)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all duration-200 ${
                        currentFilters.contractType === c
                          ? "bg-blue-100 text-blue-800 border border-blue-300 font-medium"
                          : "bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      {getContractLabel(c || "")}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mode de travail */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  Mode de travail
                </h4>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {workModes.map((w) => (
                    <button
                      key={w}
                      onClick={() => handleFilterToggle("workMode", w)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all duration-200 flex items-center gap-2 ${
                        currentFilters.workMode === w
                          ? "bg-purple-100 text-purple-800 border border-purple-300 font-medium"
                          : "bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      {w === "REMOTE" && (
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                          ></path>
                        </svg>
                      )}
                      {w === "HYBRID" && (
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                          ></path>
                        </svg>
                      )}
                      {w === "PRESENTIEL" && (
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                          ></path>
                        </svg>
                      )}
                      <span>{getWorkModeLabel(w || "")}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions en bas du panneau */}
            <div className="flex justify-between items-center mt-6 pt-4 border-t border-gray-200">
              <div className="text-sm text-gray-600">
                {getActiveFiltersCount() > 0 && (
                  <span className="bg-teal-100 text-teal-800 px-2 py-1 rounded-full">
                    {getActiveFiltersCount()} filtre
                    {getActiveFiltersCount() > 1 ? "s" : ""} actif
                    {getActiveFiltersCount() > 1 ? "s" : ""}
                  </span>
                )}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={clearAllFilters}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors text-sm font-medium"
                >
                  Réinitialiser
                </button>
                <button
                  onClick={() => setShowFilters(false)}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg transition-colors text-sm font-medium"
                >
                  Appliquer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobSearchFilter;
