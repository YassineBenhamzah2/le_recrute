/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect } from "react";
import {
  Eye,
  Plus,
  Send,
  Upload,
  ExternalLink,
  Calendar,
  TrendingUp,
} from "lucide-react";
import TitleSection from "../CandidateComponents/TitleSection";
import ApplicationCard from "../CandidateComponents/ApplicationCard";
import { useNavigate } from "react-router-dom";
import { candidateDashboardService } from "../../lib/network/dashboard/candidate";
import {
  CandidateDashboardData,
  RecentApplication,
  UpcomingInterview,
} from "../../lib/types/dashboard/candidate";
import { useAuth } from "../../contexts/AuthContext";
import { Trans } from "@lingui/macro";

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";
import { t } from "@lingui/core/macro";
import { i18n } from "@lingui/core";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const CandidateDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState<
    "week" | "month" | "all"
  >("week");
  const [scrollIndex, setScrollIndex] = useState(0);
  const [dashboardData, setDashboardData] =
    useState<CandidateDashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // Chart data for different time periods
  const chartData = {
    week: {
      labels: (() => {
        const today = new Date();
        const currentDay = today.getDay();
        const adjustedDay = currentDay === 0 ? 6 : currentDay - 1;
        const weekDays = [
          t`Mon`,
          t`Tue`,
          t`Wed`,
          t`Thu`,
          t`Fri`,
          t`Sat`,
          t`Sun`,
        ];
        return weekDays.slice(0, adjustedDay + 1);
      })(),
      data: (() => {
        const today = new Date();
        const currentDay = today.getDay();
        const adjustedDay = currentDay === 0 ? 6 : currentDay - 1;
        return Array.from(
          { length: adjustedDay + 1 },
          () => Math.floor(Math.random() * 15) + 5
        );
      })(),
      scrollable: false,
    },
    month: {
      labels: (() => {
        const today = new Date();
        const currentDay = today.getDate();
        return Array.from({ length: currentDay }, (_, i) => `${i + 1}`);
      })(),
      data: (() => {
        const today = new Date();
        const currentDay = today.getDate();
        return Array.from(
          { length: currentDay },
          () => Math.floor(Math.random() * 20) + 5
        );
      })(),
      scrollable: true,
    },
    all: {
      labels: (() => {
        const today = new Date();
        const currentMonth = today.getMonth();
        const months = [
          t`Jan`,
          t`Feb`,
          t`Mar`,
          t`Apr`,
          t`May`,
          t`Jun`,
          t`Jul`,
          t`Aug`,
          t`Sep`,
          t`Oct`,
          t`Nov`,
          t`Dec`,
        ];
        return months.slice(0, currentMonth + 1);
      })(),
      data: (() => {
        const today = new Date();
        const currentMonth = today.getMonth() + 1;
        return Array.from(
          { length: currentMonth },
          () => Math.floor(Math.random() * 50) + 30
        );
      })(),
      scrollable: true,
    },
  };

  const currentData = chartData[selectedPeriod];
  const title = i18n._({
    id: "tS6IO5",
    message: "Welcome back, {userName}!",
    values: { userName: user?.firstname || "User" },
  });
  // Fetch dashboard data
  useEffect(() => {
    const fetchDashboardData = async () => {
      if (!user?.id) return;

      try {
        setIsLoading(true);
        setFetchError(null);
        const response = await candidateDashboardService.getDashboardData(
          user.id
        );
        setDashboardData(response.data);
      } catch (err) {
        setFetchError(t`Failed to load dashboard data`);
        console.error("Dashboard data fetch error:", err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDashboardData();
  }, [user?.id]);

  // Reset scroll index when period changes
  useEffect(() => {
    setScrollIndex(0);
  }, [selectedPeriod]);

  // Get visible data (only 7 items for scrollable views)
  const getVisibleData = () => {
    if (!currentData.scrollable) {
      return {
        labels: currentData.labels,
        data: currentData.data,
      };
    }

    const endIndex = Math.min(scrollIndex + 7, currentData.labels.length);
    return {
      labels: currentData.labels.slice(scrollIndex, endIndex),
      data: currentData.data.slice(scrollIndex, endIndex),
    };
  };

  const visibleData = getVisibleData();

  // Scroll handlers
  const canScrollLeft = scrollIndex > 0;
  const canScrollRight =
    currentData.scrollable && scrollIndex + 7 < currentData.labels.length;

  const scrollLeft = () => {
    if (canScrollLeft) {
      setScrollIndex(Math.max(0, scrollIndex - 7));
    }
  };

  const scrollRight = () => {
    if (canScrollRight) {
      setScrollIndex(Math.min(currentData.labels.length - 7, scrollIndex + 7));
    }
  };

  // Chart configuration
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: "rgba(45, 55, 72, 0.9)",
        titleColor: "white",
        bodyColor: "white",
        cornerRadius: 8,
        displayColors: false,
        callbacks: {
          title: (context: any) => {
            const label = context[0].label;
            if (selectedPeriod === "month") {
              return t`Day ${label}`;
            }
            return label;
          },
          label: (context: any) => {
            return t`Applications: ${context.parsed.y}`;
          },
        },
      },
    },
    scales: {
      y: {
        display: false,
        beginAtZero: true,
        max: Math.max(...currentData.data) + 1,
      },
      x: {
        display: true,
        grid: {
          display: false,
        },
        border: {
          display: false,
        },
        ticks: {
          color: "gray",
          font: {
            size: 11,
          },
          maxRotation: 0,
          padding: 8,
        },
        categoryPercentage: 0.95,
        barPercentage: 0.95,
      },
    },
    elements: {
      bar: {
        borderRadius: {
          topLeft: 5,
          topRight: 5,
          bottomLeft: 5,
          bottomRight: 5,
        },
      },
    },
    layout: {
      padding: {
        top: 2,
        bottom: 2,
        left: 4,
        right: 4,
      },
    },
  };

  const barChartData = {
    labels: visibleData.labels,
    datasets: [
      {
        data: visibleData.data,
        backgroundColor: (context: any) => {
          const ctx = context.chart.ctx;
          const gradient = ctx.createLinearGradient(0, 0, 0, 160);
          gradient.addColorStop(0.4, "rgba(45, 212, 191, 1)");
          gradient.addColorStop(0.6, "rgba(45, 234, 212, 0.2)");
          gradient.addColorStop(1, "rgba(45, 212, 191, 0.1)");
          return gradient;
        },
        borderWidth: 0,
        barThickness: 42,
        maxBarThickness: 44,
        borderRadius: 3,
      },
    ],
  };

  const stats = [
    {
      title: t`Tests`,
      value: dashboardData?.totals.totalTests.toString() || "0",
      change: t`+${dashboardData?.totals.testsLastWeek || 0} this week`,
      icon: Send,
      color: "bg-blue-100",
      bgColor: "bg-blue-100",
      iconColor: "text-blue-500",
      changeColor: "text-blue-600",
      changeBgColor: "bg-blue-50",
      changeTextColor: "text-blue-600",
    },
    {
      title: t`Interviews`,
      value: dashboardData?.totals.totalInterviews.toString() || "0",
      change: t`+${dashboardData?.totals.scheduledInterviews || 0} pending`,
      icon: Calendar,
      color: "bg-green-100",
      bgColor: "bg-green-100",
      iconColor: "text-green-600",
      changeColor: "text-green-600",
      changeBgColor: "bg-green-50",
      changeTextColor: "text-green-600",
    },
    {
      title: t`Response Rate`,
      value: "N/A",
      change: "N/A",
      icon: TrendingUp,
      color: "bg-purple-100",
      bgColor: "bg-purple-100",
      iconColor: "text-purple-600",
      changeColor: "text-green-600",
      changeBgColor: "bg-purple-50",
      changeTextColor: "text-purple-600",
    },
    {
      title: t`Profile Views`,
      value: "N/A",
      change: "N/A",
      icon: Eye,
      color: "bg-teal-100",
      bgColor: "bg-teal-100",
      iconColor: "text-teal-600",
      changeColor: "text-green-600",
      changeBgColor: "bg-teal-50",
      changeTextColor: "text-teal-600",
    },
  ];

  // Transform API data to component format
  const recentApplications =
    dashboardData?.recentApplications.map(
      (app: RecentApplication, index: number) => ({
        id: index + 1,
        title: app.title,
        company: app.companyName,
        location: app.location,
        type: (app.jobType === "FULL_TIME"
          ? "Full Time"
          : app.jobType === "PART_TIME"
          ? "Part Time"
          : app.jobType === "FREELANCE"
          ? "Freelance"
          : "Internship") as "Full Time" | "Part Time" | "Internship",
        salary: { min: app.minSalary, max: app.maxSalary },
        postedTime: new Date(app.publicationDate).toLocaleDateString(),
        skills: [],
        logo: app.companyLogo,
        status: "applied" as const,
      })
    ) || [];

  const upcomingInterviews =
    dashboardData?.upcomingInterviews.map(
      (interview: UpcomingInterview, index: number) => ({
        id: index + 1,
        title: interview.interviewTitle,
        company: interview.companyName,
        scheduledAt: new Date(interview.scheduledAt)
          .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
            hour12: false,
          })
          .replace(",", ""),
        type: index % 2 === 0 ? "urgent" : "normal",
        duration: interview.duration,
      })
    ) || [];

  const remainingSkills = [t`Skills`, t`Experience`, t`Portfolio`];

  type QuickAction = {
    icon: React.ComponentType<{ className?: string }>;
    label: string;
    bgColor: string;
    iconColor: string;
    onClick?: () => void;
  };

  const quickActions: QuickAction[] = [
    {
      icon: Plus,
      label: t`Apply Job`,
      bgColor: "bg-teal-200",
      iconColor: "text-teal-600",
      onClick: () => navigate("/jobs"),
    },

    {
      icon: Upload,
      label: t`Update CV`,
      bgColor: "bg-teal-50",
      iconColor: "text-teal-500",
      onClick: () => navigate("/candidate/profile"),
    },
  ];

  const handleViewAllApplications = () => {
    navigate("/candidate/applications");
  };

  const handleViewAllInterviews = () => {
    navigate("/candidate/interviews");
  };

  const handleCompleteProfile = () => {
    navigate("/candidate/profile");
  };

  // Show loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-teal-500"></div>
      </div>
    );
  }

  // Show error state
  if (fetchError) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg
                className="h-5 w-5 text-red-500"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{fetchError}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-[93%] ml-[7%]">
      {/* Welcome Message */}
      <TitleSection
        title={title}
        description={t`Track your job search progress and manage your applications`}
      />

      {/* Three Boxes Section */}
      <div className="grid grid-cols-3 gap-6 mb-10">
        {/* Left Box - Profile Completion */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 h-[21rem]">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">
              <Trans>Profile Completion</Trans>
            </h3>
            <button
              onClick={handleCompleteProfile}
              className="text-teal-600 text-sm font-medium hover:text-teal-700"
            >
              <Trans>Complete Profile</Trans>
            </button>
          </div>

          {/* Profile Completion Card */}
          <div className="bg-gradient-to-br from-teal-400 to-teal-600 rounded-xl p-4 text-white mb-3 relative overflow-hidden">
            {/* Decorative circles */}
            <div className="absolute -bottom-5 -right-4 opacity-[8%]">
              <div className="w-28 h-28 bg-white rounded-full"></div>
            </div>
            <div className="absolute -bottom-2 -right-1 opacity-[15%]">
              <div className="w-16 h-16 bg-white rounded-full"></div>
            </div>

            <h3 className="text-sm font-medium mb-3">
              <Trans>Profile Completion</Trans>
            </h3>
            <div className="mb-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl font-bold">
                  {dashboardData?.totals.profileCompletion || 40}%
                </span>
                <span className="text-xs opacity-90">
                  {dashboardData?.totals.profileCompletion || 40}/100{" "}
                  <Trans>points</Trans>
                </span>
              </div>
              <div
                className="bg-white h-1.5 rounded-full"
                style={{
                  width: `${dashboardData?.totals.profileCompletion || 40}%`,
                }}
              ></div>
            </div>
            <button
              onClick={handleCompleteProfile}
              className="w-full bg-white text-teal-600 font-medium py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors text-sm"
            >
              <Trans>Complete Profile</Trans>
            </button>
          </div>

          <p className="text-center text-gray-500 text-sm mb-3">
            <Trans>Complete remaining sections</Trans>
          </p>

          {/* Action buttons */}
          <div className="flex gap-2">
            {remainingSkills.map((skill, index) => (
              <div
                key={index}
                className="flex-1 bg-teal-50 center text-center hover:bg-teal-100 text-teal-600 py-2 px-3 rounded-lg text-xs font-medium transition-colors"
              >
                {skill}
              </div>
            ))}
          </div>
        </div>

        {/* Middle Box - Quick Actions */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 h-[15rem]">
          <h3 className="text-lg font-semibold text-gray-800 mb-6">
            <Trans>Quick Actions</Trans>
          </h3>

          <div className="flex justify-center gap-12">
            {quickActions.map((action, index) => (
              <div key={index} className="flex flex-col items-center">
                <button
                  className={`w-14 h-14 rounded-full ${action.bgColor} flex items-center justify-center mb-4 hover:scale-105 transition-transform`}
                  onClick={() => action.onClick?.()}
                >
                  <action.icon className={`w-6 h-6 ${action.iconColor}`} />
                </button>
                <span className="text-sm text-gray-500 font-medium mt-4">
                  {action.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right Box - Application Progress Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 h-[15rem]">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">
              <Trans>Application Progress</Trans>
            </h3>
            <button className="flex items-center text-teal-600 text-sm font-medium hover:text-teal-700">
              <Trans>View All</Trans>
              <ExternalLink className="w-3 h-3 ml-1" />
            </button>
          </div>

          {/* Period Toggle Buttons */}
          <div className="flex gap-1 mb-4">
            {(["week", "month", "all"] as const).map((period) => (
              <button
                key={period}
                onClick={() => setSelectedPeriod(period)}
                className={`px-2 py-1 text-xs font-medium transition-colors ${
                  selectedPeriod === period
                    ? "text-gray-900 border-b-2 border-[#2da5b3]"
                    : "text-gray-400 hover:text-gray-900"
                }`}
              >
                {period === "week" ? (
                  <Trans>This Week</Trans>
                ) : period === "month" ? (
                  <Trans>This Month</Trans>
                ) : (
                  <Trans>All Time</Trans>
                )}
              </button>
            ))}
          </div>

          {/* Chart Container with Scroll */}
          <div className="relative">
            {currentData.scrollable && (
              <>
                <button
                  onClick={scrollLeft}
                  disabled={!canScrollLeft}
                  className={`absolute left-[-5%] top-1/2 -translate-y-1/2 z-10 w-6 h-6 bg-white shadow-md rounded-full flex items-center justify-center transition-colors ${
                    canScrollLeft
                      ? "text-gray-600 hover:text-gray-900"
                      : "text-gray-300 cursor-not-allowed"
                  }`}
                >
                  ←
                </button>
                <button
                  onClick={scrollRight}
                  disabled={!canScrollRight}
                  className={`absolute right-[-5%] top-1/2 -translate-y-1/2 z-10 w-6 h-6 bg-white shadow-md rounded-full flex items-center justify-center transition-colors ${
                    canScrollRight
                      ? "text-gray-600 hover:text-gray-900"
                      : "text-gray-300 cursor-not-allowed"
                  }`}
                >
                  →
                </button>
              </>
            )}
            <div className="h-32">
              <Bar data={barChartData} options={chartOptions} />
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="bg-white rounded-xl p-6 max-h-[9rem] shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${stat.bgColor}`}>
                  <stat.icon className={`h-5 w-5 ${stat.iconColor}`} />
                </div>
                <h3 className="text-lg font-semibold text-gray-600">
                  {stat.title}
                </h3>
              </div>
              <button className="text-gray-400 hover:text-gray-600">
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zM13 12a1 1 0 11-2 0 1 1 0 012 0zM20 12a1 1 0 11-2 0 1 1 0 012 0z"
                  />
                </svg>
              </button>
            </div>
            <div className="flex items-center justify-start gap-4">
              <p className="text-2xl font-semibold text-gray-900">
                {stat.value}
              </p>
              <span
                className={`inline-block ${stat.changeBgColor} ${stat.changeTextColor} text-sm font-medium px-4 py-2 rounded-lg`}
              >
                {stat.change}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Two Boxes Section - 66% and 33% */}
      <div className="grid grid-cols-3 gap-6">
        {/* Left Box - 66% (2/3 of the grid) */}
        <div className="col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6 h-64">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">
              <Trans>Recent Applications</Trans>
            </h3>
            <button
              onClick={handleViewAllApplications}
              className="text-teal-600 text-sm font-medium hover:text-teal-700 flex items-center gap-1"
            >
              <Trans>View All</Trans>
              <svg
                className="w-3 h-3"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                />
              </svg>
            </button>
          </div>

          <div className="overflow-y-auto h-44">
            {recentApplications.map((job) => (
              <ApplicationCard
                key={job.id}
                id={job.id}
                title={job.title}
                company={job.company}
                location={job.location}
                type={job.type}
                salary={job.salary}
                postedTime={job.postedTime}
                skills={job.skills}
                logo={job.logo}
                status={job.status}
                isExpandable={false}
                bookmarkable={false}
              />
            ))}
          </div>
        </div>

        {/* Right Box - 33% (1/3 of the grid) */}
        <div className="col-span-1 bg-white rounded-xl shadow-sm border border-gray-100 p-6 h-70 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">
              <Trans>Upcoming Interviews</Trans>
            </h3>
            <button
              onClick={handleViewAllInterviews}
              className="text-teal-600 text-sm font-medium hover:text-teal-700 flex items-center gap-1"
            >
              <Trans>View All</Trans>
              <svg
                className="w-3 h-3"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                />
              </svg>
            </button>
          </div>

          <div className="space-y-3">
            {upcomingInterviews.map((interview) => (
              <div
                key={interview.id}
                className={`p-3 rounded-lg border-2 ${
                  interview.type === "urgent"
                    ? "bg-teal-50 border-teal-200"
                    : "bg-gray-50 border-gray-200"
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-semibold text-gray-800 text-sm">
                    {interview.title}
                  </h4>
                  <span
                    className={`text-xs px-2 py-1 rounded-md font-medium ${
                      interview.type === "urgent"
                        ? "bg-teal-200 text-teal-700"
                        : "bg-gray-200 text-gray-600"
                    }`}
                  >
                    {interview.scheduledAt}
                  </span>
                </div>

                <p className="text-sm text-gray-600 mb-2">
                  {interview.company}
                </p>

                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <svg
                    className="w-3 h-3"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  {interview.duration}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateDashboard;
