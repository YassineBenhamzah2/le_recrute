import { useEffect, useState } from "react";
import {
  Users,
  Briefcase,
  TrendingUp,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import EmployeeManagement from "./EmployeeManagement";
import ReportedEmployees from "./ReportedEmployees";
import AllAdmins from "./AllAdmins";
import AllCandidates from "./AllCandidates";
import AdminRoles from "./AdminRoles";
import { dashboardAdminService } from "../../lib/network/dashboard/adminDashboard";
import {
  AnalyticsCardProps,
  DashboardDTO,
} from "../../lib/types/dashboard/adminDashboard";

import AdmCVtheque from "./AdminComponents/CVthequeAdmin";
import AdminAnalyticsPage from "./AdminComponents/AdminAnalyticsPage";
import { Trans, t } from '@lingui/macro';

function AnalyticsCard({
  title,
  value,
  subtitle,
  trend,
  icon,
  gradient,
  chartColor,
}: AnalyticsCardProps) {
  const isPositive = trend >= 0;

  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 relative overflow-hidden">
      <div className="flex items-start justify-between mb-4">
        <div className={`p-3 rounded-2xl ${gradient}`}>{icon}</div>
      </div>

      <div className="space-y-2 mb-4">
        <h3 className="text-2xl font-bold text-gray-900">{value}</h3>
        <p className="text-gray-600 font-medium text-sm">{title}</p>
        <div
          className={`flex items-center space-x-1 text-sm ${isPositive ? "text-[#238D94]" : "text-red-500"
            }`}
        >
          {isPositive ? (
            <ArrowUpRight size={14} />
          ) : (
            <ArrowDownRight size={14} />
          )}
          <span className="font-semibold">{Math.abs(trend)}%</span>
          <span className="text-gray-500">{subtitle}</span>
        </div>
      </div>

      {/* Mini Chart Visualization */}
      <div className="relative h-16 mt-4">
        <svg className="w-full h-full" viewBox="0 0 200 60">
          <defs>
            <linearGradient
              id={`gradient-${title}`}
              x1="0%"
              y1="0%"
              x2="0%"
              y2="100%"
            >
              <stop offset="0%" stopColor={chartColor} stopOpacity="0.3" />
              <stop offset="100%" stopColor={chartColor} stopOpacity="0.05" />
            </linearGradient>
          </defs>
          <path
            d="M0,45 Q25,35 50,40 T100,30 T150,35 T200,25"
            stroke={chartColor}
            strokeWidth="2"
            fill="none"
            className="drop-shadow-sm"
          />
          <path
            d="M0,45 Q25,35 50,40 T100,30 T150,35 T200,25 L200,60 L0,60 Z"
            fill={`url(#gradient-${title})`}
          />
        </svg>
      </div>
    </div>
  );
}

import { SpendingCardProps } from "../../lib/types/dashboard/adminDashboard";

function SpendingCard({
  title,
  amount,
  period,
  trend,
  gradient,
}: SpendingCardProps) {
  return (
    <div
      className={`${gradient} rounded-3xl p-6 text-white relative overflow-hidden`}
    >
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white/80 font-medium text-sm">{title}</h3>
          <div className="flex items-center space-x-1 bg-white/20 px-2 py-1 rounded-full text-xs">
            <ArrowUpRight size={12} />
            <span>{trend}%</span>
          </div>
        </div>
        <div className="space-y-1">
          <p className="text-2xl font-bold">{amount}</p>
          <p className="text-white/70 text-sm">{period}</p>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/10 rounded-full"></div>
      <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/5 rounded-full"></div>
    </div>
  );
}

import { ServiceItemProps } from "../../lib/types/dashboard/adminDashboard";

function ServiceItem({ name, percentage, amount, color }: ServiceItemProps) {
  return (
    <div className="flex items-center justify-between py-3">
      <div className="flex items-center space-x-3">
        <div className={`w-3 h-3 rounded-full ${color}`}></div>
        <span className="text-gray-700 font-medium">{name}</span>
      </div>
      <div className="text-right">
        <p className="text-gray-900 font-semibold">{amount}</p>
        <p className="text-gray-500 text-sm">{percentage}</p>
      </div>
    </div>
  );
}

import { AdminDashboardProps } from "../../lib/types/dashboard/adminDashboard";

function AdminDashboard({ section = "dashboard" }: AdminDashboardProps) {
  // Handle different sections
  const getSectionTitle = () => {
    switch (section) {
      case "admins":
        return t({ id: "admin_dashboard.sections.admins.title", message: "Admin Management" });
      case "analytics":
        return t({ id: "admin_dashboard.sections.analytics.title", message: "Admin Analytics" });
      case "employees":
        return t({ id: "admin_dashboard.sections.employees.title", message: "Employee Analytics" });
      case "companies":
        return t({ id: "admin_dashboard.sections.companies.title", message: "Company Analytics" });
      case "jobs":
        return t({ id: "admin_dashboard.sections.jobs.title", message: "Job Analytics" });
      case "cvtheque":
        return t({ id: "admin_dashboard.sections.cvtheque.title", message: "Manage your job postings efficiently" });
      default:
        return t({ id: "admin_dashboard.sections.default.title", message: "Analytics Overview" });
    }
  };

  const getSectionSubtitle = () => {
    switch (section) {
      case "admins":
        return t({ id: "admin_dashboard.sections.admins.subtitle", message: "Manage administrators and their permissions" });
      case "analytics":
        return t({ id: "admin_dashboard.sections.analytics.subtitle", message: "Monitor global platform performance, recruitment activity, and user engagement in real time" });
      case "employees":
        return t({ id: "admin_dashboard.sections.employees.subtitle", message: "Track employee performance and engagement" });
      case "companies":
        return t({ id: "admin_dashboard.sections.companies.subtitle", message: "Monitor company metrics and growth" });
      case "jobs":
        return t({ id: "admin_dashboard.sections.jobs.subtitle", message: "Analyze job postings and applications" });
      case "cvtheque":
        return t({ id: "admin_dashboard.sections.cvtheque.subtitle", message: "Manage your job postings efficiently" });
      default:
        return t({ id: "admin_dashboard.sections.default.subtitle", message: "Track your business performance and insights" });
    }
  };

  // Dynamic data fetched from backend

  const [dashboard, setDashboard] = useState<DashboardDTO>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStats = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await dashboardAdminService.getStats();
        setDashboard(res);
      } catch (err: unknown) {
        const msg =
          err instanceof Error ? err.message : t({ id: "admin_dashboard.errors.load_failed", message: "Failed to load dashboard data" });
        setError(msg);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  // If employees section is selected, render EmployeeManagement component
  if (section === "employees") {
    return <EmployeeManagement />;
  }

  // If reported-employees section is selected, render ReportedEmployees component
  if (section === "reported-employees") {
    return <ReportedEmployees />;
  }

  // If analytics section is selected, render AdminAnalytics component
  if (section === "analytics") {
    return <AdminAnalyticsPage />;
  }

  // If cvtheque section is selected, render AdmCVtheque component
  if (section === "cvtheque") {
    return <AdmCVtheque />;
  }

  if (section === "all-admins") {
    return <AllAdmins />;
  }
  if (section === "front-cms") {
    return <AllAdmins />;
  }

  if (section === "all-candidates") {
    return <AllCandidates />;
  }

  if (section === "admin-roles") {
    return <AdminRoles />;
  }

  // Placeholder for AllBlogs component that doesn't exist yet
  if (section === "all-blogs") {
    return (
      <div>
        <Trans id="admin_dashboard.placeholders.all_blogs">All Blogs Component Placeholder</Trans>
      </div>
    );
  }

  // Show a simple loading state while fetching dashboard data
  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-600">
          <Trans id="admin_dashboard.loading.dashboard">Loading dashboard...</Trans>
        </div>
      </div>
    );
  }

  // Show error if fetch failed
  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="bg-red-50 border border-red-200 text-red-800 rounded-lg p-4">
          {error}
        </div>
      </div>
    );
  }

  const analyticsData = [
    {
      title: t({ id: "admin_dashboard.analytics.total_users", message: "Total Users" }),
      value: dashboard?.totalUsers?.value ?? "—",
      subtitle: t({ id: "admin_dashboard.analytics.vs_last_month", message: "vs last month" }),
      trend: 0,
      icon: <Users className="text-white" size={20} />,
      gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
      chartColor: "#238D94",
    },
    {
      title: t({ id: "admin_dashboard.analytics.revenue", message: "Revenue" }),
      value: dashboard?.revenue?.value ?? "—",
      subtitle: t({ id: "admin_dashboard.analytics.vs_last_month", message: "vs last month" }),
      trend: 0,
      icon: <DollarSign className="text-white" size={20} />,
      gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
      chartColor: "#238D94",
    },
    {
      title: t({ id: "admin_dashboard.analytics.active_jobs", message: "Active Jobs" }),
      value: dashboard?.activeJobs?.value ?? "—",
      subtitle: t({ id: "admin_dashboard.analytics.vs_last_month", message: "vs last month" }),
      trend: 0,
      icon: <Briefcase className="text-white" size={20} />,
      gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
      chartColor: "#238D94",
    },
    {
      title: t({ id: "admin_dashboard.analytics.growth_rate", message: "Growth Rate" }),
      value: dashboard?.growthRate?.value ?? "—",
      subtitle: t({ id: "admin_dashboard.analytics.vs_last_month", message: "vs last month" }),
      trend: 0,
      icon: <TrendingUp className="text-white" size={20} />,
      gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
      chartColor: "#238D94",
    },
  ];

  const spendingData = [
    {
      title: t({ id: "admin_dashboard.spending.jobs", message: "Jobs" }),
      amount:
        typeof dashboard?.jobsSpendingThisMonth !== "undefined"
          ? String(dashboard?.jobsSpendingThisMonth)
          : "$—",
      period: t({ id: "admin_dashboard.spending.this_month", message: "This month" }),
      trend: 0,
      gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
    },
    {
      title: t({ id: "admin_dashboard.spending.actual_spend", message: "ACTUAL SPEND" }),
      amount:
        typeof dashboard?.actualSpendThisMonth !== "undefined"
          ? String(dashboard?.actualSpendThisMonth)
          : "$—",
      period: t({ id: "admin_dashboard.spending.current_month", message: "Current month" }),
      trend: 0,
      gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
    },
  ];

  const defaultColors = [
    "bg-[#3B82F6]",
    "bg-[#A855F7]",
    "bg-[#14B8A6]",
    "bg-[#10B981]",
  ];
  const serviceData = dashboard?.topServices?.map((s, i) => ({
    name: s.serviceName,
    percentage: `${Math.round((s.percentageOfTotal ?? 0) * 10) / 10}%`,
    amount:
      typeof s.totalRevenue === "number"
        ? `$${s.totalRevenue}`
        : String(s.totalRevenue),
    color: defaultColors[i % defaultColors.length],
  })) ?? [{ name: "—", percentage: "—", amount: "—", color: "bg-[#3B82F6]" }];

  const dailyMetrics = [
    {
      label: t({ id: "admin_dashboard.metrics.average_daily_cost", message: "Average Daily Cost" }),
      value: dashboard?.averageDailyCost
        ? String(dashboard.averageDailyCost)
        : "$—",
    },
    {
      label: t({ id: "admin_dashboard.metrics.yesterday_spend", message: "Yesterday's Spend" }),
      value: dashboard?.yesterdaySpend
        ? String(dashboard.yesterdaySpend)
        : "$—",
    },
    {
      label: t({ id: "admin_dashboard.metrics.last_month_spend", message: "Last Month's Spend" }),
      value: dashboard?.lastMonthSpend
        ? String(dashboard.lastMonthSpend)
        : "$—",
    },
    {
      label: t({ id: "admin_dashboard.metrics.currency_yearly", message: "Currency Yearly" }),
      value: dashboard?.currencyYearly
        ? String(dashboard.currencyYearly)
        : "$—",
    },
  ];

  // Prepare post statistics (sorted by date) for charting
  const postEntries = dashboard?.postStatistics
    ? Object.entries(dashboard.postStatistics).sort((a, b) =>
      a[0].localeCompare(b[0])
    )
    : [];
  const postCounts = postEntries.map(([, count]) => Number(count));
  const totalPosts = postCounts.length
    ? postCounts.reduce((s, n) => s + n, 0)
    : 0;

  // Build a simple sparkline path if we have points
  const sparkline = (() => {
    if (!postCounts.length) return { path: "", max: 0 };
    const w = 300;
    const h = 120;
    const pad = 8;
    const max = Math.max(...postCounts, 1);
    const step = postCounts.length > 1 ? w / (postCounts.length - 1) : w;
    const points = postCounts.map((v, i) => {
      const x = Math.round(i * step);
      const y = Math.round(h - pad - (v / max) * (h - pad * 2));
      return `${x},${y}`;
    });
    const path = `M${points.join(" L")}`;
    const area = `${path} L ${w},${h} L 0,${h} Z`;
    return { path, area, max };
  })();

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              {getSectionTitle()}
            </h1>
            <p className="text-lg text-gray-600">{getSectionSubtitle()}</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex bg-white rounded-2xl p-1 shadow-sm border border-gray-200">
              <button className="px-6 py-2 bg-gradient-to-r from-[#238D94] to-[#1a6b72] text-white rounded-xl font-medium text-sm">
                <Trans id="admin_dashboard.navigation.overview">Overview</Trans>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Top Row - Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {analyticsData.map((item, index) => (
          <AnalyticsCard key={index} {...item} />
        ))}
      </div>

      {/* Second Row - Spending Cards and Services */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        {/* Left: Spending Overview + Daily Metrics */}
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {spendingData.map((item, index) => (
              <SpendingCard key={index} {...item} />
            ))}
          </div>

          {/* Daily Metrics */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <span className="text-2xl font-bold text-gray-900">
                {totalPosts.toLocaleString()}
              </span>
              <div className="text-sm text-gray-500">
                <Trans id="admin_dashboard.metrics.post_statistics">Post Statistics</Trans>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {dailyMetrics.map((metric, index) => (
                <div key={index} className="space-y-2">
                  <p className="text-sm text-gray-500">{metric.label}</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-xl font-bold text-gray-900">
                      {metric.value}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Sparkline chart below the metrics */}
            <div className="h-32 relative mt-6">
              {sparkline.path ? (
                <svg
                  className="w-full h-full"
                  viewBox={`0 0 300 120`}
                  preserveAspectRatio="none"
                >
                  <defs>
                    <linearGradient
                      id="savings-gradient"
                      x1="0%"
                      y1="0%"
                      x2="0%"
                      y2="100%"
                    >
                      <stop offset="0%" stopColor="#238D94" stopOpacity="0.3" />
                      <stop
                        offset="100%"
                        stopColor="#238D94"
                        stopOpacity="0.05"
                      />
                    </linearGradient>
                  </defs>
                  <path
                    d={sparkline.path}
                    stroke="#238D94"
                    strokeWidth="2"
                    fill="none"
                  />
                  <path d={sparkline.area} fill="url(#savings-gradient)" />
                </svg>
              ) : (
                <div className="flex items-center justify-center h-32 text-sm text-gray-400">
                  <Trans id="admin_dashboard.charts.no_post_statistics">No post statistics available</Trans>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column - Top Services */}
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              <Trans id="admin_dashboard.services.top_services">Top Services</Trans>
            </h3>
            <div className="space-y-2">
              {serviceData.map((s, i) => (
                <ServiceItem
                  key={i}
                  name={s.name}
                  percentage={s.percentage}
                  amount={s.amount}
                  color={s.color}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row - Charts and Widgets */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-10">
        {/* Posts Statistics */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">
              <Trans id="admin_dashboard.charts.posts_statistics">Posts Statistics</Trans>
            </h3>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-gray-900">
                {totalPosts.toLocaleString()}
              </span>
              <div className="flex items-center space-x-2 text-sm">
                <div className="w-3 h-3 bg-[#238D94] rounded-full"></div>
                <span className="text-gray-600">
                  <Trans id="admin_dashboard.charts.post_jobs">Post Jobs</Trans>
                </span>
              </div>
            </div>

            {/* Chart Area */}
            <div className="h-32 relative">
              {sparkline.path ? (
                <svg
                  className="w-full h-full"
                  viewBox="0 0 300 120"
                  preserveAspectRatio="none"
                >
                  <defs>
                    <linearGradient
                      id="savings-gradient"
                      x1="0%"
                      y1="0%"
                      x2="0%"
                      y2="100%"
                    >
                      <stop offset="0%" stopColor="#238D94" stopOpacity="0.3" />
                      <stop
                        offset="100%"
                        stopColor="#238D94"
                        stopOpacity="0.05"
                      />
                    </linearGradient>
                  </defs>
                  <path
                    d={sparkline.path}
                    stroke="#238D94"
                    strokeWidth="3"
                    fill="none"
                  />
                  <path d={sparkline.area} fill="url(#savings-gradient)" />
                </svg>
              ) : (
                <div className="flex items-center justify-center h-32 text-sm text-gray-400">
                  <Trans id="admin_dashboard.charts.no_post_statistics">No post statistics available</Trans>
                </div>
              )}
            </div>

            <p className="text-sm text-gray-500">
              <Trans id="admin_dashboard.charts.ri_usage">RI Usage</Trans>
            </p>
          </div>
        </div>

        {/* Total Registered Users */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">
              <Trans id="admin_dashboard.users.total_active_users">Total Active Users</Trans>
            </h3>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-gray-900">
                {dashboard?.totalActiveUsers ?? 0}
              </span>
              <div className="flex items-center space-x-2 text-sm">
                <div className="w-3 h-3 bg-[#238D94] rounded-full"></div>
                <span className="text-gray-600">
                  <Trans id="admin_dashboard.users.save">Save</Trans>
                </span>
              </div>
            </div>

            {/* Circular Progress */}
            <div className="flex items-center justify-center">
              <div className="relative w-24 h-24">
                <svg
                  className="w-24 h-24 transform -rotate-90"
                  viewBox="0 0 100 100"
                >
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="#F3F4F6"
                    strokeWidth="8"
                    fill="none"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="#238D94"
                    strokeWidth="8"
                    fill="none"
                    strokeDasharray={`${40 * 2 * Math.PI}`}
                    strokeDashoffset={`${40 * 2 * Math.PI * (1 - 0.4)}`}
                    className="transition-all duration-1000"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-lg font-bold text-gray-900">40%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;
