import { candidatService } from "@/lib/network/candidat";
import { interviewService } from "@/lib/network/interview";
import { CandidateScoreRequest, Interview } from "@/lib/types/interview";
import { t, Trans } from "@lingui/macro";
import {
  CalendarIcon,
  CheckCircleIcon,
  ClockIcon,
  UserCircleIcon,
} from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { EditInterview } from "./recruiterComponents/EditInterview";
import { InterviewActionsSection } from "./recruiterComponents/InterviewActionsSection";
import { InterviewDashboardSection } from "./recruiterComponents/InterviewDashboardSection";
import { InterviewListSection } from "./recruiterComponents/InterviewListSection";
import { InterviewStatsSection } from "./recruiterComponents/InterviewStatsSection";
import {
  CandidateInfo,
  ScoreCandidate,
} from "./recruiterComponents/ScoreCandidate";

// Helper function to map API interview to component interview
const mapApiInterviewToInterview = (apiInterview: Interview): Interview => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("fr-FR");
  };

  const mapStatus = (
    apiStatus: string
  ): "Scheduled" | "Completed" | "Cancelled" | "Pending" => {
    switch (apiStatus) {
      case "SCHEDULED":
        return "Scheduled";
      case "COMPLETED":
        return "Completed";
      case "CANCELLED":
        return "Cancelled";
      default:
        return "Pending";
    }
  };

  return {
    ...apiInterview,
    // Use candidate name from API if available, otherwise fallback to name field
    name: apiInterview.candidate?.name || apiInterview.name,
    // Use job offer title as position if available, otherwise fallback to position field
    position: apiInterview.jobOffer?.title || apiInterview.position,
    status: mapStatus(apiInterview.status),
    date: formatDate(apiInterview.date),
    time: apiInterview.time,
  };
};

const RecruiterInterviewDashboard = (): JSX.Element => {
  // Move translation inside component to avoid Lingui initialization error
  const initialFilterStatuses = [
    { id: "all", label: t`All Interviews`, selected: true },
    { id: "scheduled", label: t`Scheduled`, selected: false },
    { id: "completed", label: t`Completed`, selected: false },
  ];

  // Loading states
  const [loading, setLoading] = useState<boolean>(true);
  const [interviewsLoading, setInterviewsLoading] = useState<boolean>(false);
  const [fetchingScore, setFetchingScore] = useState<boolean>(false);

  // Data states
  const [interviews, setInterviews] = useState<Interview[]>([]);
  // Initialize stats with default labels (will be updated with translations in useEffect)
  const [stats, setStats] = useState([
    {
      title: t`Total Interviews`,
      count: "0",
      icon: <CalendarIcon className="h-6 w-6 text-white" />,
      bgColor: "bg-blue-50",
      iconBgColor: "bg-[#238d94]",
    },
    {
      title: t`Scheduled`,
      count: "0",
      icon: <ClockIcon className="h-6 w-6 text-white" />,
      bgColor: "bg-[#14b8a626]",
      iconBgColor: "bg-[#238d94]",
    },
    {
      title: t`Completed`,
      count: "0",
      icon: <CheckCircleIcon className="h-6 w-6 text-white" />,
      bgColor: "bg-green-50",
      iconBgColor: "bg-[#238d94]",
    },
    {
      title: t`Today`,
      count: "0",
      icon: <UserCircleIcon className="h-6 w-6 text-white" />,
      bgColor: "bg-purple-50",
      iconBgColor: "bg-[#238d94]",
    },
  ]);

  const [filterStatuses, setFilterStatuses] = useState(initialFilterStatuses);
  const [interview, setInterview] = useState<Interview>({
    id: 0,
    name: "",
    position: "",
    status: "Pending",
    type: "",
    date: "",
    time: "",
    interviewers: [],
    meetingLink: "",
    showActions: true,
    notes: "",
    juryFeedback: {
      observations: "",
      decision: "pending",
    },
    candidate: {
      id: 0,
      name: "",
      email: "",
      whatsapp_number: "",
      cv: "",
      motivationLetter: "",
      status: "EN_COURS",
      createdAt: "",
    },
    // Required Interview fields with default values
    candidateName: "",
    jobTitle: "",
    scheduledAt: "",
    endedAt: "",
    interviewType: "",
    address: "",
    myStatus: "SCHEDULED", // Default to scheduled
    interviewTitle: "",
    companyName: "",
    companyLogo: "",
    videoLink: "",
    round: "",
    cancelReason: "",
    duration: "",
    jobOffer: undefined,
  });

  const [mockScore, setMockScore] = useState({
    diplomaMatch: "4",
    experienceMatch: "3",
    profileScore: "4",
    technicalSkills: "5",
    softSkills: "4",
    overAllScore: "0", // Read-only field from API
  });

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedCandidate, setSelectedCandidate] =
    useState<CandidateInfo | null>(null);
  const [showScoreModal, setShowScoreModal] = useState(false);

  // Fetch interviews from API
  const fetchInterviews = useCallback(async (showLoadingIndicator = true) => {
    try {
      if (showLoadingIndicator) {
        setInterviewsLoading(true);
      }
      const response = await interviewService.getRecruiterInterviews();

      if (response.success && response.data) {
        const mappedInterviews = response.data.map(mapApiInterviewToInterview);
        setInterviews(mappedInterviews);
        updateStats(mappedInterviews);
      } else {
        toast.error(<Trans>Failed to fetch interviews</Trans>);
        setInterviews([]);
      }
    } catch (error) {
      console.error("Error fetching interviews:", error);
      toast.error(<Trans>Error fetching interviews</Trans>);
      setInterviews([]);
    } finally {
      if (showLoadingIndicator) {
        setInterviewsLoading(false);
      }
    }
  }, []);

  // Expose refresh function globally so other components can call it
  useEffect(() => {
    // Store the refresh function globally with proper typing
    (
      window as Window & { refreshRecruiterInterviews?: () => Promise<void> }
    ).refreshRecruiterInterviews = () => fetchInterviews(false);

    return () => {
      // Clean up when component unmounts
      delete (
        window as Window & { refreshRecruiterInterviews?: () => Promise<void> }
      ).refreshRecruiterInterviews;
    };
  }, [fetchInterviews]);

  // Update stats based on interviews data - using Trans for runtime translation
  const updateStats = (interviewsData: Interview[]) => {
    const totalCount = interviewsData.length;
    const scheduledCount = interviewsData.filter(
      (int) => int.status === "Scheduled"
    ).length;
    const completedCount = interviewsData.filter(
      (int) => int.status === "Completed"
    ).length;

    // Count today's interviews
    const today = new Date().toLocaleDateString("fr-FR");
    const todayCount = interviewsData.filter(
      (int) => int.date === today
    ).length;

    setStats([
      {
        title: t`Total Interviews`,
        count: totalCount.toString(),
        icon: <CalendarIcon className="h-6 w-6 text-white" />,
        bgColor: "bg-blue-50",
        iconBgColor: "bg-[#238d94]",
      },
      {
        title: t`Scheduled`,
        count: scheduledCount.toString(),
        icon: <ClockIcon className="h-6 w-6 text-white" />,
        bgColor: "bg-[#14b8a626]",
        iconBgColor: "bg-[#238d94]",
      },
      {
        title: t`Completed`,
        count: completedCount.toString(),
        icon: <CheckCircleIcon className="h-6 w-6 text-white" />,
        bgColor: "bg-green-50",
        iconBgColor: "bg-[#238d94]",
      },
      {
        title: t`Today`,
        count: todayCount.toString(),
        icon: <UserCircleIcon className="h-6 w-6 text-white" />,
        bgColor: "bg-purple-50",
        iconBgColor: "bg-[#238d94]",
      },
    ]);
  };

  // Initial data loading
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await fetchInterviews();
      setLoading(false);
    };

    loadData();
  }, [fetchInterviews]);

  // Filter and utility functions
  const getSelectedFilter = () =>
    filterStatuses.find((f) => f.selected)?.id || "all";

  const filteredInterviews = () => {
    const selected = getSelectedFilter();
    return selected === "all"
      ? interviews
      : interviews.filter((int) => int.status.toLowerCase() === selected);
  };

  const handleFilterChange = (selectedId: string) => {
    setFilterStatuses((prev) =>
      prev.map((item) => ({ ...item, selected: item.id === selectedId }))
    );
  };

  // Interview action handlers
  const handleEditInterview = (id: number) => {
    setIsEditModalOpen(true);
    const interviewToEdit = interviews.find((int) => int.id === id);
    if (interviewToEdit) {
      setInterview(interviewToEdit);
    }
  };

  const handleCompleteInterview = async (id: number) => {
    try {
      const response = await interviewService.updateInterviewStatus(id, {
        status: "COMPLETED",
      });

      if (response.success) {
        setInterviews((prev) =>
          prev.map((int) =>
            int.id === id ? { ...int, status: "Completed" } : int
          )
        );

        // Update stats
        const updatedInterviews = interviews.map((int) =>
          int.id === id ? { ...int, status: "Completed" as const } : int
        );
        updateStats(updatedInterviews);

        toast.success(<Trans>Interview marked as completed</Trans>);
      } else {
        toast.error(<Trans>Failed to complete interview</Trans>);
      }
    } catch (error) {
      console.error("Error completing interview:", error);
      toast.error(<Trans>Error completing interview</Trans>);
    }
  };

  const handleCancelInterview = async (id: number) => {
    try {
      const response = await interviewService.updateInterviewStatus(id, {
        status: "CANCELLED",
      });

      if (response.success) {
        setInterviews((prev) =>
          prev.map((int) =>
            int.id === id ? { ...int, status: "Cancelled" } : int
          )
        );

        // Update stats
        const updatedInterviews = interviews.map((int) =>
          int.id === id ? { ...int, status: "Cancelled" as const } : int
        );
        updateStats(updatedInterviews);

        toast.success(<Trans>Interview cancelled</Trans>);
      } else {
        toast.error(<Trans>Failed to cancel interview</Trans>);
      }
    } catch (error) {
      console.error("Error cancelling interview:", error);
      toast.error(<Trans>Error cancelling interview</Trans>);
    }
  };

  const handleCandidateScoring = async (id: number) => {
    const interview = interviews.find((int) => int.id === id);
    if (interview) {
      // Now we can use the real candidate data from the interview
      const candidateInfo = interview.candidate;
      const jobOfferInfo = interview.jobOffer;

      setSelectedCandidate({
        id: candidateInfo?.id || interview.id,
        name: candidateInfo?.name || interview.name,
        position: jobOfferInfo?.title || interview.position,
        interviewDate: interview.date,
        interviewers: interview.interviewers,
        lastUpdatedBy: t`HR Manager`,
        lastUpdatedDate: new Date().toISOString(),
        jobOfferId: jobOfferInfo?.id || 0, // Add jobOfferId to keep track of it
      });

      // Fetch existing candidate score if available
      try {
        setFetchingScore(true);

        // Now using the real candidate ID and job offer ID from the API
        const candidateId = candidateInfo?.id || interview.id;
        const jobOfferId = jobOfferInfo?.id || 1;

        console.log(
          `Fetching existing scores for candidate ${candidateId} in job ${jobOfferId}`
        );

        const scoreResponse = await candidatService.getCandidateScore(
          candidateId,
          jobOfferId
        );

        if (scoreResponse.success && scoreResponse.data) {
          console.log("Existing scores found:", scoreResponse.data);

          // Map the API response to the form structure
          setMockScore({
            diplomaMatch: scoreResponse.data.diplomaScore.toString(),
            experienceMatch: scoreResponse.data.experienceScore.toString(),
            profileScore: "0", // This field doesn't exist in API, so we keep it as 0
            technicalSkills: scoreResponse.data.technicalSkillScore.toString(),
            softSkills: scoreResponse.data.softSkillScore.toString(),
            overAllScore: scoreResponse.data.overAllScore.toString(), // Read-only overall score from API
          });

          toast.success(<Trans>Previous scores loaded successfully</Trans>);
        } else {
          console.log("No existing scores found, using defaults");
          // No existing scores, use defaults
          setMockScore({
            diplomaMatch: "0",
            experienceMatch: "0",
            profileScore: "0",
            technicalSkills: "0",
            softSkills: "0",
            overAllScore: "0", // Default overall score when no existing scores
          });
        }
      } catch (error) {
        console.error("Error fetching candidate score:", error);

        // On error, use default scores and show a warning
        setMockScore({
          diplomaMatch: "0",
          experienceMatch: "0",
          profileScore: "0",
          technicalSkills: "0",
          softSkills: "0",
          overAllScore: "0", // Default overall score on error
        });

        // Only show error if it's not a 404 (meaning no scores exist yet)
        if (
          error &&
          typeof error === "object" &&
          "status" in error &&
          error.status !== 404
        ) {
          toast.error(
            <Trans>Could not load existing scores, using defaults</Trans>
          );
        }
      } finally {
        setFetchingScore(false);
      }

      setShowScoreModal(true);
    }
  };

  const handleCandidateScoringSubmit = async (formData: FormData) => {
    if (!selectedCandidate) return;

    try {
      // Extract scoring data from form
      const diplomaScore =
        parseInt(formData.get("diplomaMatch") as string) || 0;
      const experienceScore =
        parseInt(formData.get("experienceMatch") as string) || 0;
      const technicalSkillScore =
        parseInt(formData.get("technicalSkills") as string) || 0;
      const softSkillScore =
        parseInt(formData.get("softSkills") as string) || 0;

      // Use the real candidate ID from the selected candidate (which now comes from API)
      const candidateId = selectedCandidate.id;

      // Prepare the score request data
      const scoreData: CandidateScoreRequest = {
        candidateId,
        diplomaScore,
        experienceScore,
        technicalSkillScore,
        softSkillScore,
      };

      console.log("Submitting candidate score:", scoreData);

      // Call the API to update candidate score
      const jobOfferId = selectedCandidate.jobOfferId || 0;
      if (!jobOfferId) {
        console.error("Missing job offer ID");
        toast.error(
          <Trans>Failed to update candidate score: Missing job ID</Trans>
        );
        return;
      }

      const response = await candidatService.updateCandidateScore(
        candidateId,
        jobOfferId,
        scoreData
      );

      if (response.success) {
        console.log("Candidate score updated successfully:", response.data);

        // Update the mock score state with the submitted values
        setMockScore({
          diplomaMatch: diplomaScore.toString(),
          experienceMatch: experienceScore.toString(),
          profileScore: (formData.get("profileScore") as string) || "0",
          technicalSkills: technicalSkillScore.toString(),
          softSkills: softSkillScore.toString(),
          overAllScore: response.data?.overAllScore?.toString() || "0", // Get overall score from API response
        });

        toast.success(
          <Trans>
            Candidate scoring for {selectedCandidate.name} submitted
            successfully
          </Trans>
        );
      } else {
        toast.error(<Trans>Failed to submit candidate scoring</Trans>);
        console.error("API response error:", response);
      }
    } catch (error) {
      console.error("Error submitting candidate score:", error);
      toast.error(<Trans>Error submitting candidate scoring</Trans>);
    } finally {
      setShowScoreModal(false);
      setSelectedCandidate(null);
    }
  };

  // Loading state render
  if (loading) {
    return (
      <main className="flex flex-col w-full max-w-screen-xl mx-auto items-start gap-8 p-8">
        <div className="flex items-center justify-center min-h-[400px] w-full">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#238d94] mx-auto mb-4"></div>
            <p className="text-gray-600">
              <Trans>Loading interviews...</Trans>
            </p>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="flex flex-col w-full max-w-screen-xl mx-auto items-start gap-8 p-8">
      <InterviewStatsSection onInterviewCreated={fetchInterviews} />
      <InterviewListSection stats={stats} />
      <InterviewDashboardSection
        filterStatuses={filterStatuses.map((f) => ({
          ...f,
          count:
            f.id === "all"
              ? interviews.length
              : interviews.filter((i) => i.status.toLowerCase() === f.id)
                  .length,
        }))}
        onStatusChange={handleFilterChange}
      />

      {interviewsLoading ? (
        <div className="flex items-center justify-center p-8 w-full">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#238d94] mx-auto mb-2"></div>
            <p className="text-gray-600">
              <Trans>Loading interview data...</Trans>
            </p>
          </div>
        </div>
      ) : (
        <InterviewActionsSection
          interviews={filteredInterviews()}
          handleEditInterview={handleEditInterview}
          handleCompleteInterview={handleCompleteInterview}
          handleCancelInterview={handleCancelInterview}
          handleCandidateScoring={handleCandidateScoring}
        />
      )}

      {isEditModalOpen && (
        <EditInterview
          interview={interview}
          onClose={() => setIsEditModalOpen(false)}
          onSave={async (data) => {
            // Handle save logic here
            console.log("Interview saved:", data);
            setIsEditModalOpen(false);
            // Refresh interviews data immediately after save
            await fetchInterviews(true);
            toast.success(<Trans>Interview updated successfully</Trans>);
          }}
        />
      )}

      {showScoreModal && selectedCandidate && (
        <ScoreCandidate
          isOpen={showScoreModal}
          onClose={() => {
            setShowScoreModal(false);
            setSelectedCandidate(null);
          }}
          candidateInfo={selectedCandidate}
          scoringData={mockScore}
          handleSubmit={handleCandidateScoringSubmit}
        />
      )}

      {/* Loading overlay for score fetching */}
      {fetchingScore && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex items-center space-x-3">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#238d94]"></div>
              <p className="text-gray-600">
                <Trans>Loading existing scores...</Trans>
              </p>
            </div>
          </div>
        </div>
      )}
    </main>
  );
};

export default RecruiterInterviewDashboard;
