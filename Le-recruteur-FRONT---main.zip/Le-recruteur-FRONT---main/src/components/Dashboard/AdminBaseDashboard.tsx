import { ReactNode } from "react";

interface AdminDashboardProps {
  SideBar: ReactNode;
  children?: ReactNode;
  Footer?: ReactNode;
  Header?: ReactNode;
}
const AdminBaseDashboard = ({
  SideBar,
  children,
  Footer,
  Header,
}: AdminDashboardProps) => {
  return (
    <div className="flex h-screen bg-gradient-to-br from-slate-50 via-[#238D94]/5 to-[#238D94]/10 overflow-hidden">
      {/* Admin Sidebar */}
      <div className="flex-shrink-0 w-72 shadow-2xl flex flex-col border-r border-gray-200 bg-white">
        {SideBar}
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen">
        {/* Admin Header */}
        {Header && (
          <header className="bg-white/80 backdrop-blur-lg shadow-sm border-b border-gray-100 px-8 py-6 sticky top-0 z-30 flex-shrink-0">
            {Header}
          </header>
        )}

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto">
          <div className="p-4 min-h-full">{children}</div>
        </main>

        {/* Admin Footer */}
        {Footer && (
          <footer className="bg-white/80 backdrop-blur-lg border-t border-gray-100 px-8 py-4 flex-shrink-0 mt-auto">
            {Footer}
          </footer>
        )}
      </div>
    </div>
  );
};

export default AdminBaseDashboard;
