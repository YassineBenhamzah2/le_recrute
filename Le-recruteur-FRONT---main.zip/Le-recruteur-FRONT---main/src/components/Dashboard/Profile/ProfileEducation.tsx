import React, { useState, useEffect } from "react";
import { Plus, Award, Dot, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import AddEducationModal from "@/components/Modals/AddEducationModal";
import AddCertificationModal from "@/components/Modals/AddCertificationModal";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import { Trans, t } from "@lingui/macro";
import { i18n } from "@lingui/core";

interface CertificationItem {
  id: number;
  name: string;
}

interface EducationItem {
  id: number;
  title: string;
  institution: string;
  location: string;
  startedAt: string;
  endedAt: string;
  current: boolean;
}

interface EducationCertifications {
  educations: EducationItem[];
  certifications: CertificationItem[];
}

const ProfileEducation: React.FC = () => {
  // id candidate
  const storedUser = localStorage.getItem("userData");
  let candidateId: number | undefined;
  if (storedUser) {
    const parsedUser = JSON.parse(storedUser);
    candidateId = parsedUser.id;
  }

  const [isAddEducationModalOpen, setIsAddEducationModalOpen] = useState(false);
  const [isAddCertificationModalOpen, setIsAddCertificationModalOpen] =
    useState(false);

  const [educationCandidate, setEducationCandidate] = useState<EducationItem[]>(
    []
  );
  const [certifications, setCertificatons] = useState<CertificationItem[]>([]);
  const [deletingEducationId, setDeletingEducationId] = useState<number | null>(
    null
  );
  const [deletingCertificationId, setDeletingCertificationId] = useState<
    number | null
  >(null);

  const handleEducationAdded = (newEducation: EducationItem) => {
    setEducationCandidate((prevEducations) => [
      ...prevEducations,
      newEducation,
    ]);
  };

  const handleCertificationAdded = (newCertification: CertificationItem) => {
    setCertificatons((prevCertifications) => [
      ...prevCertifications,
      newCertification,
    ]);
  };

  const handleDeleteEducation = async (educationId: number) => {
    try {
      setDeletingEducationId(educationId);
      await api.delete(`/candidate/profile/educations/${educationId}`);
      setEducationCandidate((prevEducations) =>
        prevEducations.filter((edu) => edu.id !== educationId)
      );
      toast.success(t`Education deleted successfully!`);
    } catch (error) {
      console.error("Error deleting education:", error);
      toast.error(t`Error deleting education`);
    } finally {
      setDeletingEducationId(null);
    }
  };

  const handleDeleteCertification = async (certificationId: number) => {
    try {
      setDeletingCertificationId(certificationId);
      await api.delete(`/candidate/profile/certifications/${certificationId}`);
      setCertificatons((prevCertifications) =>
        prevCertifications.filter((cert) => cert.id !== certificationId)
      );
      toast.success(t`Certification deleted successfully!`);
    } catch (error) {
      console.error("Error deleting certification:", error);
      toast.error(t`Error deleting certification`);
    } finally {
      setDeletingCertificationId(null);
    }
  };

  useEffect(() => {
    if (candidateId) {
      api
        .getItem<EducationCertifications>(
          `/candidate/profile/educations/${candidateId}`
        )
        .then((data) => {
          setEducationCandidate(data.educations);
          setCertificatons(data.certifications);
        })
        .catch(() => toast.error(t`Error loading educations / certifications`));
    }
  }, [candidateId]);

  function formatDate(dateString: string): string {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString(i18n.locale, {
      year: "numeric",
      month: "short",
    });
  }

  return (
    <div>
      {/* Header */}
      <div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          <Trans>Education & Certifications</Trans>
        </h3>
      </div>
      <div className="my-8"></div>

      {/* Education Section */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-lg font-semibold text-gray-900">
            <Trans>Education</Trans>
          </h4>
          <Button
            onClick={() => setIsAddEducationModalOpen(true)}
            className="bg-teal-600 hover:bg-teal-700 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            <Trans>Add Education</Trans>
          </Button>
        </div>

        <div className="space-y-4">
          {educationCandidate &&
            educationCandidate.map((edu) => (
              <div
                key={edu.id}
                className="flex items-start gap-4 p-4 rounded-xl border border-gray-200 bg-gradient-to-r from-white to-gray-50 hover:shadow-sm transition group"
              >
                <div className="flex-1">
                  <h5 className="font-semibold text-gray-900 mb-1">
                    {edu.title}
                  </h5>
                  <p className="flex items-center text-teal-600 font-medium mb-1">
                    {edu.institution}
                    <Dot size={25} className="text-gray-400" />
                    {edu.location}
                  </p>
                  <p className="text-sm text-gray-500">
                    {formatDate(edu.startedAt)} –{" "}
                    {edu.current ? t`Present` : formatDate(edu.endedAt)}
                  </p>
                </div>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          <Trans>Delete Education</Trans>
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          <Trans>
                            Are you sure you want to delete "{edu.title}" from{" "}
                            {edu.institution}? This action cannot be undone.
                          </Trans>
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>
                          <Trans>Cancel</Trans>
                        </AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDeleteEducation(edu.id)}
                          disabled={deletingEducationId === edu.id}
                          className="bg-red-600 hover:bg-red-700 disabled:opacity-50"
                        >
                          {deletingEducationId === edu.id ? (
                            <div className="flex items-center gap-2">
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                              <Trans>Deleting...</Trans>
                            </div>
                          ) : (
                            <Trans>Delete</Trans>
                          )}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div> ))}
            </div>
      </div>
      <div className="my-8"></div>

      {/* Certifications Section */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-lg font-semibold text-gray-900">
            <Trans>Certifications</Trans>
          </h4>
          <Button
            onClick={() => setIsAddCertificationModalOpen(true)}
            className="bg-teal-600 hover:bg-teal-700 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            <Trans>Add Certification</Trans>
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {certifications &&
            certifications.map((cert) => (
              <div
                key={cert.id}
                className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-teal-500 transition-colors group"
              >
                <Award size={20} className="text-teal-600" />
                <span className="font-medium text-gray-900 flex-1">
                  {cert.name}
                </span>
                <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          <Trans>Delete Certification</Trans>
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          <Trans>
                            Are you sure you want to delete the certification "
                            {cert.name}"? This action cannot be undone.
                          </Trans>
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>
                          <Trans>Cancel</Trans>
                        </AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDeleteCertification(cert.id)}
                          disabled={deletingCertificationId === cert.id}
                          className="bg-red-600 hover:bg-red-700 disabled:opacity-50"
                        >
                          {deletingCertificationId === cert.id ? (
                            <div className="flex items-center gap-2">
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                              <Trans>Deleting...</Trans>
                            </div>
                          ) : (
                            <Trans>Delete</Trans>
                          )}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Modals */}
      <AddEducationModal
        isOpen={isAddEducationModalOpen}
        onClose={() => setIsAddEducationModalOpen(false)}
        onEducationAdded={handleEducationAdded}
      />
      <AddCertificationModal
        isOpen={isAddCertificationModalOpen}
        onClose={() => setIsAddCertificationModalOpen(false)}
        onCertificationAdded={handleCertificationAdded}
      />
    </div>
  );
};

export default ProfileEducation;
