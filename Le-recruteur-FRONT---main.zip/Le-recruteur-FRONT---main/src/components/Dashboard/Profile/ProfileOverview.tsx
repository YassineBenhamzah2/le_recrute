import React, { useState, useEffect } from 'react';
import { Edit, Save, X , Info  } from 'lucide-react'; 
import { Button } from '@/components/ui/button';
import { toast } from "sonner";
import { api } from '@/lib/network/utils/api';
import { Trans, t } from '@lingui/macro';



interface OverviewDataResponse {
  
  description: string;
}

interface OverviewUpdateRequest {
  description: string;
  candidateId: number ;
}

const ProfileOverview: React.FC = () => {

  
  
  
  const [isEditing, setIsEditing] = useState(false);
  
  const [overviewData, setOverviewData] = useState<OverviewDataResponse>({
   
    description: ""
  });

  const [tempDescription, setTempDescription] = useState('');


  // id candidate
  const storedUser = localStorage.getItem("userData");
  let candidateId : number ;
  if(storedUser){
    const parsedUser = JSON.parse(storedUser) ;
    candidateId = parsedUser.id;
  }


  useEffect(() => {
    api.getItem<OverviewDataResponse>(`/candidate/profile/overview/${candidateId}`)
      .then((data) => {
        setOverviewData(data);
        setTempDescription(data.description);
      })
      .catch(() => {
        toast.error(t`Unable to load the profile overview. Please try again.`) ;

      });
  }, []); 

 
  const updateOverview = (requestData: OverviewUpdateRequest) => {
    api
      .put<OverviewDataResponse>(
        `/candidate/profile/overview`,
        requestData
      )
      .then((res) => {
        setOverviewData(res);
        toast.success(t`Overview updated successfully.`);
      })
      .catch((err) => {
        console.error("Erreur lors de la mise à jour:", err);
        toast.error(t`Unable to update the overview.`) ;
       
      });
  };


  const handleEditClick = () => {
    setTempDescription(overviewData.description);
    setIsEditing(true);
  };

  const handleSaveClick = () => {
    const requestData: OverviewUpdateRequest = {
      description: tempDescription,
      candidateId: candidateId
    };
    updateOverview(requestData);
    setIsEditing(false);
  };

  const handleCancelClick = () => {
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-gray-900"><Trans>Overview</Trans></h3>
          
          {!isEditing ? (
            <Button
              variant="outline"
              size="sm"
              className="text-teal-600 border-teal-200 hover:bg-teal-50"
              onClick={handleEditClick}
            >
              <Edit className="w-4 h-4 mr-2" />
              <Trans>Edit Overview</Trans>
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="text-gray-600 border-gray-200 hover:bg-gray-50"
                onClick={handleCancelClick}
              >
                <X className="w-4 h-4 mr-2" />
                <Trans>Cancel</Trans>
              </Button>
              <Button
                size="sm"
                className="bg-teal-600 hover:bg-teal-700 text-white"
                onClick={handleSaveClick}
              >
                <Save className="w-4 h-4 mr-2" />
                <Trans>Save Changes</Trans>
              </Button>
            </div>
          )}
        </div>

        {!isEditing ? (

          overviewData.description && overviewData.description.trim() !== "" ? (
            <div className="prose max-w-none text-gray-700 leading-relaxed whitespace-pre-line">
              {overviewData.description}
            </div>
          ) : (
            <p className="text-gray-400 italic"><Trans>No overview provided.</Trans></p>
          )
        ) : (
              <textarea
                value={tempDescription}
                onChange={(e) => setTempDescription(e.target.value)}
                rows={8}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent resize-vertical"
                placeholder={t`Describe your professional background and experience...`}
              />
          
        )}
      </div>

      {isEditing && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 text-blue-600 mt-0.5">
              <Info size={20} />
            </div>
            <div className="text-sm text-blue-800">
              <p className="font-medium mb-1"><Trans>Editing Tips:</Trans></p>
              <ul className="list-disc list-inside space-y-1 text-blue-700">
                <li><Trans>Use clear, concise language to describe your experience</Trans></li>
                <li><Trans>Separate paragraphs with double line breaks</Trans></li>
                <li><Trans>Highlight your key achievements and skills</Trans></li>
                <li><Trans>Keep your career highlights specific and measurable when possible</Trans></li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfileOverview;