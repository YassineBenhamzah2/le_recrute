import React, { useState, useEffect } from "react";
// import { Eye, FileText } from "lucide-react";
import { api } from "@/lib/network/utils/api";
import { Trans, t } from "@lingui/macro";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

interface CandidateStats {
  profileViews: number;
  applications: number;
  completionPercentage: number;
}

const ProfileStats: React.FC = () => {
  // id candidate
  const { user } = useAuth();
  const candidateId = user?.id;
  // const [profileViews, setProfileViews] = useState(10);
  // const [applications, setApplications] = useState(10);
  const [completionPercentage, setCompletionPercentage] = useState(40);
  const [isHovered, setIsHovered] = useState(false);

  //for annimation
  // const [targetProfileViews, setTargetProfileViews] = useState(0);

  // const [targetApplications, setTargetApplications] = useState(0);

  // const [targetCompletion, setTargetCompletion] = useState(0);

  useEffect(() => {
    api
      .getItem<CandidateStats>(`/candidate/profile/stats/${candidateId}`)
      .then((data) => {
        // setTargetProfileViews(data.profileViews);
        // setTargetApplications(data.applications);
        setCompletionPercentage(data.completionPercentage);
      })
      .catch(() => toast.error(t`Error loading stats`));
  }, []);

  // Animate numbers on mount
  // useEffect(() => {
  //   if (targetProfileViews === 0) return;

  //   const interval = setInterval(() => {
  //     setProfileViews((prev) => {
  //       if (prev < targetProfileViews) {
  //         return Math.min(
  //           prev + Math.ceil(targetProfileViews / 30),
  //           targetProfileViews
  //         );
  //       } else {
  //         clearInterval(interval);
  //         return targetProfileViews;
  //       }
  //     });
  //   }, 40);

  //   return () => clearInterval(interval);
  // }, [targetProfileViews]);

  // useEffect(() => {
  //   if (targetApplications === 0) return;

  //   const interval = setInterval(() => {
  //     setApplications((prev) => {
  //       if (prev < targetApplications) {
  //         return Math.min(
  //           prev + Math.ceil(targetApplications / 2),
  //           targetApplications
  //         );
  //       } else {
  //         clearInterval(interval);
  //         return targetApplications;
  //       }
  //     });
  //   }, 60);

  //   return () => clearInterval(interval);
  // }, [targetApplications]);

  // const StatItem = ({
  //   icon: Icon,
  //   iconBg,
  //   iconColor,
  //   label,
  //   value,
  //   delay,
  // }: {
  //   icon: React.ComponentType<{ className?: string }>;
  //   iconBg: string;
  //   iconColor: string;
  //   label: string;
  //   value: number;
  //   delay: number;
  // }) => {
  //   const [isVisible, setIsVisible] = useState(false);

  //   useEffect(() => {
  //     const timer = setTimeout(() => setIsVisible(true), delay);
  //     return () => clearTimeout(timer);
  //   }, [delay]);

  //   return (
  //     <div
  //       className={`flex items-center justify-between transition-all duration-500 hover:scale-[1.02] ${
  //         isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
  //       }`}
  //     >
  //       <div className="flex items-center gap-3">
  //         <div
  //           className={`w-8 h-8 ${iconBg} rounded-lg flex items-center justify-center transition-all duration-300 hover:scale-110`}
  //         >
  //           <Icon
  //             className={`w-4 h-4 ${iconColor} transition-all duration-300`}
  //           />
  //         </div>
  //         <span className="text-gray-600 transition-colors duration-300 hover:text-gray-800">
  //           {label}
  //         </span>
  //       </div>
  //       <span className="font-semibold text-gray-900 tabular-nums transition-all duration-300">
  //         {value.toLocaleString()}
  //       </span>
  //     </div>
  //   );
  // };

  return (
    <div
      className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 transition-all duration-300 hover:shadow-md"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <h3 className="font-semibold text-gray-900 mb-4">
        <Trans>Profile Statistics</Trans>
      </h3>

      {/* <div className="space-y-4 mb-6">
        <StatItem
          icon={Eye}
          iconBg="bg-teal-100"
          iconColor="text-teal-600"
          label={t`Profile Views`}
          value={profileViews}
          delay={0}
        />

        <StatItem
          icon={FileText}
          iconBg="bg-blue-100"
          iconColor="text-blue-600"
          label={t`Applications`}
          value={applications}
          delay={0}
        />
      </div> */}

      {/* Profile Completion */}
      <div
        className={`bg-gradient-to-r from-teal-500 to-teal-600 rounded-lg p-4 text-white transition-all duration-500 ${
          isHovered
            ? "from-teal-600 to-teal-700 shadow-lg transform scale-[1.02]"
            : ""
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="font-medium">
            <Trans>Profile Completion</Trans>
          </span>
          <span className="font-bold text-xl tabular-nums">
            {completionPercentage}%
          </span>
        </div>

        <div className="w-full bg-teal-400/50 rounded-full h-2 mb-3 overflow-hidden">
          <div
            className="bg-white h-2 rounded-full transition-all duration-1000 ease-out relative overflow-hidden"
            style={{ width: `${completionPercentage}%` }}
          >
            {/* Animated shine effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -skew-x-12 animate-pulse"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileStats;
