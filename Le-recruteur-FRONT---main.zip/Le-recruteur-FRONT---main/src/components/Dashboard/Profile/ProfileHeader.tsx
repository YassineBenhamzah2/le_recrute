import React, { useState, useRef, useEffect } from "react";
import {
  MapPin,
  Mail,
  Phone,
  Edit,
  Download,
  Upload,
  ExternalLink,
  Linkedin,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import EditProfileModal from "@/components/Modals/EditProfileModal";
import { toast } from "sonner";
import { api } from "@/lib/network/utils/api";
import { settings } from "@/lib/settings/main";
import { Trans, t } from '@lingui/macro';

interface ProfileData {
  firstName: string;
  lastName: string;
  title: string;
  country : string ;
  city : string ;
  address: string;
  email: string;
  phone: string;
  linkedin: string;
  avatar: string;
  cvUrl: string | null;
  rating: number;
  reviewCount: number;
}

interface UploadResumeResponse {
  cvUrl: string;
}


const ProfileHeader: React.FC = () => {
  const [profileData, setProfileData] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const [uploadingResume, setUploadingResume] = useState(false);
  const [downloadingCV, setDownloadingCV] = useState(false);
  const resumeInputRef = useRef<HTMLInputElement>(null);

  // id candidate
  const storedUser = localStorage.getItem("userData");
  let candidateId : number ;
  if(storedUser){
    const parsedUser = JSON.parse(storedUser) ;
    candidateId = parsedUser.id;
  }


  useEffect(() => {
    
    api.getItem<ProfileData>(`/candidate/profile/info/${candidateId}`)
      .then((data) => {
        
        if (data.avatar && data.avatar.startsWith('uploads/')) {
          data.avatar = `${settings.IMG_ADDRESS}${data.avatar}`;
          
        }else if (!data.avatar) {
          data.avatar = settings.DEFAULT_USER_AVATAR ;
        }

        setProfileData(data);
      })
      .catch((error) => {
        toast.error(t`Error while loading candidate information`);
        console.error("Fetch error:", error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []); 


  const handleEditProfile = () => {
    setIsEditModalOpen(true);
  };

  const handleSaveProfile = (updatedData: { firstName: string,
                                            lastName: string,
                                            title: string,
                                            country : string ,
                                            city : string ,
                                            address : string ,
                                            email: string,
                                            phone: string,
                                            linkedin: string,
                                            avatar: string }
   ) => {
    if (updatedData.avatar && updatedData.avatar.startsWith('uploads/')) {
        updatedData.avatar = `${settings.IMG_ADDRESS}${updatedData.avatar}`;
        
    }else{
      updatedData.avatar = settings.DEFAULT_USER_AVATAR ;
    }
     setProfileData((prev) => ({ ...prev!, ...updatedData }));

     setIsEditModalOpen(false);
  };

  const handleDownloadCV = () => {
    if (!profileData || !profileData.cvUrl) {
      toast.error(t`No CV available for download.`);
      return;
    }

    setDownloadingCV(true);

    try {
      const fileUrl = `${settings.IMG_ADDRESS}${profileData.cvUrl}`;

      const link = document.createElement("a");
      link.href = fileUrl;

      const fileName = `CV_${profileData.firstName}_${profileData.lastName}.pdf`;
      link.setAttribute("download", fileName);

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      console.error("Download error:", e);
      toast.error(t`Failed to download CV.`);
    } finally {
      setDownloadingCV(false);
    }
  };

  // Function to upload resume
  const handleUploadResume = () => {
    if (resumeInputRef.current) {
      resumeInputRef.current.click();
    }
  };

  const handleResumeChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];

    if (!file || !candidateId) {
      toast.error(t`No file selected or candidate not found.`);
      return;
    }

    setUploadingResume(true);

    const formData = new FormData();
    formData.append('resumeFile', file);

    
    api.post<UploadResumeResponse>(`/candidate/profile/uploadResume/${candidateId}`, formData)
      .then((response)  => {
        toast.success(t`Resume ${file.name} uploaded successfully!`);
        if (profileData){
          setProfileData(prevData => ({
                  ...prevData!,
                  cvUrl: response.cvUrl 
          }));
        }
      })
      .catch((err) => {
        console.error("Failed to upload resume:", err);
        toast.error(t`Failed to upload resume. Please try again.`);
      })
      .finally(() => {
        setUploadingResume(false);
      });
  };

  
  if (loading) {
    return (
      <div className="p-6 border-b border-gray-200 text-center">
        <Trans>Loading profile...</Trans>
      </div>
    );
  }

  if (!profileData) {
    return (
      <div className="p-6 border-b border-gray-200 text-center text-red-500">
        <Trans>Could not load profile information.</Trans>
      </div>
    );
  }

  return (
    <>
      <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-white to-gray-50">
        <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
          {/* Profile Image */}
          <div className="relative group">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white text-2xl font-bold shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:scale-105">
              <img
                src={profileData.avatar}
                alt={`${profileData.firstName} ${profileData.lastName}`}
                className="w-full h-full rounded-full object-cover"
                onError={(e) => {
                  e.currentTarget.src = settings.DEFAULT_USER_AVATAR ;
                }}
              />
            </div>

            {/* Edit Badge */}
            <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-1 shadow-md">
              <div
                className="w-6 h-6 bg-teal-100 hover:bg-teal-200 rounded-full flex items-center justify-center cursor-pointer transition-colors duration-200"
                onClick={handleEditProfile}
              >
                <Edit className="w-3 h-3 text-teal-600" />
              </div>
            </div>
          </div>

          {/* Profile Info */}
          <div className="flex-1 w-full">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-gray-900 mb-1 hover:text-teal-600 transition-colors duration-200">
                  {`${profileData.firstName} ${profileData.lastName}`}
                </h2>
                <p className="text-lg text-gray-600 mb-3 font-medium">
                  {profileData.title}
                </p>

                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                  <div className="flex items-center gap-1 hover:text-gray-700 transition-colors duration-200">
                    <MapPin className="w-4 h-4 text-teal-500" />
                    <span>{profileData.address + "," + profileData.city + "," + profileData.country}</span>
                  </div>
                  <div className="flex items-center gap-1 hover:text-gray-700 transition-colors duration-200">
                    <Mail className="w-4 h-4 text-teal-500" />
                    <a
                      href={`mailto:${profileData.email}`}
                      className="hover:underline"
                    >
                      {profileData.email}
                    </a>
                  </div>
                  <div className="flex items-center gap-1 hover:text-gray-700 transition-colors duration-200">
                    <Phone className="w-4 h-4 text-teal-500" />
                    <a
                      href={`tel:${profileData.phone}`}
                      className="hover:underline"
                    >
                      {profileData.phone}
                    </a>
                  </div>
                </div>
              </div>

              <Button
                variant="outline"
                className="flex items-center gap-2 bg-white border-gray-300 text-gray-700 hover:bg-teal-50 hover:border-teal-300 hover:text-teal-700 transition-all duration-200 shadow-sm hover:shadow-md mt-4 md:mt-0"
                onClick={handleEditProfile}
              >
                <Edit className="w-4 h-4" />
                <Trans>Edit Profile</Trans>
              </Button>
            </div>

            {/* LinkedIn with Rating */}
            <div className="mb-4 space-y-2">
              <a
                href={profileData.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-blue-600 hover:text-blue-700 text-sm font-medium transition-all duration-200 hover:scale-105"
              >
                <Linkedin className="w-4 h-4 mr-2" />
                <Trans>LinkedIn Profile</Trans>
                <ExternalLink className="w-3 h-3 ml-1" />
              </a>

              
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3 mt-4">
              <Button
                className="bg-teal-600 hover:bg-teal-700 transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105"
                onClick={handleDownloadCV}
                disabled={downloadingCV}
              >
                {downloadingCV ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                ) : (
                  <Download className="w-4 h-4 mr-2" />
                )}
                {downloadingCV ? t`Downloading...` : t`Download CV`}
              </Button>

              <Button
                variant="outline"
                className="border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400 transition-all duration-200 shadow-sm hover:shadow-md"
                onClick={handleUploadResume}
                disabled={uploadingResume}
              >
                {uploadingResume ? (
                  <div className="w-4 h-4 border-2 border-gray-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                ) : (
                  <Upload className="w-4 h-4 mr-2" />
                )}
                {uploadingResume ? t`Uploading...` : t`Upload Resume`}
              </Button>

              {/* Hidden resume input */}
              <input
                ref={resumeInputRef}
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={handleResumeChange}
                className="hidden"
              />
            </div>
          </div>
        </div>
      </div>

      {/* La modale ne sera rendue que si profileData n'est pas null */}
      {profileData && (
        <EditProfileModal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          profileData={profileData}
          onSave={handleSaveProfile}
        />
      )}
    </>
  );
};

export default ProfileHeader;
