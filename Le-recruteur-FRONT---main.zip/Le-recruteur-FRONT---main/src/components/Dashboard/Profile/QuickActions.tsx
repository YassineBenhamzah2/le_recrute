// import React, { useState } from 'react';
// import { Download } from 'lucide-react';
// import { Button } from '@/components/ui/button';
// import { Trans, t } from '@lingui/macro';


// const QuickActions: React.FC = () => {
//   const [loadingStates, setLoadingStates] = useState<Record<string, boolean>>({});
//   const [hoveredAction, setHoveredAction] = useState<string | null>(null);

//   const handleAction = async (actionId: string, actionFn: () => void) => {
//     setLoadingStates(prev => ({ ...prev, [actionId]: true }));
    
//     // Simulate async action
//     setTimeout(() => {
//       actionFn();
//       setLoadingStates(prev => ({ ...prev, [actionId]: false }));
//     }, 1500);
//   };

//   const actions = [
//     {
//       id: 'download-resume',
//       icon: Download,
//       label: 'Download Resume',
//       action: () => console.log('Downloading resume...')
//     }
//   ];

//   const renderIcon = (
//     IconComponent: React.ComponentType<{ className?: string }>,
//     actionId: string
//   ) => {
//     const isLoading = loadingStates[actionId];
//     const isHovered = hoveredAction === actionId;

//     if (isLoading) {
//       return (
//         <div className="w-4 h-4 mr-3">
//           <div className="w-full h-full border-2 border-gray-300 border-t-gray-600 rounded-full animate-spin"></div>
//         </div>
//       );
//     }

//     return (
//       <IconComponent 
//         className={`w-4 h-4 mr-3 transition-all duration-200 ${
//           isHovered ? 'text-blue-600 scale-110' : 'text-gray-600'
//         }`} 
//       />
//     );
//   };

//   return (
//     <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 transition-shadow duration-300 hover:shadow-md">
//       <h3 className="font-semibold text-gray-900 mb-4"><Trans>Quick Actions</Trans></h3>
      
//       <div className="space-y-3">
//         {actions.map((action) => {
//           const isLoading = loadingStates[action.id];
//           const isHovered = hoveredAction === action.id;
          
//           return (
//             <Button
//               key={action.id}
//               variant="outline"
//               className={`w-full justify-start text-gray-700 border-gray-200 transition-all duration-200 ${
//                 isHovered && !isLoading 
//                   ? 'bg-gray-50 border-gray-300 shadow-sm transform translate-y-[-1px]' 
//                   : 'hover:bg-gray-50'
//               } ${isLoading ? 'cursor-wait opacity-70' : ''}`}
//               onClick={() => handleAction(action.id, action.action)}
//               onMouseEnter={() => setHoveredAction(action.id)}
//               onMouseLeave={() => setHoveredAction(null)}
//               disabled={isLoading}
//             >
//               {renderIcon(action.icon, action.id)}
//               <span className={`transition-colors duration-200 ${
//                 isHovered && !isLoading ? 'text-gray-900 font-medium' : ''
//               }`}>
//                 {action.label}
//               </span>
              
//               {/* Subtle loading indicator */}
//               {isLoading && (
//                 <div className="ml-auto">
//                   <div className="flex space-x-1">
//                     <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
//                     <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
//                     <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
//                   </div>
//                 </div>
//               )}
//             </Button>
//           );
//         })}
//       </div>
//     </div>
//   );
// };

// export default QuickActions;
