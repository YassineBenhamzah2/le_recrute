import React, { useState, useEffect } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import AddSkillModal from "@/components/Modals/AddSkillModal";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import { Trans, t } from "@lingui/macro";

interface Skill {
  id: number;
  name: string;
  level: number;
  type: "SOFTSKILL" | "HARDSKILL";
}

interface language {
  id: number;
  name: string;
  level: number;
}

const ProfileSkills: React.FC = () => {
  // id candidate
  const storedUser = localStorage.getItem("userData");
  const candidateId = storedUser ? JSON.parse(storedUser).id : null;

  const [isAddSkillModalOpen, setIsAddSkillModalOpen] = useState(false);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [languages, setLanguages] = useState<language[]>([]);
  const [deletingSkillId, setDeletingSkillId] = useState<number | null>(null);
  const [deletingLanguageId, setDeletingLanguageId] = useState<number | null>(
    null
  );

  const handleSkillAdded = (newSkill: Skill) => {
    setSkills((prevSkills) => [...prevSkills, newSkill]);
  };

  const handleLanguageAdded = (newLanguage: language) => {
    setLanguages((prevLanguages) => [...prevLanguages, newLanguage]);
  };

  const handleDeleteSkill = async (skillId: number) => {
    setDeletingSkillId(skillId);
    try {
      await api.delete(`/candidate/profile/skills/${skillId}`);
      setSkills((prevSkills) =>
        prevSkills.filter((skill) => skill.id !== skillId)
      );
      toast.success(t`Skill deleted successfully`);
    } catch {
      toast.error(t`Error deleting skill`);
    } finally {
      setDeletingSkillId(null);
    }
  };

  const handleDeleteLanguage = async (languageId: number) => {
    setDeletingLanguageId(languageId);
    try {
      await api.delete(`/candidate/profile/languages/${languageId}`);
      setLanguages((prevLanguages) =>
        prevLanguages.filter((language) => language.id !== languageId)
      );
      toast.success(t`Language deleted successfully`);
    } catch {
      toast.error(t`Error deleting language`);
    } finally {
      setDeletingLanguageId(null);
    }
  };

  useEffect(() => {
    if (!candidateId) return;

    api
      .getItem<Skill[]>(`/candidate/profile/skills/${candidateId}`)
      .then((data) => {
        setSkills(data);
      })
      .catch(() => toast.error(t`Error loading skills`));
  }, [candidateId]);

  useEffect(() => {
    if (!candidateId) return;

    api
      .getItem<language[]>(`/candidate/profile/languages/${candidateId}`)
      .then((data) => {
        setLanguages(data);
      })
      .catch(() => toast.error(t`Error loading languages`));
  }, [candidateId]);

  const renderSkillLanguageBar = (
    skill_language: Skill | language,
    type: "skill" | "language"
  ) => (
    <div key={skill_language.id} className="mb-4 group relative">
      <div className="flex justify-between items-center mb-2">
        <span className="font-medium text-gray-900">{skill_language.name}</span>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">{skill_language.level}%</span>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button
                className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 p-1 text-red-600 hover:text-red-700 hover:bg-red-50 rounded"
                aria-label={
                  type === "skill" ? t`Delete skill` : t`Delete language`
                }
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>
                  {type === "skill" ? (
                    <Trans>Delete Skill</Trans>
                  ) : (
                    <Trans>Delete Language</Trans>
                  )}
                </AlertDialogTitle>
                <AlertDialogDescription>
                  {type === "skill" ? (
                    <Trans>
                      Are you sure you want to delete this skill? This action
                      cannot be undone.
                    </Trans>
                  ) : (
                    <Trans>
                      Are you sure you want to delete this language? This action
                      cannot be undone.
                    </Trans>
                  )}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>
                  <Trans>Cancel</Trans>
                </AlertDialogCancel>
                <AlertDialogAction
                  onClick={() =>
                    type === "skill"
                      ? handleDeleteSkill(skill_language.id)
                      : handleDeleteLanguage(skill_language.id)
                  }
                  className="bg-red-600 hover:bg-red-700"
                  disabled={
                    type === "skill"
                      ? deletingSkillId === skill_language.id
                      : deletingLanguageId === skill_language.id
                  }
                >
                  {type === "skill" ? (
                    deletingSkillId === skill_language.id ? (
                      <Trans>Deleting...</Trans>
                    ) : (
                      <Trans>Delete Skill</Trans>
                    )
                  ) : deletingLanguageId === skill_language.id ? (
                    <Trans>Deleting...</Trans>
                  ) : (
                    <Trans>Delete Language</Trans>
                  )}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className="bg-gray-900 h-2 rounded-full transition-all duration-300"
          style={{ width: `${skill_language.level}%` }}
        ></div>
      </div>
    </div>
  );

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-gray-900">
          <Trans>Skills & Languages</Trans>
        </h3>
        <Button
          onClick={() => setIsAddSkillModalOpen(true)}
          className="bg-teal-600 hover:bg-teal-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          <Trans>Add Skill</Trans>
        </Button>
      </div>
      <div className="my-6"></div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Technical Skills */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 mb-6">
            <Trans>Hard Skills</Trans>
          </h4>
          <div className="space-y-4">
            {skills
              .filter((skill) => skill.type == "HARDSKILL")
              .map((skill) => renderSkillLanguageBar(skill, "skill"))}
          </div>
        </div>

        {/* Languages */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 mb-6">
            <Trans>Languages</Trans>
          </h4>
          <div className="space-y-4">
            {languages.map((language) =>
              renderSkillLanguageBar(language, "language")
            )}
          </div>
        </div>
      </div>
      <div className="my-6"></div>

      {/* Soft Skills */}
      <div>
        <h4 className="text-lg font-semibold text-gray-900 mb-6">
          <Trans>Soft Skills</Trans>
        </h4>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {skills
            .filter((skill) => skill.type == "SOFTSKILL")
            .map((skill) => renderSkillLanguageBar(skill, "skill"))}
        </div>
      </div>

      {/* Add Skill Modal */}
      <AddSkillModal
        isOpen={isAddSkillModalOpen}
        onClose={() => setIsAddSkillModalOpen(false)}
        onSkillAdded={handleSkillAdded}
        onLanguageAdded={handleLanguageAdded}
      />
    </div>
  );
};

export default ProfileSkills;
