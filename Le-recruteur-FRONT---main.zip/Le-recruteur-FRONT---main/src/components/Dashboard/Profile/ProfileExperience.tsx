import React, { useState, useEffect } from "react";
import { Plus, Edit, Star, Info, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import AddExperienceModal from "@/components/Modals/AddExperienceModal";
import EditExperienceModal from "@/components/Modals/EditExperienceModal";
import { toast } from "sonner";
import { Trans, t } from "@lingui/macro";
import { i18n } from "@lingui/core";

import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogCancel,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";

import { api } from "@/lib/network/utils/api";
import { settings } from "@/lib/settings/main";

interface Experience {
  id: number;
  position: string;
  company: Company;
  industry: Industry;
  startDate: string;
  endDate: string;
  current: boolean;
  location: string;
  workplaceRating: string;
  description: string;
}

interface Company {
  id: number;
  name: string;
  logo: string;
}

interface Industry {
  id: number;
  name: string;
}

const ProfileExperience: React.FC = () => {
  // id candidate
  const storedUser = localStorage.getItem("userData");
  let candidateId: number;
  if (storedUser) {
    const parsedUser = JSON.parse(storedUser);
    candidateId = parsedUser.id;
  }

  const [isAddExperienceModalOpen, setIsAddExperienceModalOpen] =
    useState(false);
  const [experiences, setExperiences] = useState<Experience[]>([]);

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingExperience, setEditingExperience] = useState<Experience | null>(
    null
  );

  const handleExperienceAdded = (newExperience: Experience) => {
    const updatedExperience: Experience = {
      ...newExperience,
      company: {
        ...newExperience.company,
        logo: newExperience.company.logo
          ? `${settings.IMG_ADDRESS}${newExperience.company.logo}`
          : settings.DEFAULT_COMPANY_AVATAR ,
      },
    };

    setExperiences((prevExperiences) => [
      ...prevExperiences,
      updatedExperience,
    ]);
  };

  const handleEditClick = (experience: Experience) => {
    setEditingExperience(experience);
    setIsEditModalOpen(true);
  };

  const handleCloseEditModal = () => {
    setIsEditModalOpen(false);
    setEditingExperience(null);
  };

  useEffect(() => {
    api
      .getItem<Experience[]>(`/candidate/profile/experiences/${candidateId}`)
      .then((data) => {
        const updatedData = data.map((e) => ({
          ...e,
          company: {
            ...e.company,
            logo: e.company.logo
              ? `${settings.IMG_ADDRESS}${e.company.logo}`
              : settings.DEFAULT_COMPANY_AVATAR ,
          },
        }));
        setExperiences(updatedData);
      })
      .catch(() => {
        toast.error(t`Unable to load experiences. Please try again.`);
      });
  }, []);

  const renderStars = (workplaceRating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-3 h-3 ${
              star <= workplaceRating
                ? "fill-yellow-400 text-yellow-400"
                : "text-gray-300"
            }`}
          />
        ))}

        <div className="relative group flex items-center">
          <Info size={14} className="text-gray-400 cursor-pointer ml-1" />

          <div
            role="tooltip"
            className="
              absolute left-full top-1/2 -translate-y-1/2 ml-2 z-10
              w-max max-w-xs
              px-3 py-2
              text-[10px] font-normal text-gray-700 bg-white
              border border-gray-300 rounded-md shadow-sm
              opacity-0 invisible group-hover:opacity-100 group-hover:visible
              transition-opacity duration-200
            "
          >
            <Trans>
              This is your personal workplaceRating of your work experience at
              this company.
            </Trans>
          </div>
        </div>
      </div>
    );
  };

  function formatDate(dateString: string): string {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString(i18n.locale, {
      year: "numeric",
      month: "short",
    });
  }

  const handleExperienceUpdated = (updatedExperience: Experience) => {
    const newExperience: Experience = {
      ...updatedExperience,
      company: {
        ...updatedExperience.company,
        logo: updatedExperience.company.logo
          ? `${settings.IMG_ADDRESS}${updatedExperience.company.logo}`
          : settings.DEFAULT_COMPANY_AVATAR ,
      },
    };
    setExperiences((prevExperiences) =>
      prevExperiences.map((exp) =>
        exp.id === updatedExperience.id ? newExperience : exp
      )
    );

    setIsEditModalOpen(false);
  };

  const handleDeleteClick = (experienceId: number) => {
    toast.promise(
      api.delete(`/candidate/profile/experiences/${experienceId}`),
      {
        loading: t`Deleting experience...`,
        success: () => {
          setExperiences((prevExperiences) =>
            prevExperiences.filter((exp) => exp.id !== experienceId)
          );
          return t`Experience deleted successfully!`;
        },
        error: (err) => {
          console.error("Failed to delete experience:", err);
          return t`An error occurred while deleting.`;
        },
      }
    );
  };

  return (
    <div className="">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-gray-900">
          <Trans>Work Experience</Trans>
        </h3>
        <Button
          onClick={() => setIsAddExperienceModalOpen(true)}
          className="bg-teal-600 hover:bg-teal-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          <Trans>Add Experience</Trans>
        </Button>
      </div>
      <div className="my-8"></div>
      {/* Experience List */}
      <div className="">
        {experiences.map((exp) => (
          <div
            key={exp.id}
            className="border border-gray-200 rounded-lg p-6 hover:border-gray-300 transition-colors"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h4 className="text-lg font-semibold text-gray-900">
                    {exp.position}
                  </h4>
                </div>
                <div className="flex items-center gap-2 mb-2">
                    <img
                      src={exp.company.logo}
                      alt={exp.company.name}
                      onError={(e) => {
                        e.currentTarget.src = settings.DEFAULT_COMPANY_AVATAR ;
                      }}
                      className="w-9 h-9 rounded-full object-cover border border-gray-200"
                    />
                  <p className="text-teal-600 font-medium">
                    {exp.company.name}
                  </p>
                  <span className="px-2 py-0.5 text-xs rounded-full bg-gray-100 text-gray-600">
                    {exp.industry.name}
                  </span>
                  {exp.workplaceRating &&
                    renderStars(Number(exp.workplaceRating))}
                </div>
                <p className="text-sm text-gray-500 mb-3">
                  {formatDate(exp.startDate)} –{" "}
                  {exp.current ? t`Present` : formatDate(exp.endDate)} •{" "}
                  {exp.location}
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  {exp.description}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-400 hover:text-gray-600"
                onClick={() => handleEditClick(exp)}
              >
                <Edit className="w-4 h-4" />
              </Button>
              {/* Bouton de suppression avec confirmation */}
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <button className="p-2 text-gray-400 hover:text-gray-600">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>
                      <Trans>Delete experience?</Trans>
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                      <Trans>
                        This action cannot be undone. This will permanently
                        remove{" "}
                        <span className="font-medium"> {exp.position}</span>{" "}
                        from your profile.
                      </Trans>
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>
                      <Trans>Cancel</Trans>
                    </AlertDialogCancel>
                    <AlertDialogAction
                      className="bg-red-600 hover:bg-red-700"
                      onClick={() => handleDeleteClick(exp.id)}
                    >
                      <Trans>Delete</Trans>
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        ))}
      </div>

      {/* Add Experience Modal */}
      <AddExperienceModal
        isOpen={isAddExperienceModalOpen}
        onClose={() => setIsAddExperienceModalOpen(false)}
        onExperienceAdded={handleExperienceAdded}
      />

      <EditExperienceModal
        isOpen={isEditModalOpen}
        onClose={handleCloseEditModal}
        experience={editingExperience}
        onExperienceUpdated={handleExperienceUpdated}
      />
    </div>
  );
};

export default ProfileExperience;
