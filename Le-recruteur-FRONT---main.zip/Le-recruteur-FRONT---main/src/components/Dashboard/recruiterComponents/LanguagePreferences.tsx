import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Trans ,t } from "@lingui/macro";

interface FrameProps {
  values: {
    keywords: string;
    tone: string;
    formality: string;
    seniority: string;
    language: string;
    companyName?: string;
    maxWordCount?: number;
  };
  onChange: (updatedValues: FrameProps["values"]) => void;
}

export const LanguagePreferences = ({
  values,
  onChange,
}: FrameProps): JSX.Element => {
  const handleChange = (field: keyof typeof values, value: string) => {
    const updated = {
      ...values,
      [field]: value,
      companyName: values.companyName || "",
      maxWordCount: values.maxWordCount || 150,
    };
    onChange(updated);
  };

  return (
    <div className="flex flex-col w-full items-start relative mt-5">
      <h2 className="w-full text-[#238d94] text-lg relative mt-[-1.00px] font-bold tracking-[0] leading-9">
        <Trans>Language Preferences</Trans>
      </h2>
      <div className="flex flex-col items-start w-full">
        <Label
          htmlFor="keywords"
          className="font-bold text-gray-900 text-sm leading-9"
        >
          <Trans>Keywords to Include</Trans>
        </Label>
        <Input
          id="keywords"
          className="w-full h-[38px] bg-white text-gray-400 rounded-[7.2px] border border-gray-300 px-4 py-2"
          placeholder={t`e.g. Javascript, agile, SaaS...`}
          value={values.keywords}
          onChange={(e) => handleChange("keywords", e.target.value)}
        />
      </div>

      {/* Generic Radio Group */}
      <RadioField
        title={<Trans>Tone of Voice</Trans>}
        field="tone"
        options={[
          { value: "professional", label: <Trans>Professional</Trans> },
          { value: "friendly", label: <Trans>Friendly</Trans> },
          { value: "bold", label: <Trans>Bold</Trans> },
          { value: "inclusive", label: <Trans>Inclusive</Trans> },
        ]}
        selected={values.tone}
        onChange={handleChange}
      />

      <RadioField
        title={<Trans>Formality Level</Trans>}
        field="formality"
        options={[
          { value: "low", label: <Trans>Low</Trans> },
          { value: "medium", label: <Trans>Medium</Trans> },
          { value: "high", label: <Trans>High</Trans> },
        ]}
        selected={values.formality}
        onChange={handleChange}
      />

      <RadioField
        title={<Trans>Seniority Level</Trans>}
        field="seniority"
        options={[
          { value: "entry-level", label: <Trans>Entry-level</Trans> },
          { value: "mid-level", label: <Trans>Mid-level</Trans> },
          { value: "senior", label: <Trans>Senior</Trans> },
        ]}
        selected={values.seniority}
        onChange={handleChange}
      />

      <RadioField
        title={<Trans>Language Options</Trans>}
        field="language"
        options={[
          { value: "english", label: <Trans>English</Trans> },
          { value: "french", label: <Trans>French</Trans> },
        ]}
        selected={values.language}
        onChange={handleChange}
      />
    </div>
  );
};

interface RadioFieldProps {
  title: JSX.Element | string;
  field: keyof FrameProps["values"];
  options: { value: string; label: JSX.Element | string }[];
  selected: string;
  onChange: (field: keyof FrameProps["values"], value: string) => void;
}

export const RadioField = ({
  title,
  field,
  options,
  selected,
  onChange,
}: RadioFieldProps) => (
  <div className="flex flex-col items-start w-full mt-2">
    <Label className="font-bold text-gray-900 text-sm leading-9">{title}</Label>
    <RadioGroup
      value={selected}
      onValueChange={(value) => onChange(field, value)}
      className="flex items-center gap-12 w-full"
    >
      {options.map((option) => (
        <div key={option.value} className="flex items-center gap-2">
          <RadioGroupItem
            value={option.value}
            id={`${field}-${option.value}`}
            className="w-4 h-4 rounded-lg border border-[#aeaeb2] data-[state=checked]:border-[#238d94]"
          />
          <Label
            htmlFor={`${field}-${option.value}`}
            className="text-gray-900 text-xs font-normal"
          >
            {option.label}
          </Label>
        </div>
      ))}
    </RadioGroup>
  </div>
);