import { Card, CardContent } from "@/components/ui/card";
import { Trans } from "@lingui/macro";

type FilterStatus = {
  id: string;
  label: string;
  count: number;
  selected: boolean;
};

type Props = {
  filterStatuses: FilterStatus[];
  onStatusChange: (statusId: string) => void;
};

export const InterviewDashboardSection = ({
  filterStatuses,
  onStatusChange,
}: Props): JSX.Element => {
  return (
    <Card className="p-6 w-full">
      <CardContent className="flex items-center p-0">
        <div className="font-semibold text-sm text-gray-700">
          <Trans>Filter by status:</Trans>
        </div>
        <div className="flex ml-4 gap-4">
          {filterStatuses.map((status) => (
            <div
              key={status.id}
              onClick={() => onStatusChange(status.id)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold cursor-pointer ${
                status.selected
                  ? "bg-[#238d9426] text-[#238d94]"
                  : "bg-[#14b8a626] text-gray-600"
              }`}
            >
              <Trans>
                {{ label: status.label }} ({{ count: status.count }})
              </Trans>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
