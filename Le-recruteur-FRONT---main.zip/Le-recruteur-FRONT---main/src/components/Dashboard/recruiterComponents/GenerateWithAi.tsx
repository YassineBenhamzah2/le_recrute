import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import { JobInformationSection } from "./JobInformationSection";
import { LanguagePreferences } from "./LanguagePreferences";
import { AdditionalPreferences } from "./AdditionalPreferences";
import { Trans } from "@lingui/macro";

interface GenerateWithAiProps {
  handleConfirm: (description: string) => void;
  handleClose: () => void;
}

const mockOutput = [
  {
    text: "We are looking for a Frontend Developer to join our team and help build responsive, accessible web applications...",
    timeAgo: <Trans>1m ago</Trans>,
  },
  {
    text: "Join our team as a Frontend Developer where you will help shape next-gen user interfaces for modern web apps...",
    timeAgo: <Trans>2m ago</Trans>,
  },
  {
    text: "Exciting opportunity for a Frontend Developer with skills in React or Vue. Collaborate with designers and engineers...",
    timeAgo: <Trans>4m ago</Trans>,
  },
];

export const GenerateWithAi = ({
  handleConfirm,
  handleClose,
}: GenerateWithAiProps): JSX.Element => {
  const [prefs, setPrefs] = useState<{
    keywords: string;
    tone: string;
    formality: string;
    seniority: string;
    language: string;
    companyName?: string;
    maxWordCount?: number;
  }>({
    keywords: "",
    tone: "inclusive",
    formality: "high",
    seniority: "senior",
    language: "french",
    companyName: "",
    maxWordCount: 150,
  });
  const [jobInfo, setJobInfo] = useState({
    description: "",
    targetProfile: "",
    jobType: "interim",
  });
  const [outputs, setOutputs] = useState(mockOutput);

  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async () => {
    try {
      setIsGenerating(true);
      console.log("Generating with the following data:");
      console.log("Job Info:", jobInfo);
      console.log("Preferences:", prefs);

      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Generate mock job descriptions based on inputs
      const mockDescriptions = [
        generateMockJobDescription(jobInfo, prefs, 1),
        generateMockJobDescription(jobInfo, prefs, 2),
        generateMockJobDescription(jobInfo, prefs, 3),
      ];

      // Create the output objects
      const newOutputs = mockDescriptions.map((text) => ({
        text,
        timeAgo: <Trans>Just now</Trans>,
      }));

      setOutputs(newOutputs);
    } catch (error) {
      console.error("Error generating job descriptions:", error);

      // Provide fallback outputs
      const fallbackOutput = {
        text: `Error generating descriptions. Please try again with more detailed information about the ${jobInfo.jobType} position.`,
        timeAgo: <Trans>Error</Trans>,
      };

      setOutputs([fallbackOutput]);
    } finally {
      setIsGenerating(false);
    }
  };

  // Function to generate mock job descriptions
  const generateMockJobDescription = (
    jobInfo: { description: string; targetProfile: string; jobType: string },
    prefs: {
      keywords: string;
      tone: string;
      formality: string;
      seniority: string;
      language: string;
      companyName?: string;
      maxWordCount?: number;
    },
    variant: number
  ): string => {
    const companyName = prefs.companyName || "Notre entreprise";
    const jobType = jobInfo.jobType || "CDI";
    const seniority = prefs.seniority || "senior";
    const targetProfile = jobInfo.targetProfile || "professionnel qualifié";
    const keywordsList = prefs.keywords.split(",").filter((k) => k.trim());

    // Different templates based on variant
    if (prefs.language.toLowerCase() === "french") {
      if (variant === 1) {
        return `${companyName} recherche un ${targetProfile} pour un poste en ${jobType}. 
        
Nous sommes à la recherche d'un profil ${seniority} avec une expérience confirmée dans le secteur. Le candidat idéal possède d'excellentes compétences en ${
          keywordsList.length > 0
            ? keywordsList.join(", ")
            : "communication et travail d'équipe"
        }.

Ce poste offre une opportunité unique de rejoindre une équipe dynamique et de contribuer significativement à la croissance de l'entreprise. Nous offrons un environnement de travail stimulant et des avantages compétitifs.`;
      } else if (variant === 2) {
        return `Opportunité d'emploi exceptionnelle chez ${companyName} - ${jobType}

Nous sommes fiers d'ouvrir un poste de ${targetProfile} de niveau ${seniority}. Votre rôle sera crucial pour le développement de nos activités et l'innovation au sein de notre structure.

Compétences requises:
${
  keywordsList.length > 0
    ? keywordsList.map((k) => `- Maîtrise de ${k.trim()}`).join("\n")
    : "- Excellentes aptitudes analytiques\n- Capacité à travailler en équipe\n- Sens de l'organisation"
}

Rejoignez-nous pour façonner l'avenir ensemble dans un environnement professionnel valorisant.`;
      } else {
        return `${companyName} - Recrutement ${targetProfile} (${jobType})

Vous êtes un professionnel de niveau ${seniority} passionné et à la recherche d'un nouveau défi? Notre équipe s'agrandit et nous cherchons un talent comme vous!

Votre mission consistera à ${
          jobInfo.description ||
          "contribuer au développement de nos projets innovants"
        }. Vous travaillerez en étroite collaboration avec nos équipes pluridisciplinaires dans un environnement stimulant.

${
  keywordsList.length > 0
    ? `Ce que nous recherchons: ${keywordsList.join(", ")}`
    : "Nous valorisons la créativité, l'esprit d'équipe et l'engagement."
}

Postulez dès maintenant pour saisir cette opportunité unique!`;
      }
    } else {
      // English descriptions
      if (variant === 1) {
        return `${companyName} is looking for a ${targetProfile} for a ${jobType} position. 
        
We are seeking a ${seniority}-level professional with proven experience in the industry. The ideal candidate has excellent skills in ${
          keywordsList.length > 0
            ? keywordsList.join(", ")
            : "communication and teamwork"
        }.

This position offers a unique opportunity to join a dynamic team and significantly contribute to the company's growth. We offer a stimulating work environment and competitive benefits.`;
      } else if (variant === 2) {
        return `Exceptional job opportunity at ${companyName} - ${jobType}

We are proud to open a position for a ${seniority} ${targetProfile}. Your role will be crucial for the development of our activities and innovation within our structure.

Required skills:
${
  keywordsList.length > 0
    ? keywordsList.map((k) => `- Proficiency in ${k.trim()}`).join("\n")
    : "- Excellent analytical skills\n- Ability to work in a team\n- Organizational skills"
}

Join us to shape the future together in a professional and rewarding environment.`;
      } else {
        return `${companyName} - ${targetProfile} Recruitment (${jobType})

Are you a passionate ${seniority}-level professional looking for a new challenge? Our team is growing, and we're looking for talent like you!

Your mission will be to ${
          jobInfo.description ||
          "contribute to the development of our innovative projects"
        }. You will work closely with our multidisciplinary teams in a stimulating environment.

${
  keywordsList.length > 0
    ? `What we're looking for: ${keywordsList.join(", ")}`
    : "We value creativity, team spirit, and commitment."
}

Apply now to seize this unique opportunity!`;
      }
    }
  };

  return (
    <Card className="relative w-full max-h-[70vh] bg-white rounded-2xl overflow-hidden shadow-xl">
      <CardContent className="p-0 h-full flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b flex-shrink-0">
          <h1 className="text-xl font-bold text-gray-900">
            <Trans>Generate with AI</Trans>
          </h1>
        </div>

        <div className="flex flex-col md:flex-row flex-1 min-h-0">
          {/* Left Panel */}
          <div className="w-full md:w-[50%] border-b md:border-b-0 md:border-r bg-gray-50 flex flex-col">
            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-4 md:p-5">
              <div className="space-y-4">
                <JobInformationSection values={jobInfo} onChange={setJobInfo} />
                <LanguagePreferences values={prefs} onChange={setPrefs} />
                <AdditionalPreferences
                  companyName={prefs.companyName || ""}
                  maxWordCount={prefs.maxWordCount || 150}
                  onChange={(field, value) =>
                    setPrefs((prev) => ({ ...prev, [field]: value }))
                  }
                />
              </div>
            </div>

            {/* Footer Actions - Fixed at bottom */}
            <div className="p-4 md:p-5 border-t bg-gray-50 flex-shrink-0">
              <div className="flex gap-3 justify-end">
                <Button
                  variant="ghost"
                  className="text-gray-700 border border-gray-300"
                  onClick={handleClose}
                >
                  <Trans>Cancel</Trans>
                </Button>
                <Button
                  onClick={() => handleGenerate()}
                  className="bg-gradient-to-b from-[#4D9CA1] to-[#015156] text-white hover:opacity-90"
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <>
                      <div className="w-4 h-4 mr-2 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                      <Trans>Generating...</Trans>
                    </>
                  ) : (
                    <>
                      <img className="w-4 h-4 mr-2" src="/Ai.png" alt="AI" />
                      <Trans>Generate</Trans>
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>

          {/* Right Panel - Output List */}
          <div className="w-full md:w-[50%] flex flex-col">
            <div className="p-4 md:p-5 border-b flex-shrink-0">
              <h2 className="text-base font-semibold text-gray-800">
                <Trans>Generated Outputs</Trans>
              </h2>
            </div>
            <div className="flex-1 overflow-y-auto p-4 md:p-5">
              <div className="space-y-6">
                {outputs.map((output, index) => (
                  <div key={index} className="space-y-3">
                    <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">
                      {output.text}
                    </p>
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                      <Button
                        variant="outline"
                        onClick={() => handleConfirm(output.text)}
                        className="w-full sm:w-auto"
                      >
                        <Trans>Confirm</Trans>
                      </Button>
                      <span className="text-xs text-gray-400">
                        {output.timeAgo}
                      </span>
                    </div>
                    {index < outputs.length - 1 && (
                      <Separator className="my-4" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
