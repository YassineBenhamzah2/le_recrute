import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Interview } from "@/lib/types/interview";
import {
  BookCheck,
  CalendarIcon,
  CheckIcon,
  ClockIcon,
  EditIcon,
  UserIcon,
  VideoIcon,
  XIcon,
  Building2,
  MapPin,
  FileText,
  Star,
  MessageSquare,
  Mail,
  Phone,
} from "lucide-react";
import { Trans } from "@lingui/macro";

type Props = {
  interviews: Interview[];
  handleEditInterview: (id: number) => void;
  handleCompleteInterview: (id: number) => void;
  handleCancelInterview: (id: number) => void;
  handleCandidateScoring: (id: number) => void;
};

export const InterviewActionsSection = ({
  interviews,
  handleEditInterview,
  handleCompleteInterview,
  handleCancelInterview,
  handleCandidateScoring,
}: Props): JSX.Element => {
  const renderStatusBadge = (status: string) => {
    if (status === "Scheduled") {
      return (
        <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
          <CalendarIcon className="w-3 h-3 mr-1" />
          <Trans>Scheduled</Trans>
        </Badge>
      );
    } else if (status === "Completed") {
      return (
        <Badge className="bg-[#238d9426] text-[#238d94] hover:bg-[#238d9426]">
          <CheckIcon className="w-3 h-3 mr-1" />
          <Trans>Completed</Trans>
        </Badge>
      );
    } else if (status === "Cancelled") {
      return (
        <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
          <XIcon className="w-3 h-3 mr-1" />
          <Trans>Cancelled</Trans>
        </Badge>
      );
    }
    return <Badge>{status}</Badge>;
  };

  const renderDecisionBadge = (decision?: string) => {
    if (!decision || decision === "ON_HOLD") {
      return (
        <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
          <ClockIcon className="w-3 h-3 mr-1" />
          <Trans>Pending Review</Trans>
        </Badge>
      );
    } else if (decision === "ACCEPTED") {
      return (
        <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
          <CheckIcon className="w-3 h-3 mr-1" />
          <Trans>Approved</Trans>
        </Badge>
      );
    } else if (decision === "REJECTED") {
      return (
        <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
          <XIcon className="w-3 h-3 mr-1" />
          <Trans>Rejected</Trans>
        </Badge>
      );
    }
    return <Badge>{decision}</Badge>;
  };

  return (
    <section className="flex flex-col items-start gap-6 w-full">
      {interviews.map((interview) => (
        <Card
          key={interview.id}
          className="w-full border shadow-[0px_1px_2px_#0000000d] rounded-xl"
        >
          <CardContent className="flex flex-col items-start gap-5 p-6">
            {/* Header */}
            <div className="flex items-start justify-between w-full">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-[#238d94] flex items-center justify-center">
                  <UserIcon className="w-6 h-6 text-white" />
                </div>
                <div className="flex flex-col">
                  <h3 className="text-gray-900 text-xl leading-7 font-semibold">
                    {interview.name}
                  </h3>
                  <p className="text-gray-600 text-base leading-6">
                    {interview.position}
                  </p>
                  {interview.candidate?.email && (
                    <div className="flex items-center gap-4 mt-1">
                      <p className="text-gray-500 text-sm flex items-center gap-1">
                        <Mail className="w-3 h-3" />
                        {interview.candidate.email}
                      </p>
                      {interview.candidate?.whatsapp_number && (
                        <p className="text-gray-500 text-sm flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          {interview.candidate.whatsapp_number}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex flex-col gap-2 items-end">
                {renderStatusBadge(interview.status)}
                {interview.juryFeedback?.decision &&
                  renderDecisionBadge(interview.juryFeedback.decision)}
              </div>
            </div>

            {/* Job and Company Info */}
            {interview.jobOffer && (
              <div className="flex items-center gap-6 w-full p-3 bg-gray-50 rounded-lg">
                <InfoItem
                  icon={<Building2 className="w-4 h-4 text-gray-500" />}
                  label={
                    interview.jobOffer.company?.name || <Trans>Company</Trans>
                  }
                />
                {interview.jobOffer.location && (
                  <InfoItem
                    icon={<MapPin className="w-4 h-4 text-gray-500" />}
                    label={interview.jobOffer.location}
                  />
                )}
                {interview.jobOffer.contractType && (
                  <InfoItem
                    icon={<FileText className="w-4 h-4 text-gray-500" />}
                    label={interview.jobOffer.contractType}
                  />
                )}
              </div>
            )}

            {/* Interview Details */}
            <div className="flex items-start justify-center gap-4 w-full">
              <InfoItem
                icon={<VideoIcon className="w-4 h-4 text-gray-500" />}
                label={interview.type}
              />
              <InfoItem
                icon={<CalendarIcon className="w-4 h-4 text-gray-500" />}
                label={interview.date}
              />
              <InfoItem
                icon={<ClockIcon className="w-4 h-4 text-gray-500" />}
                label={interview.time}
              />
              <InfoItem
                icon={<UserIcon className="w-4 h-4 text-gray-500" />}
                label={
                  interview.interviewers.length === 0 ? (
                    <Trans>No Interviewers Assigned</Trans>
                  ) : (
                    <Trans>
                      {interview.interviewers.length} Interviewer
                      {interview.interviewers.length > 1 ? "s" : ""}
                    </Trans>
                  )
                }
              />
            </div>

            {/* Interviewers List */}
            {interview.interviewers.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {interview.interviewers.map((interviewer, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {interviewer}
                  </Badge>
                ))}
              </div>
            )}

            {/* Notes and Observations */}
            {(interview.notes || interview.juryFeedback?.observations) && (
              <div className="w-full space-y-3">
                {interview.notes && (
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <MessageSquare className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-800">
                        <Trans>Notes</Trans>
                      </span>
                    </div>
                    <p className="text-blue-700 text-sm">{interview.notes}</p>
                  </div>
                )}
                {interview.juryFeedback?.observations && (
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Star className="w-4 h-4 text-purple-600" />
                      <span className="text-sm font-medium text-purple-800">
                        <Trans>Interview Observations</Trans>
                      </span>
                    </div>
                    <p className="text-purple-700 text-sm">
                      {interview.juryFeedback.observations}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Meeting link */}
            {interview.meetingLink && (
              <div className="flex flex-col items-start p-3 w-full bg-green-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <VideoIcon className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-medium text-green-800">
                    <Trans>Meeting Link</Trans>
                  </span>
                </div>
                <a
                  href={interview.meetingLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-green-700 text-sm hover:underline break-all"
                >
                  {interview.meetingLink}
                </a>
              </div>
            )}

            {/* Actions */}
            {interview.showActions && (
              <div className="flex items-center w-full gap-3 pt-4 border-t border-gray-100">
                <Button
                  variant="outline"
                  className="flex-1 bg-[#14b8a626] text-[#238d94] hover:bg-[#14b8a635] border-[#238d94]/20"
                  onClick={() => handleCompleteInterview(interview.id)}
                  disabled={interview.status === "Completed"}
                >
                  <CheckIcon className="w-4 h-4 mr-2" />
                  <Trans>Complete</Trans>
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 bg-red-50 text-red-700 hover:bg-red-100 border-red-200"
                  onClick={() => handleCancelInterview(interview.id)}
                  disabled={interview.status === "Cancelled"}
                >
                  <XIcon className="w-4 h-4 mr-2" />
                  <Trans>Cancel</Trans>
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 bg-gray-50 text-gray-700 hover:bg-gray-100 border-gray-200"
                  onClick={() => handleEditInterview(interview.id)}
                >
                  <EditIcon className="w-4 h-4 mr-2" />
                  <Trans>Edit</Trans>
                </Button>
                <Button
                  variant="default"
                  className="bg-[#238d94] flex-1 text-white hover:text-white/90 hover:bg-[#1c7a80] shadow-sm"
                  onClick={() => handleCandidateScoring(interview.id)}
                  disabled={interview.status !== "Completed"}
                >
                  <BookCheck className="w-4 h-4 mr-2" />
                  <Trans>Candidate Scoring</Trans>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </section>
  );
};

const InfoItem = ({
  icon,
  label,
  className = "flex items-center flex-1 min-w-0",
}: {
  icon: React.ReactNode;
  label: string | React.ReactNode;
  className?: string;
}) => (
  <div className={className}>
    {icon}
    <span
      className="pl-2 text-gray-600 text-sm truncate"
      title={typeof label === "string" ? label : undefined}
    >
      {label}
    </span>
  </div>
);
