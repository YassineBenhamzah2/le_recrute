import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { InterviewStatusType } from "./EditInterview";
import { Trans } from "@lingui/macro";
import { t } from "@lingui/core/macro";

interface InterviewStatusProps {
  data: InterviewStatusType;
  setData: (data: InterviewStatusType) => void;
}

export const InterviewStatusSection = ({
  data,
  setData,
}: InterviewStatusProps): JSX.Element => {
  const statusOptions = [
    { id: "scheduled", label: "Scheduled" },
    { id: "completed", label: "Completed" },
    { id: "canceled", label: "Canceled" },
  ];

  return (
    <Card className="flex flex-col w-full items-start pt-[15px] pb-5 px-5 bg-[#f6f6f6] rounded-[15px]">
      <CardContent className="p-0 w-full">
        <h2 className="w-full mb-2 [font-family:'Segoe_UI-Bold',Helvetica] font-bold text-[#238d94] text-lg tracking-[0] leading-9">
          <Trans>Status and Notes</Trans>
        </h2>

        <div className="flex flex-col items-start w-full mb-2">
          <h3 className="w-full text-gray-900 text-[13px] [font-family:'Segoe_UI-Bold',Helvetica] font-bold tracking-[0] leading-9">
            <Trans>Interview Status</Trans>
          </h3>

          <RadioGroup
            value={data.status}
            onValueChange={(value) =>
              setData({
                ...data,
                status: value as InterviewStatusType["status"],
              })
            }
            className="flex items-center gap-[68px] w-full"
          >
            {statusOptions.map((option) => (
              <div key={option.id} className="flex items-center gap-[7px]">
                <RadioGroupItem
                  value={option.id}
                  id={option.id}
                  className={`w-4 h-4 rounded-lg border-[0.8px] border-solid ${
                    data.status === option.id
                      ? "border-[#238d94]"
                      : "border-[#aeaeb2]"
                  }`}
                />
                <Label
                  htmlFor={option.id}
                  className="[font-family:'Segoe_UI-Regular',Helvetica] font-normal text-gray-900 text-xs tracking-[0] leading-[normal]"
                >
                  <Trans id={`interview.status.${option.id}`}>
                    {option.label}
                  </Trans>
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>

        <div className="flex flex-col items-start w-full">
          <h3 className="w-full [font-family:'Segoe_UI-Bold',Helvetica] font-bold text-gray-900 text-[13px] tracking-[0] leading-9">
            <Trans>Notes (Internal)</Trans>
          </h3>

          <Textarea
            placeholder={t`Add internal notes for team reference...`}
            value={data.notes}
            onChange={(e) => setData({ ...data, notes: e.target.value })}
            className="w-full h-[53px] bg-white rounded-[7.2px] border-[0.9px] border-solid border-gray-300 [font-family:'Segoe_UI-Regular',Helvetica] font-normal text-gray-400 text-xs"
          />
        </div>
      </CardContent>
    </Card>
  );
};
