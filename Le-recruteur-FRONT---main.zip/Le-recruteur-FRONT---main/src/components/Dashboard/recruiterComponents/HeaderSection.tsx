import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeftIcon,
  CalendarIcon,
  MapPinIcon,
  BriefcaseIcon,
  DollarSignIcon,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { JobOffer } from "@/lib/types/jobOffer";
import { Trans } from "@lingui/macro";


interface HeaderSectionProps {
  title: string;
  applicantsCount: number;
  jobOffer?: JobOffer; // Optional for backward compatibility
}

export const HeaderSection = ({
  title,
  applicantsCount,
  jobOffer,
}: HeaderSectionProps): JSX.Element => {
  const navigate = useNavigate();
  const handleBackClick = () => {
    navigate(-1); // Navigate back to the previous page
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("fr-FR");
  };

  const formatSalary = (min: number, max: number, currency = "€") => {
    if (min === 0 && max === 0) return <Trans>Salary not specified</Trans>;
    if (min === max) return `${min.toLocaleString()} ${currency}`;
    return `${min.toLocaleString()} - ${max.toLocaleString()} ${currency}`;
  };

  return (
    <header className="flex flex-col w-full items-start gap-4 pt-4 sm:pt-6 pb-4 sm:pb-6 px-3 sm:px-4 md:px-6 border-b">
      <div className="flex items-center w-full">
        <Button
          variant="ghost"
          className="flex items-center p-0 h-auto transition-colors duration-200 hover:bg-gray-100"
          asChild
        >
          <a
            href="#"
            className="flex items-center text-gray-600"
            onClick={handleBackClick}
          >
            <ArrowLeftIcon className="w-4 sm:w-5 h-4 sm:h-5" />
            <span className="ml-2 font-normal text-sm sm:text-base">
              <Trans>Back to Jobs</Trans>
            </span>
          </a>
        </Button>
      </div>

      <div className="flex flex-col items-start gap-4 w-full">
        <div className="flex flex-col gap-2 w-full">
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 leading-7 sm:leading-8 w-full break-words">
            {title}
          </h1>
          <p className="text-sm sm:text-base font-normal text-gray-600 leading-5 sm:leading-6 w-full">
            <Trans>{{count: applicantsCount}} candidates applied</Trans>
          </p>
        </div>

        {jobOffer && (
          <div className="w-full">
            {/* Job Details Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPinIcon className="w-4 h-4" />
                <span>{jobOffer.location}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <BriefcaseIcon className="w-4 h-4" />
                <span>
                  {jobOffer.jobType} • {jobOffer.contractType}
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <DollarSignIcon className="w-4 h-4" />
                <span>
                  {formatSalary(jobOffer.minSalary, jobOffer.maxSalary)}
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <CalendarIcon className="w-4 h-4" />
                <span><Trans>Deadline</Trans>: {formatDate(jobOffer.deadlineDate)}</span>
              </div>
            </div>

            {/* Status and Negotiable */}
            <div className="flex items-center gap-3 mb-4">
              <Badge
                variant={jobOffer.status === "ACTIVE" ? "default" : "secondary"}
                className={`${
                  jobOffer.status === "ACTIVE"
                    ? "bg-green-100 text-green-800 border-green-200 hover:bg-green-200"
                    : "bg-gray-100 text-gray-800 border-gray-200 hover:bg-gray-200"
                }`}
              >
                {jobOffer.status === "ACTIVE" ? <Trans>ACTIVE</Trans> : jobOffer.status}
              </Badge>
              {jobOffer.negotiable && (
                <Badge
                  variant="outline"
                  className="bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
                >
                  <Trans>Salary Negotiable</Trans>
                </Badge>
              )}
            </div>

            {/* Job Description Preview */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold text-gray-900 mb-2">
                <Trans>Job Description</Trans>
              </h3>
              <p className="text-sm text-gray-600 line-clamp-3">
                {jobOffer.description}
              </p>
            </div>

            {/* Requirements Preview */}
            {jobOffer.requirements && jobOffer.requirements.length > 0 && (
              <div className="mt-4">
                <h3 className="font-semibold text-gray-900 mb-2">
                  <Trans>Key Requirements</Trans>
                </h3>
                <div className="flex flex-wrap gap-2">
                  {jobOffer.requirements
                    .slice(0, 3)
                    .map((requirement, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {requirement}
                      </Badge>
                    ))}
                  {jobOffer.requirements.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{jobOffer.requirements.length - 3} <Trans>more</Trans>
                    </Badge>
                  )}
                </div>
              </div>
            )}

            {/* Skills Preview */}
            {jobOffer.skills && jobOffer.skills.length > 0 && (
              <div className="mt-4">
                <h3 className="font-semibold text-gray-900 mb-2">
                  <Trans>Required Skills</Trans>
                </h3>
                <div className="flex flex-wrap gap-2">
                  {jobOffer.skills.slice(0, 5).map((skill, index) => (
                    <Badge
                      key={index}
                      variant="outline"
                      className="bg-blue-50 text-blue-700 border-blue-200"
                    >
                      {skill}
                    </Badge>
                  ))}
                  {jobOffer.skills.length > 5 && (
                    <Badge
                      variant="outline"
                      className="bg-blue-50 text-blue-700 border-blue-200"
                    >
                      +{jobOffer.skills.length - 5} <Trans>more</Trans>
                    </Badge>
                  )}
                </div>
              </div>
            )}

            {/* Responsibilities Preview */}
            {jobOffer.responsibilities &&
              jobOffer.responsibilities.length > 0 && (
                <div className="mt-4">
                  <h3 className="font-semibold text-gray-900 mb-2">
                    <Trans>Responsibilities</Trans>
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {jobOffer.responsibilities
                      .slice(0, 3)
                      .map((responsibility, index) => (
                        <Badge
                          key={index}
                          variant="outline"
                          className="bg-purple-50 text-purple-700 border-purple-200"
                        >
                          {responsibility}
                        </Badge>
                      ))}
                    {jobOffer.responsibilities.length > 3 && (
                      <Badge
                        variant="outline"
                        className="bg-purple-50 text-purple-700 border-purple-200"
                      >
                        +{jobOffer.responsibilities.length - 3} <Trans>more</Trans>
                      </Badge>
                    )}
                  </div>
                </div>
              )}

            {/* Tags Preview */}
            {jobOffer.tags && jobOffer.tags.length > 0 && (
              <div className="mt-4">
                <h3 className="font-semibold text-gray-900 mb-2">
                  <Trans>Tags</Trans>
                </h3>
                <div className="flex flex-wrap gap-2">
                  {jobOffer.tags.map((tag, index) => (
                    <Badge
                      key={index}
                      variant="outline"
                      className="bg-green-50 text-green-700 border-green-200"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
};