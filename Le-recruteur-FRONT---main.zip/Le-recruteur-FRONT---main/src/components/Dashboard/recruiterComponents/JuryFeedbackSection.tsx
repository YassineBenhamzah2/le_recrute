import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { JuryFeedbackType } from "./EditInterview";
import { Trans ,t} from "@lingui/macro";

interface JuryFeedbackProps {
    data: JuryFeedbackType;
    setData: (data: JuryFeedbackType) => void;
}

export const JuryFeedbackSection = ({
    data,
    setData,
}: JuryFeedbackProps): JSX.Element => {
    // Decision options data
    const decisionOptions = [
        { id: "ACCEPTED", label: "Approved" },
        { id: "REJECTED", label: "Not Approved" },
        { id: "ON_HOLD", label: "Pending Decision" },
    ];
    
    const handleObservationChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setData({ ...data, observations: e.target.value as JuryFeedbackType["observations"] });
    };

    const handleDecisionChange = (value: string) => {
        setData({ ...data, decision: value as JuryFeedbackType["decision"] });
    };

    return (
        <Card className="flex flex-col w-full items-start p-5 bg-[#f6f6f6] rounded-[15px]">
            <h2 className="text-[#238d94] text-lg font-bold font-['Segoe_UI-Bold',Helvetica] leading-9 mb-2">
                <Trans>Jury/Feedback</Trans>
            </h2>

            <div className="flex flex-col items-start w-full mb-2">
                <h3 className="text-gray-900 text-[13px] font-bold font-['Segoe_UI-Bold',Helvetica] leading-9">
                    <Trans>Jury Observations</Trans>
                </h3>

                <Textarea
                    className="w-full h-[53px] bg-white rounded-[7.2px] border-[0.9px] border-gray-300 p-2"
                    placeholder={t`Write internal observations, feedback or comments here...`}
                    value={data.observations}
                    onChange={handleObservationChange}
                />
            </div>

            <div className="flex flex-col items-start w-full">
                <h3 className="text-gray-900 text-[13px] font-bold font-['Segoe_UI-Bold',Helvetica] leading-9">
                    <Trans>Jury Decision</Trans>
                </h3>

                <RadioGroup
                    value={data.decision}
                    onValueChange={handleDecisionChange}
                    className="flex items-center gap-[68px] w-full"
                >
                    {decisionOptions.map((option) => (
                        <div key={option.id} className="flex items-center gap-[7px]">
                            <RadioGroupItem
                                value={option.id}
                                id={option.id}
                                className={
                                    data.decision === option.id
                                        ? "border-[#238d94] text-[#238d94]"
                                        : "border-[#aeaeb2]"
                                }
                            />
                            <Label
                                htmlFor={option.id}
                                className="font-['Segoe_UI-Regular',Helvetica] font-normal text-gray-900 text-xs"
                            >
                                <Trans id={`jury.decision.${option.id}`}>{option.label}</Trans>
                            </Label>
                        </div>
                    ))}
                </RadioGroup>
            </div>
        </Card>
    );
};