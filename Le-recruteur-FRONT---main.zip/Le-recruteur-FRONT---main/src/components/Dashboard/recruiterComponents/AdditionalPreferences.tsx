import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Trans , t } from "@lingui/macro";

interface AdditionalPreferencesProps {
  companyName: string;
  maxWordCount: number;
  onChange: (field: string, value: string | number) => void;
}

export const AdditionalPreferences = ({
  companyName,
  maxWordCount,
  onChange,
}: AdditionalPreferencesProps): JSX.Element => {
  return (
    <div className="flex flex-col w-full items-start relative mt-5">
      <h2 className="w-full text-[#238d94] text-lg relative mt-[-1.00px] font-bold tracking-[0] leading-9">
        <Trans>Additional Information</Trans>
      </h2>

      <div className="flex flex-col items-start w-full">
        <Label
          htmlFor="companyName"
          className="font-bold text-gray-900 text-sm leading-9"
        >
          <Trans>Company Name</Trans>
        </Label>
        <Input
          id="companyName"
          className="w-full h-[38px] bg-white text-gray-400 rounded-[7.2px] border border-gray-300 px-4 py-2"
          placeholder={t`e.g. Acme Corporation`}
          value={companyName}
          onChange={(e) => onChange("companyName", e.target.value)}
        />
      </div>

      <div className="flex flex-col items-start w-full mt-4">
        <div className="flex justify-between w-full">
          <Label
            htmlFor="maxWordCount"
            className="font-bold text-gray-900 text-sm leading-9"
          >
            <Trans>Maximum Word Count</Trans>
          </Label>
          <span className="text-sm text-gray-600">
            <Trans>{maxWordCount} words</Trans>
          </span>
        </div>
        <Slider
          id="maxWordCount"
          className="mt-2"
          defaultValue={[maxWordCount]}
          value={[maxWordCount]}
          min={50}
          max={300}
          step={10}
          onValueChange={(value: number[]) =>
            onChange("maxWordCount", value[0])
          }
        />
        <div className="flex justify-between w-full text-xs text-gray-500 mt-1">
          <span>50</span>
          <span>300</span>
        </div>
      </div>
    </div>
  );
};