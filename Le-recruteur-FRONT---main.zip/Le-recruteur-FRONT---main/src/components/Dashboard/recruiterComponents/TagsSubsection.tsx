import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { TrashIcon, TagIcon } from "lucide-react";
import { useState } from "react";
import { Trans , t } from "@lingui/macro"; // Ajout de l'import Trans

interface TagsSubsectionProps {
  formData: {
    tags: string[];
  };
  addTag: (tag: string) => void;
  removeTag: (index: number) => void;
}

export const TagsSubsection = ({
  formData,
  addTag,
  removeTag,
}: TagsSubsectionProps): JSX.Element => {
  const [newTag, setNewTag] = useState("");
  const tags = formData.tags?.filter((tag) => tag.trim() !== "") || [];

  const handleAdd = () => {
    if (newTag.trim() !== "") {
      addTag(newTag.trim());
      setNewTag("");
    }
  };

  return (
    <Card className="flex flex-col w-full items-start gap-[15.4px] p-6 bg-gray-50 rounded-xl">
      <div className="flex items-center gap-2 mb-4 w-full">
        <div className="relative w-5 h-5">
          <TagIcon className="w-5 h-5" />
        </div>
        <h2 className="font-bold text-gray-900 text-xl leading-7">
          <Trans>Job Tags</Trans>
        </h2>
      </div>

      <CardContent className="p-0 w-full space-y-4">
        <div className="flex flex-wrap gap-2 w-full">
          {tags.map((tag, index) => (
            <Badge
              key={index}
              className="flex items-center gap-1 px-3 py-2 bg-blue-100 text-blue-800 hover:bg-blue-200"
            >
              {tag}
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="h-4 w-4 p-0 ml-1 hover:bg-transparent"
                onClick={() => removeTag(index)}
                aria-label={<Trans>Delete tag</Trans>}
              >
                <TrashIcon className="h-3 w-3 text-blue-800" />
              </Button>
            </Badge>
          ))}
        </div>

        <div className="flex gap-2 w-full">
          <Input
            value={newTag}
            onChange={(e) => setNewTag(e.target.value)}
            placeholder={t`Enter a job tag (e.g. React, Senior, Remote)`}
            className="flex-1 h-[50px]"
          />
          <Button
            type="button"
            onClick={handleAdd}
            className="bg-[#238d94] hover:bg-[#1c7a80] text-white h-[50px]"
          >
            <Trans>Add Tag</Trans>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};