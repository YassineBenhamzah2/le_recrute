import { Skeleton } from "@/components/ui/skeleton";
import { settings } from "@/lib/settings/main";
import { Candidate } from "@/lib/types/recruiter";
import { t } from "@lingui/core/macro";
import { Trans } from "@lingui/macro";
import {
  Briefcase,
  Download,
  GraduationCap,
  Mail,
  MapPin,
  Phone,
  Search,
} from "lucide-react";
import React from "react";

interface CandidatesTableProps {
  candidates: Candidate[];
  isLoading: boolean;
  onDownloadCv?: (candidateId: number, candidateName: string) => void; // for handling CV downloads
}

export const CandidatesTable: React.FC<CandidatesTableProps> = ({
  candidates,
  isLoading,
  onDownloadCv,
}) => {
  const getStatusBadge = (status: string) => {
    const statusConfig: { [key: string]: string } = {
      "Disponible immédiatement": "bg-green-100 text-green-800",
      "Disponible avec préavis": "bg-yellow-100 text-yellow-800",
      "Non disponible": "bg-red-100 text-red-800",
      "N/A": "bg-gray-100 text-gray-800",
    };
    return statusConfig[status] || "bg-gray-100 text-gray-800";
  };

  // Translate status labels
  const translateStatus = (status: string) => {
    const statusTranslations: { [key: string]: React.ReactNode } = {
      "Disponible immédiatement": <Trans>Disponible immédiatement</Trans>,
      "Disponible avec préavis": <Trans>Disponible avec préavis</Trans>,
      "Non disponible": <Trans>Non disponible</Trans>,
      "N/A": <Trans>N/A</Trans>,
    };
    return statusTranslations[status] || status;
  };

  // --- HELPER FUNCTION FOR CLEAN DISPLAY ---
  const renderField = (
    value: string | null | undefined,
    icon?: React.ReactNode
  ) => {
    if (!value || value === "N/A" || value === "Non spécifié") {
      return <span className="text-gray-400">-</span>;
    }
    // This part was missing. It needs to return the actual JSX.
    return (
      <div className="text-sm text-gray-900 flex items-start gap-1.5">
        {icon && (
          <span className="text-gray-400 mt-0.5 flex-shrink-0">{icon}</span>
        )}
        <span>{value}</span>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
        <h3 className="text-lg font-semibold text-gray-900">
          <Trans>Candidats CV</Trans>
        </h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                <Trans>Candidat</Trans>
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32">
                <Trans>Statut</Trans>
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                <Trans>Contact</Trans>
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-44">
                <Trans>Adresse</Trans>
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-40">
                <Trans>Formation</Trans>
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32">
                <Trans>Expérience</Trans>
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-56">
                <Trans>Compétences</Trans>
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-40">
                <Trans>Certifications</Trans>
              </th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-20">
                <Trans>CV</Trans>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {isLoading
              ? Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 9 }).map((_, j) => (
                      <td key={j} className="px-4 py-4">
                        <Skeleton className="h-4 w-full" />
                      </td>
                    ))}
                  </tr>
                ))
              : candidates.map((candidate) => (
                  <tr
                    key={candidate.id}
                    className="hover:bg-gray-50 transition-colors"
                  >
                    <td className="px-4 py-4">
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {candidate.name}
                        </div>
                        <div className="text-sm text-[#1a6b72] font-medium">
                          {renderField(candidate.currentPosition)}
                        </div>
                        <div className="text-sm text-gray-500">
                          {renderField(candidate.company)}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <span
                        className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${getStatusBadge(
                          candidate.status
                        )}`}
                      >
                        {translateStatus(candidate.status)}
                      </span>
                      <div className="text-xs text-gray-400 mt-1">
                        {candidate.lastUpdate}
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="space-y-1">
                        <div className="text-sm text-gray-900 flex items-center gap-1">
                          <Mail className="w-3 h-3 text-gray-400" />
                          <span>{renderField(candidate.email)}</span>
                        </div>
                        <div className="text-sm text-gray-900 flex items-center gap-1">
                          <Phone className="w-3 h-3 text-gray-400" />
                          {renderField(candidate.phone)}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="text-sm text-gray-900 flex items-start gap-1">
                        <MapPin className="w-3 h-3 text-gray-400 mt-0.5" />
                        <span>{renderField(candidate.location)}</span>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="text-sm text-gray-900 flex items-start gap-1">
                        <GraduationCap className="w-3 h-3 text-gray-400 mt-0.5" />
                        <span>{renderField(candidate.education)}</span>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="text-sm text-gray-900 flex items-center gap-1">
                        <Briefcase className="w-3 h-3 text-gray-400" />
                        {renderField(candidate.experience)}
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex flex-wrap gap-1">
                        {candidate.skills && candidate.skills.length > 0 ? (
                          candidate.skills.map((skill, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-teal-100 text-teal-800"
                            >
                              {skill}
                            </span>
                          ))
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex flex-wrap gap-1">
                        {candidate.certifications &&
                        candidate.certifications.length > 0 ? (
                          candidate.certifications.map((cert, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800"
                            >
                              {cert}
                            </span>
                          ))
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-4 text-center">
                      {candidate.hasCV ? (
                        // Use the download function if provided, otherwise fallback to direct link
                        onDownloadCv ? (
                          <button
                            onClick={() =>
                              onDownloadCv(candidate.id, candidate.name)
                            }
                            className="inline-flex items-center justify-center w-8 h-8 text-teal-600 bg-teal-50 border border-teal-200 rounded-lg hover:bg-teal-100 transition-colors"
                            title={t`Télécharger le CV`}
                          >
                            <Download className="w-4 h-4" />
                          </button>
                        ) : (
                          <a
                            href={`${settings.IMG_ADDRESS}/files/${candidate.cvId}/view`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center justify-center w-8 h-8 text-teal-600 bg-teal-50 border border-teal-200 rounded-lg hover:bg-teal-100 transition-colors"
                            title={t`Voir le CV`}
                          >
                            <Download className="w-4 h-4" />
                          </a>
                        )
                      ) : (
                        // No CV and no upload function
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                  </tr>
                ))}
          </tbody>
        </table>
      </div>
      {candidates.length === 0 && !isLoading && (
        <div className="text-center py-12">
          <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            <Trans>Aucun candidat trouvé</Trans>
          </h3>
          <p className="text-gray-500">
            <Trans>Essayez de modifier vos critères de recherche.</Trans>
          </p>
        </div>
      )}
    </div>
  );
};
