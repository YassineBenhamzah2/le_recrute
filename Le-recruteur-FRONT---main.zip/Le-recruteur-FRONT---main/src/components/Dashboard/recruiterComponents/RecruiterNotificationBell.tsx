import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Bell } from 'lucide-react';
import { notificationService } from '@/lib/network/notification';
import { Notification } from '@/lib/types/notification';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';
import { notificationEmitter } from '@/lib/events/notificationEmitter';
import { useLingui, Trans , t } from '@lingui/macro';

const TABS = [
  { id: 'All', label: <Trans>All</Trans> },
  { id: 'Candidate Activity', label: <Trans>Candidate Activity</Trans> },
  { id: 'Interviews', label: <Trans>Interviews</Trans> },
  { id: 'tests', label: <Trans>Tests</Trans> },
  { id: 'System', label: <Trans>System</Trans> }
];

const NotificationBell: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [activeTab, setActiveTab] = useState('All');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { i18n } = useLingui();
  const isRTL = i18n.locale === 'ar';

  const fetchInitialData = useCallback(async () => {
    try {
      const countResponse = await notificationService.getCandidateUnreadCount();
      if (countResponse.success) {
        setUnreadCount(countResponse.data.count);
      }
      const listResponse = await notificationService.getCandidateNotifications();
      if (listResponse.success) {
        setNotifications(listResponse.data);
      }
    } catch (error) {
      console.error("Failed to fetch initial notifications:", error);
    }
  }, []);

  useEffect(() => {
    fetchInitialData();
  }, [fetchInitialData]);

  useEffect(() => {
    const handleNewNotification = (newNotification: Notification) => {
      console.log('%c[NotificationBell] Event received from emitter!', 'color: #00e6e6; font-weight: bold;', newNotification);

      setNotifications(prevNotifications => {
        const isDuplicate = prevNotifications.some(notif => notif.id === newNotification.id);
        if (!isDuplicate) {
          console.log("New notification received, updating state:", newNotification.id);
          setUnreadCount(prevUnreadCount => prevUnreadCount + 1);
          toast.info(newNotification.title, {
            description: newNotification.description,
          });
          return [newNotification, ...prevNotifications];
        } else {
          console.warn("Duplicate notification received, ignoring:", newNotification.id);
          return prevNotifications;
        }
      });
    };

    const unsubscribe = notificationEmitter.subscribe(handleNewNotification);

    return () => {
      unsubscribe();
    };
  }, []);

  const handleMarkAllAsRead = async () => {
    if (unreadCount === 0) return;
    try {
      const response = await notificationService.markCandidateAsRead();
      if (response.success) {
        toast.success(t`All notifications marked as read.`);
        // Re-fetch data from the DB to ensure consistency
        fetchInitialData();
      } else {
        toast.error(t`Failed to mark notifications as read.`);
      }
    } catch (error) {
      console.error("Error marking notifications as read:", error);
      toast.error(t`An error occurred. Please try again.`);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredNotifications = notifications.filter(notification => {
    if (activeTab === 'All') return true;
    if (activeTab === 'Interviews') return notification.notificationType.startsWith('INTERVIEW');
    if (activeTab === 'Candidate Activity') return notification.notificationType.startsWith('CANDIDATE');
    if (activeTab === 'tests') return notification.notificationType.startsWith('TEST');
    if (activeTab === 'System') return notification.notificationType.startsWith('SYSTEM');
    return true;
  });

  // Helper function to get notification icons based on type
  const getNotificationIcon = (notificationType: string) => {
    if (notificationType.startsWith('INTERVIEW')) {
      return (
        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
          <span className="text-blue-600 text-sm font-bold">I</span>
        </div>
      );
    }
    if (notificationType.startsWith('TEST')) {
      return (
        <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
          <span className="text-purple-600 text-sm font-bold">T</span>
        </div>
      );
    }
    if (notificationType.startsWith('CANDIDATE')) {
      return (
        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
          <span className="text-green-600 text-sm font-bold">C</span>
        </div>
      );
    }
    // Default or system icon
    return (
      <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
        <span className="text-gray-600 text-sm font-bold">S</span>
      </div>
    );
  };


  return (
    <div className="relative" ref={dropdownRef}>
      <button onClick={() => setIsOpen(!isOpen)} className="relative p-2 hover:bg-gray-100 rounded-full">
        <Bell size={20} className="text-gray-700" />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 block h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-white" />
        )}
      </button>

      {isOpen && (
        <div className={`${isRTL ? 'left-0 ' : 'right-0 '}absolute  top-full mt-2 w-[450px] bg-white rounded-xl shadow-2xl border border-gray-200 z-30`}>
          <div className="flex justify-between items-center px-6 py-4 border-b">
            <h2 className="text-xl font-bold text-gray-800">
              <Trans>Notifications</Trans>
            </h2>
            <button
              onClick={handleMarkAllAsRead}
              className="text-sm font-medium text-teal-600 hover:text-teal-800 disabled:text-gray-400"
              disabled={unreadCount === 0}
            >
              <Trans>Mark all as read</Trans>
            </button>
          </div>
          <div className="flex border-b px-2">
            {TABS.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-3 text-sm font-semibold transition-colors ${
                  activeTab === tab.id
                    ? 'border-b-2 border-teal-600 text-teal-600'
                    : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <div className="max-h-[60vh] overflow-y-auto">
            {filteredNotifications.length > 0 ? (
              filteredNotifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`flex items-center gap-4 px-6 py-4 border-b border-gray-100 transition-colors ${
                    !notif.isRead ? 'bg-teal-50' : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="relative flex-shrink-0">
                    {getNotificationIcon(notif.notificationType)}
                    {!notif.isRead && (
                      <span className="absolute -top-1 -right-1 block h-2 w-2 rounded-full bg-red-500" />
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-baseline">
                      <p className="font-bold text-sm text-gray-800">{notif.title}</p>
                      <p className="text-xs text-gray-400 whitespace-nowrap">
                        {formatDistanceToNow(new Date(notif.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                    <p className="text-sm text-gray-600 mt-0.5">{notif.description}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-10 text-center text-sm text-gray-500">
                <Trans>You have no notifications in this category.</Trans>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationBell;