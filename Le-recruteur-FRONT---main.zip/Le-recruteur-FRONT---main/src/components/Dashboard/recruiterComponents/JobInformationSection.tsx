import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Trans , t } from "@lingui/macro";

interface JobInformationValues {
    description: string;
    targetProfile: string;
    jobType: string;
}

interface JobInformationSectionProps {
    values: JobInformationValues;
    onChange: (updatedValues: JobInformationValues) => void;
}

export const JobInformationSection = ({
    values,
    onChange,
}: JobInformationSectionProps): JSX.Element => {
    const jobTypes = [
        { id: "internship", label: <Trans>Internship</Trans> },
        { id: "cdi", label: <Trans>CDI</Trans> },
        { id: "cdd", label: <Trans>CDD</Trans> },
        { id: "interim", label: <Trans>Interim</Trans> },
        { id: "freelance", label: <Trans>Freelance</Trans> },
    ];

    const handleChange = (field: keyof JobInformationValues, value: string) => {
        onChange({ ...values, [field]: value });
    };

    return (
        <section className="flex flex-col w-full items-start relative">
            <h2 className="w-full text-[#238d94] text-lg relative mt-[-1.00px] font-bold tracking-[0] leading-9">
                <Trans>Job Information</Trans>
            </h2>

            <div className="flex flex-col items-start w-full">
                <Label className="font-bold text-gray-900 text-[13px] leading-9">
                    <Trans>What is your job about?</Trans>
                </Label>
                <Textarea
                    placeholder={t`Write a brief description of the job...`}
                    value={values.description}
                    onChange={(e) => handleChange("description", e.target.value)}
                    className="w-full h-[77px] bg-white rounded-[7.2px] border border-gray-300 resize-none p-[15px] pt-2 text-gray-400 text-xs leading-[21.6px] placeholder:text-gray-400"
                />
            </div>

            <div className="flex flex-col items-start w-full">
                <Label className="font-bold text-gray-900 text-[13px] leading-9">
                    <Trans>Target Profile</Trans>
                </Label>
                <Input
                    placeholder={t`Write and separate keywords/traits with commas (e.g., Team player, UI/UX, detail-oriented)`}
                    value={values.targetProfile}
                    onChange={(e) => handleChange("targetProfile", e.target.value)}
                    className="w-full h-[38px] bg-white rounded-[7.2px] border border-gray-300 px-[15px] py-2 text-gray-400 text-xs leading-[21.6px] placeholder:text-gray-400"
                />
            </div>

            <div className="flex flex-col items-start w-full">
                <Label className="text-gray-900 text-[13px] font-bold leading-9">
                    <Trans>Job Type</Trans>
                </Label>
                <RadioGroup
                    value={values.jobType}
                    onValueChange={(val) => handleChange("jobType", val)}
                    className="flex items-center gap-10 w-full"
                >
                    {jobTypes.map((jobType) => (
                        <div key={jobType.id} className="flex items-center gap-0.5">
                            <RadioGroupItem
                                value={jobType.id}
                                id={jobType.id}
                                className="w-4 h-4 rounded-lg border border-[#aeaeb2] data-[state=checked]:border-[#238d94]"
                            />
                            <Label
                                htmlFor={jobType.id}
                                className="text-gray-900 text-xs font-normal cursor-pointer"
                            >
                                {jobType.label}
                            </Label>
                        </div>
                    ))}
                </RadioGroup>
            </div>
        </section>
    );
};