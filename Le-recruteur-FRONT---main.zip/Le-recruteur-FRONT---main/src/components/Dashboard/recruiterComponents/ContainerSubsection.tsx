import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { DialogHeader } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { X, Clock } from "lucide-react";
import { Trans , t} from "@lingui/macro"; // Ajout de l'import Trans

interface ContainerSubsectionProps {
  onClose?: () => void;
  scheduledDateTime?: string | null;
  isScheduled?: boolean;
}

export const ContainerSubsection = ({
  onClose,
  scheduledDateTime,
  isScheduled,
}: ContainerSubsectionProps): JSX.Element => {
  return (
    <DialogHeader>
      <Card className="w-full border-none shadow-none">
        <CardContent className="flex items-center justify-between p-0 py-2">
          <div className="flex items-center gap-3">
            <img className="w-16 h-16" alt={t`Hero Jobs Logo`} src="/HeroJobs.png" />

            <div className="flex flex-col">
              <div className="flex items-center gap-3">
                <h1 className="font-bold text-3xl text-gray-900 leading-9">
                  <Trans>Create New Job</Trans>
                </h1>
                {isScheduled && scheduledDateTime && (
                  <Badge
                    variant="outline"
                    className="flex items-center gap-1 text-blue-600 border-blue-200"
                  >
                    <Clock className="h-3 w-3" />
                    <Trans>Scheduled</Trans>
                  </Badge>
                )}
              </div>
              <p className="text-base text-gray-600 leading-6">
                {isScheduled && scheduledDateTime ? (
                  <Trans>
                    Will be published on {new Date(scheduledDateTime).toLocaleString()}
                  </Trans>
                ) : (
                  <Trans>Fill in the job information</Trans>
                )}
              </p>
            </div>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="rounded-lg"
            onClick={onClose}
            aria-label={t`Close modal`}
          >
            <X className="h-5 w-5" />
          </Button>
        </CardContent>
      </Card>
    </DialogHeader>
  );
};