import {
  BarChart,
  Bar,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
interface BarChartProps {
  data: { name: string; value: number }[];
}
const BarChartComponent = ({ data }: BarChartProps) => {
  return (
    <div className="xl:col-span-2 bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-gray-900">
          Candidates per Job Type
        </h3>
        <button className="text-[#238D94] hover:text-[#1a6b75] font-medium text-sm transition-colors duration-200 hover:bg-[#238D94] hover:bg-opacity-5 px-3 py-1 rounded-lg">
          View Details
        </button>
      </div>
      <ResponsiveContainer width="100%" height={600}>
        <BarChart
          data={data}
          barCategoryGap="10%"
          margin={{ top: 20, right: 30, left: 20, bottom: 80 }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis
            dataKey="name"
            angle={-45}
            textAnchor="end"
            height={100}
            interval={0}
            tick={{ fontSize: 12 }}
            axisLine={{ stroke: "#e5e7eb" }}
            tickLine={{ stroke: "#e5e7eb" }}
          />
          <YAxis
            axisLine={{ stroke: "#e5e7eb" }}
            tickLine={{ stroke: "#e5e7eb" }}
            tick={{ fontSize: 12 }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#1f2937",
              border: "none",
              borderRadius: "8px",
              color: "#fff",
              boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)",
            }}
            cursor={{ fill: "rgba(35, 141, 148, 0.1)" }}
            labelStyle={{ color: "#fff" }}
          />
          <Bar
            dataKey="value"
            fill="url(#gradient)"
            radius={[6, 6, 0, 0]}
            isAnimationActive={true}
            maxBarSize={60}
          />
          <defs>
            <linearGradient id="gradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#2da5b3" />
              <stop offset="100%" stopColor="#238D94" />
            </linearGradient>
          </defs>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default BarChartComponent;
