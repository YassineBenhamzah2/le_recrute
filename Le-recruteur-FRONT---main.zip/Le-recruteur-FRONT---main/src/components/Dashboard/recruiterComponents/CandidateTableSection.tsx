import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  CalendarIcon,
  CheckIcon,
  CircleUserRound,
  MailIcon,
  PhoneIcon,
  XIcon,
} from "lucide-react";
import { useState } from "react";
import { Candidate } from "../RecruiterJobDetailsDashboard";
import { CandidateDetailsModal } from "./CandidateDetailsModal";
import { useNavigate } from "react-router-dom";
import { Trans } from "@lingui/macro";


interface CandidateTableSectionProps {
  candidates: Candidate[];
  jobOfferId: number;
  onStatusChange: (
    candidateId: number,
    status: "approved" | "rejected"
  ) => void;
}

export const CandidateTableSection = ({
  candidates,
  jobOfferId,
  onStatusChange,
}: CandidateTableSectionProps): JSX.Element => {
  const navigate = useNavigate();
  const [selectedFullCandidate, setSelectedFullCandidate] =
    useState<Candidate | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const handleViewProfile = (candidate: Candidate) => {
    setSelectedFullCandidate(candidate);
    setShowDetailsModal(true);
  };
  const navigateToProfile = (candidateId: number) => {
    navigate(`/recruiter/jobs/${jobOfferId}/candidat/${candidateId}`);
  };
  return (
    <>
      <div className="flex flex-col w-full items-start justify-center overflow-auto px-2 sm:px-4 md:px-6">
        <div className="w-full overflow-x-auto">
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="whitespace-nowrap px-3 sm:px-4 md:px-6 py-4 [font-family:'Segoe_UI-Semibold',Helvetica] font-normal text-gray-500 text-xs tracking-[0.60px] leading-4">
                  <Trans>CANDIDATE</Trans>
                </TableHead>
                <TableHead className="whitespace-nowrap px-3 sm:px-4 md:px-6 py-4 [font-family:'Segoe_UI-Semibold',Helvetica] font-normal text-gray-500 text-xs tracking-[0.60px] leading-4 hidden sm:table-cell">
                  <Trans>CONTACT</Trans>
                </TableHead>
                <TableHead className="whitespace-nowrap px-3 sm:px-4 md:px-6 py-4 [font-family:'Segoe_UI-Semibold',Helvetica] font-normal text-gray-500 text-xs tracking-[0.60px] leading-4 hidden md:table-cell">
                  <Trans>APPLIED DATE</Trans>
                </TableHead>
                <TableHead className="whitespace-nowrap px-3 sm:px-4 md:px-6 py-4 [font-family:'Segoe_UI-Semibold',Helvetica] font-normal text-gray-500 text-xs tracking-[0.60px] leading-4">
                  <Trans>STATUS</Trans>
                </TableHead>
                <TableHead className="whitespace-nowrap px-3 sm:px-4 md:px-6 py-4 [font-family:'Segoe_UI-Semibold',Helvetica] font-normal text-gray-500 text-xs tracking-[0.60px] leading-4">
                  <Trans>ACTIONS</Trans>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="bg-white">
              {candidates.length > 0 ? (
                candidates.map((candidate) => (
                  <TableRow
                    key={candidate.id}
                    className="border-t border-solid hover:bg-gray-50 transition-colors duration-150"
                  >
                    <TableCell className="py-4 px-3 sm:px-4 md:px-6 text-xl font-extrabold">
                      <div className="[font-family:'Segoe_UI-Semibold',Helvetica] font-normal text-gray-900 text-sm">
                        <span
                          className="cursor-pointer hover:text-[#238d94] transition-colors"
                          onClick={() => handleViewProfile(candidate)}
                        >
                          {candidate.name}
                        </span>
                        <div className="sm:hidden text-xs text-gray-500 mt-1">
                          {candidate.email}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="px-3 sm:px-4 md:px-6 py-4 hidden sm:table-cell">
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center">
                          <PhoneIcon className="w-4 h-4 text-gray-600" />
                          <span className="pl-2 [font-family:'Segoe_UI-Regular',Helvetica] font-normal text-gray-600 text-sm">
                            {candidate.phone}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <MailIcon className="w-4 h-4 text-gray-600" />
                          <span className="pl-2 [font-family:'Segoe_UI-Regular',Helvetica] font-normal text-gray-600 text-sm">
                            {candidate.email}
                          </span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="px-3 sm:px-4 md:px-6 py-4 hidden md:table-cell">
                      <div className="flex items-center">
                        <CalendarIcon className="w-4 h-4 text-gray-600" />
                        <span className="pl-2 [font-family:'Segoe_UI-Regular',Helvetica] font-normal text-gray-600 text-sm">
                          {candidate.appliedDate}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="px-3 sm:px-4 md:px-6 py-4">
                      <Badge
                        className={`${
                          candidate.status === "approved"
                            ? "bg-green-100 text-green-800 hover:bg-green-100"
                            : candidate.status === "rejected"
                            ? "bg-red-100 text-red-800 hover:bg-red-100"
                            : "bg-gray-100 text-gray-800 hover:bg-gray-100"
                        }`}
                      >
                        {candidate.status === "approved" && (
                          <CheckIcon className="w-3.5 h-3.5 mr-1" />
                        )}
                        {candidate.status === "rejected" && (
                          <XIcon className="w-3.5 h-3.5 mr-1" />
                        )}
                        {candidate?.status &&
                          candidate.status === "approved" ? (
                            <Trans>Approved</Trans>
                          ) : candidate.status === "rejected" ? (
                            <Trans>Rejected</Trans>
                          ) : (
                            candidate.status.charAt(0).toUpperCase() +
                            candidate.status.slice(1)
                          )}
                      </Badge>
                    </TableCell>
                    <TableCell className="px-3 sm:px-4 md:px-6 py-4">
                      <div className="flex space-x-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="rounded-full p-1 transition-colors duration-200 hover:bg-blue-50"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigateToProfile(candidate.id);
                          }}
                          title={<Trans>View candidate profile</Trans>}
                        >
                          <CircleUserRound className="w-5 h-5 text-blue-600" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className={`rounded-full p-1 transition-colors duration-200 ${
                            candidate.status === "approved"
                              ? "bg-green-100"
                              : "hover:bg-green-50"
                          }`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onStatusChange(candidate.id, "approved");
                          }}
                          title={<Trans>Approve candidate</Trans>}
                        >
                          <CheckIcon className="w-5 h-5 text-green-500" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className={`rounded-full p-1 transition-colors duration-200 ${
                            candidate.status === "rejected"
                              ? "bg-red-100"
                              : "hover:bg-red-50"
                          }`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onStatusChange(candidate.id, "rejected");
                          }}
                          title={<Trans>Reject candidate</Trans>}
                        >
                          <XIcon className="w-5 h-5 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <p className="text-gray-500 text-sm">
                        <Trans>No candidates found</Trans>
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Candidate Details Modal */}
      {showDetailsModal && selectedFullCandidate && (
        <CandidateDetailsModal
          isOpen={showDetailsModal}
          onClose={() => setShowDetailsModal(false)}
          candidate={selectedFullCandidate}
          onStatusChange={onStatusChange}
          jobOfferId={jobOfferId}
        />
      )}
    </>
  );
};