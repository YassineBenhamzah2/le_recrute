import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { JobTypeList } from "@/lib/types/subtype/main";
import { convertToDateInputFormat } from "@/lib/utils/time";
import { Trans ,t } from "@lingui/macro"; // Ajout de l'import Trans

interface BackgroundWrapperSubsectionProps {
  formData: {
    jobType: string;
    contract: string;
    jobDeadline: string;
    description: string;
  };
  handleChange: (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => void;
  handleSelectChange: (name: string, value: string) => void;
  handleGenerateWithAi: () => void;
}

export const BackgroundWrapperSubsection = ({
  formData,
  handleChange,
  handleSelectChange,
  handleGenerateWithAi,
}: BackgroundWrapperSubsectionProps): JSX.Element => {
  return (
    <Card className="flex flex-col w-full items-start gap-[15.4px] p-6 bg-gray-50 rounded-xl">
      <div className="flex items-center gap-2 mb-4 w-full">
        <div className="relative w-5 h-5">
          <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M3 5H17M3 10H17M3 15H10"
              stroke="#111827"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <h2 className="font-bold text-xl text-gray-900">
          <Trans>Job Details</Trans>
        </h2>
      </div>

      <CardContent className="p-0 w-full">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
          <div className="flex flex-col gap-2">
            <Label
              htmlFor="jobType"
              className="text-sm font-medium text-gray-700"
            >
              <Trans>Job Type *</Trans>
            </Label>
            <Select
              value={formData.jobType}
              onValueChange={(value) => handleSelectChange("jobType", value)}
            >
              <SelectTrigger id="jobType" className="h-[50px]">
                <SelectValue placeholder={<Trans>Select job type</Trans>} />
              </SelectTrigger>
              <SelectContent>
                {JobTypeList.map((jobType) => (
                  <SelectItem key={jobType} value={jobType}>
                    {jobType}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-col gap-2">
            <Label
              htmlFor="contract"
              className="text-sm font-medium text-gray-700"
            >
              <Trans>Contract Type</Trans>
            </Label>
            <Select
              value={formData.contract}
              onValueChange={(value) => handleSelectChange("contract", value)}
            >
              <SelectTrigger id="contract" className="h-[50px]">
                <SelectValue placeholder={<Trans>Select contract type</Trans>} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="CDI">CDI</SelectItem>
                <SelectItem value="CDD">CDD</SelectItem>
                <SelectItem value="CONTRACT_PROJECT">
                  <Trans>Contract Project</Trans>
                </SelectItem>
                <SelectItem value="CONTRACT_ANAPEC">
                  <Trans>Contract ANAPEC</Trans>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-col gap-2">
            <Label
              htmlFor="jobDeadline"
              className="text-sm font-medium text-gray-700"
            >
              <Trans>Application Deadline *</Trans>
            </Label>
            <Input
              id="jobDeadline"
              name="jobDeadline"
              type="date"
              value={
                formData.jobDeadline &&
                convertToDateInputFormat(formData.jobDeadline)
              }
              onChange={handleChange}
              className="h-[50px]"
              required
            />
          </div>
        </div>

        <div className="mt-6 relative">
          <Label
            htmlFor="description"
            className="text-sm font-medium text-gray-700"
          >
            <Trans>Job Description *</Trans>
          </Label>
          <Textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder={t`Describe the job responsibilities and requirements`}
            className="mt-1 min-h-[120px] resize-none"
            required
          />
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              handleGenerateWithAi();
            }}
            className="absolute bottom-2 right-2 p-1 hover:bg-gray-100 rounded transition-colors"
            aria-label={t`Generate with AI`}
          >
            <img src="/Ai.png" alt={t`AI Icon`} className="w-[25px] h-[25px] " />
          </button>
        </div>
      </CardContent>
    </Card>
  );
};