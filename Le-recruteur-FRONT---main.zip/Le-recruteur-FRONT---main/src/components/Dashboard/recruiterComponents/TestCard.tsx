import React from "react";
import { Clock, Users, BarChart3, Eye, Edit, Trash2 } from "lucide-react";
import { TestCategory, TestDifficulty, TestStatus } from "@/lib/types/test";

// Props interface
interface TestCardProps {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  passedTestCount: number;
  category: TestCategory;
  difficulty: TestDifficulty;
  status: TestStatus;
  passingScore: number; // percentage

  // Optional props for expandable functionality
  isExpandable?: boolean;
  isExpanded?: boolean;
  onCardClick?: (id: string) => void;

  // Action handlers
  onView?: (id: string) => void;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
}

const TestCard: React.FC<TestCardProps> = ({
  id,
  title,
  description,
  duration,
  passedTestCount,
  category,
  difficulty,
  status,
  passingScore,
  isExpandable = false,
  isExpanded = false,
  onCardClick,
  onView,
  onEdit,
  onDelete,
}) => {
  // Helper functions for styling
  const getDifficultyColor = (difficulty: TestDifficulty) => {
    switch (difficulty) {
      case "EASY":
        return "bg-green-100 text-green-800";
      case "MEDIUM":
        return "bg-yellow-100 text-yellow-800";
      case "HARD":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: TestStatus) => {
    switch (status) {
      case "ACTIVE":
        return "bg-blue-100 text-blue-800";
      case "DRAFT":
        return "bg-gray-200 text-gray-800";
      case "INACTIVE":
        return "bg-teal-600 text-white";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getCategoryDisplayName = (category: TestCategory) => {
    switch (category) {
      case "LANGUAGE":
        return "Programming";
      case "SKILL":
        return "Skills Assessment";
      case "PERSONALITY":
        return "Soft Skills";
      default:
        return category;
    }
  };

  // Button handlers
  const handleView = (e: React.MouseEvent) => {
    e.stopPropagation();
    onView?.(id);
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    onEdit?.(id);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete?.(id);
  };

  const handleCardClick = () => {
    if (isExpandable && onCardClick) {
      onCardClick(id);
    }
  };

  const cardContent = (
    <div
      className={`bg-white border border-gray-200 rounded-lg p-6 mb-4 shadow-sm hover:shadow-md transition-all duration-300 ${
        isExpanded ? "shadow-md" : ""
      } ${isExpandable ? "cursor-pointer" : ""}`}
    >
      {/* Title */}
      <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>

      {/* Description */}
      <p className="text-gray-600 text-sm leading-relaxed mb-6">
        {description}
      </p>

      {/* Stats Row */}
      <div className="flex items-center gap-6 text-sm text-[#238D94] mb-6">
        <span className="flex items-center gap-2">
          <Clock className="w-4 h-4" />
          {duration} min
        </span>
        <span className="flex items-center gap-2">
          <Users className="w-4 h-4" />
          {passedTestCount} Responses
        </span>
        <span className="flex items-center gap-2">
          <BarChart3 className="w-4 h-4" />
          {passingScore} To pass
        </span>
      </div>

      {/* Tags Row */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <span
            className={`px-4 py-2 rounded-full text-xs font-medium ${getDifficultyColor(
              difficulty
            )}`}
          >
            {difficulty.charAt(0) + difficulty.slice(1).toLowerCase()}
          </span>
          <span
            className={`px-4 py-2 rounded-full text-xs font-medium ${getStatusColor(
              status
            )}`}
          >
            {status}
          </span>
        </div>
        <span className={`text-sm text-teal-600 font-medium`}>
          {getCategoryDisplayName(category)}
        </span>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-3">
        <button
          onClick={handleView}
          className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors font-medium"
        >
          <Eye className="w-4 h-4" />
          <span>View</span>
        </button>
        <button
          onClick={handleEdit}
          className="p-3 bg-gray-100 text-gray-700 hover:bg-gray-300 hover:text-gray-900 rounded-lg transition-colors"
          title="Edit Test"
        >
          <Edit className="w-4 h-4" />
        </button>
        <button
          onClick={handleDelete}
          className="p-3 bg-red-50 text-red-600 hover:bg-red-300 hover:text-red-700 rounded-lg transition-colors"
          title="Delete Test"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );

  if (isExpandable) {
    return <div onClick={handleCardClick}>{cardContent}</div>;
  }

  return cardContent;
};

export default TestCard;
