import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CreateJobOfferSchema } from "@/lib/form/jobOffer";
import { jobOfferService } from "@/lib/network/jobOffer";
import { CreateJobOfferRequest } from "@/lib/types/jobOffer";
import { PlusIcon } from "lucide-react";
import { useState } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { toast } from "sonner";
import { Country, State } from "react-country-state-city/dist/esm/types";
import { BackgroundSubsection } from "./BackgroundSubsection";
import { BackgroundWrapperSubsection } from "./BackgroundWrapperSubsection";
import { ContainerSubsection } from "./ContainerSubsection";
import { ContainerWrapperSubsection } from "./ContainerWrapperSubsection";
import { DivSubsection } from "./DivSubsection";
import { DivWrapperSubsection } from "./DivWrapperSubsection";
import { GenerateWithAi } from "./GenerateWithAi";
import { SkillsSubsection } from "./SkillsSubsection";
import { ResponsibilitiesSubsection } from "./ResponsibilitiesSubsection";
import { TagsSubsection } from "./TagsSubsection";
import ScheduleJob from "./ScheduleJob";
import { Trans, t } from "@lingui/macro";
import { i18n } from "@lingui/core";

// Form data interface that matches what components expect
interface FormData {
  title: string;
  departmentId: number;
  location: string;
  country?: string | null; // New field for country
  state?: string | null; // New field for state
  jobType: "FULL_TIME" | "PART_TIME" | "FREELANCE" | "INTERNSHIP";
  contract: "CDI" | "CDD" | "CONTRACT_PROJECT" | "CONTRACT_ANAPEC";
  jobDeadline: string;
  description: string;
  currency: string;
  minSalary: string;
  maxSalary: string;
  negotiable: boolean;
  bonus: string;
  requirements: string[];
  questions: string[];
  jobOfferSkills: string[];
  jobOfferResponsibilities: string[];
  tags: string[];
  scheduledDateTime?: string; // New field for scheduling
}

interface CreateJobModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onJobCreated?: () => void;
}

export const CreateJobModal = ({
  open,
  onOpenChange,
  onJobCreated,
}: CreateJobModalProps): JSX.Element => {
  const [loading, setLoading] = useState(false);
  const [openAi, setOpenAi] = useState(false);
  const [openScheduleJob, setOpenScheduleJob] = useState(false);
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduledDateTime, setScheduledDateTime] = useState<string | null>(
    null
  );

  // Initialize react-hook-form with improved validation
  const {
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    defaultValues: {
      requirements: [""],
      questions: [""],
      jobOfferSkills: [""],
      jobOfferResponsibilities: [""],
      tags: [],
    },
    mode: "onTouched", // Change to onTouched to prevent excessive validation while typing
  });

  const formData = watch();
  const handleGenerateWithAi = async () => {
    setOpenAi(true);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setValue(name as keyof FormData, value);
  };

  const handleDescriptionGeneration = async (description: string) => {
    setValue("description", description);
  };

  const handleConfirm = (description: string) => {
    handleDescriptionGeneration(description);
    setOpenAi(false);
  };

  const handleSelectChange = (name: string, value: string) => {
    if (name === "departmentId") {
      setValue("departmentId", parseInt(value));
    } else {
      setValue(name as keyof FormData, value);
    }
  };

  const handleLocationChange = (
    countryObj: Country | null,
    stateObj: State | null
  ) => {
    // Store country and state objects for reference
    setValue("country", countryObj?.name || null);
    setValue("state", stateObj?.name || null);

    // Update location string
    let locationString = "";
    if (countryObj) {
      locationString = countryObj.name;
      if (stateObj) {
        locationString += `, ${stateObj.name}`;
      }
    }
    setValue("location", locationString);
  };

  const toggleNegotiable = () => {
    setValue("negotiable", !formData.negotiable);
  };

  const addRequirement = (requirement: string) => {
    const currentRequirements = formData.requirements || [];
    setValue("requirements", [...currentRequirements, requirement]);
  };

  const removeRequirement = (index: number) => {
    const currentRequirements = formData.requirements || [];
    setValue(
      "requirements",
      currentRequirements.filter((_: string, i: number) => i !== index)
    );
  };

  const addQuestion = (question: string) => {
    const currentQuestions = formData.questions || [];
    setValue("questions", [...currentQuestions, question]);
  };

  const removeQuestion = (index: number) => {
    const currentQuestions = formData.questions || [];
    setValue(
      "questions",
      currentQuestions.filter((_: string, i: number) => i !== index)
    );
  };

  const addSkill = (skill: string) => {
    const currentSkills = formData.jobOfferSkills || [];
    setValue("jobOfferSkills", [...currentSkills, skill]);
  };

  const removeSkill = (index: number) => {
    const currentSkills = formData.jobOfferSkills || [];
    setValue(
      "jobOfferSkills",
      currentSkills.filter((_: string, i: number) => i !== index)
    );
  };

  const addResponsibility = (responsibility: string) => {
    const currentResponsibilities = formData.jobOfferResponsibilities || [];
    setValue("jobOfferResponsibilities", [
      ...currentResponsibilities,
      responsibility,
    ]);
  };

  const removeResponsibility = (index: number) => {
    const currentResponsibilities = formData.jobOfferResponsibilities || [];
    setValue(
      "jobOfferResponsibilities",
      currentResponsibilities.filter((_: string, i: number) => i !== index)
    );
  };

  const addTag = (tag: string) => {
    const currentTags = formData.tags || [];
    setValue("tags", [...currentTags, tag]);
  };

  const removeTag = (index: number) => {
    const currentTags = formData.tags || [];
    setValue(
      "tags",
      currentTags.filter((_: string, i: number) => i !== index)
    );
  };

  const onSubmit: SubmitHandler<FormData> = async (data) => {
    if (loading || isSubmitting) return; // Prevent multiple submissions while loading

    setLoading(true);

    try {
      // Validate with Zod schema - wrap in try/catch for better error handling
      let validatedData;
      try {
        // Before validation, check for empty required fields
        const requiredFields = [
          "title",
          "description",
          "departmentId",
          "location",
          "jobType",
          "contract",
          "jobDeadline",
          "currency",
        ];
        const missingFields = requiredFields.filter(
          (field) => !data[field as keyof FormData]
        );

        if (missingFields.length > 0) {
          const missingFieldsStr = missingFields.join(", ");
          toast.error(t`Missing required fields: ${missingFieldsStr}`);
          setLoading(false);
          return;
        }

        validatedData = CreateJobOfferSchema.parse(data);
      } catch (validationError) {
        console.error("Form validation error:", validationError);
        if (validationError instanceof Error) {
          toast.error(validationError.message);
        } else {
          toast.error(t`Please complete all required fields`);
        }
        setLoading(false);
        return;
      }

      // Prepare the create request data
      const createData: CreateJobOfferRequest = {
        title: validatedData.title,
        description: validatedData.description,
        departmentId: validatedData.departmentId,
        location: validatedData.location,
        contractType: validatedData.contract,
        jobType: validatedData.jobType,
        publicationDate: scheduledDateTime || new Date().toISOString(),
        deadlineDate: validatedData.jobDeadline,
        minSalary: parseInt(validatedData.minSalary || "0"),
        maxSalary: parseInt(validatedData.maxSalary || "0"),
        currency: validatedData.currency,
        status: scheduledDateTime ? "PENDING" : "ACTIVE", // If scheduled, set as PENDING
        negotiable: validatedData.negotiable,
        jobOfferSchedule: scheduledDateTime || "",
        jobOfferRequirements: formData.requirements.filter(
          (req: string) => req.trim() !== ""
        ),
        jobOfferQuestions: formData.questions.filter(
          (q: string) => q.trim() !== ""
        ),
        jobOfferSkills: formData.jobOfferSkills.filter(
          (skill: string) => skill.trim() !== ""
        ),
        jobOfferResponsibilities: formData.jobOfferResponsibilities.filter(
          (resp: string) => resp.trim() !== ""
        ),
        tags: formData.tags.filter((tag: string) => tag.trim() !== ""),
        bonus: validatedData.bonus,
      };

      const response = await jobOfferService.createJobOffer(createData);

      if (response.success) {
        const message = scheduledDateTime
          ? t`Job scheduled successfully!`
          : t`Job created successfully!`;
        toast.success(message);
        onJobCreated?.();
        onOpenChange(false);
        reset(); // Reset form using react-hook-form
        setIsScheduled(false);
        setScheduledDateTime(null);
      } else {
        toast.error(t`Failed to create job`);
      }
    } catch (error) {
      console.error("Error creating job:", error);
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error(t`Failed to create job`);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleScheduleJob = () => {
    setOpenScheduleJob(true);
    console.log("Job scheduled for later");
  };

  const handleConfirmSchedule = (scheduledDateTimeStr: string) => {
    setScheduledDateTime(scheduledDateTimeStr);
    setIsScheduled(scheduledDateTimeStr !== ""); // Set true if scheduled, false if posting now
    setOpenScheduleJob(false);

    if (scheduledDateTimeStr) {
      // 1. **MOVE** the date formatting logic OUTSIDE the t`...` macro.
      const formattedDateTime = new Date(scheduledDateTimeStr).toLocaleString();

      const translatedMessage = i18n._(
        t`Job scheduled for {scheduledDate}`,
        { scheduledDate: formattedDateTime } // <-- Variables go here
      );

      // 2. Pass only the resulting string to toast.success
      toast.success(translatedMessage); // <-- No second object argument here!
    } else {
      toast.success(t`Job will be posted immediately`);
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="z-50 max-w-5xl w-full rounded-2xl bg-white p-6  overflow-hidden shadow-xl [&>button]:hidden">
          {/* Modal Header */}
          <ContainerSubsection
            onClose={() => onOpenChange(false)}
            scheduledDateTime={scheduledDateTime}
            isScheduled={isScheduled}
          />
          {/* Modal Body */}
          <Card className="border-none shadow-none">
            <ScrollArea className="h-[600px]  px-6 py-4">
              <form
                onSubmit={handleSubmit(onSubmit)}
                className="space-y-6"
                id="job-form"
              >
                <BackgroundSubsection
                  formData={formData}
                  handleChange={handleChange}
                  handleSelectChange={handleSelectChange}
                  handleLocationChange={handleLocationChange}
                />
                <BackgroundWrapperSubsection
                  formData={formData}
                  handleChange={handleChange}
                  handleGenerateWithAi={handleGenerateWithAi}
                  handleSelectChange={handleSelectChange}
                />
                <DivWrapperSubsection
                  formData={formData}
                  handleChange={handleChange}
                  handleSelectChange={handleSelectChange}
                  toggleNegotiable={toggleNegotiable}
                />
                <ContainerWrapperSubsection
                  formData={formData}
                  addRequirement={addRequirement}
                  removeRequirement={removeRequirement}
                />
                <SkillsSubsection
                  formData={formData}
                  addSkill={addSkill}
                  removeSkill={removeSkill}
                />
                <ResponsibilitiesSubsection
                  formData={formData}
                  addResponsibility={addResponsibility}
                  removeResponsibility={removeResponsibility}
                />
                <TagsSubsection
                  formData={formData}
                  addTag={addTag}
                  removeTag={removeTag}
                />
                <DivSubsection
                  formData={formData}
                  addQuestion={addQuestion}
                  removeQuestion={removeQuestion}
                />
                {/* Modal Footer */}
                <DialogFooter className="flex flex-col sm:flex-row justify-center gap-4 p-6 bg-white">
                  <Button
                    type="button"
                    variant="outline"
                    disabled={loading}
                    className="w-full sm:w-56 h-12 font-normal text-gray-700 bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    onClick={() => onOpenChange(false)}
                  >
                    <Trans>Cancel</Trans>
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    disabled={loading}
                    className="w-full sm:w-[278px] h-12 font-normal text-[#238d94] border-[#238d94] disabled:opacity-50 disabled:cursor-not-allowed"
                    onClick={handleScheduleJob}
                  >
                    <Trans>Schedule Post</Trans>
                  </Button>
                  <Button
                    type="submit"
                    disabled={loading || isSubmitting}
                    onClick={() => {
                      // Show validation errors if any
                      if (Object.keys(errors).length > 0) {
                        const errorMessages = Object.entries(errors)
                          .map(
                            ([field, error]) =>
                              `${field}: ${error?.message || "is required"}`
                          )
                          .join(", ");
                        toast.error(
                          <Trans>Please fix form errors: {errorMessages}</Trans>
                        );
                        return;
                      }

                      // Ensure the form is submitted properly
                      if (!loading && !isSubmitting) {
                        document.getElementById("job-form")?.dispatchEvent(
                          new Event("submit", {
                            cancelable: true,
                            bubbles: true,
                          })
                        );
                      }
                    }}
                    className="w-full sm:w-[278px] h-12 font-normal bg-[#238d94] text-white hover:bg-[#1a7379] disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading || isSubmitting ? (
                      <div className="flex items-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        <Trans>Publishing...</Trans>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <PlusIcon className="h-4 w-4" />
                        {isScheduled ? (
                          <Trans>Scheduled for Later</Trans>
                        ) : (
                          <Trans>Publish Now</Trans>
                        )}
                      </div>
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </ScrollArea>
          </Card>
        </DialogContent>
      </Dialog>
      <Dialog open={openAi} onOpenChange={setOpenAi}>
        <DialogContent className="max-w-[1200px] p-0 rounded-2xl [&>button]:hidden">
          <GenerateWithAi
            handleConfirm={handleConfirm}
            handleClose={() => setOpenAi(false)}
          />
        </DialogContent>
      </Dialog>
      <Dialog open={openScheduleJob} onOpenChange={setOpenScheduleJob}>
        <DialogContent className="max-w-[650px] p-0 rounded-2xl ">
          <ScheduleJob onConfirm={handleConfirmSchedule} />
        </DialogContent>
      </Dialog>
    </>
  );
};
