import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Candidate } from "@/lib/types/candidat";
import { JobOffer } from "@/lib/types/jobOffer";
import { Loader2, PersonStanding, Plus, XIcon } from "lucide-react";
import { useState } from "react";
import { Trans } from "@lingui/macro";
import { t } from "@lingui/core/macro";

interface InterviewInformationProps {
  data: {
    jobOfferId: number | null;
    candidateId: number | null;
    candidateName: string;
    positionTitle: string;
    date: string;
    time: string;
    duration: string;
    meetingLink: string;
    interviewers: { id: number; name: string }[];
  };

  setData: (data: InterviewInformationProps["data"]) => void;
  jobOffers: JobOffer[];
  candidates: Candidate[];
  onJobSelection: (jobOfferId: number) => void;
  loading: boolean;
}

export const InterviewInformationSection = ({
  data,
  setData,
  jobOffers,
  candidates,
  onJobSelection,
  loading,
}: InterviewInformationProps): JSX.Element => {
  const [newInterviewerName, setNewInterviewerName] = useState("");
  const {
    jobOfferId,
    candidateId,
    positionTitle,
    date,
    time,
    duration,
    meetingLink,
    interviewers,
  } = data;
  const handleInputChange =
    (field: keyof InterviewInformationProps["data"]) =>
    (e: React.ChangeEvent<HTMLInputElement>) => {
      setData({ ...data, [field]: e.target.value });
    };

  const handleJobChange = (value: string) => {
    const selectedJobId = parseInt(value);
    const selectedJob = jobOffers.find((job) => job.id === selectedJobId);

    setData({
      ...data,
      jobOfferId: selectedJobId,
      candidateId: null, // Reset candidate when job changes
      candidateName: "",
      positionTitle: selectedJob?.title || "",
    });

    onJobSelection(selectedJobId);
  };

  const handleCandidateChange = (value: string) => {
    const selectedCandidateId = parseInt(value);
    const selectedCandidate = candidates.find(
      (c) => c.id === selectedCandidateId
    );

    setData({
      ...data,
      candidateId: selectedCandidateId,
      candidateName: selectedCandidate?.name || "",
    });
  };

  const addInterviewer = () => {
    const trimmedName = newInterviewerName.trim();
    if (trimmedName && !interviewers.some((i) => i.name === trimmedName)) {
      const newInterviewer = {
        id: Date.now(),
        name: trimmedName,
      };
      setData({ ...data, interviewers: [...interviewers, newInterviewer] });
      setNewInterviewerName("");
    }
  };

  const handleAddInterviewerKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addInterviewer();
    }
  };

  const removeInterviewer = (id: number) => {
    setData({ ...data, interviewers: interviewers.filter((i) => i.id !== id) });
  };

  return (
    <Card className="flex flex-col w-full max-w-[590px] items-start p-5 pt-[15px] bg-[#f6f6f6] rounded-[15px]">
      <h2 className="w-full text-[#238d94] text-lg [font-family:'Segoe_UI-Bold',Helvetica] font-bold tracking-[0] leading-9">
        <Trans>Interview Information</Trans>
      </h2>
      <CardContent className="p-0 w-full mt-2">
        <div className="grid gap-y-5 w-full">
          {/* Job Selection */}
          <div className="flex flex-col gap-2">
            <Label className="font-bold text-gray-900 text-[13px]">
              <Trans>Job Position *</Trans>
            </Label>
            <Select
              value={jobOfferId?.toString() || ""}
              onValueChange={handleJobChange}
            >
              <SelectTrigger className="h-[38px] rounded-[7.2px] border-[0.9px] border-solid border-gray-300">
                <SelectValue
                  placeholder={<Trans>Select a job position</Trans>}
                />
              </SelectTrigger>
              <SelectContent>
                {jobOffers.map((job) => (
                  <SelectItem key={job.id} value={job.id.toString()}>
                    {job.title} - {job.location}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Candidate Selection */}
          <div className="flex flex-col gap-2">
            <Label className="font-bold text-gray-900 text-[13px]">
              <Trans>Candidate *</Trans>
              {loading && (
                <Loader2 className="inline w-4 h-4 ml-2 animate-spin" />
              )}
            </Label>
            <Select
              value={candidateId?.toString() || ""}
              onValueChange={handleCandidateChange}
              disabled={!jobOfferId || loading}
            >
              <SelectTrigger className="h-[38px] rounded-[7.2px] border-[0.9px] border-solid border-gray-300">
                <SelectValue
                  placeholder={
                    !jobOfferId ? (
                      <Trans>Select a job first</Trans>
                    ) : candidates.length === 0 ? (
                      <Trans>No candidates for this job</Trans>
                    ) : (
                      <Trans>Select a candidate</Trans>
                    )
                  }
                />
              </SelectTrigger>
              <SelectContent>
                {candidates.map((candidate) => (
                  <SelectItem
                    key={candidate.id}
                    value={candidate.id.toString()}
                  >
                    {candidate.name} - {candidate.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Candidate Information */}
          <div className="flex flex-col gap-6">
            <div className="flex items-center gap-[23px] w-full">
              <Label className="w-[108.73px] font-bold text-gray-900 text-[13px]">
                <Trans>Position Title:</Trans>
              </Label>
              <Input
                id="positionTitle"
                name="positionTitle"
                value={positionTitle}
                disabled
                onChange={handleInputChange("positionTitle")}
                className="h-8 text-xs bg-white"
                placeholder={t`e.g., Technical Interview`}
              />
            </div>

            <div className="flex items-center gap-[23px] w-full">
              <Label className="w-[108.73px] font-bold text-gray-900 text-[13px]">
                <Trans>Date:</Trans>
              </Label>
              <div className="flex items-center relative">
                <Input
                  type="date"
                  value={date}
                  onChange={handleInputChange("date")}
                  className="w-fit h-8 text-xs -ml-6"
                />
              </div>
            </div>
          </div>

          {/* Time Selection */}
          <div className="flex items-center gap-[23px] w-full">
            <Label className="w-[108.73px] font-bold text-gray-900 text-[13px]">
              <Trans>Time:</Trans>
            </Label>
            <Input
              type="time"
              value={time}
              onChange={handleInputChange("time")}
              className="w-fit h-8 text-xs -ml-6"
            />
          </div>

          <div className="flex items-center gap-[23px] w-full">
            <Label
              htmlFor="duration"
              className="w-[108.73px] font-bold text-gray-900 text-[13px]"
            >
              <Trans>Duration:</Trans>
            </Label>
            <Input
              id="duration"
              name="duration"
              value={duration}
              onChange={handleInputChange("duration")}
              className="h-8 text-xs -ml-6"
              placeholder={t`e.g., 45 mins`}
            />
          </div>

          {/* Meeting Link */}
          <div className="flex flex-col w-full gap-2">
            <Label className="font-bold text-gray-900 text-[13px]">
              <Trans>Meeting Link</Trans>
            </Label>
            <Input
              value={meetingLink}
              onChange={handleInputChange("meetingLink")}
              placeholder={t`Paste meeting link (e.g., https://meet.google.com/...)`}
              className="h-[38px] rounded-[7.2px] border-[0.9px] border-solid border-gray-300"
            />
          </div>

          {/* Interviewers */}
          <div className="flex flex-col w-full gap-3">
            <Label className="font-bold text-gray-900 text-[13px]">
              <Trans>Interviewer(s)</Trans>
            </Label>
            <div className="flex gap-2">
              <Input
                value={newInterviewerName}
                onChange={(e) => setNewInterviewerName(e.target.value)}
                onKeyPress={handleAddInterviewerKeyPress}
                placeholder={t`Enter interviewer name`}
                className="flex-1 h-[38px] rounded-[7.2px] border-[0.9px] border-solid border-gray-300"
              />
              <Button
                type="button"
                onClick={addInterviewer}
                disabled={!newInterviewerName.trim()}
                className="px-4 h-[38px] bg-[#238d94] hover:bg-[#1c7a80] text-white rounded-[7.2px]"
              >
                <Plus className="w-4 h-4 mr-1" />
                <Trans>Add</Trans>
              </Button>
            </div>

            <div className="flex flex-wrap gap-2">
              {interviewers.map((interviewer, index) => (
                <div
                  key={interviewer.id || `interviewer-${index}`}
                  className="flex items-center gap-1 px-2 py-1 border border-[#238d94] rounded-[12px] bg-white hover:bg-[#e0f7f8] transition-colors duration-200 text-sm"
                >
                  <PersonStanding className="w-4 h-4 text-[#238d94]" />
                  <span className="text-xs font-medium text-gray-800">
                    {interviewer.name}
                  </span>
                  <XIcon
                    className="w-3 h-3 text-gray-500 hover:text-red-500 cursor-pointer"
                    onClick={() => removeInterviewer(interviewer.id)}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
