import React, { useState, useEffect } from "react";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import { Trans } from "@lingui/macro";

interface LicenseDetailsData {
  licenseType: string;
  status: "Active" | "Inactive" | "Expired";
  expirationDate: string;
  dailyQuota: string;
  licenseCode: string;
}

interface PermissionData {
  name: string;
  description: string;
}


interface PermissionsPageData {
  licenseDetails: LicenseDetailsData;
  permissions: PermissionData[];
}

// --- Composant pour une ligne d'information sur la licence ---
const InfoRow: React.FC<{ label: React.ReactNode; value: string }> = ({
  label,
  value,
}) => (
  <div className="flex flex-col sm:flex-row py-3">
    <dt className="w-full sm:w-1/3 text-gray-500 font-medium">{label}</dt>
    <dd className="w-full sm:w-2/3 text-gray-800 font-semibold">{value}</dd>
  </div>
);

// --- Composant pour la section des détails de la licence ---
const LicenseDetailsSection: React.FC<{ data: LicenseDetailsData }> = ({
  data,
}) => (
  <div className="mb-10">
    <h2 className="text-xl font-bold text-gray-800">
      <Trans>License Details</Trans>
    </h2>
    <p className="text-sm text-gray-500 mb-2">
      <Trans>Your scheduled interviews at a glance</Trans>
    </p>
    <div className="border-t border-gray-200">
      <dl className="divide-y divide-gray-200">
        <InfoRow label={<Trans>License Type:</Trans>} value={data.licenseType} />
        <InfoRow label={<Trans>Status:</Trans>} value={data.status} />
        <InfoRow label={<Trans>Expiration Date:</Trans>} value={data.expirationDate} />
        <InfoRow label={<Trans>Daily Job Posting Quota:</Trans>} value={data.dailyQuota} />
        <InfoRow label={<Trans>License Code:</Trans>} value={data.licenseCode} />
      </dl>
    </div>
  </div>
);


// --- Composant pour la table des permissions ---
const PermissionsTable: React.FC<{ data: PermissionData[] }> = ({ data }) => (
  <div>
    <h2 className="text-xl font-bold text-gray-800">
      <Trans>Permissions</Trans>
    </h2>
    <p className="text-sm text-gray-500 mb-4">
      <Trans>All recruiters linked to this company</Trans>
    </p>
    <div className="border border-gray-200 rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-700">
          <thead className="bg-gray-50 text-xs text-gray-600 uppercase tracking-wider">
            <tr>

              <th scope="col" className="px-6 py-3 font-semibold"><Trans>Name</Trans></th>
              <th scope="col" className="px-6 py-3 font-semibold"><Trans>Description</Trans></th>

            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {data.map((permission) => (
              <tr key={permission.name} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 font-semibold text-gray-900 whitespace-nowrap">{permission.name}</td>
                <td className="px-6 py-4">{permission.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);




export const PermissionsPage: React.FC = () => {
  const [pageData, setPageData] = useState<PermissionsPageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // id recruiter
  const storedUser = localStorage.getItem("userData");
  let recruiterId : number ;
  if(storedUser){
    const parsedUser = JSON.parse(storedUser) ;
    recruiterId = parsedUser.id;
  }

  
  useEffect(() => {

    api
      .getItem<PermissionsPageData>(
        `/recruiter/${recruiterId}/licensePermissions`
      )
      .then((data) => {
        setPageData(data);
      })
      .catch((err) => {
        console.error("Failed to fetch license and permissions:", err);
        const errorMessage = <Trans>Could not load license details. Please try again.</Trans>;
        setError(errorMessage);
        toast.error(errorMessage);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm text-center">
        <p><Trans>Loading license details...</Trans></p>
      </div>
    );
  }

  if (error || !pageData) {
    return (
      <div className="bg-white p-6 rounded-lg border border-red-200 shadow-sm text-center text-red-600">
        <p>{error || <Trans>No license data found.</Trans>}</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 sm:p-8 rounded-lg border border-gray-200 shadow-sm w-full font-sans">
      <LicenseDetailsSection data={pageData.licenseDetails} />
      <PermissionsTable data={pageData.permissions} />
    </div>
  );
};