import { api } from "@/lib/network/utils/api";
import { Trans } from "@lingui/macro";
import React, { useEffect, useState } from "react";
import { toast } from "sonner";

import { settings } from "@/lib/settings/main";
import { CompanyData } from "@/lib/types/auth";
import CompanyHeaderSection from "./CompanyPageSections/CompanyHeaderSection";
import CompanyInfoAndContactSection from "./CompanyPageSections/CompanyInfoAndContactSection";
import LocationSection from "./CompanyPageSections/LocationSection";
import ResponsibilitiesSection from "./CompanyPageSections/ResponsibilitiesSection";
import { Settings } from "lucide-react";

export const CompanyPage: React.FC = () => {
  const [companyData, setCompanyData] = useState<CompanyData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // id recruiter
  const storedUser = localStorage.getItem("userData");
  let recruiterId: number;
  if (storedUser) {
    const parsedUser = JSON.parse(storedUser);
    recruiterId = parsedUser.id;
  }

  useEffect(() => {
    setLoading(true);

    api
      .getItem<CompanyData>(`/recruiter/${recruiterId}/company`)
      .then((data) => {
        if (data.logo && !data.logo.startsWith("http")) {
          data.logo = `${settings.IMG_ADDRESS}${data.logo}`;
        } else if (!data.logo) {
          data.logo = settings.DEFAULT_COMPANY_AVATAR;
        }
        setCompanyData(data);
      })
      .catch((err) => {
        console.error("Failed to fetch company profile:", err);
        setError("Could not load company information. Please try again later.");
        toast.error("Failed to load company profile.");
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="text-center p-10">
        <p>
          <Trans>Loading company profile...</Trans>
        </p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center p-10 text-red-600 bg-red-50 rounded-lg border border-red-200">
        <p>{error}</p>
      </div>
    );
  }

  if (!companyData) {
    return (
      <div className="text-center p-10 text-gray-500">
        <p>
          <Trans>No company data available.</Trans>
        </p>
      </div>
    );
  }

  return (
    <div className=" w-full max-w-5xl mx-auto font-sans relative">
      <CompanyHeaderSection data={companyData} />
      <div className="my-8 "></div>
      <CompanyInfoAndContactSection data={companyData} />
      <div className="my-8 "></div>
      <ResponsibilitiesSection data={companyData} />
      <div className="my-8 "></div>
      <LocationSection initialData={companyData} />
    </div>
  );
};
