import React, { useState, useEffect } from "react";
import { LogOut } from "lucide-react";
import { ChangePasswordModal } from "@/components/Modals/RecruiterModals/ChangePasswordModal";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import { Trans, t } from "@lingui/macro";
import { useAuth } from "@/contexts/AuthContext";

interface SecurityPageData {
  signInEmail: string;
  signInPhone: string;
  lastSignIn: string;
}

const InfoRow: React.FC<{
  label: React.ReactNode;
  children: React.ReactNode;
}> = ({ label, children }) => (
  <div className="flex flex-col sm:flex-row items-start sm:items-center py-4">
    <dt className="w-full sm:w-1/3 text-gray-500 font-medium mb-1 sm:mb-0">
      {label}
    </dt>
    <dd className="w-full sm:w-2/3 text-gray-800 font-semibold">{children}</dd>
  </div>
);

export const SecurityPage: React.FC = () => {
  const [pageData, setPageData] = useState<SecurityPageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { logout } = useAuth();

  const handleSignOut = async () => {
    try {
      await logout();
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  // id recruiter
  const storedUser = localStorage.getItem("userData");
  let recruiterId: number;
  if (storedUser) {
    const parsedUser = JSON.parse(storedUser);
    recruiterId = parsedUser.id;
  }

  useEffect(() => {
    api
      .getItem<SecurityPageData>(`/recruiter/${recruiterId}/securitySettings`)
      .then((data) => {
        setPageData(data);
      })
      .catch((err) => {
        console.error("Failed to fetch security settings:", err);
        setError(t`Could not load security settings.`);
        toast.error(t`Could not load security settings.`);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="bg-white p-8 text-center">
        <Trans>Loading security settings...</Trans>
      </div>
    );
  }

  if (error || !pageData) {
    return (
      <div className="bg-white p-8 text-center text-red-600">
        {<Trans>Failed to load data.</Trans>}
      </div>
    );
  }

  return (
    <div className="bg-white p-6 sm:p-8 rounded-lg border border-gray-200 shadow-sm w-full font-sans">
      {/* --- En-tête de la section --- */}
      <div className="pb-4 border-b border-gray-200">
        <h1 className="text-xl font-bold text-gray-800">
          <Trans>Security Settings</Trans>
        </h1>
        <p className="text-sm text-gray-500 mt-1">
          <Trans>Manage your account security and control device access.</Trans>
        </p>
      </div>

      {/* --- Informations de connexion --- */}
      <div className="divide-y divide-gray-200">
        <InfoRow label={<Trans>Sign-in Email:</Trans>}>
          {pageData.signInEmail}
        </InfoRow>
        <InfoRow label={<Trans>Sign-in Phone Number:</Trans>}>
          {pageData.signInPhone || <Trans>Not provided</Trans>}
        </InfoRow>
        <InfoRow label={<Trans>Password:</Trans>}>
          <button
            className="text-cyan-700 font-semibold hover:text-cyan-800 transition-colors"
            onClick={() => setIsModalOpen(true)}
          >
            <Trans>Change password</Trans>
          </button>
        </InfoRow>

        <InfoRow label={<Trans>Last Sign-In:</Trans>}>
          {pageData.lastSignIn}
        </InfoRow>
      </div>

      <ChangePasswordModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />

      {/* --- Action de déconnexion --- */}
      <div className="mt-6 pt-6 border-t border-gray-200">
        <button
          className="flex items-center gap-2 text-cyan-700 font-semibold hover:text-cyan-800 transition-colors"
          onClick={handleSignOut}
        >
          <LogOut size={16} />
          <span>
            <Trans>Logout from all devices</Trans>
          </span>
        </button>
      </div>
    </div>
  );
};
