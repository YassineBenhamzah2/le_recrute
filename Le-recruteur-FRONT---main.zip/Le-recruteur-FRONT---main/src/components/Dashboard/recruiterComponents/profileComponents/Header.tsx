import React from "react";
import { t } from "@lingui/macro";

// Les onglets disponibles

// Nouvelles props pour le composant
type HeaderProps = {
  activeTab: string;
  onTabChange: (tabName: string) => void;
};

export const Header: React.FC<HeaderProps> = ({ activeTab, onTabChange }) => {
  const TABS = [
    t`Overview`,
    t`Company`,
    t`Permissions & Licenses`,
    t`Security`,
  ];

  return (
    <header className="border-b border-gray-200">
      <nav className="flex space-x-2 -mb-px">
        {TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => onTabChange(tab)}
            className={`px-4 py-3 text-sm font-medium transition-colors focus:outline-none ${
              activeTab === tab // Applique le style si l'onglet est actif
                ? "text-cyan-700 border-b-2 border-cyan-700"
                : "text-gray-500 hover:text-gray-800"
            }`}
          >
            {tab}
          </button>
        ))}
      </nav>
    </header>
  );
};
