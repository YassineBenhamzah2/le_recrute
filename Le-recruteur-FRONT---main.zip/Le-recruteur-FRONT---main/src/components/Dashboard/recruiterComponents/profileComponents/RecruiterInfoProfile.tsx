import { RecruiterInfoModal } from "@/components/Modals/RecruiterModals/RecruiterInfoModal";
import { api } from "@/lib/network/utils/api";
import { settings } from "@/lib/settings/main";
import { Trans, t } from "@lingui/macro";
import { Briefcase, Building, Check, Edit, Mail, Phone } from "lucide-react";
import React, { useEffect, useState } from "react";
import { toast } from "sonner";

interface RecruiterSidebarData {
  firstName: string;
  lastName: string;
  role: string;
  joined: string;
  pack: string;
  phone: string;
  email: string;
  companyName: string;
  avatarUrl: string;
}

export const RecruiterInfoProfile: React.FC = () => {
  const [sidebarData, setSidebarData] = useState<RecruiterSidebarData | null>(
    null
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // id recruiter
  const storedUser = localStorage.getItem("userData");
  let recruiterId: number;
  if (storedUser) {
    const parsedUser = JSON.parse(storedUser);
    recruiterId = parsedUser.id;
  }

  useEffect(() => {
    api
      .getItem<RecruiterSidebarData>(`/recruiter/${recruiterId}/infos`)
      .then((data) => {
        if (data.avatarUrl && !data.avatarUrl.startsWith("http")) {
          data.avatarUrl = `${settings.IMG_ADDRESS}${data.avatarUrl}`;
        } else if (!data.avatarUrl) {
          data.avatarUrl = settings.DEFAULT_USER_AVATAR;
        }

        setSidebarData(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch sidebar data:", err);
        toast.error(t`Could not load recruiter information.`);
        setError("Could not load recruiter information.");
        setLoading(false);
      });
  }, []);

  const handleSaveData = (formData: RecruiterSidebarData) => {
    if (formData.avatarUrl && !formData.avatarUrl.startsWith("http")) {
      formData.avatarUrl = `${settings.IMG_ADDRESS}${formData.avatarUrl}`;
    } else if (!formData.avatarUrl) {
      formData.avatarUrl = settings.DEFAULT_USER_AVATAR ;
    }

    setSidebarData(formData);
  };

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg border border-gray-200 w-full shadow-sm text-center">
        <Trans>Loading profile...</Trans>
      </div>
    );
  }

  if (error || !sidebarData) {
    return (
      <div className="bg-white p-6 rounded-lg border border-red-300 w-full shadow-sm text-center text-red-600">
        {error}
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200 w-full shadow-sm relative">
      <button
        className="absolute top-2 right-2 px-2 py-2 text-sm font-semibold text-cyan-700 bg-cyan-70 border border-cyan-200 rounded-lg hover:bg-cyan-100 transition-colors"
        onClick={() => setIsModalOpen(true)}
      >
        <Edit size={16} />
      </button>

      <div className="pt-6">
        <div className="flex flex-col items-center text-center">
          <div className="relative w-32 h-32 rounded-full p-1 bg-gradient-to-r from-teal-500 to-cyan-500">
            <img
              src={sidebarData.avatarUrl}
              alt={sidebarData.firstName + " " + sidebarData.lastName}
              onError={(e) => {
                e.currentTarget.src = settings.DEFAULT_USER_AVATAR ;
              }}
              className="w-full h-full object-cover rounded-full border-4 border-white"
            />
          </div>
          <div className="flex items-center gap-2 mt-4">
            <h2 className="text-md font-bold text-gray-800">
              {sidebarData.firstName + " " + sidebarData.lastName}
            </h2>
            <div className="w-5 h-5 bg-cyan-600 rounded-full flex items-center justify-center text-white">
              <Check size={14} strokeWidth={3} />
            </div>
          </div>
          <p className="text-sm text-gray-500 mb-11 mt-2">
            {sidebarData.role} • {sidebarData.joined} • {sidebarData.pack}
          </p>
        </div>
        <div className="space-y-3 text-sm">
          <div className="flex items-center gap-3">
            <Phone size={16} className="text-gray-400" />
            <span className="text-gray-500 font-medium w-20 flex-shrink-0">
              <Trans>Phone:</Trans>
            </span>
            <span className="text-gray-800">{sidebarData.phone}</span>
          </div>
          <div className="flex items-center gap-3">
            <Mail size={16} className="text-gray-400" />
            <span className="text-gray-500 font-medium w-20 flex-shrink-0">
              <Trans>Email:</Trans>
            </span>
            <a
              href={`mailto:${sidebarData.email}`}
              className="text-cyan-700 hover:underline cursor-pointer truncate"
            >
              {sidebarData.email}
            </a>
          </div>

          <div className="flex items-center gap-3">
            <Briefcase size={16} className="text-gray-400" />
            <span className="text-gray-500 font-medium w-20 flex-shrink-0">
              <Trans>Positon:</Trans>
            </span>
            <span className="text-gray-800 font-semibold">
              {sidebarData.role}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <Building size={16} className="text-gray-400" />
            <span className="text-gray-500 font-medium w-20 flex-shrink-0">
              <Trans>Company:</Trans>
            </span>
            <span className="text-gray-800 font-semibold">
              {sidebarData.companyName}
            </span>
          </div>
        </div>
      </div>

      <RecruiterInfoModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveData}
        profileData={sidebarData}
      />
    </div>
  );
};
