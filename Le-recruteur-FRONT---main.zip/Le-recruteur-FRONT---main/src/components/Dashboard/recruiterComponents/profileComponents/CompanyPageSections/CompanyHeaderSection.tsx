import React, { useState } from "react";
import { CompanyData } from "@/lib/types/auth";
import { Edit, ArrowUpRight } from "lucide-react";
import { EditHeaderCompanyModal } from "@/components/Modals/RecruiterModals/EditHeaderCompanyModal";
import { settings } from "@/lib/settings/main";
import { Trans, t } from '@lingui/macro';


const CompanyHeaderSection: React.FC<{ data: CompanyData }> = ({ data }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [companyHeaderData, setCompanyHeaderData] = useState({
    name: data.name,
    website: data.website,
    logo: data.logo,
    about: data.about,
    tags: data.tags,
  });

  const handleSaveSuccess = (updatedData: {
    name: string;
    website: string;
    logo: string;
    about: string;
    tags: { id: number; name: string }[];
  }) => {
    if (updatedData.logo && !updatedData.logo.startsWith("http")) {
      updatedData.logo = `${settings.IMG_ADDRESS}${updatedData.logo}`;
    }else{
      updatedData.logo = settings.DEFAULT_COMPANY_AVATAR ;
    }

    setCompanyHeaderData(updatedData);
  };

  return (
    <>
      <button
        className="absolute top-4 right-4 z-10 flex items-center gap-2 px-2 py-2 text-sm font-semibold text-cyan-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors shadow-sm"
        onClick={() => setIsModalOpen(true)}
      >
        <Edit size={16} />
      </button>

      <div className="bg-white p-6 sm:p-8 rounded-lg border border-gray-200 shadow-sm w-full">
        {/* Header */}
        <div className="flex items-center gap-6 pb-8 border-b border-gray-200">
          <img
            src={companyHeaderData.logo}
            alt={`${data.name} logo`}
            className="w-24 h-24 rounded-full object-cover flex-shrink-0 border-2 border-gray-100 shadow-md"
            onError={(e) => {
              e.currentTarget.src = settings.DEFAULT_COMPANY_AVATAR ;
            }}
          />
          <div>
            <h1 className="text-3xl font-bold text-gray-800">
              {companyHeaderData.name}
            </h1>
            <a
              href={companyHeaderData.website}
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-700 hover:text-cyan-800 transition-colors flex items-center gap-1 group"
            >
              {companyHeaderData.website}
              <ArrowUpRight
                size={16}
                className="opacity-70 group-hover:opacity-100"
              />
            </a>
          </div>
        </div>

        {/* About Section */}
        <div className="pt-8">
          <h2 className="text-xl font-bold text-gray-800"><Trans>About the Company</Trans></h2>
          <p className="text-gray-700 leading-relaxed mt-2">
            {companyHeaderData.about}
          </p>
        </div>

        {/* Tags Section */}
        <div className="mt-6 pt-6 border-t border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            <Trans>Company Tags</Trans>
          </h3>
          <div className="flex items-center gap-2 flex-wrap">
            {companyHeaderData.tags.map((tag) => (
              <span
                key={tag.id}
                className="text-gray-800 bg-gray-100 px-3 py-1 rounded-full text-sm font-medium"
              >
                {tag.name}
              </span>
            ))}
          </div>
        </div>
      </div>
      {isModalOpen && (
        <EditHeaderCompanyModal
          onClose={() => setIsModalOpen(false)}
          isOpen={isModalOpen}
          onSave={handleSaveSuccess}
          companyInfo={{
            id: data.id,
            name: data.name,
            website: data.website,
            logo: data.logo,
            about: data.about,
            tags: data.tags,
          }}
        />
      )}
    </>
  );
};

export default CompanyHeaderSection;
