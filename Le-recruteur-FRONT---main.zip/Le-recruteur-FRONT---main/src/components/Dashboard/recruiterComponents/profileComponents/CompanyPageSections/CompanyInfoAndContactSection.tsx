/* eslint-disable @typescript-eslint/no-explicit-any */
import { EditInfoContactModal } from "@/components/Modals/RecruiterModals/EditInfoContactCompanyModal";
import { api } from "@/lib/network/utils/api";
import { CompanyData, Sector } from "@/lib/types/auth";
import { Edit } from "lucide-react";
import React, { useState } from "react";
import { toast } from "sonner";
import { Trans, t } from '@lingui/macro';


interface CompanyInfoContactEditData {
  sector: Sector | null;
  employeeCount: number;
  founded: string;

  phone: string;
  email: string;
}

const InfoItem: React.FC<{ label: string; value: string | number }> = ({
  label,
  value,
}) => (
  <div className="flex flex-col sm:flex-row py-4">
    <dt className="w-full sm:w-1/3 text-gray-500 font-medium">{label}</dt>
    <dd className="w-full sm:w-2/3 text-gray-800 font-medium">{value}</dd>
  </div>
);

const CompanyInfoAndContactSection: React.FC<{ data: CompanyData }> = ({
  data,
}) => {
  const [InfoContactData, setInfoContactData] = useState({
    sector: data.info.industry,
    employeeCount: data.info.employeeCount,
    founded: data.info.founded,
    phone: data.contact.phone,
    email: data.contact.email,
    status: data.info.status,
    score: data.info.score,
  });
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleSave = (formData: CompanyInfoContactEditData) => {
    const payload = {
      sectorId: formData.sector?.id,
      employeeCount: formData.employeeCount,
      founded: formData.founded,

      phone: formData.phone,
      email: formData.email,
    };

    toast.promise(
      api.put(`/recruiter/company/${data.id}/infoContact`, payload),
      {
        loading: "Updating information...",
        success: (response: any) => {
          setInfoContactData((prev) => ({
            ...prev,
            sector: response.industry,
            employeeCount: response.employeeCount,
            founded: response.founded,
            phone: response.phone,
            email: response.email,
          }));
          setIsModalOpen(false);
          return t`Information updated successfully!`;
        },
        error: t`Failed to update information.`,
      }
    );
  };

  const transformDataForModal = (): CompanyInfoContactEditData => {
    return {
      sector: InfoContactData.sector,
      employeeCount: InfoContactData.employeeCount,
      founded: InfoContactData.founded,

      phone: InfoContactData.phone,
      email: InfoContactData.email,
    };
  };

  return (
    <>
      <div className="bg-white p-6 sm:p-8 rounded-lg border border-gray-200 shadow-sm w-full relative">
        {/* Company Information */}
        <button
          onClick={() => setIsModalOpen(true)}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100"
        >
          <Edit size={16} />
        </button>

        <div>
          <h2 className="text-xl font-bold text-gray-800">
            <Trans>Company Information</Trans>
          </h2>
          <dl className="mt-4 divide-y divide-gray-200">
            <InfoItem label={t`Industry:`} value={InfoContactData.sector.name} />
            <InfoItem
              label={t`Number of Employees:`}
              value={InfoContactData.employeeCount}
            />
            <InfoItem label={t`Founded:`} value={InfoContactData.founded} />
            <InfoItem label={t`Status:`} value={InfoContactData.status} />
            <InfoItem label={t`Score:`} value={InfoContactData.score} />
          </dl>
        </div>
        {/* Contact Information */}
        <div className="mt-8">
          <h2 className="text-xl font-bold text-gray-800">
            <Trans>Contact Information</Trans>
          </h2>
          <dl className="mt-4 divide-y divide-gray-200">
            <InfoItem label={t`Phone:`} value={InfoContactData.phone} />
            <InfoItem label={t`Email:`} value={InfoContactData.email} />
          </dl>
        </div>

        <EditInfoContactModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSave={handleSave}
          initialData={transformDataForModal()}
        />
      </div>
    </>
  );
};

export default CompanyInfoAndContactSection;
