import React, { useState, useEffect } from "react";
import { Edit, Save, LinkIcon } from "lucide-react";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import AsyncSelect from "react-select/async";
import { Country, City } from "country-state-city";
import { Trans, t } from "@lingui/macro";

import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  useMap,
  useMapEvents,
} from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// Additional CSS to ensure map renders properly
const mapStyles = `
  .leaflet-container {
    height: 100% !important;
    width: 100% !important;
  }
  .custom-div-icon {
    background: none !important;
    border: none !important;
  }
`;

// Inject styles
if (typeof document !== "undefined") {
  const styleSheet = document.createElement("style");
  styleSheet.innerText = mapStyles;
  document.head.appendChild(styleSheet);
}

// Fix for default markers in React Leaflet
const DefaultIcon = L.divIcon({
  html: `<svg width="25" height="41" viewBox="0 0 25 41" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12.5 0C5.596 0 0 5.596 0 12.5C0 19.404 12.5 41 12.5 41S25 19.404 25 12.5C25 5.596 19.404 0 12.5 0ZM12.5 17C10.019 17 8 14.981 8 12.5S10.019 8 12.5 8S17 10.019 17 12.5S14.981 17 12.5 17Z" fill="#238d94"/>
  </svg>`,
  className: "custom-div-icon",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

import { CompanyData } from "@/lib/types/auth";

interface SelectOption {
  value: string;
  label: string;
}

interface UpdateLocationRes {
  address: string;
  city: string;
  country: string;
  lat: number;
  lng: number;
}

interface LocationData {
  address: string;
  city: SelectOption | null;
  country: SelectOption | null;
  coordinates: {
    lat: number;
    lng: number;
  };
}

const MapUpdater = ({
  position,
}: {
  position: { lat: number; lng: number };
}) => {
  const map = useMap();

  useEffect(() => {
    if (position.lat && position.lng) {
      map.setView([position.lat, position.lng], map.getZoom());
      // Force map to resize/invalidate size after a short delay
      setTimeout(() => {
        map.invalidateSize();
      }, 100);
    }
  }, [position.lat, position.lng, map]);

  return null;
};

const MapEditor = ({
  position,
  onPositionChange,
}: {
  position: { lat: number; lng: number };
  onPositionChange: (pos: { lat: number; lng: number }) => void;
}) => {
  const map = useMap();

  // Force map resize on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 100);
    return () => clearTimeout(timer);
  }, [map]);

  useMapEvents({
    click(e) {
      const newPosition = { lat: e.latlng.lat, lng: e.latlng.lng };
      onPositionChange(newPosition);
    },
  });

  const markerPosition: [number, number] = [position.lat, position.lng];

  return (
    <>
      <MapUpdater position={position} />
      <Marker position={markerPosition}>
        <Popup>
          <div className="text-center">
            <p>
              <Trans>Click on the map to move the pin</Trans>
            </p>
            <small>
              Lat: {position.lat.toFixed(6)}, Lng: {position.lng.toFixed(6)}
            </small>
          </div>
        </Popup>
      </Marker>
    </>
  );
};

const LocationSection: React.FC<{ initialData: CompanyData }> = ({
  initialData,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [locationMode, setLocationMode] = useState<"enter" | "map">("map");

  const [locationData, setLocationData] = useState(initialData.location);

  const [editData, setEditData] = useState<LocationData>({
    country: null,
    city: null,
    address: "",
    coordinates: { lat: 0, lng: 0 },
  });

  useEffect(() => {
    setLocationData(initialData.location);
  }, [initialData]);

  // Ensure coordinates are valid numbers
  const isValidCoordinate = (lat: number, lng: number) => {
    return !isNaN(lat) && !isNaN(lng) && lat !== 0 && lng !== 0;
  };

  // Default coordinates (Morocco center) if invalid coordinates
  const getValidCoordinates = () => {
    if (isValidCoordinate(locationData.lat, locationData.lng)) {
      return [locationData.lat, locationData.lng] as [number, number];
    }
    // Default to Rabat, Morocco
    return [34.0209, -6.8416] as [number, number];
  };

  useEffect(() => {
    if (isEditing) {
      const country = Country.getAllCountries().find(
        (c) => c.name === locationData.country
      );
      const countryOption = country
        ? { value: country.isoCode, label: country.name }
        : null;
      const cityOption =
        country && locationData.city
          ? { value: locationData.city, label: locationData.city }
          : null;

      setEditData({
        country: countryOption,
        city: cityOption,
        address: locationData.addriss,
        coordinates: { lat: locationData.lat, lng: locationData.lng },
      });
    }
  }, [isEditing, locationData]);

  const handleCancel = () => {
    setIsEditing(false);
  };

  const handleGoogleMapsLink = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value;
    const regex = /@(-?\d+\.\d+),(-?\d+\.\d+)/;
    const match = url.match(regex);
    if (match && match[1] && match[2]) {
      const lat = parseFloat(match[1]);
      const lng = parseFloat(match[2]);
      setEditData((prev) => ({ ...prev, coordinates: { lat, lng } }));
      toast.success(t`Location updated from Google Maps link!`);
    }
  };

  const handleSave = async () => {
    setIsLoading(true);

    const payload =
      locationMode === "enter"
        ? {
            updateType: "ADDRESS",
            address: editData.address,
            city: editData.city?.label,
            country: editData.country?.label,
          }
        : { updateType: "COORDINATES", coordinates: editData.coordinates };

    const savePromise = api.put<UpdateLocationRes>(
      `/recruiter/company/${initialData.id}/location`,
      payload
    );

    toast.promise(savePromise, {
      loading: t`Updating location...`,
      success: t`Location updated successfully!`,
      error: t`Failed to update location.`,
    });

    try {
      const response = await savePromise;
      // Met à jour l'état d'affichage avec la réponse
      setLocationData({
        addriss: response.address,
        city: response.city,
        country: response.country,
        lat: response.lat,
        lng: response.lng,
      });
      setIsEditing(false);
    } catch (err) {
      console.error("Failed to save location:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;

    setEditData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSelectChange = (
    field: "country" | "city",
    option: SelectOption | null
  ) => {
    setEditData((prev) => {
      const newState = { ...prev, [field]: option };
      if (field === "country") newState.city = null;
      return newState;
    });
  };

  const loadCountryOptions = (inputValue: string) =>
    Promise.resolve(
      Country.getAllCountries()
        .map((c) => ({ value: c.isoCode, label: c.name }))
        .filter((c) => c.label.toLowerCase().includes(inputValue.toLowerCase()))
    );

  const loadCityOptions = (inputValue: string) => {
    if (!editData.country?.value) return Promise.resolve([]);
    return Promise.resolve(
      City.getCitiesOfCountry(editData.country.value)
        ?.map((c) => ({ value: c.name, label: c.name }))
        .filter((c) =>
          c.label.toLowerCase().includes(inputValue.toLowerCase())
        ) || []
    );
  };

  return (
    <div className="bg-white p-6 sm:p-8 rounded-lg border border-gray-200 shadow-sm w-full relative">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">
          <Trans>Company Location</Trans>
        </h2>
        {!isEditing ? (
          <button onClick={() => setIsEditing(true)} className="p-2 ...">
            <Edit size={16} />
          </button>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={handleCancel}
              disabled={isLoading}
              className="px-3 py-1 text-sm font-semibold bg-white border rounded-md text-gray-700 hover:bg-gray-50"
            >
              <Trans>Cancel</Trans>
            </button>
            <button
              onClick={handleSave}
              disabled={isLoading}
              className="px-3 py-1 text-sm font-semibold bg-cyan-600 text-white rounded-md hover:bg-cyan-700"
            >
              {isLoading ? (
                t`Saving...`
              ) : (
                <>
                  <Save size={14} className="inline-block mr-1" />
                  <Trans> Save</Trans>
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {!isEditing ? (
        <div className="overflow-hidden rounded-lg border border-gray-200 h-64 mt-4 relative">
          {isValidCoordinate(locationData.lat, locationData.lng) ? (
            <MapContainer
              key={`view-${locationData.lat}-${locationData.lng}`}
              center={getValidCoordinates()}
              zoom={13}
              scrollWheelZoom={false}
              className="w-full h-full z-0"
              style={{ height: "100%", width: "100%" }}
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              <Marker position={getValidCoordinates()}>
                <Popup>
                  <div className="text-center">
                    <strong>{locationData.city}</strong>
                    <br />
                    {locationData.addriss}
                  </div>
                </Popup>
              </Marker>
            </MapContainer>
          ) : (
            <div className="flex items-center justify-center h-full bg-gray-50 text-gray-500">
              <div className="text-center">
                <div className="text-lg mb-2">📍</div>
                <p>
                  <Trans>No location coordinates available</Trans>
                </p>
                <p className="text-sm">
                  <Trans>Click Edit to set location</Trans>
                </p>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="mt-4 space-y-4">
          <div className="flex gap-6">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="locationMode"
                value="map"
                checked={locationMode === "map"}
                onChange={() => setLocationMode("map")}
                className="form-radio text-cyan-600"
              />
              <Trans> Use Map</Trans>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="locationMode"
                value="enter"
                checked={locationMode === "enter"}
                onChange={() => setLocationMode("enter")}
                className="form-radio text-cyan-600"
              />
              <Trans> Enter Address</Trans>
            </label>
          </div>

          {locationMode === "map" ? (
            <div className="space-y-4">
              <div className="relative">
                <label
                  htmlFor="gmaps-link"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  <Trans>Paste Google Maps Link</Trans>
                </label>
                <LinkIcon className="absolute left-3 top-10 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  id="gmaps-link"
                  onChange={handleGoogleMapsLink}
                  placeholder={t`Paste a link here to update the map`}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 pl-10"
                />
              </div>
              <div className="overflow-hidden rounded-lg border border-gray-200 h-64 relative">
                <MapContainer
                  key={`edit-${editData.coordinates.lat}-${editData.coordinates.lng}`}
                  center={[
                    editData.coordinates.lat || 34.0209,
                    editData.coordinates.lng || -6.8416,
                  ]}
                  zoom={13}
                  scrollWheelZoom={true}
                  className="w-full h-full z-0"
                  style={{ height: "100%", width: "100%" }}
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  />
                  <MapEditor
                    position={{
                      lat: editData.coordinates.lat || 34.0209,
                      lng: editData.coordinates.lng || -6.8416,
                    }}
                    onPositionChange={(newPos) =>
                      setEditData((prev) => ({ ...prev, coordinates: newPos }))
                    }
                  />
                </MapContainer>
              </div>
            </div>
          ) : (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Trans>Location</Trans>
              </label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-1">
                <AsyncSelect
                  defaultOptions
                  cacheOptions
                  loadOptions={loadCountryOptions}
                  value={editData.country}
                  onChange={(opt) => handleSelectChange("country", opt)}
                  placeholder={t`Country`}
                />

                <AsyncSelect
                  key={editData.country?.value}
                  cacheOptions
                  loadOptions={loadCityOptions}
                  value={editData.city}
                  onChange={(opt) => handleSelectChange("city", opt)}
                  isDisabled={!editData.country}
                  placeholder={t`City`}
                />

                <input
                  type="text"
                  name="address"
                  value={editData.address}
                  onChange={handleInputChange}
                  placeholder={t` Address`}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default LocationSection;
