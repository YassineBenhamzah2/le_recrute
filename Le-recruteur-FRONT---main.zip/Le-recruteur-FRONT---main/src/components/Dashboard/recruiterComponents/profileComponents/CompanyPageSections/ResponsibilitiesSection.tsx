import React, { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CompanyData, Responsibility } from "@/lib/types/auth";
import { PlusCircle, Trash2, Edit, CheckCircle, Save } from "lucide-react";
import { api } from "@/lib/network/utils/api";
import { toast } from "sonner";
import { Trans, t } from '@lingui/macro';

const ResponsibilitiesSection: React.FC<{ data: CompanyData }> = ({ data }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const [responsibilities, setResponsibilities] = useState<Responsibility[]>(
    data.responsibilities
  );
  const [newResponsibility, setNewResponsibility] = useState("");

  useEffect(() => {
    setResponsibilities(data.responsibilities);
  }, [data.responsibilities]);

  const handleResponsibilityChange = (id: number | string, newName: string) => {
    setResponsibilities((current) =>
      current.map((resp) =>
        resp.id === id ? { ...resp, name: newName } : resp
      )
    );
  };

  const handleAddResponsibility = () => {
    if (newResponsibility.trim()) {
      const newItem: Responsibility = {
        id: `temp-${Date.now()}`, // ID temporaire pour la key React
        name: newResponsibility.trim(),
      };
      setResponsibilities((current) => [...current, newItem]);
      setNewResponsibility("");
    }
  };

  const handleRemoveResponsibility = (idToRemove: number | string) => {
    setResponsibilities((current) =>
      current.filter((resp) => resp.id !== idToRemove)
    );
  };

  const handleCancel = () => {
    setResponsibilities(data.responsibilities); // Restaure les données d'origine
    setIsEditing(false);
  };

  const handleSave = async () => {
    setIsLoading(true);

    const payload = {
      responsibilities: responsibilities.map((r) => r.name).filter(Boolean),
    };

    const promise = api.post<Responsibility[]>(
      `/recruiter/company/${data.id}/responsibilities`,
      payload
    );
    toast.promise(promise, {
      loading: t`Saving responsibilities...`,
      success: t`Responsibilities updated successfully!`,
      error: (err) => err.message || t`Failed to save changes.`,
    });

    try {
      const updatedListFromApi = await promise;

      setResponsibilities(updatedListFromApi);
      setIsEditing(false);
    } catch (err) {
      console.error("Save failed:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 sm:p-8 rounded-lg border border-gray-200 shadow-sm w-full">
      {/* --- EN-TÊTE AVEC BOUTONS CONDITIONNELS --- */}
      <div className="flex justify-between items-center pb-4 border-b border-gray-200">
        <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
          <CheckCircle size={22} className="text-cyan-600" />
          <Trans>Our Responsibilities</Trans>
        </h2>

        {!isEditing ? (
          <button
            onClick={() => setIsEditing(true)}
            className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold text-gray-600 bg-gray-100 border border-gray-200 rounded-md hover:bg-gray-200 transition-colors"
          >
            <Edit size={16} />
          </button>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={handleCancel}
              disabled={isLoading}
              className="px-4 py-1.5 text-sm font-semibold bg-white border rounded-md text-gray-700 hover:bg-gray-50"
            >
              <Trans>Cancel</Trans>
            </button>
            <button
              onClick={handleSave}
              disabled={isLoading}
              className="px-4 py-1.5 text-sm font-semibold bg-cyan-600 text-white rounded-md hover:bg-cyan-700 flex items-center gap-2"
            >
              {isLoading ? (
                "Saving..."
              ) : (
                <>
                  <Save size={14} className="inline-block mr-1" /> <Trans>Save</Trans>
                </>
              )}
            </button>
          </div>
        )}
      </div>

      <div className="mt-4">
        {/* --- LISTE DES RESPONSABILITÉS (Affichage ou Édition) --- */}
        <AnimatePresence>
          <motion.ul layout className="space-y-3">
            {responsibilities.map((resp) => (
              <motion.li
                key={resp.id}
                layout
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="flex items-center gap-3"
              >
                {isEditing ? (
                  <>
                    <input
                      type="text"
                      value={resp.name}
                      onChange={(e) =>
                        handleResponsibilityChange(resp.id, e.target.value)
                      }
                      className="w-full py-2 bg-transparent border-b-2 border-gray-200 focus:border-cyan-500 focus:outline-none transition-colors"
                    />
                    <button
                      onClick={() => handleRemoveResponsibility(resp.id)}
                      className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full"
                    >
                      <Trash2 size={16} />
                    </button>
                  </>
                ) : (
                  <>
                    <span className="w-2 h-2 bg-cyan-500 rounded-full flex-shrink-0"></span>
                    <p className="text-gray-700">{resp.name}</p>
                  </>
                )}
              </motion.li>
            ))}
          </motion.ul>
        </AnimatePresence>

        {/* --- CHAMP D'AJOUT (Apparaît en mode édition) --- */}
        <AnimatePresence>
          {isEditing && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto", marginTop: "1rem" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="flex items-center gap-2 pt-3 border-t border-gray-200 mt-4"
            >
              <input
                type="text"
                value={newResponsibility}
                onChange={(e) => setNewResponsibility(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleAddResponsibility();
                  }
                }}
                placeholder={t`Add a new responsibility and press Enter`}
                className="w-full py-2 bg-gray-50 border border-gray-200 rounded-md px-3 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
              <button
                onClick={handleAddResponsibility}
                className="p-2 bg-green-100 text-green-700 hover:bg-green-200 rounded-full"
              >
                <PlusCircle size={20} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ResponsibilitiesSection;
