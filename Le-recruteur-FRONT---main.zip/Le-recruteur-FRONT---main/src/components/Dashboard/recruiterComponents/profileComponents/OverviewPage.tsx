import React, { useState, useEffect } from 'react';
import { DollarSign, Users } from 'lucide-react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { api } from '@/lib/network/utils/api';
import { toast } from "sonner";
import { Trans, t } from '@lingui/macro';

// --- TYPES ---
interface StatsItem {
  label: React.ReactNode; // Le label peut être un composant de traduction
  value: number;
}



interface OverviewStats {
  jobsPostedStats: {
    totalThisMonth: number;
    activeJobs: number;
    closedJobs: number;
  };
  applicationsReceivedStats: {
    totalThisMonth: number;
    aNew: number;
    inProgress: number;
    rejected: number;
  };
  jobStatusChartData: {
    active: number;
    inactive: number;
    expired: number;
    pause: number;
    pending: number;
    scheduled: number;
  };
}


interface StatsCardProps {
  icon: React.ReactNode;
  title: React.ReactNode;
  totalValue: React.ReactNode;
  items: StatsItem[];
}

interface JobStatusChartProps {
  data: { name: string; value: number }[];
}

// --- SOUS-COMPOSANTS ---

const StatsCard: React.FC<StatsCardProps> = ({ icon, title, totalValue, items }) => (
  <div className="bg-white p-6 rounded-lg border border-gray-200 w-full shadow-sm">
    <div className="flex justify-between items-start mb-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-cyan-700">
          {icon}
        </div>
        <span className="text-gray-600 font-medium">{title}</span>
      </div>
      <span className="text-gray-800 font-bold">{totalValue}</span>
    </div>
    <div className="flex pt-4 border-t border-gray-100 text-center">
        {items.map((item, index) => (
          <React.Fragment key={index}> {/* Utilisez l'index comme clé, c'est plus sûr ici */}
            
            {/* Conteneur pour chaque stat qui prend une part égale de l'espace */}
            <div className="flex-1 flex-grow p-2">
              <p className="text-2xl font-bold text-gray-800">{item.value}</p>
              <p className="text-sm text-gray-500">{item.label}</p>
            </div>
            
            {/* Séparateur */}
            {index < items.length - 1 && (
              <div className="border-l border-gray-200"></div>
            )}

          </React.Fragment>
        ))}
      </div>
  </div>
);

const CustomChartCenter = ({ data }: { data: { name: string; value: number }[] }) => {
  const total = Array.isArray(data) ? data.reduce((sum, entry) => sum + entry.value, 0) : 0;
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
      <p className="text-4xl font-bold text-gray-800">{total}</p>
      <p className="text-sm text-gray-500 font-medium"><Trans>Total Jobs</Trans></p>
    </div>
  );
};

const JobStatusChart: React.FC<JobStatusChartProps> = ({ data }) => {
  const chartColors = ['#0891b2', '#0e7490', '#a5f3fc', '#67e8f9', '#22d3ee', '#06b6d4'];
  const hasData = data && data.length > 0 && data.some(item => item.value > 0);

  return (
    <div className="bg-white p-6 rounded-xl border border-gray-200 w-full shadow-sm">
      <h3 className="text-lg font-bold text-gray-800"><Trans>Job Posts by Status</Trans></h3>
      <p className="text-sm text-gray-500 mb-4"><Trans>Overview of all job posts</Trans></p>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center min-h-[250px]">
        <div className="md:col-span-2 h-[250px] relative">
          {hasData ? (
            <>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={data} cx="50%" cy="50%" innerRadius={80} outerRadius={100} fill="#8884d8" paddingAngle={5} dataKey="value" labelLine={false} label={false}>
                    {data.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={chartColors[index % chartColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ background: 'white', border: '1px solid #e2e8f0', borderRadius: '0.5rem' }} />
                </PieChart>
              </ResponsiveContainer>
              <CustomChartCenter data={data} />
            </>
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-gray-500"><Trans>No data to display.</Trans></p>
            </div>
          )}
        </div>

        <div className="md:col-span-1 space-y-3">
          {data.map((entry, index) => (
            <div key={`legend-${index}`} className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full" style={{ backgroundColor: chartColors[index % chartColors.length] }} />
                <span className="text-gray-600 font-medium">{entry.name}</span>
              </div>
              <span className="font-bold text-gray-800">{entry.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};


export const OverviewPage: React.FC = () => {
  const [stats, setStats] = useState<OverviewStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const recruiterId = JSON.parse(localStorage.getItem("userData") || '{}').id;
    if (!recruiterId) {
        toast.error(t`User not authenticated.`);
        setLoading(false);
        return;
    }
    
    api.getItem<OverviewStats>(`/recruiter/${recruiterId}/profileOverview`)
      .then(data => {
        setStats(data);
      })
      .catch(error => {
        toast.error(t`Could not load dashboard statistics.`);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  if (loading) return <div><Trans>Loading...</Trans></div>;
  if (!stats) return <div><Trans>Failed to load data.</Trans></div>;

  // --- Définition des labels et construction des props CÔTÉ FRONT-END ---
  const jobsPostedStatsProps = {
    icon: <DollarSign size={20} />,
    title: <Trans>Jobs Posted</Trans>,
    totalValue: <Trans>{stats.jobsPostedStats.totalThisMonth} This Month</Trans>,
    items: [
      { label: <Trans>Active Jobs</Trans>, value: stats.jobsPostedStats.activeJobs },
      { label: <Trans>Closed/Filled</Trans>, value: stats.jobsPostedStats.closedJobs },
    ],
  };

  const applicationsReceivedStatsProps = {
    icon: <Users size={20} />,
    title: <Trans>Applications Received</Trans>,
    totalValue: <Trans>{stats.applicationsReceivedStats.totalThisMonth} This Month</Trans>,
    items: [
      { label: <Trans>New</Trans>, value: stats.applicationsReceivedStats.aNew },
      { label: <Trans>In Process</Trans>, value: stats.applicationsReceivedStats.inProgress },
      { label: <Trans>Rejected</Trans>, value: stats.applicationsReceivedStats.rejected },
    ],
  };
  
  // Transformation des données pour le diagramme
  const chartDataForDisplay = [
    { name: t`Active`, value: stats.jobStatusChartData.active },
    { name: t`Inactive`, value: stats.jobStatusChartData.inactive },
    { name: t`Expired`, value: stats.jobStatusChartData.expired },
    { name: t`Paused`, value: stats.jobStatusChartData.pause },
    { name: t`Pending`, value: stats.jobStatusChartData.pending },
    { name: t`Scheduled`, value: stats.jobStatusChartData.scheduled },
  ].filter(item => item.value > 0); // Filtre pour ne pas afficher les statuts à zéro

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <StatsCard {...jobsPostedStatsProps} />
        <StatsCard {...applicationsReceivedStatsProps} />
      </div>
      <JobStatusChart data={chartDataForDisplay} />
    </div>
  );
};