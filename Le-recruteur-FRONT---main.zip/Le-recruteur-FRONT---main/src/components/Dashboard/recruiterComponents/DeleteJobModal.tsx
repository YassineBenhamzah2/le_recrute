import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Trans } from "@lingui/macro";

interface DeleteJobModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  jobTitle: string;
  onConfirm: () => Promise<void>;
}

export const DeleteJobModal = ({
  open,
  onOpenChange,
  jobTitle,
  onConfirm,
}: DeleteJobModalProps): JSX.Element => {
  const [loading, setLoading] = useState(false);

  const handleDelete = async () => {
    setLoading(true);
    try {
      await onConfirm();
      onOpenChange(false);
    } catch (error) {
      console.error("Error deleting job:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] rounded-2xl p-6">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-900">
            <Trans>Delete Job Post</Trans>
          </DialogTitle>
          <DialogDescription className="text-gray-500 mt-2">
            <Trans>
              Are you sure you want to delete the job post for{" "}
              <span className="font-semibold text-gray-700">"{jobTitle}"</span>?
              This action cannot be undone.
            </Trans>
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex flex-col sm:flex-row gap-4 mt-6">
          <Button
            type="button"
            variant="outline"
            disabled={loading}
            className="w-full sm:w-32 h-12 font-normal text-gray-700 bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={() => onOpenChange(false)}
          >
            <Trans>Cancel</Trans>
          </Button>
          <Button
            type="button"
            disabled={loading}
            className="w-full sm:w-32 h-12 font-normal bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={handleDelete}
          >
            {loading ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                <Trans>Deleting...</Trans>
              </div>
            ) : (
              <Trans>Delete</Trans>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};