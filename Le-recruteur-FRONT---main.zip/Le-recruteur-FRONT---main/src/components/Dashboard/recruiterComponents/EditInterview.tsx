import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { candidatService } from "@/lib/network/candidat";
import { interviewService } from "@/lib/network/interview";
import { jobOfferService } from "@/lib/network/jobOffer";
import { Candidate } from "@/lib/types/candidat";
import { CreateInterviewRequest, Interview } from "@/lib/types/interview";
import { JobOffer } from "@/lib/types/jobOffer";
import { convertToDateInputFormatV2 } from "@/lib/utils/time";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { InterviewInformationSection } from "./InterviewInformationSection";
import { InterviewStatusSection } from "./InterviewStatusSection";
import { JuryFeedbackSection } from "./JuryFeedbackSection";
import { Trans } from "@lingui/macro";

type InterviewerType = { id: number; name: string };
type DecisionType = "pending" | "approved" | "rejected";
type StatusType = "scheduled" | "completed" | "cancelled" | "pending";

export interface InterviewInfoType {
  jobOfferId: number | null;
  candidateId: number | null;
  candidateName: string;
  positionTitle: string;
  date: string;
  time: string;
  duration: string;
  meetingLink: string;
  interviewers: InterviewerType[];
}

export interface JuryFeedbackType {
  observations: string;
  decision: DecisionType;
}

export interface InterviewStatusType {
  status: StatusType;
  notes: string;
}

interface EditInterviewProps {
  interview?: Interview;
  onClose: () => void;
  onSave?: (data: {
    interviewInfo: InterviewInfoType;
    juryFeedback: JuryFeedbackType;
    interviewStatus: InterviewStatusType;
  }) => void;
  onRefresh?: () => void;
}

export const EditInterview = ({
  interview,
  onClose,
  onSave,
  onRefresh,
}: EditInterviewProps): JSX.Element => {
  const [jobOffers, setJobOffers] = useState<JobOffer[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(false);

  const defaultInterviewInfo = useMemo(
    () => ({
      jobOfferId: null,
      candidateId: null,
      candidateName: "",
      positionTitle: "",
      date: "",
      time: "",
      duration: "",
      meetingLink: "",
      interviewers: [],
    }),
    []
  );

  const defaultJuryFeedback = useMemo(
    () => ({
      observations: "",
      decision: "pending" as const,
    }),
    []
  );

  const defaultInterviewStatus = useMemo(
    () => ({
      status: "scheduled" as const,
      notes: "",
    }),
    []
  );

  const [interviewInfo, setInterviewInfo] =
    useState<InterviewInfoType>(defaultInterviewInfo);
  const [juryFeedback, setJuryFeedback] =
    useState<JuryFeedbackType>(defaultJuryFeedback);
  const [interviewStatus, setInterviewStatus] = useState<InterviewStatusType>(
    defaultInterviewStatus
  );

  const handleSave = async () => {
    if (!interviewInfo.jobOfferId || !interviewInfo.candidateId) {
      toast.error(<Trans>Please select both a job and a candidate</Trans>);
      return;
    }

    if (!interviewInfo.date || !interviewInfo.time) {
      toast.error(<Trans>Please select both date and time</Trans>);
      return;
    }

    setLoading(true);
    try {
      if (interview) {
        // Editing existing interview
        const updateData: CreateInterviewRequest = {
          title: interviewInfo.positionTitle,
          jobOfferId: interviewInfo.jobOfferId,
          candidateId: interviewInfo.candidateId,
          scheduledAt: `${interviewInfo.date}T${interviewInfo.time}:00`,
          endedAt: `${interviewInfo.date}T${interviewInfo.time}:00`,
          interviewType: "VIDEO",
          interviewers: interviewInfo.interviewers.map((i) => i.name),
          juryDecision: juryFeedback.decision.toUpperCase(),
          address: interviewInfo.meetingLink,
          observations: juryFeedback.observations,
          notes: interviewStatus.notes,
          status: interviewStatus.status.toUpperCase(),
          duration: interviewInfo.duration,
        };
        await interviewService.updateInterview(interview.id, updateData);
        toast.success(<Trans>Interview updated successfully</Trans>);

        // Trigger refresh of the interview dashboard if it's available
        const refreshFunction = (
          window as Window & {
            refreshRecruiterInterviews?: () => Promise<void>;
          }
        ).refreshRecruiterInterviews;

        if (refreshFunction) {
          await refreshFunction();
        }
      } else {
        // Creating new interview
        const createData: CreateInterviewRequest = {
          title: interviewInfo.positionTitle,
          jobOfferId: interviewInfo.jobOfferId,
          candidateId: interviewInfo.candidateId,
          scheduledAt: `${interviewInfo.date}T${interviewInfo.time}:00`,
          endedAt: `${interviewInfo.date}T${interviewInfo.time}:00`,
          interviewType: "VIDEO",
          interviewers: interviewInfo.interviewers.map((i) => i.name),
          juryDecision: juryFeedback.decision.toUpperCase(),
          address: interviewInfo.meetingLink,
          observations: juryFeedback.observations,
          notes: interviewStatus.notes,
          status: interviewStatus.status.toUpperCase(),
          duration: interviewInfo.duration,
        };
        await interviewService.createInterview(createData);
        toast.success(<Trans>Interview scheduled successfully</Trans>);

        // Trigger refresh of the interview dashboard if it's available
        const refreshFunction = (
          window as Window & {
            refreshRecruiterInterviews?: () => Promise<void>;
          }
        ).refreshRecruiterInterviews;

        if (refreshFunction) {
          await refreshFunction();
        }
      }

      if (onSave) {
        const payload = {
          interviewInfo,
          juryFeedback,
          interviewStatus,
        };
        onSave(payload);
      }

      if (onRefresh) {
        onRefresh();
      }

      onClose();
    } catch (error) {
      console.error("Error saving interview:", error);
      toast.error(<Trans>Failed to save interview. Please try again.</Trans>);
    } finally {
      setLoading(false);
    }
  };

  // Fetch job offers on component mount
  useEffect(() => {
    const fetchJobOffers = async () => {
      try {
        const response = await jobOfferService.getRecruiterJobs();
        if (response.success) {
          setJobOffers(response.data);
        }
      } catch (error) {
        console.error("Error fetching job offers:", error);
        toast.error(<Trans>Failed to fetch job offers</Trans>);
      }
    };

    fetchJobOffers();
  }, []);

  // Fetch candidates when job is selected
  const handleJobSelection = useCallback(
    async (jobOfferId: number) => {
      try {
        setLoading(true);
        const response = await candidatService.getJobCandidates({ jobOfferId });
        if (response.success) {
          setCandidates(response.data);
          if (!interview) {
            setInterviewInfo((prev) => ({
              ...prev,
              candidateId: null,
              candidateName: "",
            }));
          }
        }
      } catch (error) {
        console.error("Error fetching candidates:", error);
        toast.error(<Trans>Failed to fetch candidates for this job</Trans>);
      } finally {
        setLoading(false);
      }
    },
    [interview]
  );

  useEffect(() => {
    if (interview) {
      setInterviewInfo({
        jobOfferId: interview.jobOffer?.id || null,
        candidateId: interview.candidate?.id || null,
        candidateName: interview.name,
        positionTitle: interview.position,
        date: convertToDateInputFormatV2(interview.date),
        time: interview.time,
        meetingLink: interview.meetingLink || "",
        interviewers: interview.interviewers.map((i) => ({ id: +i, name: i })),
        duration: interview.duration || "",
      });

      // Fetch candidates for the existing interview's job
      if (interview.jobOffer?.id) {
        handleJobSelection(interview.jobOffer.id);
      }

      // If the interview has existing status/feedback, set those too
      if (interview.status) {
        setInterviewStatus({
          status: interview.status.toLowerCase() as StatusType,
          notes: interview.notes || "",
        });
      }

      if (interview.juryFeedback) {
        setJuryFeedback({
          observations: interview.juryFeedback.observations || "",
          decision:
            (interview.juryFeedback.decision as DecisionType) || "pending",
        });
      }
    } else {
      // Creating new interview - reset to defaults
      setInterviewInfo(defaultInterviewInfo);
      setJuryFeedback(defaultJuryFeedback);
      setInterviewStatus(defaultInterviewStatus);
    }
  }, [
    interview,
    defaultInterviewInfo,
    defaultJuryFeedback,
    defaultInterviewStatus,
    handleJobSelection,
  ]);

  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="w-full max-w-[1250px] max-h-[90vh] overflow-auto rounded-[15px] p-6 bg-white  [&>button]:hidden">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold text-gray-900 text-center mb-6">
            {interview ? (
              <Trans>Edit Interview Details</Trans>
            ) : (
              <Trans>Schedule New Interview</Trans>
            )}
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col lg:flex-row gap-6 h-full  overflow-visible">
          <div className="lg:w-[47%]">
            <InterviewInformationSection
              data={interviewInfo}
              setData={setInterviewInfo}
              jobOffers={jobOffers}
              candidates={candidates}
              onJobSelection={handleJobSelection}
              loading={loading}
            />
          </div>

          <div className="lg:w-[47%] flex flex-col gap-6">
            <div className="flex-grow">
              <JuryFeedbackSection
                data={juryFeedback}
                setData={setJuryFeedback}
              />
            </div>
            <div className="flex-grow">
              <InterviewStatusSection
                data={interviewStatus}
                setData={setInterviewStatus}
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-4 mt-6">
          <Button
            variant="outline"
            className="w-[278px] text-[#238d94] border-[#238d94] hover:bg-[#238d94]/5"
            onClick={onClose}
          >
            <Trans>Cancel</Trans>
          </Button>
          <Button
            className="w-[278px] bg-[#238d94] hover:bg-[#1c7a80] text-white"
            onClick={handleSave}
            disabled={loading}
          >
            {loading ? (
              <Trans>Saving...</Trans>
            ) : interview ? (
              <Trans>Save Changes</Trans>
            ) : (
              <Trans>Schedule Interview</Trans>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
