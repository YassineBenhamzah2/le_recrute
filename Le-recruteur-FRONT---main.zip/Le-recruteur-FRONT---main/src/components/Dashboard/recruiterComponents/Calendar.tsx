import { DateRange } from 'react-date-range';

interface CalendarProps {
    range: {
        startDate: Date;
        endDate: Date;
        key: 'selection';
    }[];
    setRange: React.Dispatch<React.SetStateAction<{
        startDate: Date;
        endDate: Date;
        key: 'selection';
    }[]>>;
}

const Calendar = ({ range, setRange }: CalendarProps) => {
    return (<div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300">
        <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-gray-900">Calendar</h3>
        </div>
        <div className="w-full">
            <DateRange
                ranges={range}
                onChange={(item) => setRange([item.selection as { startDate: Date; endDate: Date; key: 'selection'; }])}
                editableDateInputs={true}
                moveRangeOnFirstSelection={false}
                showDateDisplay={false}
                rangeColors={['#238D94']}
                months={1}
                direction="horizontal"
            />
        </div>
    </div>
    );
};

export default Calendar;