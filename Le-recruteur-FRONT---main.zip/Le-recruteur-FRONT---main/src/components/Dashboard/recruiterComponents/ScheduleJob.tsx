import { useState } from "react";
import { Calendar } from "react-date-range";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { generateTimeOptions } from "@/lib/utils/time";

interface DashboardProps {
  onConfirm: (scheduledDateTime: string) => void;
  onCancel?: () => void;
}

const ScheduleJob = ({ onConfirm }: DashboardProps) => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedHour, setSelectedHour] = useState("09");
  const [selectedMinute, setSelectedMinute] = useState("00");

  const handleScheduleJob = () => {
    const scheduledDateTime = new Date(selectedDate);
    scheduledDateTime.setHours(Number(selectedHour));
    scheduledDateTime.setMinutes(Number(selectedMinute));
    scheduledDateTime.setSeconds(0);

    // Format as YYYY-MM-DDTHH:mm:ss without timezone
    const year = scheduledDateTime.getFullYear();
    const month = String(scheduledDateTime.getMonth() + 1).padStart(2, "0");
    const day = String(scheduledDateTime.getDate()).padStart(2, "0");
    const hours = String(scheduledDateTime.getHours()).padStart(2, "0");
    const minutes = String(scheduledDateTime.getMinutes()).padStart(2, "0");
    const seconds = String(scheduledDateTime.getSeconds()).padStart(2, "0");

    const formattedDateTime = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
    onConfirm(formattedDateTime);
  };

  const handlePostNow = () => {
    onConfirm(""); // Empty string means post immediately
  };
  return (
    <Card className="relative w-full bg-white rounded-2xl overflow-hidden shadow-xl">
      <CardContent className="p-0">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="px-8 py-6 border-b">
            <h1 className="text-2xl font-bold text-gray-900">
              Schedule Job Post
            </h1>
          </div>

          <div className="flex flex-col md:flex-row h-full px-8 py-4 gap-4">
            {/* Calendar */}
            <div className="w-full md:w-1/2">
              <h2 className="font-semibold text-gray-800 mb-2">Select Date</h2>
              <Calendar
                date={selectedDate}
                onChange={setSelectedDate}
                color="#238d94"
                rangeColors={["#238d94"]}
                minDate={new Date()}
              />
            </div>

            {/* Time Selection */}
            <div className="w-full md:w-1/2 flex flex-col gap-8">
              <h2 className="font-semibold text-gray-800 mb-2">Select Time</h2>
              <div className="relative">
                <select
                  value={`${selectedHour}:${selectedMinute}`}
                  onChange={(e) => {
                    const [hour, minute] = e.target.value.split(":");
                    setSelectedHour(hour);
                    setSelectedMinute(minute);
                  }}
                  className="w-full appearance-none bg-white border-2 border-[#238d94]/20 focus:border-[#238d94] rounded-lg px-4 py-3 text-gray-700 leading-tight focus:outline-none hover:border-[#238d94]/50 transition-colors cursor-pointer"
                >
                  {generateTimeOptions().map((time) => (
                    <option
                      key={time.value}
                      value={time.value}
                      className="py-2"
                    >
                      {time.label}
                    </option>
                  ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-[#238d94]">
                  <svg
                    className="fill-current h-4 w-4"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                  </svg>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="mt-6 flex justify-between items-center px-8 pb-6">
            <div className="flex gap-4 ml-auto">
              <Button
                onClick={handlePostNow}
                className="w-full sm:w-[278px] h-12 font-normal text-[#238d94] border-[#238d94] bg-transparent hover:bg-transparent border-2 hover:border-ehc-green-light"
              >
                Post Now
              </Button>
              <Button
                onClick={handleScheduleJob}
                className="w-full sm:w-[278px] h-12 font-normal bg-[#238d94] text-white hover:bg-[#1a7379]"
              >
                Schedule Post
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ScheduleJob;
