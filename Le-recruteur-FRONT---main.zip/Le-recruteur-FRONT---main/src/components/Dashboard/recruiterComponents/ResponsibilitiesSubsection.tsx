import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { TrashIcon } from "lucide-react";
import { useState } from "react";
import { Trans , t} from "@lingui/macro"; // Ajout de l'import Trans

interface ResponsibilitiesSubsectionProps {
  formData: {
    jobOfferResponsibilities: string[];
  };
  addResponsibility: (responsibility: string) => void;
  removeResponsibility: (index: number) => void;
}

export const ResponsibilitiesSubsection = ({
  formData,
  addResponsibility,
  removeResponsibility,
}: ResponsibilitiesSubsectionProps): JSX.Element => {
  const [newResponsibility, setNewResponsibility] = useState("");
  const responsibilities =
    formData.jobOfferResponsibilities?.filter((resp) => resp.trim() !== "") ||
    [];

  const handleAdd = () => {
    if (newResponsibility.trim() !== "") {
      addResponsibility(newResponsibility.trim());
      setNewResponsibility("");
    }
  };

  return (
    <Card className="flex flex-col w-full items-start gap-[15.4px] p-6 bg-gray-50 rounded-xl">
      <div className="flex items-center gap-2 mb-4 w-full">
        <div className="relative w-5 h-5">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M9 5H11V7H9V5Z" fill="#111827" />
            <path d="M9 9H11V15H9V9Z" fill="#111827" />
            <path
              d="M10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18Z"
              stroke="#111827"
              strokeWidth="2"
            />
          </svg>
        </div>
        <h2 className="font-bold text-gray-900 text-xl leading-7">
          <Trans>Job Responsibilities</Trans>
        </h2>
      </div>

      <CardContent className="p-0 w-full space-y-4">
        {responsibilities.map((responsibility, index) => (
          <div key={index} className="flex items-center gap-2 w-full">
            <div className="flex-1 text-gray-800 border border-gray-200 px-4 py-2 rounded-md bg-white">
              {responsibility}
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-[42px] w-[42px]"
              onClick={() => removeResponsibility(index)}
              aria-label={<Trans>Delete responsibility</Trans>}
            >
              <TrashIcon className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        ))}

        <div className="flex gap-2 w-full">
          <Input
            value={newResponsibility}
            onChange={(e) => setNewResponsibility(e.target.value)}
            placeholder={t`Enter a job responsibility`}
            className="flex-1 h-[50px]"
          />
          <Button
            type="button"
            onClick={handleAdd}
            className="bg-[#238d94] hover:bg-[#1c7a80] text-white h-[50px]"
          >
            <Trans>Add Responsibility</Trans>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};