import * as React from "react";
import { Check, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

interface MultiSelectDropdownProps {
  options: string[];
  placeholder: string;
  selectedValues: string[];
  onChange: (values: string[]) => void;
  icon?: React.ComponentType<{ className?: string }>;
}

export function MultiSelectDropdown({
  options,
  placeholder,
  selectedValues,
  onChange,
  icon: Icon,
}: MultiSelectDropdownProps) {
  const [open, setOpen] = React.useState(false);

  const handleOptionToggle = (option: string) => {
    const newSelected = selectedValues.includes(option)
      ? selectedValues.filter((item) => item !== option)
      : [...selectedValues, option];
    onChange(newSelected);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between font-normal h-12 border-gray-200 bg-white hover:border-[#1a6b72]"
        >
          <div className="flex items-center gap-2 flex-1 overflow-hidden">
            {Icon && <Icon className="w-4 h-4 text-gray-400" />}
            {selectedValues.length > 0 ? (
              <div className="flex flex-wrap gap-1 items-center">
                {selectedValues.slice(0, 2).map((value) => (
                  <span
                    key={value}
                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-gray-800 text-xs rounded"
                  >
                    {value}
                  </span>
                ))}
                {selectedValues.length > 2 && (
                  <span className="text-xs text-gray-500">
                    +{selectedValues.length - 2} de plus
                  </span>
                )}
              </div>
            ) : (
              <span className="text-gray-500">{placeholder}</span>
            )}
          </div>
          <ChevronDown
            className={`ml-auto w-4 h-4 text-gray-400 shrink-0 opacity-50 transition-transform ${
              open ? "rotate-180" : ""
            }`}
          />
        </Button>
      </PopoverTrigger>
      <PopoverContent
          className="w-[--radix-popover-trigger-width] p-0"
          onInteractOutside={(e) => {
              e.preventDefault();
          }}
      >
        <Command>
          <CommandInput placeholder="Filtrer..." />
          <CommandList>
            <CommandEmpty>Aucun résultat.</CommandEmpty>
            <CommandGroup>
              {options.map((option) => {
                const isSelected = selectedValues.includes(option);
                return (
                  <CommandItem
                    key={option}
                    onSelect={() => handleOptionToggle(option)}
                    className="flex items-center gap-2 cursor-pointer"
                  >
                     <div
                        className={cn(
                          "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                          isSelected
                            ? "bg-primary text-primary-foreground"
                            : "opacity-50 [&_svg]:invisible"
                        )}
                      >
                        <Check className={cn("h-4 w-4")} />
                      </div>
                    <span>{option}</span>
                  </CommandItem>
                );
              })}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}