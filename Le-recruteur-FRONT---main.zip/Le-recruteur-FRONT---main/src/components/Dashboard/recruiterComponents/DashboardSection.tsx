import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  JobStatus,
  JobStatusList,
  JobType,
  JobTypeList,
} from "@/lib/types/subtype/main";
import { Trans ,t } from "@lingui/macro";
import { SearchIcon, MapPinIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { GetCountries, GetState } from "react-country-state-city";
import { Country, State } from "react-country-state-city/dist/esm/types";

export type FilterOption = { id: string; name: string };

interface DashboardSectionProps {
  search: string;
  onSearch: (query: string) => void;
  location: FilterOption | null;
  onLocationChange: (loc: FilterOption | null) => void;
  type: JobType | null;
  onTypeChange: (type: JobType | null) => void;
  status: JobStatus | null;
  onStatusChange: (status: JobStatus | null) => void;
}

export const DashboardSection = ({
  search,
  onSearch,
  location,
  onLocationChange,
  type,
  onTypeChange,
  status,
  onStatusChange,
}: DashboardSectionProps): JSX.Element => {
  // State for country and state selection
  const [countries, setCountries] = useState<Country[]>([]);
  const [states, setStates] = useState<State[]>([]);
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [selectedState, setSelectedState] = useState<State | null>(null);

  // Load countries on component mount
  useEffect(() => {
    GetCountries().then(setCountries);
  }, []);

  // Load states when country changes
  useEffect(() => {
    if (selectedCountry) {
      GetState(selectedCountry.id).then(setStates);
    } else {
      setStates([]);
      setSelectedState(null);
    }
  }, [selectedCountry]);

  // Reset location filter when external location prop changes to null
  useEffect(() => {
    if (!location) {
      setSelectedCountry(null);
      setSelectedState(null);
    }
  }, [location]);

  // Handle location change - build location string from country and state
  const handleLocationChange = (
    country: Country | null,
    state: State | null = null
  ) => {
    let locationString = "";
    if (country) {
      //   locationString = country.name;
      if (state) {
        locationString += `${state.name}`;
      }
    }

    // Update the location filter with the constructed string
    const locationFilter = locationString
      ? { id: locationString, name: locationString }
      : null;
    onLocationChange(locationFilter);
  };

  // Handle country selection
  const handleCountryChange = (countryId: string) => {
    if (countryId === "all") {
      // Clear selection
      setSelectedCountry(null);
      setSelectedState(null);
      handleLocationChange(null, null);
      return;
    }

    const country =
      countries.find((c) => c.id.toString() === countryId) || null;
    setSelectedCountry(country);
    setSelectedState(null);
  };

  // Handle state selection
  const handleStateChange = (stateId: string) => {
    if (stateId === "all") {
      // Clear state selection but keep country
      setSelectedState(null);
      handleLocationChange(selectedCountry, null);
      return;
    }

    const state = states.find((s) => s.id.toString() === stateId) || null;
    setSelectedState(state);
    handleLocationChange(selectedCountry, state);
  };

  return (
    <Card className="w-full p-6 shadow-sm rounded-xl border-2 ">
      <div className="flex flex-col md:flex-row gap-4">
        {/* Search */}
        <div className="relative flex-1">
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
            <SearchIcon className="h-5 w-5" />
          </div>
          <Input
            className="pl-10 h-[50px] border-gray-300 text-base"
            placeholder={t`Search jobs, companies, or locations...`}
            value={search}
            onChange={(e) => onSearch(e.target.value)}
          />
        </div>
        {/* Location Filter - Country and State */}
        <div className="flex items-center gap-2">
          <MapPinIcon className="w-5 h-5 text-gray-400" />
          <Select
            value={selectedCountry?.id?.toString() || ""}
            onValueChange={handleCountryChange}
          >
            <SelectTrigger className="w-[160px] h-[50px] border-gray-300">
              <SelectValue placeholder={t`Country`} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Countries</SelectItem>
              {countries.map((country) => (
                <SelectItem key={country.id} value={country.id.toString()}>
                  <div className="flex items-center gap-2">
                    <img
                      alt={country.name}
                      src={`http://purecatamphetamine.github.io/country-flag-icons/3x2/${country.iso2}.svg`}
                      className="w-4 h-3"
                    />
                    {country.name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select
            disabled={!selectedCountry}
            value={selectedState?.id?.toString() || ""}
            onValueChange={handleStateChange}
          >
            <SelectTrigger className="w-[160px] h-[50px] border-gray-300">
              <SelectValue placeholder={t`State`} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all"><Trans>All States</Trans></SelectItem>
              {states.map((state) => (
                <SelectItem key={state.id} value={state.id.toString()}>
                  {state.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {/* Type Filter */}
        <Select
          value={type ? type : ""}
          onValueChange={(value) => {
            const selected = JobTypeList.find((t) => t === value) || null;
            onTypeChange(value === "all" ? null : selected);
          }}
        >
          <SelectTrigger className="w-[150px] h-[50px] border-gray-300">
            <SelectValue placeholder={t`All Types`} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all"><Trans>All Types</Trans></SelectItem>
            {JobTypeList.map((t) => (
              <SelectItem key={t} value={t}>
                {t}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {/* Status Filter */}
        <Select
          value={status ? status : ""}
          onValueChange={(value) => {
            const selected = JobStatusList.find((s) => s === value) || null;
            onStatusChange(value === "all" ? null : selected);
          }}
        >
          <SelectTrigger className="w-[150px] h-[50px] border-gray-300">
            <SelectValue placeholder={t`All Statuses`} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all"><Trans>All Statuses</Trans></SelectItem>
            {JobStatusList.map((s) => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </Card>
  );
};
