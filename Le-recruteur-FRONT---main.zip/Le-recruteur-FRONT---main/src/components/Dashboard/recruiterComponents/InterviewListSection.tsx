import { Card, CardContent } from "@/components/ui/card";

interface InterviewStat {
    title: string;
    count: string;
    icon: JSX.Element;
    bgColor: string;
    iconBgColor: string;
}

interface InterviewListSectionProps {
    stats: InterviewStat[];
}

export const InterviewListSection = ({ stats }: InterviewListSectionProps): JSX.Element => {
    return (
        <section className="flex items-start justify-center gap-6 w-full">
            {stats.map((stat, index) => (
                <Card
                    key={`interview-stat-${index}`}
                    className={`w-[286px] border ${stat.bgColor}`}
                >
                    <CardContent className="p-[25px]">
                        <div className="flex items-center justify-between w-full">
                            <div className="flex flex-col items-start gap-1">
                                <div className="flex flex-col items-start w-full">
                                    <div className="font-semibold text-gray-600 text-sm leading-5 whitespace-nowrap">
                                        {stat.title}
                                    </div>
                                </div>
                                <div className="flex flex-col items-start w-full">
                                    <div className="font-bold text-gray-900 text-3xl leading-9 whitespace-nowrap">
                                        {stat.count}
                                    </div>
                                </div>
                            </div>
                            <div className={`flex w-12 h-12 items-center justify-center rounded-lg overflow-hidden ${stat.iconBgColor}`}>
                                {stat.icon}
                            </div>
                        </div>
                    </CardContent>
                </Card>
            ))}
        </section>
    );
};
