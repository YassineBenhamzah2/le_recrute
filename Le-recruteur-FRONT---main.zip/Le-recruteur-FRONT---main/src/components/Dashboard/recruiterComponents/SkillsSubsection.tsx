import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { TrashIcon } from "lucide-react";
import { useState } from "react";
import { Trans , t} from "@lingui/macro"; // Ajout de l'import Trans

interface SkillsSubsectionProps {
  formData: {
    jobOfferSkills: string[];
  };
  addSkill: (skill: string) => void;
  removeSkill: (index: number) => void;
}

export const SkillsSubsection = ({
  formData,
  addSkill,
  removeSkill,
}: SkillsSubsectionProps): JSX.Element => {
  const [newSkill, setNewSkill] = useState("");
  const skills =
    formData.jobOfferSkills?.filter((skill) => skill.trim() !== "") || [];

  const handleAdd = () => {
    if (newSkill.trim() !== "") {
      addSkill(newSkill.trim());
      setNewSkill("");
    }
  };

  return (
    <Card className="flex flex-col w-full items-start gap-[15.4px] p-6 bg-gray-50 rounded-xl">
      <div className="flex items-center gap-2 mb-4 w-full">
        <div className="relative w-5 h-5">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path
              d="M10.8626 2.31752C10.3812 1.89394 9.61881 1.89394 9.13739 2.31752L2.34363 8.18241C1.88806 8.58366 1.86283 9.29088 2.28645 9.72411C2.7371 10.1846 3.49233 10.2061 3.96777 9.77285L4.28283 9.48734V16.666C4.28283 17.58 5.03253 18.333 5.9426 18.333H14.0574C14.9675 18.333 15.7172 17.58 15.7172 16.666V9.48734L16.0322 9.77285C16.5077 10.2061 17.2629 10.1846 17.7135 9.72411C18.1372 9.29088 18.1119 8.58367 17.6564 8.18241L10.8626 2.31752ZM10 4.33579L14.0574 7.96928V15.7179L13.1973 14.9998C13.1387 14.9495 13.0724 14.9094 13.0012 14.8813L10.8333 14.1666V11.6785C10.8333 10.9885 10.2769 10.4285 9.58333 10.4285H7.91667C7.22313 10.4285 6.66667 10.9885 6.66667 11.6785V13.3452L5.9426 13.0833V7.96928L10 4.33579Z"
              fill="#111827"
            />
          </svg>
        </div>
        <h2 className="font-bold text-gray-900 text-xl leading-7">
          <Trans>Skills Required</Trans>
        </h2>
      </div>

      <CardContent className="p-0 w-full space-y-4">
        {skills.map((skill, index) => (
          <div key={index} className="flex items-center gap-2 w-full">
            <div className="flex-1 text-gray-800 border border-gray-200 px-4 py-2 rounded-md bg-white">
              {skill}
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-[42px] w-[42px]"
              onClick={() => removeSkill(index)}
              aria-label={<Trans>Delete skill</Trans>}
            >
              <TrashIcon className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        ))}

        <div className="flex gap-2 w-full">
          <Input
            value={newSkill}
            onChange={(e) => setNewSkill(e.target.value)}
            placeholder={t`Enter a required skill`}
            className="flex-1 h-[50px]"
          />
          <Button
            type="button"
            onClick={handleAdd}
            className="bg-[#238d94] hover:bg-[#1c7a80] text-white h-[50px]"
          >
            <Trans>Add Skill</Trans>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};