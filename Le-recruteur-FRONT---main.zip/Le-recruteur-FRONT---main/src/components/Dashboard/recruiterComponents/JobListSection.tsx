import { useDebounce } from "@/components/Auth/hooks/useDebounce";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { jobOfferService } from "@/lib/network/jobOffer";
import { GetRecruiterJobsQuery, PaginationMetadata } from "@/lib/types/base";
import { JobOffer } from "@/lib/types/jobOffer";
import { JobStatus, JobType } from "@/lib/types/subtype/main";
import {
  BadgeDollarSignIcon,
  Building2Icon,
  CalendarIcon,
  CheckCircleIcon,
  ClockIcon,
  EyeIcon,
  MapPinIcon,
  PencilIcon,
  TrashIcon,
} from "lucide-react";
import {
  useCallback,
  useEffect,
  useState,
  useRef,
  forwardRef,
  useImperativeHandle,
} from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import type { FilterOption } from "./DashboardSection";
import { DeleteJobModal } from "./DeleteJobModal";
import { EditJobModal } from "./EditJobModal";
import { toast } from "sonner";
import { Trans, t } from "@lingui/macro";

const ITEMS_PER_PAGE = 10; // Server will handle pagination
interface JobListSectionProps {
  search: string;
  location: FilterOption | null;
  type: JobType | null;
  status: JobStatus | null;
  onJobsChanged?: () => void;
}

// Handle type for the ref
export interface JobListSectionHandle {
  refreshJobs: (params?: GetRecruiterJobsQuery) => Promise<void>;
}

// Extended job interface combining API data with display properties
export interface Job extends JobOffer {
  postedDays?: string;
  daysLeft?: string;
  postedDate?: string;
  department?: string;
  country?: string;
  city?: string;
}

export const JobListSection = forwardRef<
  JobListSectionHandle,
  JobListSectionProps
>(({ search, location, type, status, onJobsChanged }, ref) => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState<number>(1);
  const [pagination, setPagination] = useState<PaginationMetadata>({
    page: 1,
    pageSize: ITEMS_PER_PAGE,
    totalPages: 1,
    totalItems: 0,
  });
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [editJobModal, setEditJobModal] = useState<string | null>(null);
  const [deleteJobModal, setDeleteJobModal] = useState<string | null>(null);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);

  // Debounce search input to avoid too many API calls
  const debouncedSearch = useDebounce(search, 500);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("fr-FR");
  };

  const getDaysAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const value = `${diffDays}d ago`;
    return t`${value}`;
  };

  const getDaysLeft = (deadlineString: string) => {
    const deadline = new Date(deadlineString);
    const now = new Date();
    const diffTime = deadline.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return t`${Math.abs(diffDays)} days overdue`;
    } else if (diffDays === 0) {
      return t`Today`;
    } else {
      return t`${diffDays} days left`;
    }
  };

  // Utility function to split location into country and city
  const splitLocation = (location: string) => {
    if (!location) {
      return { country: "", city: "" };
    }

    // Split by comma and trim whitespace
    const parts = location.split(",").map((part) => part.trim());

    if (parts.length >= 2) {
      return {
        country: parts[0],
        city: parts[1],
      };
    } else {
      // If no comma found, treat the whole string as city
      return {
        country: "",
        city: location,
      };
    }
  };

  const getStatusDisplay = (status: JobStatus) => {
    switch (status?.toUpperCase()) {
      case "ACTIVE":
        return <Trans>Active</Trans>;
      case "PAUSE":
        return <Trans>Paused</Trans>;
      case "INACTIVE":
        return <Trans>Inactive</Trans>;
      case "EXPIRED":
        return <Trans>Expired</Trans>;
      case "PENDING":
        return <Trans>Pending</Trans>;
      default:
        return status || <Trans>Unknown</Trans>;
    }
  };

  const getStatusBadgeClasses = (status: JobStatus) => {
    switch (status?.toUpperCase()) {
      case "ACTIVE":
        return "bg-green-100 text-green-800 hover:bg-green-200";
      case "PAUSE":
        return "bg-yellow-100 text-yellow-800 hover:bg-yellow-200";
      case "INACTIVE":
        return "bg-gray-100 text-gray-800 hover:bg-gray-200";
      case "EXPIRED":
        return "bg-red-100 text-red-800 hover:bg-red-200";
      case "PENDING":
        return "bg-blue-100 text-blue-800 hover:bg-blue-200";
      default:
        return "bg-gray-100 text-gray-800 hover:bg-gray-200";
    }
  };

  // Convert API job to display job
  const convertApiJobToDisplayJob = useCallback((apiJob: JobOffer): Job => {
    const { country, city } = splitLocation(apiJob.location);
    return {
      ...apiJob,
      postedDays: getDaysAgo(apiJob.publicationDate),
      postedDate: formatDate(apiJob.publicationDate),
      daysLeft: getDaysLeft(apiJob.deadlineDate),
      company: apiJob.company, // This should come from the recruiter's company info
      currency: apiJob.currency,
      country: country,
      city: city,
    };
  }, []);

  // Fetch jobs from API with server-side pagination and filtering
  const fetchJobs = useCallback(
    async (params: GetRecruiterJobsQuery = {}) => {
      try {
        setLoading(true);
        setError(null);

        // Ensure pagination is enabled
        const queryParams: GetRecruiterJobsQuery = {
          ...params,
          paginated: true,
          page: params.page || page,
        };

        const response = await jobOfferService.getRecruiterJobs(queryParams);

        if (response.success && response.data) {
          const displayJobs = response.data.map(convertApiJobToDisplayJob);
          setJobs(displayJobs);

          // Update pagination metadata if provided
          if (response.metadata?.pagination) {
            setPagination(response.metadata.pagination);
          }
        } else {
          setError(t`Failed to fetch jobs`);
        }
      } catch (err) {
        console.error("Error fetching jobs:", err);
        setError(t`Failed to load jobs`);
      } finally {
        setLoading(false);
      }
    },
    [convertApiJobToDisplayJob, page]
  );

  // Initialize page from URL on component mount
  useEffect(() => {
    const initialPage = parseInt(searchParams.get("page") || "1", 10);
    setPage(initialPage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Only run once on mount

  // Expose fetchJobs to parent via ref
  useImperativeHandle(ref, () => ({
    refreshJobs: fetchJobs,
  }));

  // Main effect to fetch jobs and update URL params
  useEffect(() => {
    const params: GetRecruiterJobsQuery = {
      page,
      paginated: true,
    };

    // Build query params for URL
    const urlParams: Record<string, string> = { page: String(page) };

    // Add filters to both API params and URL params
    if (debouncedSearch && debouncedSearch.length > 0) {
      params.search = debouncedSearch;
      urlParams.search = debouncedSearch;
    }
    if (location) {
      params.location = location.name;
      urlParams.location = location.name;
    }
    if (type) {
      params.jobType = type;
      urlParams.jobType = type;
    }
    if (status) {
      params.status = status;
      urlParams.status = status;
    }

    // Update URL params
    setSearchParams(urlParams);

    // Fetch jobs with current params
    fetchJobs(params);
  }, [
    debouncedSearch,
    location,
    type,
    status,
    page,
    fetchJobs,
    setSearchParams,
  ]);

  // Reset to page 1 when filters change (but not on initial mount)
  const filtersRef = useRef({ debouncedSearch, location, type, status });
  const isInitialMount = useRef(true);

  useEffect(() => {
    // Skip if this is the initial mount
    if (isInitialMount.current) {
      isInitialMount.current = false;
      filtersRef.current = { debouncedSearch, location, type, status };
      return;
    }

    // Check if filters actually changed
    const prevFilters = filtersRef.current;
    const filtersChanged =
      prevFilters.debouncedSearch !== debouncedSearch ||
      prevFilters.location !== location ||
      prevFilters.type !== type ||
      prevFilters.status !== status;

    if (filtersChanged && page !== 1) {
      setPage(1);
    }

    // Update ref with current filters
    filtersRef.current = { debouncedSearch, location, type, status };
  }, [debouncedSearch, location, type, status, page]);

  // Server-side pagination - no need to slice data locally
  const totalPages = pagination.totalPages;

  // Enhanced pagination logic with ellipses
  const generatePaginationItems = () => {
    const items: Array<{
      number: number;
      active: boolean;
      isEllipsis?: boolean;
    }> = [];
    const maxVisiblePages = 5; // Maximum number of page buttons to show

    if (totalPages <= maxVisiblePages) {
      // Show all pages if total pages is small
      for (let i = 1; i <= totalPages; i++) {
        items.push({ number: i, active: i === page });
      }
    } else {
      // Always show first page
      items.push({ number: 1, active: page === 1 });

      if (page > 3) {
        items.push({ number: -1, active: false, isEllipsis: true }); // Left ellipsis
      }

      // Show pages around current page
      const start = Math.max(2, page - 1);
      const end = Math.min(totalPages - 1, page + 1);

      for (let i = start; i <= end; i++) {
        if (i !== 1 && i !== totalPages) {
          items.push({ number: i, active: i === page });
        }
      }

      if (page < totalPages - 2) {
        items.push({ number: -2, active: false, isEllipsis: true }); // Right ellipsis
      }

      // Always show last page
      if (totalPages > 1) {
        items.push({ number: totalPages, active: page === totalPages });
      }
    }

    return items;
  };

  const paginationItems = generatePaginationItems();

  const handlePageChange = useCallback(
    (newPage: number) => {
      if (newPage >= 1 && newPage <= totalPages && newPage !== page) {
        setPage(newPage);
      }
    },
    [page, totalPages]
  );

  const handleJobClick = (job: Job) => {
    setSearchParams({});
    navigate(`/recruiter/jobs/${job.id}`);
  };

  const handleEditJob = (job: Job) => {
    const { country, city } = splitLocation(job.location);
    setSelectedJob({
      ...job,
      country: country,
      city: city,
    });
    setEditJobModal(job.id.toString());
  };

  const handleDeleteJob = (jobId: number) => {
    const job = jobs.find((j: Job) => j.id === jobId);
    if (job) {
      setSelectedJob(job);
      setDeleteJobModal(jobId.toString());
    }
  };

  const handleConfirmDelete = async (): Promise<void> => {
    if (selectedJob) {
      try {
        const response = await jobOfferService.deleteJobOffer(selectedJob.id);
        if (response.success) {
          // Refresh the jobs list
          const params: GetRecruiterJobsQuery = {
            page,
            paginated: true,
          };

          if (debouncedSearch && debouncedSearch.length > 0) {
            params.search = debouncedSearch;
          }
          if (location) {
            params.location = location.name;
          }
          if (type) {
            params.jobType = type;
          }
          if (status) {
            params.status = status;
          }

          fetchJobs(params);
          toast.success(<Trans>Job deleted successfully!</Trans>);
          setSelectedJob(null);
          setDeleteJobModal(null);
          onJobsChanged?.(); // Notify parent component
        } else {
          console.error("Failed to delete job");
          toast.error(<Trans>Failed to delete job</Trans>);
          throw new Error("Failed to delete job");
        }
      } catch (err) {
        console.error("Error deleting job:", err);
        toast.error(<Trans>Failed to delete job</Trans>);
        throw err; // Re-throw to let the modal handle loading state
      }
    }
  };

  return (
    <>
      <Card className="w-full shadow rounded-2xl border border-solid overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-auto min-h-[120px] flex flex-col justify-center">
            {loading ? (
              <div className="w-full flex justify-center items-center py-10 text-lg text-gray-500">
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-[#238d94]"></div>
                  <Trans>Loading jobs...</Trans>
                </div>
              </div>
            ) : error ? (
              <div className="w-full flex justify-center items-center py-10 text-lg text-red-500">
                <Trans>Error: {error}</Trans>
              </div>
            ) : jobs.length === 0 ? (
              <div className="w-full flex justify-center items-center py-10 text-lg text-gray-400">
                <Trans>No jobs found.</Trans>
              </div>
            ) : (
              <div>
                {/* Pagination Info */}
                {pagination.totalItems > 0 && (
                  <div className="flex justify-between items-center px-6 py-4 bg-gray-50 border-t">
                    <div className="text-sm text-gray-600">
                      <Trans>
                        Showing {(page - 1) * pagination.pageSize + 1} to{" "}
                        {Math.min(
                          page * pagination.pageSize,
                          pagination.totalItems
                        )}{" "}
                        of {pagination.totalItems} jobs
                      </Trans>
                    </div>
                    <div className="text-sm text-gray-600">
                      <Trans>
                        Page {page} of {totalPages}
                      </Trans>
                    </div>
                  </div>
                )}

                {/* Table header & body - keep yours as is */}
                <Table>
                  <TableHeader className="bg-gray-50 border-b">
                    <TableRow>
                      <TableHead className="pl-6 font-bold text-gray-900 text-sm">
                        <div className="flex items-center gap-2">
                          <Building2Icon className="w-5 h-5 text-gray-400" />
                          <span>
                            <Trans>Job Details</Trans>
                          </span>
                        </div>
                      </TableHead>
                      <TableHead className="font-bold text-gray-900 text-sm">
                        <div className="flex items-center gap-2">
                          <MapPinIcon className="w-5 h-5 text-gray-400" />
                          <span>
                            <Trans>Location & Type</Trans>
                          </span>
                        </div>
                      </TableHead>
                      <TableHead className="font-bold text-gray-900 text-sm">
                        <div className="flex items-center gap-2">
                          <BadgeDollarSignIcon className="w-5 h-5 text-gray-400" />
                          <span>
                            <Trans>Salary</Trans>
                          </span>
                        </div>
                      </TableHead>
                      <TableHead className="font-bold text-gray-900 text-sm">
                        <div className="flex items-center gap-2">
                          <CalendarIcon className="w-5 h-5 text-gray-400" />
                          <span>
                            <Trans>Posted</Trans>
                          </span>
                        </div>
                      </TableHead>
                      <TableHead className="font-bold text-gray-900 text-sm">
                        <div className="flex items-center gap-2">
                          <ClockIcon className="w-5 h-5 text-gray-400" />
                          <span>
                            <Trans>Deadline</Trans>
                          </span>
                        </div>
                      </TableHead>
                      <TableHead className="font-bold text-gray-900 text-sm">
                        <div className="flex items-center gap-2">
                          <CheckCircleIcon className="w-5 h-5 text-gray-400" />
                          <span>
                            <Trans>Status</Trans>
                          </span>
                        </div>
                      </TableHead>
                      <TableHead className="text-center font-bold text-gray-900 text-sm">
                        <Trans>Actions</Trans>
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {jobs.map((job, index) => (
                      <TableRow key={index}>
                        <TableCell
                          className="pl-6 cursor-pointer"
                          onClick={() => handleJobClick(job)}
                        >
                          <div className="flex flex-col">
                            <h3 className="font-bold text-gray-900 text-lg">
                              {job.title}
                            </h3>
                            <span className="text-gray-600 text-sm">
                              {job.company.name}
                            </span>
                            <span className="text-gray-500 text-xs">
                              {job.company.sector}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-1">
                            <div className="flex flex-col">
                              {job.country && (
                                <span className="text-gray-900 text-sm font-medium">
                                  {job.country}
                                </span>
                              )}
                              {job.city && (
                                <span className="text-gray-600 text-xs">
                                  {job.city}
                                </span>
                              )}
                              {!job.country && !job.city && (
                                <span className="text-gray-900 text-sm">
                                  {job.location}
                                </span>
                              )}
                            </div>
                            <div className="flex gap-1 mt-1">
                              <Badge className="bg-blue-100 text-blue-800 text-xs  hover:bg-purple-200">
                                {job.jobType}
                              </Badge>
                              <Badge className="bg-purple-100 text-purple-800 text-xs  hover:bg-purple-200">
                                {job.contractType}
                              </Badge>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-[#238d94] font-bold text-lg">
                            {job.currency} {job.minSalary} - {job.maxSalary}
                          </div>
                          <div className="text-xs text-gray-500">
                            <Trans>per month</Trans>{" "}
                            {job.negotiable && <Trans>(Negotiable)</Trans>}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm text-gray-900">
                            {job.postedDays}
                          </div>
                          <div className="text-xs text-gray-500">
                            {job.postedDate}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm text-gray-900">
                            {job.daysLeft}
                          </div>
                          <div className="text-xs text-gray-500">
                            {job.daysLeft}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            className={`text-xs ${getStatusBadgeClasses(
                              job.status
                            )}`}
                          >
                            {getStatusDisplay(job.status)}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex justify-center gap-2">
                            <button
                              className="text-sky-500"
                              onClick={() => handleJobClick(job)}
                            >
                              <EyeIcon className="w-5 h-5" />
                            </button>
                            <button
                              className="text-green-500"
                              onClick={() => handleEditJob(job)}
                            >
                              <PencilIcon className="w-5 h-5" />
                            </button>
                            <button
                              className="text-red-500"
                              onClick={() => handleDeleteJob(job.id)}
                            >
                              <TrashIcon className="w-5 h-5" />
                            </button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center my-6">
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              if (page > 1) {
                                handlePageChange(page - 1);
                              }
                            }}
                            className={
                              page <= 1 ? "pointer-events-none opacity-50" : ""
                            }
                          />
                        </PaginationItem>
                        {paginationItems.map((item) => (
                          <PaginationItem key={item.number}>
                            <PaginationLink
                              href="#"
                              onClick={(e) => {
                                e.preventDefault();
                                handlePageChange(item.number);
                              }}
                              className={`w-10 h-10 rounded-lg flex items-center justify-center font-semibold text-base ${
                                item.active
                                  ? "bg-[#238d94] text-white"
                                  : "text-[#192335]"
                              }`}
                            >
                              {item.number}
                            </PaginationLink>
                          </PaginationItem>
                        ))}
                        <PaginationItem>
                          <PaginationNext
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              if (page < totalPages) {
                                handlePageChange(page + 1);
                              }
                            }}
                            className={
                              page >= totalPages
                                ? "pointer-events-none opacity-50"
                                : ""
                            }
                          />
                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      {selectedJob && (
        <EditJobModal
          open={Boolean(editJobModal)}
          onOpenChange={(open) => {
            if (!open) {
              setEditJobModal(null);
              setSelectedJob(null);
            }
          }}
          job={selectedJob}
          onJobUpdated={() => {
            // Refresh the jobs list after successful update
            const params: GetRecruiterJobsQuery = {
              page,
              paginated: true,
            };

            if (debouncedSearch && debouncedSearch.length > 0) {
              params.search = debouncedSearch;
            }
            if (location) {
              params.location = location.name;
            }
            if (type) {
              params.jobType = type;
            }
            if (status) {
              params.status = status;
            }

            fetchJobs(params);
            onJobsChanged?.(); // Notify parent component
          }}
        />
      )}
      <DeleteJobModal
        open={Boolean(deleteJobModal)}
        onOpenChange={(open) => {
          if (!open) {
            setDeleteJobModal(null);
            setSelectedJob(null);
          }
        }}
        jobTitle={selectedJob?.title || ""}
        onConfirm={handleConfirmDelete}
      />
    </>
  );
});
