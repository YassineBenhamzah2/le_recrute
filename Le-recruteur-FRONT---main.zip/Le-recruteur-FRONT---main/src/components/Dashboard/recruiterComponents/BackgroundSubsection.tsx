import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { departmentService } from "@/lib/network/department";
import { Department } from "@/lib/types/department";
import { ClipboardListIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { GetCountries, GetState } from "react-country-state-city";
import { Country, State } from "react-country-state-city/dist/esm/types";
import { Trans, t } from "@lingui/macro"; // Ajout de l'import Trans

interface BackgroundSubsectionProps {
  formData: {
    title: string;
    departmentId: number;
    location: string;
    country?: string | null;
    state?: string | null;
  };
  handleChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleSelectChange: (name: string, value: string) => void;
  handleLocationChange?: (country: Country | null, state: State | null) => void;
}

export const BackgroundSubsection = ({
  formData,
  handleChange,
  handleSelectChange,
  handleLocationChange,
}: BackgroundSubsectionProps): JSX.Element => {
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(false);
  const [countries, setCountries] = useState<Country[]>([]);
  const [states, setStates] = useState<State[]>([]);
  const [country, setCountry] = useState<Country | null>(null);
  const [state, setState] = useState<State | null>(null);

  // Fetch departments
  useEffect(() => {
    const fetchDepartments = async () => {
      setLoading(true);
      try {
        const response = await departmentService.getDepartments();
        if (response.success && "data" in response) {
          setDepartments(response.data);
        } else {
          console.error("Failed to fetch departments");
          setDepartments([]);
        }
      } catch (error) {
        console.error("Error fetching departments:", error);
        setDepartments([]);
      } finally {
        setLoading(false);
      }
    };

    fetchDepartments();
  }, []);

  // Fetch countries and initialize from formData
  useEffect(() => {
    GetCountries().then((countriesData) => {
      setCountries(countriesData);

      // Initialize country from formData if available
      if (formData.country && countriesData.length > 0) {
        const foundCountry = countriesData.find(
          (c) => c.name === formData.country
        );
        if (foundCountry) {
          setCountry(foundCountry);
        }
      }
    });
  }, [formData.country]);

  // Fetch states when country changes and initialize from formData
  useEffect(() => {
    if (country) {
      GetState(country.id).then((statesData) => {
        setStates(statesData);

        // Initialize state from formData if available
        if (formData.state && statesData.length > 0) {
          const foundState = statesData.find((s) => s.name === formData.state);
          if (foundState) {
            setState(foundState);
          }
        }
      });
    } else {
      setStates([]);
      setState(null);
    }
  }, [country, formData.state]);

  // Update location in parent component
  const updateLocation = (
    countryVal: Country | null,
    stateVal: State | null = null
  ) => {
    let locationString = "";
    if (countryVal) {
      locationString = countryVal.name;
      if (stateVal) {
        locationString += `, ${stateVal.name}`;
      }
    }

    // Update form data location
    if (handleLocationChange) {
      handleLocationChange(countryVal, stateVal);
    } else {
      // Fall back to updating location string directly
      const event = {
        target: {
          name: "location",
          value: locationString,
        },
      } as React.ChangeEvent<HTMLInputElement>;
      handleChange(event);
    }
  };

  return (
    <Card className="w-full bg-gray-50 p-6">
      <div className="flex items-center gap-2 mb-4">
        <div className="relative w-5 h-5">
          <ClipboardListIcon className="w-5 h-5 text-gray-900" />
        </div>
        <h2 className="font-bold text-xl text-gray-900">
          <Trans>Basic Information</Trans>
        </h2>
      </div>

      <CardContent className="p-0 grid grid-cols-1 md:grid-cols-2 gap-x-[55px] gap-y-4">
        {/* Job Title */}
        <div className="flex flex-col gap-2">
          <Label htmlFor="title" className="font-normal text-gray-700 text-sm">
            <Trans>Job Title *</Trans>
          </Label>
          <Input
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            placeholder={t`Enter job title`}
            className="h-[50px] text-gray-400"
            required
          />
        </div>

        {/* Department */}
        <div className="flex flex-col gap-2">
          <Label className="font-normal text-gray-700 text-sm">
            <Trans>Department *</Trans>
          </Label>
          <Select
            value={formData.departmentId?.toString()}
            onValueChange={(value) => handleSelectChange("departmentId", value)}
            disabled={loading}
          >
            <SelectTrigger className="h-[50px] text-gray-400">
              <SelectValue placeholder={<Trans>Select department</Trans>} />
            </SelectTrigger>
            <SelectContent>
              {departments.map((department) => (
                <SelectItem
                  key={department.id}
                  value={department.id.toString()}
                >
                  {department.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Location */}
        <div className="flex flex-col gap-2">
          {/* Country Select */}
          <Label className="font-normal text-gray-700 text-sm">
            <Trans>Country *</Trans>
          </Label>
          <Select
            value={country?.id?.toString()}
            onValueChange={(id) => {
              if (id === "all") {
                setCountry(null);
                setState(null);
                updateLocation(null, null);
              } else {
                const selected = countries.find((c) => c.id.toString() === id);
                if (selected) {
                  setCountry(selected);
                  setState(null);
                  updateLocation(selected, null);
                }
              }
            }}
          >
            <SelectTrigger className="h-[50px] flex-1 text-gray-400">
              <SelectValue placeholder={<Trans>Select Country</Trans>} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem key="all" value="all">
                <Trans>All Countries</Trans>
              </SelectItem>
              {countries.map((c) => (
                <SelectItem key={c.id} value={c.id.toString()}>
                  <img
                    alt={`${t`Flag of`} ${c.name}`}
                    src={`http://purecatamphetamine.github.io/country-flag-icons/3x2/${c.iso2}.svg`}
                    className="w-6 h-4 inline-block mr-2"
                  />
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex flex-col gap-2">
          {/* City Select */}
          <Label className="font-normal text-gray-700 text-sm">
            <Trans>City *</Trans>
          </Label>
          <Select
            disabled={!country}
            value={state?.id?.toString()}
            onValueChange={(id) => {
              if (id === "clear") {
                setState(null);
                updateLocation(country, null);
              } else {
                const selected = states.find((s) => s.id.toString() === id);
                if (selected) {
                  setState(selected);
                  updateLocation(country, selected);
                }
              }
            }}
          >
            <SelectTrigger className="h-[50px] flex-1 text-gray-400">
              <SelectValue placeholder={<Trans>Select State</Trans>} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem key="clear" value="clear">
                <Trans>Clear Selection</Trans>
              </SelectItem>
              {states.map((s) => (
                <SelectItem key={s.id} value={s.id.toString()}>
                  {s.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  );
};
