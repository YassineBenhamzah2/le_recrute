import React, { useEffect, useState, useCallback } from "react";
import {
  X,
  FileText,
  HelpCircle,
  BarChart3,
  Clock,
  Users,
  Play,
  Edit3,
  Check,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Search,
  UserPlus,
  UserMinus,
  Briefcase,
} from "lucide-react";
import {
  Test,
  TestQuestion,
  TestQuestionOption,
  TestTopPerformer,
  TestSpecificAnalytics,
  AssignTestRequest,
  TestAssignment,
} from "@/lib/types/test";
import { testService } from "@/lib/network/test";
import { jobOfferService } from "@/lib/network/jobOffer";
import { candidatService } from "@/lib/network/candidat";
import { JobOffer } from "@/lib/types/jobOffer";
import { Candidate } from "@/lib/types/candidat";
import { GetRecruiterJobsQuery, GetJobCandidatesQuery } from "@/lib/types/base";
import { toast } from "sonner";
import { Trans } from "@lingui/macro";
import { t } from "@lingui/core/macro";

interface ViewTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  testId?: string;
  testData?: Test;
  onEditTest?: (testId: string) => void;
}

type TabType = "overview" | "questions" | "analytics" | "assignments";

const ViewTestModal: React.FC<ViewTestModalProps> = ({
  isOpen,
  onClose,
  testId,
  testData,
  onEditTest,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>("overview");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [prevIsOpen, setPrevIsOpen] = useState(false);
  const [topPerformers, setTopPerformers] = useState<TestTopPerformer[]>([]);
  const [loadingPerformers, setLoadingPerformers] = useState(false);
  const [analyticsData, setAnalyticsData] =
    useState<TestSpecificAnalytics | null>(null);
  const [loadingAnalytics, setLoadingAnalytics] = useState(false);

  // Assignments tab state
  const [jobs, setJobs] = useState<JobOffer[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);
  const [loadingJobs, setLoadingJobs] = useState(false);
  const [loadingCandidates, setLoadingCandidates] = useState(false);
  const [jobsPage, setJobsPage] = useState(1);
  const [candidatesPage, setCandidatesPage] = useState(1);
  const [jobsSearch, setJobsSearch] = useState("");
  const [assigning, setAssigning] = useState(false);
  const [assignedCandidateIds, setAssignedCandidateIds] = useState<number[]>(
    []
  );
  const [testAssignments, setTestAssignments] = useState<TestAssignment[]>([]);

  // Fetch top performers for the test
  const fetchTopPerformers = useCallback(async () => {
    if (!testId) return;

    try {
      setLoadingPerformers(true);
      const response = await testService.getTestTopPerformers(testId, 3);
      if (response.success && response.data) {
        setTopPerformers(response.data);
      }
    } catch (error) {
      console.error("Error fetching top performers:", error);
      setTopPerformers([]); // Fallback to empty array
    } finally {
      setLoadingPerformers(false);
    }
  }, [testId]);

  // Fetch analytics for the test
  const fetchAnalytics = useCallback(async () => {
    if (!testId) return;

    try {
      setLoadingAnalytics(true);
      const response = await testService.getTestSpecificAnalytics(testId);
      if (response.success && response.data) {
        setAnalyticsData(response.data);
      }
    } catch (error) {
      console.error("Failed to fetch analytics:", error);
      setAnalyticsData(null);
    } finally {
      setLoadingAnalytics(false);
    }
  }, [testId]);

  // Fetch jobs for assignments
  const fetchJobs = useCallback(async () => {
    setLoadingJobs(true);
    try {
      const params: GetRecruiterJobsQuery = {
        page: jobsPage,
        search: jobsSearch || undefined,
        paginated: true,
      };
      const response = await jobOfferService.getRecruiterJobs(params);
      if (response.success && response.data) {
        setJobs(response.data);
      }
    } catch (error) {
      console.error("Failed to fetch jobs:", error);
      setJobs([]);
    } finally {
      setLoadingJobs(false);
    }
  }, [jobsPage, jobsSearch]);

  // Fetch assigned candidates for the test
  const fetchAssignedCandidates = useCallback(async () => {
    if (!testData?.id) return;

    try {
      const response = await testService.getTestAssignedCandidates(testData.id);
      if (response.success && response.data) {
        setTestAssignments(response.data);
        const candidateIds = response.data.map(
          (assignment) => assignment.candidateId
        );
        setAssignedCandidateIds(candidateIds);
      }
    } catch (error) {
      console.error("Error fetching assigned candidates:", error);
      setTestAssignments([]);
      setAssignedCandidateIds([]);
    }
  }, [testData?.id]); // Fetch candidates for selected job
  const fetchCandidates = useCallback(async () => {
    if (!selectedJobId) return;

    setLoadingCandidates(true);
    try {
      const params: GetJobCandidatesQuery = {
        jobOfferId: selectedJobId,
        page: candidatesPage,
      };
      const response = await candidatService.getJobCandidates(params);
      if (response.success && response.data) {
        setCandidates(response.data);
      }
    } catch (error) {
      console.error("Failed to fetch candidates:", error);
      setCandidates([]);
    } finally {
      setLoadingCandidates(false);
    }
  }, [selectedJobId, candidatesPage]);

  // Assign test to candidate
  const handleAssignTest = useCallback(
    async (candidateId: number) => {
      if (!testId || !selectedJobId) return;

      setAssigning(true);
      try {
        const assignRequest: AssignTestRequest = {
          testId: testId,
          candidateIds: [candidateId],
          jobOfferId: selectedJobId,
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days from now
        };

        const response = await testService.assignTest(assignRequest);
        if (response.success) {
          toast.success(<Trans>Test assigned successfully!</Trans>);
          // Refresh assignments to update the UI
          fetchAssignedCandidates();
        }
      } catch (error) {
        console.error("Failed to assign test:", error);
        toast.error(<Trans>Failed to assign test. Please try again.</Trans>);
      } finally {
        setAssigning(false);
      }
    },
    [testId, selectedJobId, fetchAssignedCandidates]
  );

  // Unassign test from candidate
  const handleUnassignTest = useCallback(
    async (candidateId: number) => {
      const assignment = testAssignments.find(
        (a) => a.candidateId === candidateId
      );
      if (!assignment) return;

      setAssigning(true);
      try {
        const response = await testService.deleteTestAssignment(
          assignment.id.toString()
        );
        if (response.success) {
          toast.success(<Trans>Test unassigned successfully!</Trans>);
          // Refresh assignments to update the UI
          fetchAssignedCandidates();
        }
      } catch (error) {
        console.error("Failed to unassign test:", error);
        toast.error(<Trans>Failed to unassign test. Please try again.</Trans>);
      } finally {
        setAssigning(false);
      }
    },
    [testAssignments, fetchAssignedCandidates]
  );

  // Helper function to check if candidate has test assigned
  const isCandidateAssigned = useCallback(
    (candidateId: number) => {
      return assignedCandidateIds.includes(candidateId);
    },
    [assignedCandidateIds]
  );

  // Helper function to get candidate assignment details
  const getCandidateAssignment = useCallback(
    (candidateId: number) => {
      return testAssignments.find(
        (assignment) => assignment.candidateId === candidateId
      );
    },
    [testAssignments]
  );

  // Log test info for debugging
  useEffect(() => {
    if (isOpen && testId) {
      console.log("Viewing test:", testId, testData);
      fetchTopPerformers();
      fetchAnalytics();
      fetchAssignedCandidates();
    }
  }, [
    isOpen,
    testId,
    testData,
    fetchTopPerformers,
    fetchAnalytics,
    fetchAssignedCandidates,
  ]);

  // Fetch jobs when assignments tab is active
  useEffect(() => {
    if (isOpen && activeTab === "assignments") {
      fetchJobs();
    }
  }, [isOpen, activeTab, fetchJobs]);

  // Fetch candidates when job is selected
  useEffect(() => {
    if (selectedJobId) {
      fetchCandidates();
    } else {
      setCandidates([]);
    }
  }, [selectedJobId, fetchCandidates]);

  // Reset jobs page when search changes
  useEffect(() => {
    setJobsPage(1);
  }, [jobsSearch]);

  // Simple background scroll prevention
  useEffect(() => {
    if (isOpen) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }

    // Cleanup on unmount
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [isOpen]);

  // Reset to overview tab when modal opens (only when transitioning from closed to open)
  useEffect(() => {
    if (isOpen && !prevIsOpen) {
      // Modal is opening (was closed, now open)
      setActiveTab("overview");
      setCurrentQuestionIndex(0);
    }
    setPrevIsOpen(isOpen);
  }, [isOpen, prevIsOpen]);

  const handlePreviewTest = () => {
    if (testId) {
      // Open test preview in a new tab
      const testUrl = `${window.location.origin}/recruiter/test?id=${testId}`;
      window.open(testUrl, "_blank");
      //   onClose(); // Close the modal after opening new tab
    }
  };

  if (!isOpen) return null;

  const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  let tabs = [
    {
      id: "overview" as TabType,
      name: <Trans>Overview</Trans>,
      icon: FileText,
      current: activeTab === "overview",
    },
    {
      id: "questions" as TabType,
      name: <Trans>Questions</Trans>,
      icon: HelpCircle,
      current: activeTab === "questions",
    },
    {
      id: "analytics" as TabType,
      name: <Trans>Analytics</Trans>,
      icon: BarChart3,
      current: activeTab === "analytics",
    },
    {
      id: "assignments" as TabType,
      name: <Trans>Assignments</Trans>,
      icon: UserPlus,
      current: activeTab === "assignments",
    },
  ];

  // Hide analytics tab if no analytics data is available
  if (!analyticsData) {
    console.log("No analytics data, hiding tab");
    tabs = tabs.filter((tab) => tab.id !== "analytics");
  }
  const renderTabContent = () => {
    switch (activeTab) {
      case "overview":
        return (
          <div className="p-6">
            {/* Test Header */}
            <div className="bg-gradient-to-r from-teal-50 to-blue-50 rounded-xl p-6 mb-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h1 className="text-xl font-bold text-gray-900">
                      {testData?.title || <Trans>Test Title</Trans>}
                    </h1>
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        testData?.difficulty === "EASY"
                          ? "bg-green-100 text-green-700"
                          : testData?.difficulty === "MEDIUM"
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-red-100 text-red-700"
                      }`}
                    >
                      {testData?.difficulty || <Trans>Easy</Trans>}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm mb-4">
                    {testData?.description}
                  </p>

                  <div className="grid grid-cols-4 gap-6">
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-teal-600" />
                      <div>
                        <p className="text-gray-600 text-sm">
                          <Trans>{testData?.duration || 0} minutes</Trans>
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-teal-600" />
                      <div>
                        <p className="text-gray-600 text-sm">
                          <Trans>
                            {testData?.questions?.length || 0} questions
                          </Trans>
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-teal-600" />
                      <div>
                        <p className="text-gray-600 text-sm">
                          <Trans>{testData?.passingScore || 0} to pass</Trans>
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-5 h-5 text-teal-600" />
                      <div>
                        <p className="text-gray-600 text-sm">
                          {testData?.category || <Trans>N/A</Trans>}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handlePreviewTest}
                  className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors"
                >
                  <Play className="w-4 h-4" />
                  <Trans>Preview Test</Trans>
                </button>
              </div>
            </div>

            {/* Content Grid */}
            <div className="grid grid-cols-2 gap-6">
              {/* Left Column - Test Information */}
              <div className="bg-white border border-gray-200 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  <Trans>Test Information</Trans>
                </h3>

                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">
                      <Trans>Created</Trans>
                    </span>
                    <span className="font-normal">
                      {testData?.created ? (
                        new Date(testData.created).toLocaleDateString("en-GB")
                      ) : (
                        <Trans>N/A</Trans>
                      )}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">
                      <Trans>Last Updated</Trans>
                    </span>
                    <span className="font-normal">
                      {testData?.lastUpdated ? (
                        new Date(testData.lastUpdated).toLocaleDateString(
                          "en-GB"
                        )
                      ) : (
                        <Trans>N/A</Trans>
                      )}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">
                      <Trans>Category</Trans>
                    </span>
                    <span className="font-normal">
                      {testData?.category || <Trans>N/A</Trans>}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">
                      <Trans>Total Points</Trans>
                    </span>
                    <span className="font-normal">
                      {testData?.questions?.reduce(
                        (total: number, question: TestQuestion) =>
                          total + (question.points || 0),
                        0
                      ) || 0}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">
                      <Trans>Question Types</Trans>
                    </span>
                    <span className="font-normal">
                      {testData?.questions ? (
                        [
                          ...new Set(
                            testData.questions.map((q: TestQuestion) => q.type)
                          ),
                        ].join(", ")
                      ) : (
                        <Trans>N/A</Trans>
                      )}
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Column - Top Performers */}
              <div className="bg-white border border-gray-200 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  <Trans>Top Performers</Trans>
                </h3>

                <div className="space-y-4">
                  {loadingPerformers ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-6 h-6 animate-spin text-teal-600" />
                      <span className="ml-2 text-gray-600">
                        <Trans>Loading top performers...</Trans>
                      </span>
                    </div>
                  ) : topPerformers.length > 0 ? (
                    topPerformers.map((performer) => {
                      const initials = `${performer.firstName.charAt(
                        0
                      )}${performer.lastName.charAt(0)}`.toUpperCase();
                      return (
                        <div
                          key={performer.id}
                          className="flex items-center justify-between"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-teal-100 rounded-full flex items-center justify-center">
                              <span className="text-teal-600 font-semibold text-sm">
                                {initials}
                              </span>
                            </div>
                            <span className="font-medium text-gray-900">
                              {performer.firstName} {performer.lastName}
                            </span>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-semibold text-teal-600">
                              {performer.score}%
                            </div>
                            <div className="text-sm text-gray-500">
                              {performer.completionTime}
                              <Trans>min</Trans>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <p>
                        <Trans>No test results available yet</Trans>
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      case "questions": {
        const questions = testData?.questions || [];
        const currentQuestion = questions[currentQuestionIndex];
        const totalQuestions = questions.length;

        const handleEditQuestions = () => {
          if (testId && onEditTest) {
            onClose(); // Close the view modal
            onEditTest(testId); // Open the edit modal
          }
        };

        const handlePreviousQuestion = () => {
          if (currentQuestionIndex > 0) {
            setCurrentQuestionIndex(currentQuestionIndex - 1);
          }
        };

        const handleNextQuestion = () => {
          if (currentQuestionIndex < totalQuestions - 1) {
            setCurrentQuestionIndex(currentQuestionIndex + 1);
          }
        };

        return (
          <div className="flex flex-col h-full">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">
                <Trans>Questions ({totalQuestions})</Trans>
              </h3>
              <button
                onClick={handleEditQuestions}
                className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors"
              >
                <Edit3 className="w-4 h-4" />
                <Trans>Edit Questions</Trans>
              </button>
            </div>

            {/* Question Content */}
            <div className="flex-1 overflow-y-auto p-6">
              {currentQuestion ? (
                <div>
                  {/* Question Header */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                        <span className="text-gray-600 font-medium">
                          {currentQuestionIndex + 1}
                        </span>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold text-gray-900">
                          <Trans>Question {currentQuestionIndex + 1}</Trans>
                        </h4>
                        <p className="text-sm text-gray-500">
                          {currentQuestion.type}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-medium text-[#238D94] bg-blue-100 p-2 rounded-lg">
                        <Trans>{currentQuestion.points} pts</Trans>
                      </span>
                    </div>
                  </div>

                  {/* Question Text */}
                  <div className="mb-4">
                    <p className="text-lg text-gray-900 font-medium">
                      {currentQuestion.question}
                    </p>
                  </div>

                  {/* Answer Options */}
                  <div className="space-y-2">
                    {currentQuestion.options?.map(
                      (option: TestQuestionOption) => (
                        <div
                          key={option.id}
                          className={`flex items-center p-3 rounded-lg border-2 transition-colors ${
                            option.isCorrect
                              ? "bg-teal-50 border-[#238D94] text-gray-900"
                              : "bg-white border-gray-200 text-gray-700"
                          }`}
                        >
                          <div className="flex items-center gap-3 flex-1">
                            <div
                              className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                                option.isCorrect
                                  ? "bg-[#238D94] border-[#238D94]"
                                  : "border-gray-300"
                              }`}
                            >
                              {option.isCorrect && (
                                <Check className="w-4 h-4 text-white" />
                              )}
                            </div>
                            <span className="font-medium">{option.text}</span>
                          </div>
                        </div>
                      )
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-gray-500">
                  <p>
                    <Trans>No questions available</Trans>
                  </p>
                </div>
              )}
            </div>

            {/* Navigation Footer */}
            {totalQuestions > 0 && (
              <div className="flex items-center justify-between p-6 border-t border-gray-200 bg-gray-50">
                <button
                  onClick={handlePreviousQuestion}
                  disabled={currentQuestionIndex === 0}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                    currentQuestionIndex === 0
                      ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                      : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-300"
                  }`}
                >
                  <ChevronLeft className="w-4 h-4" />
                  <Trans>Previous</Trans>
                </button>

                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">
                    <Trans>
                      {currentQuestionIndex + 1} of {totalQuestions}
                    </Trans>
                  </span>
                </div>

                <button
                  onClick={handleNextQuestion}
                  disabled={currentQuestionIndex === totalQuestions - 1}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                    currentQuestionIndex === totalQuestions - 1
                      ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                      : "bg-teal-600 text-white hover:bg-teal-700"
                  }`}
                >
                  <Trans>Next</Trans>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        );
      }
      case "analytics": {
        const analyticsQuestions = testData?.questions || [];

        // Show loading state
        if (loadingAnalytics) {
          return (
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">
                <Trans>Test Analytics</Trans>
              </h3>
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600"></div>
                <span className="ml-3 text-gray-600">
                  <Trans>Loading analytics...</Trans>
                </span>
              </div>
            </div>
          );
        }

        // Show error state if no analytics data
        if (!analyticsData) {
          return (
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">
                <Trans>Test Analytics</Trans>
              </h3>
              <div className="text-center py-12">
                <p className="text-gray-500">
                  <Trans>No Candidat has taken the test yet</Trans>
                </p>
              </div>
            </div>
          );
        }

        return (
          <div className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">
              <Trans>Test Analytics</Trans>
            </h3>

            {/* Top Stats Grid */}
            <div className="grid grid-cols-5 gap-6 mb-8">
              {/* Total Attempts */}
              <div className="bg-white border border-gray-200 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-teal-600 mb-1">
                  {analyticsData.totalAttempts}
                </div>
                <div className="text-sm text-gray-600">
                  <Trans>Total Attempts</Trans>
                </div>
              </div>

              {/* Avg Completion Time */}
              <div className="bg-white border border-gray-200 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-teal-600 mb-1">
                  {analyticsData.avgCompletionTime}
                </div>
                <div className="text-sm text-gray-600">
                  <Trans>Avg. Completion Time</Trans>
                </div>
              </div>

              {/* Completion Rate */}
              <div className="bg-white border border-gray-200 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-teal-600 mb-1">
                  {analyticsData.completionRate}%
                </div>
                <div className="text-sm text-gray-600">
                  <Trans>Completion Rate</Trans>
                </div>
              </div>

              {/* Pass Rate */}
              <div className="bg-white border border-gray-200 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-teal-600 mb-1">
                  {analyticsData.passRate}%
                </div>
                <div className="text-sm text-gray-600">
                  <Trans>Pass Rate</Trans>
                </div>
              </div>

              {/* Average Score */}
              <div className="bg-white border border-gray-200 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-teal-600 mb-1">
                  {analyticsData.averageScore}%
                </div>
                <div className="text-sm text-gray-600">
                  <Trans>Average Score</Trans>
                </div>
              </div>
            </div>

            {/* Question Performance Section */}
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-4">
                <Trans>Question Performance</Trans>
              </h4>

              {/* Scrollable Questions List */}
              <div className="max-h-60 overflow-y-auto space-y-3">
                {analyticsQuestions.map(
                  (question: TestQuestion, index: number) => {
                    // Get performance data from API response or use default
                    const performance = analyticsData.questionPerformance?.[
                      index
                    ] || {
                      correctPercentage: 0,
                      avgTimeSpent: 0,
                    };

                    return (
                      <div
                        key={question.id}
                        className="bg-gray-100  rounded-lg p-4"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h5 className="font-medium text-gray-900 mb-1">
                              <Trans>Question {index + 1}</Trans>
                            </h5>
                            <p className="text-sm text-gray-600 truncate">
                              {question.question}
                            </p>
                          </div>
                          <div className="flex items-center gap-8 ml-4">
                            <div className="text-right">
                              <div className="text-sm font-bold text-teal-600">
                                {performance.correctPercentage}%
                              </div>
                              <div className="text-xs text-gray-500">
                                <Trans>Correct</Trans>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-sm font-bold text-gray-600">
                                {performance.avgTimeSpent}
                                <Trans>s</Trans>
                              </div>
                              <div className="text-xs text-gray-500">
                                <Trans>Avg. Time</Trans>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  }
                )}
              </div>

              {/* Empty State */}
              {analyticsQuestions.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Trans>No questions available for analytics</Trans>
                </div>
              )}
            </div>
          </div>
        );
      }
      case "assignments": {
        return (
          <div className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">
              <Trans>Assign Test to Candidates</Trans>
            </h3>

            {/* Jobs Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Column - Job Applications */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-md font-medium text-gray-900">
                    <Trans>Job Applications</Trans>
                  </h4>
                  <Briefcase className="h-5 w-5 text-gray-400" />
                </div>

                {/* Search Input */}
                <div className="relative mb-4">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder={t`Search jobs...`}
                    value={jobsSearch}
                    onChange={(e) => setJobsSearch(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                  />
                </div>

                {/* Jobs List */}
                <div className="border rounded-lg max-h-80 overflow-y-auto">
                  {loadingJobs ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="h-6 w-6 animate-spin text-teal-600" />
                      <span className="ml-2 text-gray-600">
                        <Trans>Loading jobs...</Trans>
                      </span>
                    </div>
                  ) : jobs.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Trans>No jobs found</Trans>
                    </div>
                  ) : (
                    jobs.map((job) => (
                      <div
                        key={job.id}
                        onClick={() => setSelectedJobId(job.id)}
                        className={`p-4 border-b border-gray-200 cursor-pointer hover:bg-gray-50 ${
                          selectedJobId === job.id
                            ? "bg-teal-50 border-teal-200"
                            : ""
                        }`}
                      >
                        <h5 className="font-medium text-gray-900">
                          {job.title}
                        </h5>
                        <p className="text-sm text-gray-600 truncate">
                          {job.description}
                        </p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-gray-500">
                            {job.location}
                          </span>
                          <span
                            className={`px-2 py-1 text-xs rounded-full ${
                              job.status === "ACTIVE"
                                ? "bg-green-100 text-green-700"
                                : "bg-gray-100 text-gray-700"
                            }`}
                          >
                            {job.status}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Jobs Pagination */}
                {jobs.length > 0 && (
                  <div className="flex items-center justify-between mt-4">
                    <button
                      onClick={() => setJobsPage(Math.max(1, jobsPage - 1))}
                      disabled={jobsPage === 1}
                      className="px-3 py-1 text-sm border rounded disabled:opacity-50"
                    >
                      <Trans>Previous</Trans>
                    </button>
                    <span className="text-sm text-gray-600">
                      <Trans>Page {jobsPage}</Trans>
                    </span>
                    <button
                      onClick={() => setJobsPage(jobsPage + 1)}
                      className="px-3 py-1 text-sm border rounded"
                    >
                      <Trans>Next</Trans>
                    </button>
                  </div>
                )}
              </div>

              {/* Right Column - Candidates */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-md font-medium text-gray-900">
                    <Trans>Candidates</Trans>
                    {selectedJobId && (
                      <span className="text-sm text-gray-500 ml-2">
                        (<Trans>for selected job</Trans>)
                      </span>
                    )}
                  </h4>
                  <Users className="h-5 w-5 text-gray-400" />
                </div>

                {!selectedJobId ? (
                  <div className="border rounded-lg p-8 text-center text-gray-500">
                    <Trans>Select a job to view candidates</Trans>
                  </div>
                ) : (
                  <div className="border rounded-lg max-h-80 overflow-y-auto">
                    {loadingCandidates ? (
                      <div className="flex items-center justify-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin text-teal-600" />
                        <span className="ml-2 text-gray-600">
                          <Trans>Loading candidates...</Trans>
                        </span>
                      </div>
                    ) : candidates.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        <Trans>No candidates found for this job</Trans>
                      </div>
                    ) : (
                      candidates.map((candidate) => {
                        const assignment = getCandidateAssignment(candidate.id);
                        const isAssigned = isCandidateAssigned(candidate.id);

                        return (
                          <div
                            key={candidate.id}
                            className="p-4 border-b border-gray-200 hover:bg-gray-50"
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h5 className="font-medium text-gray-900">
                                  {candidate.name}
                                </h5>
                                <p className="text-sm text-gray-600">
                                  {candidate.email}
                                </p>
                                <div className="flex items-center gap-2 mt-2">
                                  <span
                                    className={`px-2 py-1 text-xs rounded-full ${
                                      candidate.status === "ACCEPTEE"
                                        ? "bg-green-100 text-green-700"
                                        : candidate.status === "REFUSEE"
                                        ? "bg-red-100 text-red-700"
                                        : "bg-yellow-100 text-yellow-700"
                                    }`}
                                  >
                                    {candidate.status}
                                  </span>

                                  {/* Test Assignment Status */}
                                  {isAssigned && assignment && (
                                    <span
                                      className={`px-2 py-1 text-xs rounded-full ${
                                        assignment.status === "COMPLETED"
                                          ? "bg-green-100 text-green-700"
                                          : assignment.status === "IN_PROGRESS"
                                          ? "bg-blue-100 text-blue-700"
                                          : assignment.status === "ASSIGNED"
                                          ? "bg-orange-100 text-orange-700"
                                          : "bg-gray-100 text-gray-700"
                                      }`}
                                    >
                                      {assignment.status === "COMPLETED" ? (
                                        <Trans>Completed</Trans>
                                      ) : assignment.status ===
                                        "IN_PROGRESS" ? (
                                        <Trans>In Progress</Trans>
                                      ) : assignment.status === "ASSIGNED" ? (
                                        <Trans>Assigned</Trans>
                                      ) : (
                                        assignment.status
                                      )}
                                    </span>
                                  )}
                                </div>

                                {/* Test Results */}
                                {isAssigned &&
                                  assignment &&
                                  assignment.status === "COMPLETED" && (
                                    <div className="mt-2 text-xs text-gray-600">
                                      <div className="flex items-center gap-4">
                                        <span className="flex items-center gap-1">
                                          <strong className="text-teal-600">
                                            <Trans>
                                              Score: {assignment.score}%
                                            </Trans>
                                          </strong>
                                        </span>
                                        {assignment.status === "COMPLETED" && (
                                          <span>
                                            <Trans>Status: Completed</Trans>
                                          </span>
                                        )}
                                        {testData?.passingScore && (
                                          <span
                                            className={`font-medium ${
                                              (assignment.score || 0) >=
                                              testData.passingScore
                                                ? "text-green-600"
                                                : "text-red-600"
                                            }`}
                                          >
                                            {(assignment.score || 0) >=
                                            testData.passingScore ? (
                                              <Trans>✓ Passed</Trans>
                                            ) : (
                                              <Trans>✗ Failed</Trans>
                                            )}
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                  )}

                                {/* Assignment Date for non-completed tests */}
                                {isAssigned &&
                                  assignment &&
                                  assignment.status !== "COMPLETED" && (
                                    <div className="mt-2 text-xs text-gray-600">
                                      <span>
                                        <Trans>
                                          Assigned:{" "}
                                          {new Date(
                                            assignment.assignedDate
                                          ).toLocaleDateString()}
                                        </Trans>
                                      </span>
                                      {assignment.dueDate && (
                                        <span className="ml-4">
                                          <Trans>
                                            Due:{" "}
                                            {new Date(
                                              assignment.dueDate
                                            ).toLocaleDateString()}
                                          </Trans>
                                        </span>
                                      )}
                                    </div>
                                  )}
                              </div>

                              <button
                                onClick={() =>
                                  isAssigned
                                    ? handleUnassignTest(candidate.id)
                                    : handleAssignTest(candidate.id)
                                }
                                disabled={assigning}
                                className={`px-3 py-1 text-white text-sm rounded disabled:opacity-50 flex items-center gap-1 ml-4 ${
                                  isAssigned
                                    ? "bg-red-600 hover:bg-red-700"
                                    : "bg-teal-600 hover:bg-teal-700"
                                }`}
                              >
                                {assigning ? (
                                  <>
                                    <Loader2 className="h-3 w-3 animate-spin" />
                                    {isAssigned ? (
                                      <Trans>Unassigning...</Trans>
                                    ) : (
                                      <Trans>Assigning...</Trans>
                                    )}
                                  </>
                                ) : (
                                  <>
                                    {isAssigned ? (
                                      <>
                                        <UserMinus className="h-3 w-3" />
                                        <Trans>Unassign</Trans>
                                      </>
                                    ) : (
                                      <>
                                        <UserPlus className="h-3 w-3" />
                                        <Trans>Assign Test</Trans>
                                      </>
                                    )}
                                  </>
                                )}
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                )}

                {/* Candidates Pagination */}
                {candidates.length > 0 && (
                  <div className="flex items-center justify-between mt-4">
                    <button
                      onClick={() =>
                        setCandidatesPage(Math.max(1, candidatesPage - 1))
                      }
                      disabled={candidatesPage === 1}
                      className="px-3 py-1 text-sm border rounded disabled:opacity-50"
                    >
                      <Trans>Previous</Trans>
                    </button>
                    <span className="text-sm text-gray-600">
                      <Trans>Page {candidatesPage}</Trans>
                    </span>
                    <button
                      onClick={() => setCandidatesPage(candidatesPage + 1)}
                      className="px-3 py-1 text-sm border rounded"
                    >
                      <Trans>Next</Trans>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      }
      default:
        return null;
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 overflow-hidden"
      onClick={handleOverlayClick}
    >
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl max-h-[95vh] overflow-hidden mx-4">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              <Trans>View Test</Trans>
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              {testData?.title || <Trans>Test Details</Trans>}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6" aria-label="Tabs">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`${
                    tab.current
                      ? "border-[#238D94] text-[#238D94]"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2 transition-colors`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.name}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Tab Content */}
        <div
          className={`h-[500px] ${
            activeTab === "questions"
              ? "flex flex-col"
              : activeTab === "analytics"
              ? ""
              : "overflow-y-auto"
          }`}
        >
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default ViewTestModal;
