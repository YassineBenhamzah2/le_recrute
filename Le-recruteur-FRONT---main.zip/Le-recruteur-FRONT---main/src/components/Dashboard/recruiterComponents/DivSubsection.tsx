import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { TrashIcon } from "lucide-react";
import { useState } from "react";
import { Trans , t } from "@lingui/macro"; // Ajout de l'import Trans

interface DivSubsectionProps {
    formData: {
        questions: string[];
    };
    addQuestion: (question: string) => void;
    removeQuestion: (index: number) => void;
}

export const DivSubsection = ({
    formData,
    addQuestion,
    removeQuestion
}: DivSubsectionProps): JSX.Element => {
    const [newQuestion, setNewQuestion] = useState("");
    const questions = formData.questions.filter((q) => q.trim() !== "");
    const handleAdd = () => {
        if (newQuestion.trim()) {
            addQuestion(newQuestion.trim());
            setNewQuestion("");
        }
    };

    return (
        <Card className="flex flex-col w-full items-start gap-[15.4px] p-6 rounded-xl">
            <div className="flex items-center gap-2 mb-4 w-full">
                <div className="relative w-5 h-5">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <path d="M10 17.5C14.1421 17.5 17.5 14.1421 17.5 10C17.5 5.85786 14.1421 2.5 10 2.5C5.85786 2.5 2.5 5.85786 2.5 10C2.5 14.1421 5.85786 17.5 10 17.5Z" stroke="#111827" strokeWidth="2" />
                        <path d="M10 10.8333V7.5" stroke="#111827" strokeWidth="2" />
                        <path d="M10 13.3333H10.0083" stroke="#111827" strokeWidth="2" />
                    </svg>
                </div>
                <h2 className="font-bold text-xl text-gray-900">
                    <Trans>Questions for The Candidates</Trans>
                </h2>
            </div>

            <CardContent className="p-0 w-full">
                <div className="flex flex-col items-start gap-4 w-full">

                    {/* Input + Confirm button */}
                    <div className="flex items-center gap-2 w-full">
                        <Input
                            value={newQuestion}
                            onChange={(e) => setNewQuestion(e.target.value)}
                            placeholder={t`Enter question for candidates`}
                            className="flex-1 h-[50px]"
                        />
                        <Button
                            type="button"
                            onClick={handleAdd}
                            className="bg-[#238d94] hover:bg-[#1c7a80] text-white h-[50px]"
                        >
                            <Trans>Confirm</Trans>
                        </Button>
                    </div>

                    {/* Confirmed questions list */}
                    {questions.map((question, index) => (
                        <div key={index} className="flex justify-between items-center w-full bg-gray-100 px-4 py-2 rounded-lg">
                            <span className="text-sm text-gray-800">{question}</span>
                            <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                onClick={() => removeQuestion(index)}
                                className="text-red-500 hover:bg-red-100"
                                aria-label={t`Delete question`}
                            >
                                <TrashIcon className="w-4 h-4" />
                            </Button>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
};