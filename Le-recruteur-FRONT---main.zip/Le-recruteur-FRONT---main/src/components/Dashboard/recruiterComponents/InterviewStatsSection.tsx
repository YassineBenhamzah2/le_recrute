import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CalendarIcon, PlusIcon } from "lucide-react";
import { useState } from "react";
import { EditInterview } from "./EditInterview";
import { Trans } from "@lingui/macro";

export const InterviewStatsSection = ({
  onInterviewCreated,
}: {
  onInterviewCreated?: () => void;
}): JSX.Element => {
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const handleInterviewSaved = () => {
    setIsCreateOpen(false);
    if (onInterviewCreated) {
      onInterviewCreated();
    }
  };
  return (
    <Card className="flex flex-col p-8 w-full rounded-xl overflow-hidden shadow-[0px_4px_6px_-4px_#0000001a,0px_10px_15px_-3px_#0000001a] bg-[linear-gradient(90deg,rgba(35,141,148,1)_0%,rgba(13,148,136,1)_100%)]">
      <div className="flex items-center justify-between w-full">
        <div className="flex items-center">
          <CalendarIcon className="w-16 h-16 text-white/80" />

          <div className="pl-4">
            <div className="flex flex-col gap-2">
              <div>
                <h2 className="font-bold text-white text-3xl leading-9">
                  <Trans>Interview Dashboard</Trans>
                </h2>
              </div>

              <div>
                <p className="font-normal text-purple-100 text-base leading-6">
                   <Trans>Schedule and manage candidate interviews</Trans>
                </p>
              </div>
            </div>
          </div>
        </div>

        <Button
          variant="ghost"
          className="px-6 py-3 bg-white/10 backdrop-blur-[2px] hover:bg-white/20 hover:text-white/80 text-white"
          onClick={() => setIsCreateOpen(true)}
        >
          <PlusIcon className="w-5 h-5 mr-2" />
          <span className="font-semibold"><Trans>Schedule Interview</Trans></span>
        </Button>
      </div>
      {isCreateOpen && (
        <EditInterview
          onClose={() => setIsCreateOpen(false)}
          onRefresh={handleInterviewSaved}
        />
      )}
    </Card>
  );
};
