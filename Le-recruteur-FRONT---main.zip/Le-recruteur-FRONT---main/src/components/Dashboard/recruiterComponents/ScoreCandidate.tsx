import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { InfoIcon } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Trans } from "@lingui/macro";

export type CandidateInfo = {
  id: number;
  name: string;
  position: string;
  interviewDate: string;
  interviewers: string[];
  lastUpdatedBy: string;
  lastUpdatedDate: string;
  jobOfferId?: number; // Added jobOfferId field
};

type ScoringData = {
  diplomaMatch: string;
  experienceMatch: string;
  profileScore: string;
  technicalSkills: string;
  softSkills: string;
  overAllScore: string; // Read-only overall score from API
};

type ScoreCandidateFzProps = {
  isOpen: boolean;
  onClose: () => void;
  candidateInfo: CandidateInfo;
  scoringData: ScoringData;
  handleSubmit?: (data: FormData) => void;
};

export const ScoreCandidate = ({
  isOpen,
  onClose,
  candidateInfo,
  scoringData,
  handleSubmit,
}: ScoreCandidateFzProps): JSX.Element => {
  const [scores, setScores] = useState<ScoringData>({
    diplomaMatch: scoringData.diplomaMatch,
    experienceMatch: scoringData.experienceMatch,
    profileScore: scoringData.profileScore,
    technicalSkills: scoringData.technicalSkills,
    softSkills: scoringData.softSkills,
    overAllScore: scoringData.overAllScore, // Include overall score
  });

  useEffect(() => {
    // Reset scores when the modal is opened with new scoring data
    setScores(scoringData);
  }, [scoringData]);

  const handleScoreChange = (key: keyof ScoringData, value: string) => {
    // Don't allow changes to overAllScore as it's read-only
    if (key === "overAllScore") return;

    setScores((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleSaveChanges = () => {
    // Validate that all editable scores are filled (excluding overAllScore which is read-only)
    const editableScores = {
      diplomaMatch: scores.diplomaMatch,
      experienceMatch: scores.experienceMatch,
      profileScore: scores.profileScore,
      technicalSkills: scores.technicalSkills,
      softSkills: scores.softSkills,
    };
    const hasEmptyScores = Object.values(editableScores).some(
      (score) => score === ""
    );
    if (hasEmptyScores) {
      toast.error(<Trans>Please fill in all scoring fields</Trans>);
      return;
    }

    const formData = new FormData();
    // Only include editable scores in form data (overAllScore is calculated by backend)
    Object.entries(editableScores).forEach(([key, value]) => {
      formData.append(key, value);
    });

    // Add candidate info to form data
    formData.append("candidateId", candidateInfo.id.toString());
    formData.append("candidateName", candidateInfo.name);
    formData.append("position", candidateInfo.position);
    formData.append("interviewDate", candidateInfo.interviewDate);
    formData.append("interviewers", JSON.stringify(candidateInfo.interviewers));

    handleSubmit?.(formData);
    onClose();
    toast.success(<Trans>Candidate scoring saved successfully</Trans>);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[1060px] max-h-[90vh] overflow-y-auto p-6 rounded-[15px]">
        <DialogHeader>
          <DialogTitle className="text-2xl text-center font-bold text-gray-900 mb-6">
            <Trans>Score Candidate</Trans>
          </DialogTitle>
        </DialogHeader>

        <Card className="w-full rounded-[15px] border-2 bg-white">
          <CardContent className="p-6 flex  gap-6">
            {/* Candidate Info Section */}
            <div className="flex flex-col space-y-6 border-r border-gray-300 pr-6">
              <div>
                <div className="text-lg font-bold text-ehc-green mb-5">
                  <Trans>Candidate Overview</Trans>
                </div>
                <div className="grid grid-rows-4 grid-cols-1 gap-4 text-sm text-gray-700">
                  <div>
                    <strong><Trans>Name:</Trans></strong> {candidateInfo.name}
                  </div>
                  <div>
                    <strong><Trans>Position:</Trans></strong> {candidateInfo.position}
                  </div>
                  <div>
                    <strong><Trans>Interview:</Trans></strong> {candidateInfo.interviewDate}
                  </div>
                  <div>
                    <strong><Trans>Interviewers:</Trans></strong>{" "}
                    {candidateInfo.interviewers.join(", ")}
                  </div>
                </div>
              </div>
              <Separator />
              <div>
                <div className="text-lg font-bold text-ehc-green mb-5">
                  <Trans>Scoring Scale</Trans>
                </div>
                <ul className="list-disc pl-5">
                  <li><Trans>0 - Not Applicable</Trans></li>
                  <li><Trans>1 - Weak</Trans></li>
                  <li><Trans>2 - Average</Trans></li>
                  <li><Trans>3 - Good</Trans></li>
                  <li><Trans>4 - Very Good</Trans></li>
                  <li><Trans>5 - Exceptional</Trans></li>
                </ul>
              </div>
            </div>

            <div className="flex-1">
              <div className="text-lg font-bold text-ehc-green mb-5">
                <Trans>Scoring Form</Trans>
              </div>
              {/* Evaluation Section */}
              <div className="grid grid-cols-1 grid-rows-5 gap-8 ">
                {[
                  {
                    label: <Trans>Diploma Match</Trans>,
                    key: "diplomaMatch",
                    info: <Trans>Score based on diploma relevance to the position.</Trans>,
                  },
                  {
                    label: <Trans>Experience Match</Trans>,
                    key: "experienceMatch",
                    info: <Trans>Based on years of relevant work experience.</Trans>,
                  },
                  {
                    label: <Trans>Profile Fit</Trans>,
                    key: "profileScore",
                    info: <Trans>General impression, motivation, interest, presentation, etc.</Trans>,
                  },
                  {
                    label: <Trans>Technical Skills</Trans>,
                    key: "technicalSkills",
                    info: <Trans>Technical level observed during interview.</Trans>,
                  },
                  {
                    label: <Trans>Soft Skills</Trans>,
                    key: "softSkills",
                    info: <Trans>Communication, collaboration, adaptability, etc.</Trans>,
                  },
                ].map(({ label, key, info }) => (
                  <div
                    key={key}
                    className="flex gap-6 w-full items-start justify-center "
                  >
                    <div className="flex flex-col items-start justify-start min-w-48">
                      <div className="flex items-center gap-2 text-md font-medium">
                        {label}
                        <HoverCard>
                          <HoverCardTrigger>
                            <InfoIcon className="w-4 h-4 text-gray-500" />
                          </HoverCardTrigger>
                          <HoverCardContent className="text-xs">
                            {info}
                          </HoverCardContent>
                        </HoverCard>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        <Trans>Previous:</Trans> {scoringData[key as keyof ScoringData]}
                      </div>
                    </div>
                    <Select
                      defaultValue={
                        (+scores[key as keyof ScoringData])?.toString() || "0"
                      }
                      onValueChange={(value) =>
                        handleScoreChange(key as keyof ScoringData, value)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={<Trans>Select a score</Trans>} />
                      </SelectTrigger>
                      <SelectContent>
                        {[0, 1, 2, 3, 4, 5].map((score) => (
                          <SelectItem key={score} value={score.toString()}>
                            {score} -{" "}
                            {score === 0
                              ? <Trans>Not Applicable</Trans>
                              : score === 1
                              ? <Trans>Weak</Trans>
                              : score === 2
                              ? <Trans>Average</Trans>
                              : score === 3
                              ? <Trans>Good</Trans>
                              : score === 4
                              ? <Trans>Very Good</Trans>
                              : <Trans>Exceptional</Trans>}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>

              {/* Overall Score Display - Read Only */}
              <div className="mt-8 p-4 bg-gray-50 rounded-lg border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="text-lg font-semibold text-ehc-green">
                      <Trans>Overall Score</Trans>
                    </div>
                    <HoverCard>
                      <HoverCardTrigger>
                        <InfoIcon className="w-4 h-4 text-gray-500" />
                      </HoverCardTrigger>
                      <HoverCardContent className="text-xs">
                        <Trans>Calculated automatically based on individual scores. This field is read-only.</Trans>
                      </HoverCardContent>
                    </HoverCard>
                  </div>
                  <div className="text-2xl font-bold text-ehc-green">
                    {parseFloat(scores.overAllScore).toFixed(1)}/5.0
                  </div>
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  <Trans>This score is calculated automatically by the system and cannot be modified.</Trans>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4 mt-6">
          <Button
            variant="outline"
            className="w-[278px] h-[46px] rounded-lg border border-solid text-[#238d94] hover:bg-[#238d94]/5"
            onClick={onClose}
          >
            <Trans>Cancel</Trans>
          </Button>
          <Button
            className="w-[278px] h-[46px] bg-[#238d94] text-white rounded-lg hover:bg-[#238d94]/90"
            onClick={handleSaveChanges}
          >
            <Trans>Save Changes</Trans>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};