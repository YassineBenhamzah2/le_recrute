/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  User,
  Mail,
  Phone,
  FileText,
  MapPin,
  Clock,
  Calendar,
  Briefcase,
  GraduationCap,
  Star,
  Download,
  Flag,
  Users,
  Home,
  Globe,
  Linkedin,
  Check as CheckIcon,
  X as XIcon,
} from "lucide-react";
import { Candidate } from "../RecruiterJobDetailsDashboard";
import { downloadBlob, sanitizeFilename } from "@/lib/utils/fileDownload";
import { toast } from "sonner";
import { candidatService } from "@/lib/network/candidat";
import {
  EducationResponse,
  ExperienceResponse,
  CertificationResponse,
  LanguageResponse,
  SkillResponse,
  QuestionAnswerResponse,
} from "@/lib/types/candidate";
import { Trans } from "@lingui/macro";


interface CandidateDetailsProps {
  isOpen: boolean;
  onClose: () => void;
  candidate: Candidate | null;
  onStatusChange: (
    candidateId: number,
    status: "approved" | "rejected"
  ) => void;
  jobOfferId?: number;
}

export const CandidateDetailsModal = ({
  isOpen,
  onClose,
  candidate,
  onStatusChange,
  jobOfferId,
}: CandidateDetailsProps) => {
  // Track active tab for future use
  const setActiveTab = (tab: string) => {
    // For future use if needed
    console.log(`Tab changed to: ${tab}`);
  };
  const [downloadingFiles, setDownloadingFiles] = useState<{
    [key: string]: boolean;
  }>({});

  if (!candidate) return null;

  const formatDate = (dateString?: string) => {
    if (!dateString) return <Trans>N/A</Trans>;
    return new Date(dateString).toLocaleDateString("fr-FR");
  };

  const handleDownloadCV = async () => {
    if (!candidate || !jobOfferId) return;

    const downloadKey = `cv-${candidate.id}`;
    try {
      setDownloadingFiles((prev) => ({ ...prev, [downloadKey]: true }));
      const blob = await candidatService.downloadCV(candidate.id, jobOfferId);
      const filename = sanitizeFilename(`${candidate.name}_CV.pdf`);
      downloadBlob(blob, filename);
      toast.success(<Trans>CV downloaded successfully</Trans>);
    } catch (error) {
      console.error("Error downloading CV:", error);
      toast.error(<Trans>Failed to download CV</Trans>);
    } finally {
      setDownloadingFiles((prev) => ({ ...prev, [downloadKey]: false }));
    }
  };

  const handleDownloadMotivationLetter = async () => {
    if (!candidate || !jobOfferId) return;

    const downloadKey = `letter-${candidate.id}`;
    try {
      setDownloadingFiles((prev) => ({ ...prev, [downloadKey]: true }));
      const blob = await candidatService.downloadMotivationLetter(
        candidate.id,
        jobOfferId
      );
      const filename = sanitizeFilename(
        `${candidate.name}_Motivation_Letter.pdf`
      );
      downloadBlob(blob, filename);
      toast.success(<Trans>Motivation letter downloaded successfully</Trans>);
    } catch (error) {
      console.error("Error downloading motivation letter:", error);
      toast.error(<Trans>Failed to download motivation letter</Trans>);
    } finally {
      setDownloadingFiles((prev) => ({ ...prev, [downloadKey]: false }));
    }
  };

  // Helper to get proficiency label with proper formatting
  const getProficiencyLabel = (level: string) => {
    switch (level?.toUpperCase()) {
      case "BEGINNER":
        return <Trans>Beginner</Trans>;
      case "INTERMEDIATE":
        return <Trans>Intermediate</Trans>;
      case "ADVANCED":
        return <Trans>Advanced</Trans>;
      case "NATIVE":
        return <Trans>Native</Trans>;
      default:
        return level || <Trans>Not specified</Trans>;
    }
  };

  // Helper to get skill level badge color
  const getSkillLevelColor = (level?: string) => {
    switch (level?.toLowerCase()) {
      case "beginner":
        return "bg-blue-50 text-blue-700";
      case "intermediate":
        return "bg-green-50 text-green-700";
      case "advanced":
        return "bg-purple-50 text-purple-700";
      case "expert":
        return "bg-red-50 text-red-700";
      default:
        return "bg-gray-50 text-gray-700";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto p-6">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-900 mb-2 flex items-center">
            <User className="mr-2 h-6 w-6 text-[#238d94]" />
            {candidate.name}
          </DialogTitle>
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <span><Trans>Applied on</Trans> {candidate.appliedDate}</span>
            <span>•</span>
            <Badge
              className={`${
                candidate.status === "approved"
                  ? "bg-green-100 text-green-800"
                  : candidate.status === "rejected"
                  ? "bg-red-100 text-red-800"
                  : "bg-gray-100 text-gray-800"
              }`}
            >
              {candidate.status === "approved" && <Trans>Approved</Trans>}
              {candidate.status === "rejected" && <Trans>Rejected</Trans>}
              {candidate.status === "pending" && <Trans>Pending</Trans>}
            </Badge>
            {candidate.score !== undefined && (
              <>
                <span>•</span>
                <Badge className="bg-blue-100 text-blue-800 flex items-center">
                  <Star className="w-3 h-3 mr-1" fill="currentColor" />
                  <Trans>Score</Trans>: {candidate.score}/5
                </Badge>
              </>
            )}
          </div>
        </DialogHeader>

        <div className="mt-4">
          <Tabs
            defaultValue="profile"
            className="w-full"
            onValueChange={setActiveTab}
          >
            <TabsList className="mb-4">
              <TabsTrigger value="profile"><Trans>Profile</Trans></TabsTrigger>
              <TabsTrigger value="experience"><Trans>Experience</Trans></TabsTrigger>
              <TabsTrigger value="education"><Trans>Education</Trans></TabsTrigger>
              {candidate.answers && candidate.answers.length > 0 && (
                <TabsTrigger value="questions"><Trans>Questions</Trans></TabsTrigger>
              )}
              <TabsTrigger value="documents"><Trans>Documents</Trans></TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="focus:outline-none">
              <Card>
                <CardContent className="p-4 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">
                      <Trans>Personal Information</Trans>
                    </h3>

                    <div className="space-y-2">
                      <div className="flex items-center">
                        <Mail className="w-4 h-4 mr-2 text-gray-400" />
                        <span className="text-sm text-gray-700">
                          {candidate.email}
                        </span>
                      </div>
                      {candidate.whatsapp_number && (
                        <div className="flex items-center">
                          <Phone className="w-4 h-4 mr-2 text-gray-400" />
                          <span className="text-sm text-gray-700">
                            {candidate.whatsapp_number}
                          </span>
                        </div>
                      )}
                      {candidate.nationality && (
                        <div className="flex items-center">
                          <Flag className="w-4 h-4 mr-2 text-gray-400" />
                          <span className="text-sm text-gray-700">
                            <Trans>Nationality</Trans>: {candidate.nationality}
                          </span>
                        </div>
                      )}
                      {candidate.familyStatus && (
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-2 text-gray-400" />
                          <span className="text-sm text-gray-700">
                            <Trans>Family Status</Trans>: {candidate.familyStatus}
                            {candidate.childrenNumber !== undefined &&
                              ` (${candidate.childrenNumber} <Trans>children</Trans>)`}
                          </span>
                        </div>
                      )}
                    </div>

                    <h3 className="font-semibold text-lg pt-2"><Trans>Location</Trans></h3>
                    <div className="space-y-2">
                      {candidate.address && (
                        <div className="flex items-center">
                          <Home className="w-4 h-4 mr-2 text-gray-400" />
                          <span className="text-sm text-gray-700">
                            {candidate.address}
                          </span>
                        </div>
                      )}
                      {(candidate.city ||
                        candidate.region ||
                        candidate.country) && (
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                          <span className="text-sm text-gray-700">
                            {[
                              candidate.city,
                              candidate.region,
                              candidate.country,
                            ]
                              .filter(Boolean)
                              .join(", ")}
                          </span>
                        </div>
                      )}
                    </div>

                    {candidate.linkedIn && (
                      <>
                        <h3 className="font-semibold text-lg pt-2"><Trans>Social</Trans></h3>
                        <div className="flex items-center">
                          <Linkedin className="w-4 h-4 mr-2 text-gray-400" />
                          <a
                            href={candidate.linkedIn}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue-600 hover:underline"
                          >
                            <Trans>LinkedIn Profile</Trans>
                          </a>
                        </div>
                      </>
                    )}
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">
                      <Trans>Professional Details</Trans>
                    </h3>

                    {candidate.experienceLevel && (
                      <div className="flex items-center">
                        <Briefcase className="w-4 h-4 mr-2 text-gray-400" />
                        <span className="text-sm text-gray-700">
                          <Trans>Experience Level</Trans>: {candidate.experienceLevel}
                        </span>
                      </div>
                    )}

                    {candidate.availability && (
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2 text-gray-400" />
                        <span className="text-sm text-gray-700">
                          <Trans>Availability</Trans>: {candidate.availability}
                        </span>
                      </div>
                    )}

                    {candidate.mobility && (
                      <div className="flex items-center">
                        <Globe className="w-4 h-4 mr-2 text-gray-400" />
                        <span className="text-sm text-gray-700">
                          <Trans>Mobility</Trans>: {candidate.mobility}
                        </span>
                      </div>
                    )}

                    {candidate.skills && candidate.skills.length > 0 && (
                      <div className="mt-4">
                        <h3 className="font-semibold text-lg mb-2"><Trans>Skills</Trans></h3>
                        <div className="flex flex-wrap gap-2">
                          {candidate.skills.map((skill: SkillResponse, idx) => (
                            <Badge
                              key={idx}
                              className={
                                skill.level
                                  ? getSkillLevelColor(skill.level)
                                  : "bg-blue-50 text-blue-700"
                              }
                            >
                              {skill.name}
                              {skill.level && ` - ${skill.level}`}
                              {skill.years !== undefined &&
                                ` (${skill.years} <Trans>yrs</Trans>)`}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {candidate.languages && candidate.languages.length > 0 && (
                      <div className="mt-4">
                        <h3 className="font-semibold text-lg mb-2">
                          <Trans>Languages</Trans>
                        </h3>
                        <div className="flex flex-wrap gap-2">
                          {candidate.languages.map(
                            (language: LanguageResponse, idx) => (
                              <Badge
                                key={idx}
                                className="bg-purple-50 text-purple-700"
                              >
                                {(language as any).name ||
                                  (language as any).language}
                                :{" "}
                                {getProficiencyLabel(
                                  (language as any).proficiency ||
                                    (language as any).proficiencyLevel
                                )}
                              </Badge>
                            )
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {candidate.bio && (
                    <div className="col-span-1 md:col-span-2">
                      <h3 className="font-semibold text-lg mb-2"><Trans>About</Trans></h3>
                      <p className="text-sm text-gray-700 whitespace-pre-line">
                        {candidate.bio}
                      </p>
                    </div>
                  )}

                  {candidate.overview &&
                    candidate.bio !== candidate.overview && (
                      <div className="col-span-1 md:col-span-2">
                        <h3 className="font-semibold text-lg mb-2">
                          <Trans>Professional Overview</Trans>
                        </h3>
                        <p className="text-sm text-gray-700 whitespace-pre-line">
                          {candidate.overview}
                        </p>
                      </div>
                    )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Experience Tab */}
            <TabsContent value="experience" className="focus:outline-none">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-4">
                    <Trans>Work Experience</Trans>
                  </h3>

                  {candidate.experiences && candidate.experiences.length > 0 ? (
                    <div className="space-y-6">
                      {candidate.experiences.map(
                        (exp: ExperienceResponse, idx) => (
                          <div
                            key={idx}
                            className="border-b pb-4 last:border-0 last:pb-0"
                          >
                            <div className="flex flex-col sm:flex-row sm:justify-between mb-2">
                              <div>
                                <h4 className="font-medium text-base">
                                  {(exp as any).position || <Trans>Unknown</Trans>}
                                </h4>
                                <p className="text-sm text-gray-600">
                                  {exp.company}
                                </p>
                              </div>
                              <div className="text-sm text-gray-500 mt-1 sm:mt-0 sm:text-right">
                                <div className="flex items-center sm:justify-end">
                                  <Calendar className="w-3 h-3 mr-1" />
                                  {formatDate(exp.startDate)} -{" "}
                                  {(exp as any).current ||
                                  (exp as any).isCurrentPosition
                                    ? <Trans>Present</Trans>
                                    : formatDate(exp.endDate)}
                                </div>
                                {exp.location && (
                                  <div className="flex items-center sm:justify-end mt-1">
                                    <MapPin className="w-3 h-3 mr-1" />
                                    {exp.location}
                                  </div>
                                )}
                              </div>
                            </div>
                            {exp.description && (
                              <p className="text-sm text-gray-700 mt-2 whitespace-pre-line">
                                {exp.description}
                              </p>
                            )}
                          </div>
                        )
                      )}
                    </div>
                  ) : (
                    <p className="text-gray-500 italic">
                      <Trans>No work experience provided</Trans>
                    </p>
                  )}

                  {candidate.certifications &&
                    candidate.certifications.length > 0 && (
                      <>
                        <Separator className="my-6" />

                        <h3 className="font-semibold text-lg mb-4">
                          <Trans>Certifications</Trans>
                        </h3>
                        <div className="space-y-4">
                          {candidate.certifications.map(
                            (cert: CertificationResponse, idx) => (
                              <div
                                key={idx}
                                className="border-b pb-4 last:border-0 last:pb-0"
                              >
                                <div className="flex flex-col sm:flex-row sm:justify-between">
                                  <div>
                                    <h4 className="font-medium">{cert.name}</h4>
                                    <p className="text-sm text-gray-600">
                                      {(cert as any).issuingOrganization ||
                                        <Trans>Unknown</Trans>}
                                    </p>
                                  </div>
                                  {(cert.issueDate || cert.expirationDate) && (
                                    <div className="text-sm text-gray-500 mt-1 sm:mt-0 sm:text-right">
                                      <div className="flex items-center sm:justify-end">
                                        <Calendar className="w-3 h-3 mr-1" />
                                        {cert.issueDate &&
                                          `<Trans>Issued</Trans>: ${formatDate(
                                            cert.issueDate
                                          )}`}
                                        {cert.expirationDate &&
                                          cert.issueDate &&
                                          " • "}
                                        {cert.expirationDate &&
                                          `<Trans>Expires</Trans>: ${formatDate(
                                            cert.expirationDate
                                          )}`}
                                      </div>
                                    </div>
                                  )}
                                </div>
                                {(cert.credentialId || cert.credentialUrl) && (
                                  <div className="mt-2 text-sm">
                                    {cert.credentialId && (
                                      <p><Trans>Credential ID</Trans>: {cert.credentialId}</p>
                                    )}
                                    {cert.credentialUrl && (
                                      <a
                                        href={cert.credentialUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-blue-600 hover:underline flex items-center mt-1"
                                      >
                                        <Trans>View Credential</Trans>
                                        <svg
                                          className="w-3 h-3 ml-1"
                                          fill="none"
                                          stroke="currentColor"
                                          viewBox="0 0 24 24"
                                        >
                                          <path
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                            strokeWidth={2}
                                            d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                                          />
                                        </svg>
                                      </a>
                                    )}
                                  </div>
                                )}
                              </div>
                            )
                          )}
                        </div>
                      </>
                    )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Education Tab */}
            <TabsContent value="education" className="focus:outline-none">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-4"><Trans>Education</Trans></h3>

                  {candidate.education && candidate.education.length > 0 ? (
                    <div className="space-y-6">
                      {candidate.education.map(
                        (edu: EducationResponse, idx) => (
                          <div
                            key={idx}
                            className="border-b pb-4 last:border-0 last:pb-0"
                          >
                            <div className="flex flex-col sm:flex-row sm:justify-between mb-2">
                              <div>
                                <h4 className="font-medium text-base">
                                  {edu.degree}
                                </h4>
                                <p className="text-sm text-gray-600">
                                  {(edu as any).institution ||
                                    (edu as any).schoolName}
                                </p>
                                {edu.fieldOfStudy && (
                                  <p className="text-sm text-gray-600 mt-1">
                                    {edu.fieldOfStudy}
                                  </p>
                                )}
                              </div>
                              <div className="text-sm text-gray-500 mt-1 sm:mt-0 sm:text-right">
                                <div className="flex items-center sm:justify-end">
                                  <GraduationCap className="w-3 h-3 mr-1" />
                                  {formatDate(edu.startDate)} -{" "}
                                  {edu.isCurrentlyStudying
                                    ? <Trans>Present</Trans>
                                    : formatDate(edu.endDate)}
                                </div>
                                {(edu as any).location && (
                                  <div className="flex items-center sm:justify-end mt-1">
                                    <MapPin className="w-3 h-3 mr-1" />
                                    {(edu as any).location}
                                  </div>
                                )}
                              </div>
                            </div>
                            {edu.description && (
                              <p className="text-sm text-gray-700 mt-2 whitespace-pre-line">
                                {edu.description}
                              </p>
                            )}
                          </div>
                        )
                      )}
                    </div>
                  ) : (
                    <p className="text-gray-500 italic">
                      <Trans>No education details provided</Trans>
                    </p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Questions Tab */}
            {candidate.answers && candidate.answers.length > 0 && (
              <TabsContent value="questions" className="focus:outline-none">
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg mb-4">
                      <Trans>Job Application Answers</Trans>
                    </h3>

                    <div className="space-y-4">
                      {candidate.answers.map(
                        (qa: QuestionAnswerResponse, idx) => (
                          <div
                            key={idx}
                            className="border-b pb-4 last:border-0 last:pb-0"
                          >
                            <h4 className="font-medium text-base text-[#238d94] bg-[#f0f7f8] p-3 rounded-t-md border-l-4 border-[#238d94]">
                              {qa.question}
                            </h4>
                            <div className="p-3 bg-white rounded-b-md border border-t-0 border-gray-200 shadow-sm">
                              <p className="text-sm whitespace-pre-line text-gray-700">
                                {qa.answer}
                              </p>
                            </div>
                          </div>
                        )
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            )}

            {/* Documents Tab */}
            <TabsContent value="documents" className="focus:outline-none">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-4"><Trans>Documents</Trans></h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {candidate.documents.cv ? (
                      <div className="border rounded-lg p-4 flex items-center justify-between">
                        <div className="flex items-center">
                          <FileText className="w-8 h-8 text-blue-500 mr-3" />
                          <div>
                            <h4 className="font-medium"><Trans>Curriculum Vitae</Trans></h4>
                            <p className="text-xs text-gray-500">
                              <Trans>PDF Document</Trans>
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                          onClick={handleDownloadCV}
                          disabled={downloadingFiles[`cv-${candidate.id}`]}
                        >
                          {downloadingFiles[`cv-${candidate.id}`] ? (
                            <div className="w-4 h-4 animate-spin rounded-full border-2 border-blue-600 border-t-transparent" />
                          ) : (
                            <Download className="w-4 h-4" />
                          )}
                          <span className="ml-1"><Trans>Download</Trans></span>
                        </Button>
                      </div>
                    ) : (
                      <div className="border rounded-lg p-4 bg-gray-50">
                        <div className="flex items-center text-gray-400">
                          <FileText className="w-8 h-8 mr-3 opacity-50" />
                          <div>
                            <h4 className="font-medium"><Trans>CV not available</Trans></h4>
                            <p className="text-xs"><Trans>No CV has been submitted</Trans></p>
                          </div>
                        </div>
                      </div>
                    )}

                    {candidate.documents.letter ? (
                      <div className="border rounded-lg p-4 flex items-center justify-between">
                        <div className="flex items-center">
                          <FileText className="w-8 h-8 text-green-500 mr-3" />
                          <div>
                            <h4 className="font-medium"><Trans>Motivation Letter</Trans></h4>
                            <p className="text-xs text-gray-500">
                              <Trans>PDF Document</Trans>
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-green-600 hover:text-green-800 hover:bg-green-50"
                          onClick={handleDownloadMotivationLetter}
                          disabled={downloadingFiles[`letter-${candidate.id}`]}
                        >
                          {downloadingFiles[`letter-${candidate.id}`] ? (
                            <div className="w-4 h-4 animate-spin rounded-full border-2 border-green-600 border-t-transparent" />
                          ) : (
                            <Download className="w-4 h-4" />
                          )}
                          <span className="ml-1"><Trans>Download</Trans></span>
                        </Button>
                      </div>
                    ) : (
                      <div className="border rounded-lg p-4 bg-gray-50">
                        <div className="flex items-center text-gray-400">
                          <FileText className="w-8 h-8 mr-3 opacity-50" />
                          <div>
                            <h4 className="font-medium">
                              <Trans>Motivation Letter not available</Trans>
                            </h4>
                            <p className="text-xs">
                              <Trans>No motivation letter has been submitted</Trans>
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="mt-6 flex justify-between">
          <div>
            <Button variant="outline" onClick={onClose} className="mr-2">
              <Trans>Close</Trans>
            </Button>
          </div>

          <div className="space-x-2">
            <Button
              variant="outline"
              className={`border ${
                candidate.status === "rejected"
                  ? "border-red-500 bg-red-50 text-red-700 hover:bg-red-100"
                  : "border-red-200 text-red-600 hover:bg-red-50 hover:border-red-500"
              }`}
              onClick={() => onStatusChange(candidate.id, "rejected")}
            >
              <XIcon className="w-4 h-4 mr-2" />
              {candidate.status === "rejected" ? <Trans>Rejected</Trans> : <Trans>Reject</Trans>}
            </Button>

            <Button
              className={`border ${
                candidate.status === "approved"
                  ? "border-green-500 bg-green-50 text-green-700 hover:bg-green-100"
                  : "border-green-200 text-green-600 hover:bg-green-50 hover:border-green-500"
              }`}
              variant="outline"
              onClick={() => onStatusChange(candidate.id, "approved")}
            >
              <CheckIcon className="w-4 h-4 mr-2" />
              {candidate.status === "approved" ? <Trans>Approved</Trans> : <Trans>Approve</Trans>}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};