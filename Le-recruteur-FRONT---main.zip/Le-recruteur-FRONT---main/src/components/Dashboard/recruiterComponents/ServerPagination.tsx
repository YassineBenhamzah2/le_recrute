import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Trans } from "@lingui/macro";

interface ServerPaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export function ServerPagination({ currentPage, totalPages, onPageChange }: ServerPaginationProps) {
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-center space-x-4 mt-8">
      <Button
        variant="outline"
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
      >
        <ChevronLeft className="h-4 w-4 mr-2" />
        <Trans>Précédent</Trans>
      </Button>
      <span className="text-sm font-medium text-gray-700">
        <Trans>Page {currentPage} sur {totalPages}</Trans>
      </span>
      <Button
        variant="outline"
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
      >
        <Trans>Suivant</Trans>
        <ChevronRight className="h-4 w-4 ml-2" />
      </Button>
    </div>
  );
}