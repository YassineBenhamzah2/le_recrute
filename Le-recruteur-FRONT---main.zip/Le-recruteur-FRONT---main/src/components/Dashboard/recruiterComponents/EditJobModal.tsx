import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { jobOfferService } from "@/lib/network/jobOffer";
import { UpdateJobOfferRequest } from "@/lib/types/jobOffer";
import { ContractType, JobType } from "@/lib/types/subtype/main";
import { useState } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { toast } from "sonner";
import { Country, State } from "react-country-state-city/dist/esm/types";
import { BackgroundSubsection } from "./BackgroundSubsection";
import { BackgroundWrapperSubsection } from "./BackgroundWrapperSubsection";
import { ContainerSubsection } from "./ContainerSubsection";
import { ContainerWrapperSubsection } from "./ContainerWrapperSubsection";
import { DivSubsection } from "./DivSubsection";
import { DivWrapperSubsection } from "./DivWrapperSubsection";
import { GenerateWithAi } from "./GenerateWithAi";
import { Job } from "./JobListSection";
import { SkillsSubsection } from "./SkillsSubsection";
import { ResponsibilitiesSubsection } from "./ResponsibilitiesSubsection";
import { TagsSubsection } from "./TagsSubsection";
import { Trans } from "@lingui/macro";

// Edit Form data interface that matches what components expect
interface EditFormData {
  title: string;
  departmentId: number;
  location: string;
  country?: string | null; // New field for country
  state?: string | null; // New field for state
  jobType: JobType;
  contract: ContractType;
  jobDeadline: string;
  description: string;
  currency: string;
  minSalary: string;
  maxSalary: string;
  negotiable: boolean;
  bonus: string;
  requirements: string[];
  questions: string[];
  jobOfferSkills: string[];
  jobOfferResponsibilities: string[];
  tags: string[];
}

interface EditJobModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  job: Job;
  onJobUpdated?: () => void;
}

export const EditJobModal = ({
  open,
  onOpenChange,
  job,
  onJobUpdated,
}: EditJobModalProps): JSX.Element => {
  const [loading, setLoading] = useState(false);
  const [openAi, setOpenAi] = useState(false);

  // Initialize react-hook-form
  const { handleSubmit, setValue, watch } = useForm<EditFormData>({
    defaultValues: {
      title: job.title || "",
      departmentId: typeof job.department === "number" ? job.department : 1,
      location: job.location || "",
      country: job.country || null,
      state: job.city || null, // Use city as state since we parse location into country/city
      jobType: (job.jobType as JobType) || "FULL_TIME",
      contract: (job.contractType as ContractType) || "CDI",
      jobDeadline: job.deadlineDate || "",
      description: job.description || "",
      currency: job.currency || "EUR (€)",
      minSalary: job.minSalary?.toString() || "",
      maxSalary: job.maxSalary?.toString() || "",
      negotiable: job.negotiable || false,
      bonus: job.bonus || "",
      requirements: job.requirements || [""],
      questions: job.questions || [""],
      jobOfferSkills: job.skills || [""],
      jobOfferResponsibilities: job.responsibilities || [""],
      tags: job.tags || [""],
    },
    mode: "onChange",
  });
  const formData = watch();

  const handleGenerateWithAi = async () => {
    setOpenAi(true);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setValue(name as keyof EditFormData, value);
  };

  const handleDescriptionGeneration = async (description: string) => {
    setValue("description", description);
  };

  const handleConfirm = (description: string) => {
    handleDescriptionGeneration(description);
    setOpenAi(false);
  };

  const handleSelectChange = (name: string, value: string) => {
    if (name === "departmentId") {
      setValue("departmentId", parseInt(value));
    } else {
      setValue(name as keyof EditFormData, value);
    }
  };

  const handleLocationChange = (
    countryObj: Country | null,
    stateObj: State | null
  ) => {
    // Store country and state objects for reference
    setValue("country", countryObj?.name || null);
    setValue("state", stateObj?.name || null);

    // Update location string
    let locationString = "";
    if (countryObj) {
      locationString = countryObj.name;
      if (stateObj) {
        locationString += `, ${stateObj.name}`;
      }
    }
    setValue("location", locationString);
  };

  const toggleNegotiable = () => {
    setValue("negotiable", !formData.negotiable);
  };

  const addRequirement = (requirement: string) => {
    const currentRequirements = formData.requirements || [];
    setValue("requirements", [...currentRequirements, requirement]);
  };

  const removeRequirement = (index: number) => {
    const currentRequirements = formData.requirements || [];
    setValue(
      "requirements",
      currentRequirements.filter((_: string, i: number) => i !== index)
    );
  };

  const addQuestion = (question: string) => {
    const currentQuestions = formData.questions || [];
    setValue("questions", [...currentQuestions, question]);
  };

  const removeQuestion = (index: number) => {
    const currentQuestions = formData.questions || [];
    setValue(
      "questions",
      currentQuestions.filter((_: string, i: number) => i !== index)
    );
  };

  const addSkill = (skill: string) => {
    const currentSkills = formData.jobOfferSkills || [];
    setValue("jobOfferSkills", [...currentSkills, skill]);
  };

  const removeSkill = (index: number) => {
    const currentSkills = formData.jobOfferSkills || [];
    setValue(
      "jobOfferSkills",
      currentSkills.filter((_: string, i: number) => i !== index)
    );
  };

  const addResponsibility = (responsibility: string) => {
    const currentResponsibilities = formData.jobOfferResponsibilities || [];
    setValue("jobOfferResponsibilities", [
      ...currentResponsibilities,
      responsibility,
    ]);
  };

  const removeResponsibility = (index: number) => {
    const currentResponsibilities = formData.jobOfferResponsibilities || [];
    setValue(
      "jobOfferResponsibilities",
      currentResponsibilities.filter((_: string, i: number) => i !== index)
    );
  };

  const addTag = (tag: string) => {
    const currentTags = formData.tags || [];
    setValue("tags", [...currentTags, tag]);
  };

  const removeTag = (index: number) => {
    const currentTags = formData.tags || [];
    setValue(
      "tags",
      currentTags.filter((_: string, i: number) => i !== index)
    );
  };

  // Handle job update
  const onSubmit: SubmitHandler<EditFormData> = async (data) => {
    if (!job) {
      toast.error(<Trans>No job data available</Trans>);
      return;
    }

    setLoading(true);

    try {
      // Map the status to the correct format
      const getApiStatus = (
        status: string
      ): "PENDING" | "ACTIVE" | "CLOSED" | "PAUSED" => {
        switch (status.toUpperCase()) {
          case "ACTIVE":
            return "ACTIVE";
          case "PAUSE":
          case "PAUSED":
            return "PAUSED";
          case "INACTIVE":
          case "EXPIRED":
            return "CLOSED";
          case "PENDING":
            return "PENDING";
          default:
            return "ACTIVE";
        }
      };

      // Prepare the update request data
      const updateData: UpdateJobOfferRequest = {
        id: job.id,
        title: data.title,
        description: data.description,
        departmentId: data.departmentId,
        location: data.location,
        contractType: data.contract,
        jobType: data.jobType,
        publicationDate: job.publicationDate,
        deadlineDate: data.jobDeadline,
        minSalary: parseInt(data.minSalary || "0"),
        maxSalary: parseInt(data.maxSalary || "0"),
        currency: data.currency,
        status: getApiStatus(job.status),
        negotiable: data.negotiable,
        jobOfferSchedule: "",
        jobOfferRequirements: data.requirements.filter(
          (req: string) => req.trim() !== ""
        ),
        jobOfferQuestions: data.questions.filter(
          (q: string) => q.trim() !== ""
        ),
        jobOfferSkills: data.jobOfferSkills.filter(
          (skill: string) => skill.trim() !== ""
        ),
        jobOfferResponsibilities: data.jobOfferResponsibilities.filter(
          (resp: string) => resp.trim() !== ""
        ),
        tags: data.tags.filter((tag: string) => tag.trim() !== ""),
        bonus: data.bonus,
      };

      const response = await jobOfferService.updateJobOffer(job.id, updateData);

      if (response.success) {
        toast.success(<Trans>Job updated successfully!</Trans>);
        onJobUpdated?.();
        onOpenChange(false);
      } else {
        toast.error(<Trans>Failed to update job</Trans>);
      }
    } catch (error) {
      console.error("Error updating job:", error);
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error(<Trans>Failed to update job</Trans>);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="z-50 max-w-5xl w-full rounded-2xl bg-white p-6  overflow-hidden shadow-xl [&>button]:hidden">
          {/* Modal Header */}
          <ContainerSubsection onClose={() => onOpenChange(false)} />
          {/* Modal Body */}
          <Card className="border-none shadow-none">
            <ScrollArea className="h-[600px]  px-6 py-4">
              <form
                onSubmit={handleSubmit(onSubmit)}
                className="space-y-6"
                id="job-form"
              >
                <BackgroundSubsection
                  formData={formData}
                  handleChange={handleChange}
                  handleSelectChange={handleSelectChange}
                  handleLocationChange={handleLocationChange}
                />
                <BackgroundWrapperSubsection
                  formData={formData}
                  handleChange={handleChange}
                  handleGenerateWithAi={handleGenerateWithAi}
                  handleSelectChange={handleSelectChange}
                />
                <DivWrapperSubsection
                  formData={formData}
                  handleChange={handleChange}
                  handleSelectChange={handleSelectChange}
                  toggleNegotiable={toggleNegotiable}
                />
                <ContainerWrapperSubsection
                  formData={formData}
                  addRequirement={addRequirement}
                  removeRequirement={removeRequirement}
                />
                <SkillsSubsection
                  formData={formData}
                  addSkill={addSkill}
                  removeSkill={removeSkill}
                />
                <ResponsibilitiesSubsection
                  formData={formData}
                  addResponsibility={addResponsibility}
                  removeResponsibility={removeResponsibility}
                />
                <TagsSubsection
                  formData={formData}
                  addTag={addTag}
                  removeTag={removeTag}
                />
                <DivSubsection
                  formData={formData}
                  addQuestion={addQuestion}
                  removeQuestion={removeQuestion}
                />
                {/* Modal Footer */}
                <DialogFooter className="flex flex-col sm:flex-row justify-end gap-4 p-6 bg-white">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full sm:w-32 h-12 font-normal text-gray-700 bg-gray-50"
                    onClick={() => onOpenChange(false)}
                  >
                    <Trans>Cancel</Trans>
                  </Button>
                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full sm:w-32 h-12 font-normal bg-[#238d94] text-white hover:bg-[#1a7379] disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <div className="flex items-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        <Trans>Saving...</Trans>
                      </div>
                    ) : (
                      <Trans>Save Changes</Trans>
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </ScrollArea>
          </Card>
        </DialogContent>
      </Dialog>
      <Dialog open={openAi} onOpenChange={setOpenAi}>
        <DialogContent className="max-w-[1200px] p-0 rounded-2xl [&>button]:hidden">
          <GenerateWithAi
            handleConfirm={handleConfirm}
            handleClose={() => setOpenAi(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
};
