/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";
import {
  Filter,
  MapPin,
  Calendar,
  Briefcase,
  GraduationCap,
  Award,
  Download,
  ChevronDown,
} from "lucide-react";
import { MultiSelectDropdown } from "./MultiSelectDropdown";
import { Skeleton } from "@/components/ui/skeleton";
import { Filters, FilterOptions } from "@/lib/types/recruiter";
import { Trans } from "@lingui/macro";
import { t } from "@lingui/core/macro";

interface CandidateFiltersProps {
  filters: Filters;
  filterOptions: FilterOptions | null;
  onFilterChange: (filterType: keyof Filters, value: any) => void;
  onClearFilters: () => void;
  isLoading: boolean;
  resultsCount: number;
}

const moroccoRegions = [
  "Tanger-Tétouan-Al Hoceïma",
  "L'Oriental",
  "Fès-Meknès",
  "Rabat-Salé-Kénitra",
  "Béni Mellal-Khénifra",
  "Casablanca-Settat",
  "Marrakech-Safi",
  "Drâa-Tafilalet",
  "Souss-Massa",
  "Guelmim-Oued Noun",
  "Laâyoune-Sakia El Hamra",
  "Dakhla-Oued Ed-Dahab",
];

export const CandidateFilters: React.FC<CandidateFiltersProps> = ({
  filters,
  filterOptions,
  onFilterChange,
  onClearFilters,
  isLoading,
  resultsCount,
}) => {
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Move cvStatusOptions inside the component where i18n context is available
  const cvStatusOptions = [t`CV disponible`, t`CV non disponible`];

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <div className="flex items-center gap-2 mb-6">
          <Filter className="w-5 h-5 text-gray-400" />
          <h2 className="text-lg font-semibold text-gray-900">
            <Trans>Filtres Principaux</Trans>
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
      <div className="flex items-center gap-2 mb-6">
        <Filter className="w-5 h-5 text-[#1a6b72]" />
        <h2 className="text-lg font-semibold text-gray-900">
          <Trans>Filtres Principaux</Trans>
        </h2>
      </div>

      {/* Basic Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Trans>Nom et prénom</Trans>
          </label>
          <input
            type="text"
            placeholder={t`Ex: Marie Dubois`}
            value={filters.name}
            onChange={(e) => onFilterChange("name", e.target.value)}
            className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1a6b72] focus:border-transparent"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Trans>Fonction actuelle</Trans>
          </label>
          <MultiSelectDropdown
            options={filterOptions?.positions || []}
            placeholder={t`Ex: Développeur`}
            selectedValues={filters.positions}
            onChange={(v) => onFilterChange("positions", v)}
            icon={Briefcase}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Trans>Niveau d'étude</Trans>
          </label>
          <MultiSelectDropdown
            options={filterOptions?.educationLevels || []}
            placeholder={t`Ex: Bac+5`}
            selectedValues={filters.educationLevels}
            onChange={(v) => onFilterChange("educationLevels", v)}
            icon={GraduationCap}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Trans>Niveau d'expérience</Trans>
          </label>
          <MultiSelectDropdown
            options={filterOptions?.experienceLevels || []}
            placeholder={t`Ex: 3 ans`}
            selectedValues={filters.experienceLevels}
            onChange={(v) => onFilterChange("experienceLevels", v)}
            icon={Calendar}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Trans>Typologie de la fonction</Trans>
          </label>
          <MultiSelectDropdown
            options={filterOptions?.jobTypes || []}
            placeholder={t`Ex: Finance / RH...`}
            selectedValues={filters.jobTypes}
            onChange={(v) => onFilterChange("jobTypes", v)}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Trans>Secteur d'activité</Trans>
          </label>
          <MultiSelectDropdown
            options={filterOptions?.sectors || []}
            placeholder={t`Ex: Informatique...`}
            selectedValues={filters.sectors}
            onChange={(v) => onFilterChange("sectors", v)}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Trans>Compétences</Trans>
          </label>
          <MultiSelectDropdown
            options={filterOptions?.skills || []}
            placeholder={t`Ex: React, Python...`}
            selectedValues={filters.skills}
            onChange={(v) => onFilterChange("skills", v)}
            icon={Award}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Trans>Région</Trans>
          </label>
          <MultiSelectDropdown
            options={moroccoRegions}
            placeholder={t`Ex: Kenitra`}
            selectedValues={filters.regions}
            onChange={(v) => onFilterChange("regions", v)}
            icon={MapPin}
          />
        </div>
      </div>

      <button
        onClick={() => setShowAdvanced(!showAdvanced)}
        className="flex items-center gap-2 text-[#1a6b72] hover:text-[#238D94] font-medium mb-4"
      >
        <Trans>Recherche avancée</Trans>
        <ChevronDown
          className={`w-4 h-4 transition-transform ${
            showAdvanced ? "rotate-180" : ""
          }`}
        />
      </button>

      {/* --- ADVANCED FILTERS (RESTORED) --- */}
      {showAdvanced && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4 border-t pt-4 animate-fade-in">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Employeur actuel</Trans>
            </label>
            <MultiSelectDropdown
              options={filterOptions?.companies || []}
              placeholder={t`Ex: Orange...`}
              selectedValues={filters.companies}
              onChange={(v) => onFilterChange("companies", v)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Formation</Trans>
            </label>
            <MultiSelectDropdown
              options={filterOptions?.formations || []}
              placeholder={t`Ex: Licence, Master...`}
              selectedValues={filters.formations}
              onChange={(v) => onFilterChange("formations", v)}
              icon={GraduationCap}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Certification</Trans>
            </label>
            <MultiSelectDropdown
              options={filterOptions?.certifications || []}
              placeholder={t`Ex: AWS Certified...`}
              selectedValues={filters.certifications}
              onChange={(v) => onFilterChange("certifications", v)}
              icon={Award}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Statut CV</Trans>
            </label>
            <MultiSelectDropdown
              options={cvStatusOptions}
              placeholder={t`CV disponible ?`}
              selectedValues={filters.cvStatus}
              onChange={(v) => onFilterChange("cvStatus", v)}
              icon={Download}
            />
          </div>
          {/* Email, Phone, and Address were missing - they are now restored */}
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Contact (email)</Trans>
            </label>
            <input
              type="text"
              placeholder={t`Ex: marie.dubois@email.com`}
              value={filters.email}
              onChange={(e) => onFilterChange("email", e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1a6b72] focus:border-transparent"
            />
          </div>
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Téléphone</Trans>
            </label>
            <input
              type="text"
              placeholder={t`Ex: +33 1 23 45 67 89`}
              value={filters.phone}
              onChange={(e) => onFilterChange("phone", e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1a6b72] focus:border-transparent"
            />
          </div>
          <div className="lg:col-span-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Adresse complète</Trans>
            </label>
            <input
              type="text"
              placeholder={t`Ex: 15 Rue Victor Hugo, Paris`}
              value={filters.address}
              onChange={(e) => onFilterChange("address", e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#1a6b72] focus:border-transparent"
            />
          </div>
        </div>
      )}

      <div className="flex justify-between items-center pt-4 border-t border-gray-100">
        <button
          onClick={onClearFilters}
          className="text-gray-600 hover:text-gray-800 font-medium"
        >
          <Trans>Effacer tous les filtres</Trans>
        </button>
        <div className="text-sm text-gray-600 font-medium">
          <Trans>
            {resultsCount} candidat{resultsCount !== 1 ? "s" : ""} trouvé
            {resultsCount !== 1 ? "s" : ""}
          </Trans>
        </div>
      </div>
    </div>
  );
};
