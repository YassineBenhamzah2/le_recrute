import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { DollarSignIcon } from "lucide-react";
import { Trans ,t  } from "@lingui/macro"; // Ajout de l'import Trans

interface DivWrapperSubsectionProps {
  formData: {
    currency: string;
    minSalary: string;
    maxSalary: string;
    negotiable: boolean;
    bonus: string;
  };
  handleChange: (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => void;
  handleSelectChange: (name: string, value: string) => void;
  toggleNegotiable: () => void;
}

export const DivWrapperSubsection = ({
  formData,
  handleChange,
  handleSelectChange,
  toggleNegotiable,
}: DivWrapperSubsectionProps): JSX.Element => {
  return (
    <Card className="w-full p-6 bg-gray-50 rounded-xl">
      <CardContent className="flex flex-col gap-4 p-0">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 relative">
            <DollarSignIcon className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-xl text-gray-900 leading-7">
            <Trans>Salary Information</Trans>
          </h3>
        </div>

        <div className="flex flex-col md:flex-row items-start justify-center gap-4 w-full">
          <div className="flex flex-col w-full gap-2">
            <Label
              htmlFor="currency"
              className="font-normal text-sm text-gray-700 leading-5"
            >
              <Trans>Currency</Trans>
            </Label>
            <Select
              value={formData.currency}
              onValueChange={(value) => handleSelectChange("currency", value)}
            >
              <SelectTrigger
                id="currency"
                className="w-full h-[50px] bg-white rounded-lg border border-solid border-gray-300"
              >
                <SelectValue defaultValue={formData.currency} placeholder={<Trans>Select currency</Trans>} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="$">USD</SelectItem>
                <SelectItem value="€">EUR</SelectItem>
                <SelectItem value="DH">DH</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-col w-full gap-2">
            <Label
              htmlFor="minSalary"
              className="font-normal text-sm text-gray-700 leading-5"
            >
              <Trans>Minimum Salary *</Trans>
            </Label>
            <Input
              id="minSalary"
              name="minSalary"
              type="text"
              value={formData.minSalary}
              onChange={handleChange}
              className="w-full h-[50px] bg-white rounded-lg border border-solid border-gray-300 px-4 text-gray-700"
              placeholder="50000"
              disabled={formData.negotiable}
            />
          </div>

          <div className="flex flex-col w-full gap-2">
            <Label
              htmlFor="maxSalary"
              className="font-normal text-sm text-gray-700 leading-5"
            >
              <Trans>Maximum Salary *</Trans>
            </Label>
            <Input
              id="maxSalary"
              name="maxSalary"
              type="text"
              value={formData.maxSalary}
              onChange={handleChange}
              className="w-full h-[50px] bg-white rounded-lg border border-solid border-gray-300 px-4 text-gray-700"
              placeholder="80000"
              disabled={formData.negotiable}
            />
          </div>
        </div>

        {formData.negotiable && (
          <div className="w-full h-[49px] bg-white rounded-lg overflow-hidden border border-solid border-gray-300 flex items-center justify-center mt-2">
            <span className="font-normal italic text-black text-xl text-center leading-7">
              <Trans>Negotiable</Trans>
            </span>
          </div>
        )}

        <div className="flex items-center gap-2 mt-2">
          <Switch
            id="negotiable"
            checked={formData.negotiable}
            onCheckedChange={toggleNegotiable}
          />
          <Label
            htmlFor="negotiable"
            className="font-normal text-sm text-gray-700 leading-5"
          >
            <Trans>Negotiable</Trans>
          </Label>
        </div>
        {/* A Section for Bonus and Prime */}
        <div className="mt-6">
          <Label
            htmlFor="bonus"
            className="text-sm font-medium text-gray-700"
          >
            <Trans>Bonus / Primes *</Trans>
          </Label>
          <Textarea
            id="bonus"
            name="bonus"
            value={formData.bonus}
            onChange={handleChange}
            placeholder={t`Describe the bonus and prime conditions`}
            className="mt-1 min-h-[120px]"
            required
          />
        </div>
      </CardContent>
    </Card>
  );
};