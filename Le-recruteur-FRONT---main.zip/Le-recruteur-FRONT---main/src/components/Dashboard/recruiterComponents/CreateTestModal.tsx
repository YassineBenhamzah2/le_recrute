import { AlertCircle, Loader2, Plus, Trash2, X } from "lucide-react";
import React, { useEffect, useState } from "react";
import { testService } from "../../../lib/network/test";
import {
  CreateTestRequest,
  TestCategory,
  TestDifficulty,
} from "../../../lib/types/test";
import { toast } from "sonner";
import { Trans } from "@lingui/macro"; // Import corrigé

interface CreateTestModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Question {
  id: string;
  type: string;
  question: string;
  options: Option[];
  points: number;
}

interface Option {
  id: string;
  text: string;
  isCorrect: boolean;
  points: number;
}

const CreateTestModal: React.FC<CreateTestModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [duration, setDuration] = useState("");
  const [passingScore, setPassing_score] = useState("");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [selectedQuestionId, setSelectedQuestionId] = useState<string | null>(
    null
  );
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedQuestion = questions.find((q) => q.id === selectedQuestionId);

  // Simple background scroll prevention
  useEffect(() => {
    if (isOpen) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }

    // Cleanup on unmount
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [isOpen]);

  // Helper functions
  const addQuestion = () => {
    const newQuestion: Question = {
      id: Date.now().toString(),
      type: "Multiple Choice",
      question: "",
      options: [
        { id: "1", text: "", isCorrect: false, points: 0 },
        { id: "2", text: "", isCorrect: false, points: 0 },
      ],
      points: 3,
    };
    setQuestions([...questions, newQuestion]);
    setSelectedQuestionId(newQuestion.id);
  };

  const deleteQuestion = (questionId: string) => {
    setQuestions(questions.filter((q) => q.id !== questionId));
    if (selectedQuestionId === questionId) {
      setSelectedQuestionId(questions[0]?.id || null);
    }
  };

  const updateQuestion = (field: string, value: unknown) => {
    if (!selectedQuestion) return;
    setQuestions(
      questions.map((q) =>
        q.id === selectedQuestion.id ? { ...q, [field]: value } : q
      )
    );
  };

  // Function to assign points to correct options when points value changes
  const updateQuestionPoints = (newPoints: number) => {
    if (!selectedQuestion) return;

    // Update question points and assign points to all correct options
    const updatedOptions = selectedQuestion.options.map((option) => ({
      ...option,
      points: option.isCorrect ? newPoints : 0,
    }));

    setQuestions(
      questions.map((q) =>
        q.id === selectedQuestion.id
          ? {
              ...q,
              points: newPoints,
              options: updatedOptions,
            }
          : q
      )
    );
  };

  // Function to update option and assign points based on isCorrect status
  const updateOptionCorrectness = (optionId: string, isCorrect: boolean) => {
    if (!selectedQuestion) return;

    const updatedOptions = selectedQuestion.options.map((opt) =>
      opt.id === optionId
        ? {
            ...opt,
            isCorrect: isCorrect,
            points: isCorrect ? selectedQuestion.points : 0,
          }
        : opt
    );

    setQuestions(
      questions.map((q) =>
        q.id === selectedQuestion.id ? { ...q, options: updatedOptions } : q
      )
    );
  };

  const addOption = () => {
    if (!selectedQuestion) return;
    const newOption: Option = {
      id: Date.now().toString(),
      text: "",
      isCorrect: false,
      points: 0,
    };
    updateQuestion("options", [...selectedQuestion.options, newOption]);
  };

  const updateOption = (
    optionId: string,
    field: string,
    value: string | number
  ) => {
    if (!selectedQuestion) return;
    const updatedOptions = selectedQuestion.options.map((opt) =>
      opt.id === optionId ? { ...opt, [field]: value } : opt
    );
    updateQuestion("options", updatedOptions);
  };

  const deleteOption = (optionId: string) => {
    if (!selectedQuestion) return;
    updateQuestion(
      "options",
      selectedQuestion.options.filter((opt) => opt.id !== optionId)
    );
  };

  if (!isOpen) return null;

  const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const validateTestData = () => {
    // Basic field validation
    if (!title.trim()) {
      return { isValid: false, error: "Test title is required" };
    }

    if (!description.trim()) {
      return { isValid: false, error: "Test description is required" };
    }

    if (!category) {
      return { isValid: false, error: "Test category is required" };
    }

    if (!difficulty) {
      return { isValid: false, error: "Test difficulty is required" };
    }

    if (!duration || parseInt(duration) <= 0) {
      return { isValid: false, error: "Valid test duration is required" };
    }

    if (
      !passingScore ||
      parseInt(passingScore) <= 0 ||
      parseInt(passingScore) > 100
    ) {
      return {
        isValid: false,
        error: "Passing score must be between 1 and 100",
      };
    }

    // Questions validation
    if (!questions.length) {
      return { isValid: false, error: "At least one question is required" };
    }

    // Validate each question
    for (let i = 0; i < questions.length; i++) {
      const question = questions[i];

      if (!question.question.trim()) {
        return { isValid: false, error: `Question ${i + 1} text is required` };
      }

      if (!question.options.length) {
        return {
          isValid: false,
          error: `Question ${i + 1} must have at least one option`,
        };
      }

      if (question.options.length < 2) {
        return {
          isValid: false,
          error: `Question ${i + 1} must have at least 2 options`,
        };
      }

      // Check if all options have text
      const emptyOptionIndex = question.options.findIndex(
        (opt) => !opt.text.trim()
      );
      if (emptyOptionIndex !== -1) {
        return {
          isValid: false,
          error: `Question ${i + 1}, Option ${
            emptyOptionIndex + 1
          } text is required`,
        };
      }

      // Check if at least one option is marked as correct
      const hasCorrectAnswer = question.options.some((opt) => opt.isCorrect);
      if (!hasCorrectAnswer) {
        return {
          isValid: false,
          error: `Question ${i + 1} must have at least one correct answer`,
        };
      }

      // Validate points
      if (!question.points || question.points <= 0) {
        return {
          isValid: false,
          error: `Question ${i + 1} must have points greater than 0`,
        };
      }
    }

    return { isValid: true, error: null };
  };

  const handleSaveTest = async () => {
    // Reset error state
    setError(null);

    // Comprehensive validation
    const validation = validateTestData();
    if (!validation.isValid) {
      setError(validation.error);
      return;
    }

    try {
      setIsLoading(true);

      // Prepare request data according to CreateTestRequest interface
      const requestData: CreateTestRequest = {
        title,
        description,
        category: category as TestCategory,
        difficulty: difficulty as TestDifficulty,
        duration: parseInt(duration) || 60,
        passingScore: parseInt(passingScore) || 70,
        status: "DRAFT", // Default to draft status
        questions: questions.map((q) => ({
          type: q.type,
          question: q.question,
          options: q.options,
          points: q.points,
        })),
      };

      // Call the API to create the test
      await testService.createTest(requestData);

      toast.success("Test created successfully");

      // Clear all modal data
      setTitle("");
      setDescription("");
      setCategory("");
      setDifficulty("");
      setDuration("");
      setPassing_score("");
      setQuestions([]);
      setSelectedQuestionId(null);

      // Close modal
      onClose();
    } catch (err: unknown) {
      const errorMessage =
        err instanceof Error
          ? err.message
          : "An error occurred while creating the test";
      setError(errorMessage);
      console.error("Error creating test:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 overflow-hidden"
      onClick={handleOverlayClick}
    >
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl max-h-[95vh] overflow-hidden mx-4">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">
            <Trans>Create New Test</Trans>
          </h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="flex h-[500px]">
          {/* Left Section - Test Settings */}
          <div className="w-1/3 bg-gray-50 overflow-y-auto h-full">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">
                <Trans>Test Settings</Trans>
              </h3>

              {/* Test Title */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Trans>Test Title</Trans>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter test title"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-transparent outline-none"
                />
              </div>

              {/* Description */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Trans>Description</Trans>
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Enter test description"
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-transparent outline-none resize-none"
                />
              </div>

              {/* Category & Difficulty */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Trans>Category</Trans>
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-transparent outline-none text-gray-500"
                  >
                    <option value=""><Trans>select category</Trans></option>
                    <option value="LANGUAGE"><Trans>LANGUAGE</Trans></option>
                    <option value="SKILL"><Trans>SKILL</Trans></option>
                    <option value="PERSONALITY"><Trans>PERSONALITY</Trans></option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Trans>Difficulty</Trans>
                  </label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-transparent outline-none text-gray-500"
                  >
                    <option value=""><Trans>select difficulty</Trans></option>
                    <option value="EASY"><Trans>Easy</Trans></option>
                    <option value="MEDIUM"><Trans>Medium</Trans></option>
                    <option value="HARD"><Trans>Hard</Trans></option>
                  </select>
                </div>
              </div>

              {/* Duration & Passing Score */}
              <div className="grid grid-cols-2 gap-3 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Trans>Duration (minutes)</Trans>
                  </label>
                  <input
                    type="number"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-transparent outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Trans>Passing Score</Trans>
                  </label>
                  <input
                    type="number"
                    value={passingScore}
                    onChange={(e) => setPassing_score(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-transparent outline-none"
                  />
                </div>
              </div>

              {/* Questions Section */}
              <div>
                <h4 className="text-md font-medium text-gray-900 mb-4">
                  <Trans>Questions</Trans> ({questions.length})
                </h4>

                <div className="space-y-2 mb-4">
                  {questions.map((question, index) => (
                    <div
                      key={question.id}
                      onClick={() => setSelectedQuestionId(question.id)}
                      className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                        selectedQuestionId === question.id
                          ? "border-[#238D94] bg-teal-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900">
                          <Trans>Question</Trans> {index + 1}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteQuestion(question.id);
                          }}
                          className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-sm text-gray-600 truncate mt-1">
                        {question.question || <Trans>Click to edit question</Trans>}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Add Question Button */}
                <button
                  onClick={addQuestion}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-700 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <Trans>Add Question</Trans>
                </button>
              </div>
            </div>
          </div>

          {/* Gray Divider Line */}
          <div className="w-px bg-gray-300"></div>

          {/* Right Section - Question Editor */}
          <div className="w-2/3 bg-white overflow-y-auto h-full">
            <div className="p-6">
              {selectedQuestion ? (
                <>
                  <h3 className="text-lg font-semibold text-gray-900 mb-6">
                    <Trans>Question</Trans> (
                    {questions.findIndex((q) => q.id === selectedQuestion.id) +
                      1}
                    )
                  </h3>

                  {/* Question Type */}
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Trans>Question Type</Trans>
                    </label>
                    <input
                      type="text"
                      value={selectedQuestion.type}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
                    />
                  </div>

                  {/* Question */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Trans>Question</Trans>
                    </label>
                    <textarea
                      value={selectedQuestion.question}
                      onChange={(e) =>
                        updateQuestion("question", e.target.value)
                      }
                      placeholder="Enter your question"
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-transparent outline-none resize-none"
                    />
                  </div>

                  {/* Answer Options */}
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-4">
                      <label className="block text-sm font-medium text-gray-700">
                        <Trans>Answer Options</Trans>{" "}
                        <span className="text-gray-500">
                          <Trans>(select one or multiple correct options)</Trans>
                        </span>
                      </label>
                      <button
                        onClick={addOption}
                        className="text-[#238D94] hover:text-[#1a6b75] font-medium text-sm"
                      >
                        + <Trans>Add Option</Trans>
                      </button>
                    </div>

                    <div className="space-y-3">
                      {selectedQuestion.options.map((option, index) => (
                        <div
                          key={option.id}
                          className="flex items-center gap-3 p-3"
                        >
                          <input
                            type="checkbox"
                            checked={option.isCorrect}
                            onChange={(e) =>
                              updateOptionCorrectness(
                                option.id,
                                e.target.checked
                              )
                            }
                            className="w-4 h-4 text-[#238D94] focus:ring-[#238D94]"
                          />
                          <input
                            type="text"
                            value={option.text}
                            onChange={(e) =>
                              updateOption(option.id, "text", e.target.value)
                            }
                            placeholder={`Option ${index + 1}`}
                            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-transparent outline-none"
                          />
                          {selectedQuestion.options.length > 2 && (
                            <button
                              onClick={() => deleteOption(option.id)}
                              className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Points */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Trans>Points</Trans>{" "}
                      <span className="text-gray-500">
                        <Trans>(per each true option)</Trans>
                      </span>
                    </label>
                    <input
                      type="number"
                      value={selectedQuestion.points}
                      onChange={(e) =>
                        updateQuestionPoints(parseInt(e.target.value) || 0)
                      }
                      className="w-24 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-transparent outline-none"
                    />
                  </div>
                </>
              ) : (
                <div className="flex items-center justify-center h-full text-gray-500">
                  <p><Trans>Select a question to edit or add a new question</Trans></p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-gray-200 bg-white">
          {/* Error message */}
          {error && (
            <div className="text-red-500 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              <span>{error}</span>
            </div>
          )}

          <div className="ml-auto">
            <button
              onClick={handleSaveTest}
              disabled={isLoading}
              className="px-6 py-3 bg-[#238D94] text-white rounded-lg hover:bg-[#1a6b75] transition-colors font-medium disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
              {isLoading ? <Trans>Saving...</Trans> : <Trans>Save Test</Trans>}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateTestModal;