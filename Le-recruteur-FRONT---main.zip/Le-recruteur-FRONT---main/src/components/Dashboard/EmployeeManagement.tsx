import { useState, useEffect, useCallback } from 'react';
import {
  Users,
  CheckCircle,
  AlertTriangle,
  UserX,
  AlertCircleIcon,
  CheckCircle2Icon
  // Archive,
  // Ban
} from 'lucide-react';
import { cn } from "@/lib/utils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Trans, t } from '@lingui/macro';

import { EmployeeTable } from './AdminComponents/EmployeeTable';
import { MetricCard } from './AdminComponents/MetricCard';
import { SearchAndFilter } from './AdminComponents/SearchAndFilter';
import { api } from '../../lib/network/utils/api';

import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationEllipsis,
} from "@/components/ui/pagination";

interface Employee {
  id: number;
  firstname: string;
  lastname: string;
  company: string;
  department: string;
  location: string;
  joined: string;
  phone: string;
  email: string;
  position: string;
  status: 'ACTIVE' | 'INACTIVE' | 'REPORTED' | 'SUSPENDED' | 'REJECTED';
}

interface PaginatedEmployeesResponse {
  data: Employee[];
  totalCount: number;
  currentPage: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

interface EmployeeStats {
  total: number;
  active: number;
  inactive: number;
  reported: number;
  suspended: number;
  rejected: number;
}

// --- NOTIFICATION STATE TYPE ---
type NotificationState = {
  title: string;
  description?: React.ReactNode;
  variant: "success" | "destructive";
} | null;

export default function EmployeeManagement() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [stats, setStats] = useState<EmployeeStats>({
    total: 0,
    active: 0,
    inactive: 0,
    reported: 0,
    suspended: 0,
    rejected: 0
  });

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [itemsPerPage] = useState(9);

  // --- ADD NOTIFICATION STATE ---
  const [notification, setNotification] = useState<NotificationState>(null);

  // Fetch employees (wrapped with useCallback to satisfy hook deps)
  const fetchEmployees = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const params = new URLSearchParams({
        page: (currentPage - 1).toString(),
        size: itemsPerPage.toString(),
        search: searchTerm,
      });

      if (statusFilter !== 'all') {
        params.append('status', statusFilter.toUpperCase());
      }

      const data = await api.getItem<PaginatedEmployeesResponse>(`/employees?${params.toString()}`);
      setEmployees(data.data);
      setTotalPages(data.totalPages);
      setTotalCount(data.totalCount);
      setCurrentPage(data.currentPage);

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error fetching employees:', err);
    } finally {
      setLoading(false);
    }
  }, [currentPage, itemsPerPage, searchTerm, statusFilter]);

  // Fetch employee stats
  const fetchEmployeeStats = useCallback(async () => {
    try {
      const statsData = await api.getItem<EmployeeStats>('/employees/stats');
      setStats(statsData);
    } catch (err) {
      console.error('Error fetching employee stats:', err);
    }
  }, []);

  // Debounced search effect: reset to page 1 when filters/search change
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      setCurrentPage(1);
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchTerm, statusFilter]);

  // Fetch employees whenever the fetch function changes (it captures deps)
  useEffect(() => {
    fetchEmployees();
  }, [fetchEmployees]);

  // Fetch employee stats on mount
  useEffect(() => {
    fetchEmployeeStats();
  }, [fetchEmployeeStats]);

  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // Handle page change
  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages && page !== currentPage) {
      setCurrentPage(page);
    }
  };

  const handleSearch = (value: string) => {
    setSearchTerm(value);
  };

  const handleFilter = () => {
    // Cycle through filter options
    const filters = ['all', 'active', 'inactive', 'reported', 'suspended', 'rejected'];
    const currentIndex = filters.indexOf(statusFilter);
    const nextIndex = (currentIndex + 1) % filters.length;
    setStatusFilter(filters[nextIndex]);
  };

  const handleApprove = async (id: number) => {
    setLoading(true);
    try {
      await api.patch(`/employees/${id}/approve`);
      setNotification({ 
        title: t({ id: "employee_management.notifications.success", message: "Success!" }), 
        description: t({ id: "employee_management.notifications.approved", message: "Employee has been approved." }), 
        variant: "success" 
      });
      await fetchEmployees();
      await fetchEmployeeStats();
    } catch (err) {
      const message = err instanceof Error ? err.message : t({ id: "employee_management.errors.approve_failed", message: "Failed to approve employee" });
      setError(message);
      setNotification({ 
        title: t({ id: "employee_management.notifications.error", message: "Error!" }), 
        description: message, 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeactivate = async (id: number) => {
    setLoading(true);
    try {
      await api.patch(`/employees/${id}/deactivate`);
      setNotification({ 
        title: t({ id: "employee_management.notifications.success", message: "Success!" }), 
        description: t({ id: "employee_management.notifications.deactivated", message: "Employee has been deactivated." }), 
        variant: "success" 
      });
      await fetchEmployees();
      await fetchEmployeeStats();
    } catch (err) {
      const message = err instanceof Error ? err.message : t({ id: "employee_management.errors.deactivate_failed", message: "Failed to deactivate employee" });
      setError(message);
      setNotification({ 
        title: t({ id: "employee_management.notifications.error", message: "Error!" }), 
        description: message, 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSuspend = async (id: number) => {
    setLoading(true);
    try {
      await api.patch(`/employees/${id}/suspend`);
      setNotification({ 
        title: t({ id: "employee_management.notifications.success", message: "Success!" }), 
        description: t({ id: "employee_management.notifications.suspended", message: "Employee has been suspended." }), 
        variant: "success" 
      });
      await fetchEmployees();
      await fetchEmployeeStats();
    } catch (err) {
      const message = err instanceof Error ? err.message : t({ id: "employee_management.errors.suspend_failed", message: "Failed to suspend employee" });
      setError(message);
      setNotification({ 
        title: t({ id: "employee_management.notifications.error", message: "Error!" }), 
        description: message, 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async (id: number) => {
    setLoading(true);
    try {
      await api.patch(`/employees/${id}/reject`);
      setNotification({ 
        title: t({ id: "employee_management.notifications.success", message: "Success!" }), 
        description: t({ id: "employee_management.notifications.rejected", message: "Employee has been rejected." }), 
        variant: "success" 
      });
      await fetchEmployees();
      await fetchEmployeeStats();
    } catch (err) {
      const message = err instanceof Error ? err.message : t({ id: "employee_management.errors.reject_failed", message: "Failed to reject employee" });
      setError(message);
      setNotification({ 
        title: t({ id: "employee_management.notifications.error", message: "Error!" }), 
        description: message, 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  // Analytics data for MetricCards
  const analyticsData = [
    {
      icon: Users,
      title: t({ id: "employee_management.stats.total_employees", message: "Total Employees" }),
      value: stats.total.toString(),
      subtitle: t({ id: "employee_management.stats.registered_employees", message: "Registered employees" }),
      change: t({ id: "employee_management.stats.change_last_month", message: "+12% from last month" }),
      chartColor: "teal" as const
    },
    {
      icon: CheckCircle,
      title: t({ id: "employee_management.stats.active", message: "Active" }),
      value: stats.active.toString(),
      subtitle: t({ id: "employee_management.stats.currently_active", message: "Currently active" }),
      change: t({ id: "employee_management.stats.active_change", message: "+8% from last month" }),
      chartColor: "emerald" as const
    },
    // {
    //   icon: Archive,
    //   title: "Inactive",
    //   value: stats.inactive.toString(),
    //   subtitle: "Currently inactive",
    //   change: "+1% from last month",
    //   chartColor: "gray" as const
    // },
    {
      icon: AlertTriangle,
      title: t({ id: "employee_management.stats.reported", message: "Reported" }),
      value: stats.reported.toString(),
      subtitle: t({ id: "employee_management.stats.under_review", message: "Under review" }),
      change: t({ id: "employee_management.stats.reported_change", message: "+3 this week" }),
      chartColor: "purple" as const
    },
    {
      icon: UserX,
      title: t({ id: "employee_management.stats.suspended", message: "Suspended" }),
      value: stats.suspended.toString(),
      subtitle: t({ id: "employee_management.stats.temporarily_suspended", message: "Temporarily suspended" }),
      change: t({ id: "employee_management.stats.suspended_change", message: "-2 from last month" }),
      chartColor: "blue" as const
    }
    // {
    //   icon: Ban,
    //   title: "Rejected",
    //   value: stats.rejected.toString(),
    //   subtitle: "Permanently rejected",
    //   change: "",
    //   chartColor: "purple" as const
    // }
  ];

  const getFilterText = (filter: string) => {
    switch (filter) {
      case 'all':
        return t({ id: "employee_management.filter.all", message: "All" });
      case 'active':
        return t({ id: "employee_management.filter.active", message: "Active" });
      case 'inactive':
        return t({ id: "employee_management.filter.inactive", message: "Inactive" });
      case 'reported':
        return t({ id: "employee_management.filter.reported", message: "Reported" });
      case 'suspended':
        return t({ id: "employee_management.filter.suspended", message: "Suspended" });
      case 'rejected':
        return t({ id: "employee_management.filter.rejected", message: "Rejected" });
      default:
        return filter.charAt(0).toUpperCase() + filter.slice(1);
    }
  };

  return (
    <div className="space-y-8">
      {/* --- THE NOTIFICATION --- */}
      {notification && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 w-full max-w-xl z-[100] animate-in fade-in-5 slide-in-from-top-5">
          <Alert
            variant={notification.variant === 'destructive' ? 'destructive' : 'default'}
            className={cn(
              "bg-background",
              notification.variant === 'success' &&
              "border-green-500/50 text-green-700 dark:border-green-500 [&>[data-slot=icon]]:text-green-700"
            )}
          >
            {notification.variant === 'destructive'
              ? <AlertCircleIcon className="h-4 w-4" data-slot="icon" />
              : <CheckCircle2Icon className="h-4 w-4" data-slot="icon" />}
            <AlertTitle>{notification.title}</AlertTitle>
            {notification.description && <AlertDescription>{notification.description}</AlertDescription>}
          </Alert>
        </div>
      )}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              <Trans id="employee_management.title">Employee Management</Trans>
            </h1>
            <p className="text-lg text-gray-600">
              <Trans id="employee_management.description">Track and manage all registered employees</Trans>
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              className="px-6 py-2 bg-gradient-to-r from-[#238D94] to-[#1a6b72] text-white rounded-xl font-medium text-sm hover:shadow-lg transition-all duration-200"
            >
              <Trans id="employee_management.overview_button">Overview</Trans>
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards using MetricCard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {analyticsData.map((item, index) => (
          <MetricCard key={index} {...item} />
        ))}
      </div>

      {/* Search and Filter using SearchAndFilter */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 ">
        <div className="mb-6">
          <SearchAndFilter
            searchTerm={searchTerm}
            onSearchChange={handleSearch}
            onFilterClick={handleFilter}
          />
        </div>

        {/* Status Filter Indicator */}
        {statusFilter !== 'all' && (
          <div className="mb-4">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
              <Trans id="employee_management.filter_indicator">Filter:</Trans> {getFilterText(statusFilter)}
              <button
                onClick={() => setStatusFilter('all')}
                className="ml-2 text-blue-600 hover:text-blue-800"
                title={t({ id: "employee_management.clear_filter", message: "Clear filter" })}
              >
                ×
              </button>
            </span>
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div className="flex justify-center items-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#238D94]"></div>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
            <p className="text-red-800">{error}</p>
            <button
              onClick={fetchEmployees}
              className="mt-2 px-4 py-2 bg-red-100 text-red-800 rounded hover:bg-red-200"
            >
              <Trans id="employee_management.retry_button">Retry</Trans>
            </button>
          </div>
        )}

        {/* Employee Table using EmployeeTable */}
        {!loading && !error && (
          <>
            <EmployeeTable
              employees={employees}
              onApprove={handleApprove}
              onDeactivate={handleDeactivate}
              onSuspend={handleSuspend}
              onReject={handleReject}
              isLoading={loading}
            />

            {/* Results count */}
            <div className="mt-4 text-sm text-gray-600">
              <Trans id="employee_management.results_count">
                Showing {totalCount > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0}-{Math.min(currentPage * itemsPerPage, totalCount)} of {totalCount} employees
              </Trans>
              {statusFilter !== 'all' && (
                <span>
                  {" "}(<Trans id="employee_management.filtered_by">filtered by</Trans> {getFilterText(statusFilter)})
                </span>
              )}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-6">
                <Pagination className="flex justify-center">
                  <PaginationContent className="flex justify-center gap-2">
                    {/* Previous Button */}
                    <PaginationItem>
                      <PaginationLink
                        href="#"
                        className="w-[40px] h-[40px] flex items-center justify-center rounded-[5px] border border-[#eaeaea] hover:bg-[#f5f5f5]"
                        onClick={(e) => {
                          e.preventDefault();
                          if (currentPage > 1 && !loading) handlePageChange(currentPage - 1);
                        }}
                        tabIndex={currentPage === 1 || loading ? -1 : 0}
                        aria-disabled={currentPage === 1 || loading}
                        title={t({ id: "employee_management.pagination.previous", message: "Previous page" })}
                      >
                        <span className="sr-only">
                          <Trans id="employee_management.pagination.previous">Previous page</Trans>
                        </span>
                        <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M7.41 10.59L2.83 6L7.41 1.41L6 0L0 6L6 12L7.41 10.59Z" fill={currentPage === 1 || loading ? "#D1D1D1" : "#333333"} />
                        </svg>
                      </PaginationLink>
                    </PaginationItem>

                    {/* Page Numbers with Ellipsis */}
                    {(() => {
                      const pageNumbers = [];
                      const siblingCount = 1;
                      const totalPageNumbersToShow = siblingCount + 5;

                      // If the total number of pages is small, show them all
                      if (totalPages <= totalPageNumbersToShow) {
                        for (let i = 1; i <= totalPages; i++) {
                          pageNumbers.push(
                            <PaginationItem key={i}>
                              <PaginationLink
                                href="#"
                                className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium ${currentPage === i ? "bg-[#238d94] text-white" : "border border-[#eaeaea] hover:bg-[#f5f5f5]"}`}
                                onClick={(e) => { e.preventDefault(); if (!loading) handlePageChange(i); }}
                              >
                                {i}
                              </PaginationLink>
                            </PaginationItem>
                          );
                        }
                        return pageNumbers;
                      }

                      // --- Logic for when ellipsis (...) is needed for a large number of pages ---

                      // Always add the first page
                      pageNumbers.push(
                        <PaginationItem key={1}>
                          <PaginationLink
                            href="#"
                            className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium ${currentPage === 1 ? "bg-[#238d94] text-white" : "border border-[#eaeaea] hover:bg-[#f5f5f5]"}`}
                            onClick={(e) => { e.preventDefault(); if (!loading) handlePageChange(1); }}
                          >
                            1
                          </PaginationLink>
                        </PaginationItem>
                      );

                      // Add left ellipsis if needed
                      if (currentPage > siblingCount + 2) {
                        pageNumbers.push(<PaginationItem key="ellipsis-start"><PaginationEllipsis /></PaginationItem>);
                      }

                      // Generate the middle page numbers
                      const startPage = Math.max(2, currentPage - siblingCount);
                      const endPage = Math.min(totalPages - 1, currentPage + siblingCount);

                      for (let i = startPage; i <= endPage; i++) {
                        pageNumbers.push(
                          <PaginationItem key={i}>
                            <PaginationLink
                              href="#"
                              className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium ${currentPage === i ? "bg-[#238d94] text-white" : "border border-[#eaeaea] hover:bg-[#f5f5f5]"}`}
                              onClick={(e) => { e.preventDefault(); if (!loading) handlePageChange(i); }}
                            >
                              {i}
                            </PaginationLink>
                          </PaginationItem>
                        );
                      }

                      // Add right ellipsis if needed
                      if (currentPage < totalPages - (siblingCount + 1)) {
                        pageNumbers.push(<PaginationItem key="ellipsis-end"><PaginationEllipsis /></PaginationItem>);
                      }

                      // Always add the last page
                      pageNumbers.push(
                        <PaginationItem key={totalPages}>
                          <PaginationLink
                            href="#"
                            className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium ${currentPage === totalPages ? "bg-[#238d94] text-white" : "border border-[#eaeaea] hover:bg-[#f5f5f5]"}`}
                            onClick={(e) => { e.preventDefault(); if (!loading) handlePageChange(totalPages); }}
                          >
                            {totalPages}
                          </PaginationLink>
                        </PaginationItem>
                      );

                      return pageNumbers;
                    })()}

                    {/* Next Button */}
                    <PaginationItem>
                      <PaginationLink
                        href="#"
                        className="w-[40px] h-[40px] flex items-center justify-center rounded-[5px] border border-[#eaeaea] hover:bg-[#f5f5f5]"
                        onClick={(e) => {
                          e.preventDefault();
                          // Use the real totalPages from the backend
                          if (currentPage < totalPages && !loading) {
                            handlePageChange(currentPage + 1);
                          }
                        }}
                        tabIndex={currentPage === totalPages || loading ? -1 : 0}
                        aria-disabled={currentPage === totalPages || loading}
                        title={t({ id: "employee_management.pagination.next", message: "Next page" })}
                      >
                        <span className="sr-only">
                          <Trans id="employee_management.pagination.next">Next page</Trans>
                        </span>
                        <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                          {/* Use the real totalPages for the icon color */}
                          <path d="M0.59 1.41L5.17 6L0.59 10.59L2 12L8 6L2 0L0.59 1.41Z" fill={currentPage === totalPages || loading ? "#D1D1D1" : "#333333"} />
                        </svg>
                      </PaginationLink>
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
