import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { candidatService } from "@/lib/network/candidat";
import { jobOfferService } from "@/lib/network/jobOffer";
import { Candidate as ApiCandidate } from "@/lib/types/candidat";
import { JobOffer } from "@/lib/types/jobOffer";
import {
  CandidateResponse,
  QuestionAnswerResponse,
  SkillResponse,
  EducationResponse,
  ExperienceResponse,
  CertificationResponse,
  LanguageResponse,
} from "@/lib/types/candidate";
import { useCallback, useEffect, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { CandidateTableSection } from "./recruiterComponents/CandidateTableSection";
import { HeaderSection } from "./recruiterComponents/HeaderSection";
import { Trans } from "@lingui/macro";

// Extended Candidate interface for the component
export interface Candidate {
  id: number;
  name: string;
  email: string;
  whatsapp_number?: string;
  phone?: string; // For backward compatibility
  appliedDate: string;
  createdAt?: string;
  documents: { cv: boolean; letter: boolean };
  status?: "pending" | "approved" | "rejected";

  // Additional candidate profile info
  nationality?: string;
  familyStatus?: string;
  childrenNumber?: number;
  address?: string;
  city?: string;
  region?: string;
  country?: string;
  linkedIn?: string;
  bio?: string;
  experienceLevel?: string;
  availability?: string;
  mobility?: string;
  profileCompletion?: number;
  overview?: string;

  // Candidate's answers to job offer questions
  answers?: QuestionAnswerResponse[];

  // Skills, education, experience
  skills?: SkillResponse[];
  education?: EducationResponse[];
  experiences?: ExperienceResponse[];
  certifications?: CertificationResponse[];
  languages?: LanguageResponse[];

  // Application score if available
  score?: number;
}

// Helper function to map API candidate to component candidate
const mapApiCandidateToCandidate = (
  apiCandidate: ApiCandidate | CandidateResponse
): Candidate => {
  return {
    id: apiCandidate.id,
    name: apiCandidate.name,
    whatsapp_number: apiCandidate.whatsapp_number,
    phone: apiCandidate.whatsapp_number || "",
    email: apiCandidate.email,
    appliedDate: new Date(apiCandidate.createdAt).toLocaleDateString("fr-FR"),
    createdAt: apiCandidate.createdAt,
    documents: {
      cv: !!apiCandidate.cv,
      letter: !!apiCandidate.motivationLetter,
    },
    status:
      apiCandidate.status === "ACCEPTEE"
        ? "approved"
        : apiCandidate.status === "REFUSEE"
        ? "rejected"
        : "pending",

    // Additional profile information
    nationality: (apiCandidate as CandidateResponse).nationality,
    familyStatus: (apiCandidate as CandidateResponse).familyStatus,
    childrenNumber: (apiCandidate as CandidateResponse).childrenNumber,
    address: (apiCandidate as CandidateResponse).address,
    city: (apiCandidate as CandidateResponse).city,
    region: (apiCandidate as CandidateResponse).region,
    country: (apiCandidate as CandidateResponse).country,
    linkedIn: (apiCandidate as CandidateResponse).linkedIn,
    bio: (apiCandidate as CandidateResponse).bio,
    experienceLevel: (apiCandidate as CandidateResponse).experienceLevel,
    availability: (apiCandidate as CandidateResponse).availability,
    mobility: (apiCandidate as CandidateResponse).mobility,
    profileCompletion: (apiCandidate as CandidateResponse).profileCompletion,
    overview: (apiCandidate as CandidateResponse).overview,

    // Question answers and professional details
    answers: (apiCandidate as CandidateResponse).answers,
    skills: (apiCandidate as CandidateResponse).skills,
    education: (apiCandidate as CandidateResponse).education,
    experiences: (apiCandidate as CandidateResponse).experiences,
    certifications: (apiCandidate as CandidateResponse).certifications,
    languages: (apiCandidate as CandidateResponse).languages,

    // Score
    score: (apiCandidate as CandidateResponse).score,
  };
};
const itemsPerPage = 10;
export const RecruiterJobDetailsDashboard = (): JSX.Element => {
  const navigate = useNavigate();
  const location = useLocation();
  const { jobId } = useParams<{ jobId: string }>();

  // Loading states
  const [loading, setLoading] = useState<boolean>(true);
  const [candidatesLoading, setCandidatesLoading] = useState<boolean>(false);

  // Job details state
  const [jobOffer, setJobOffer] = useState<JobOffer | null>(null);
  const [applicantsCount, setApplicantsCount] = useState<number>(0);

  // Candidates data
  const [candidates, setCandidates] = useState<Candidate[]>([]);

  // Parse page from URL query params
  const getPageFromUrl = useCallback((): number => {
    const searchParams = new URLSearchParams(location.search);
    const pageParam = searchParams.get("page");
    return pageParam ? parseInt(pageParam, 10) : 1;
  }, [location.search]);

  // Pagination state
  const [currentPage, setCurrentPage] = useState<number>(getPageFromUrl());
  const [totalPages, setTotalPages] = useState<number>(0);

  // Initial data loading
  useEffect(() => {
    const fetchCandidates = async (page: number = 1) => {
      if (!jobId) return;

      try {
        setCandidatesLoading(true);
        const response = await candidatService.getJobCandidates({
          jobOfferId: parseInt(jobId),
          page,
        });

        if (response.success && response.data) {
          const mappedCandidates = response.data.map(
            mapApiCandidateToCandidate
          );
          setCandidates(mappedCandidates);
          setApplicantsCount(mappedCandidates.length);

          // Update pagination metadata if available
          if (response.metadata?.pagination) {
            setTotalPages(response.metadata.pagination.totalPages);
          } else {
            setTotalPages(Math.ceil(mappedCandidates.length / itemsPerPage));
          }
        } else {
          toast.error(<Trans>Failed to fetch candidates</Trans>);
          setCandidates([]);
          setApplicantsCount(0);
        }
      } catch (error) {
        console.error("Error fetching candidates:", error);
        toast.error(<Trans>Error fetching candidates</Trans>);
        setCandidates([]);
        setApplicantsCount(0);
      } finally {
        setCandidatesLoading(false);
      }
    };
    fetchCandidates(currentPage);
  }, [currentPage, jobId]);
  useEffect(() => {
    const fetchJobOffer = async () => {
      if (!jobId) return;

      try {
        setLoading(true);
        const response = await jobOfferService.getJobOffer(parseInt(jobId));
        if (response.success && response.data) {
          setJobOffer(response.data);
        } else {
          toast.error(<Trans>Failed to fetch job details</Trans>);
        }
      } catch (error) {
        console.error("Error fetching job offer:", error);
        toast.error(<Trans>Error fetching job details</Trans>);
      } finally {
        setLoading(false);
      }
    };
    fetchJobOffer();
  }, [jobId]);
  // Calculate total pages based on candidates length and items per page
  useEffect(() => {
    setTotalPages(Math.ceil(candidates.length / itemsPerPage));
  }, [candidates]);

  // Update URL when page changes
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    searchParams.set("page", currentPage.toString());
    navigate({ search: searchParams.toString() }, { replace: true });
  }, [currentPage, navigate, location.search]);

  // Update page when URL changes
  useEffect(() => {
    const pageFromUrl = getPageFromUrl();
    if (pageFromUrl !== currentPage) {
      setCurrentPage(pageFromUrl);
    }
  }, [location.search, currentPage, getPageFromUrl]);

  // Get current candidates based on pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentCandidates = candidates.slice(indexOfFirstItem, indexOfLastItem);

  // Change page handler
  const handlePageChange = (pageNumber: number) => {
    if (pageNumber > 0 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  // Handle candidate status change with API integration
  const handleCandidateStatusChange = async (
    candidateId: number,
    status: "approved" | "rejected"
  ) => {
    if (!jobId) return;

    try {
      const jobOfferId = parseInt(jobId);

      if (status === "approved") {
        await candidatService.acceptCandidate(jobOfferId, candidateId);
      } else if (status === "rejected") {
        await candidatService.rejectCandidate(jobOfferId, candidateId);
      }

      // Update local state
      setCandidates((prevCandidates) =>
        prevCandidates.map((candidate) =>
          candidate.id === candidateId ? { ...candidate, status } : candidate
        )
      );

      toast.success(<Trans>Candidate {status} successfully</Trans>);
    } catch (error) {
      console.error(`Error ${status} candidate:`, error);
      toast.error(
        status === "approved" 
          ? <Trans>Failed to accept candidate</Trans>
          : <Trans>Failed to reject candidate</Trans>
      );
    }
  };

  // Loading state render
  if (loading) {
    return (
      <div className="flex flex-col h-full w-full p-4">
        <div className="relative w-full max-w-[1800px] mx-auto bg-white rounded-xl border border-solid shadow-sm flex-1 flex items-center justify-center min-h-[calc(100vh-10rem)]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#238d94] mx-auto mb-4"></div>
            <p className="text-gray-600"><Trans>Loading job details...</Trans></p>
          </div>
        </div>
      </div>
    );
  }

  // Error state render
  if (!jobOffer) {
    return (
      <div className="flex flex-col h-full w-full p-4">
        <div className="relative w-full max-w-[1800px] mx-auto bg-white rounded-xl border border-solid shadow-sm flex-1 flex items-center justify-center min-h-[calc(100vh-10rem)]">
          <div className="text-center">
            <p className="text-red-600 text-lg mb-4"><Trans>Job not found</Trans></p>
            <button
              onClick={() => navigate(-1)}
              className="px-4 py-2 bg-[#238d94] text-white rounded-lg hover:bg-[#1a7379] transition-colors"
            >
              <Trans>Go Back</Trans>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full w-full p-4 ">
      <div className="relative w-full max-w-[1800px] mx-auto bg-white rounded-xl border border-solid shadow-sm flex-1 flex flex-col min-h-[calc(100vh-10rem)] overflow-y-auto">
        <HeaderSection
          title={jobOffer.title}
          applicantsCount={applicantsCount}
          jobOffer={jobOffer}
        />
        {/* Tabs for Job Details and Candidates */}
        <div className="px-6 mt-4">
          <Tabs defaultValue="candidates" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger
                value="candidates"
                className="text-sm sm:text-base font-medium"
              >
                <Trans>Candidates ({applicantsCount})</Trans>
              </TabsTrigger>
            </TabsList>
            <TabsContent
              value="candidates"
              className="focus-visible:outline-none focus-visible:ring-0"
            >
              <div className="flex-1 overflow-auto">
                <h2 className="text-xl font-bold text-gray-900 mb-4">
                  <Trans>Candidates List</Trans>
                </h2>
                {candidatesLoading ? (
                  <div className="flex items-center justify-center p-8">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#238d94] mx-auto mb-2"></div>
                      <p className="text-gray-600"><Trans>Loading candidates...</Trans></p>
                    </div>
                  </div>
                ) : (
                  <CandidateTableSection
                    candidates={currentCandidates}
                    jobOfferId={parseInt(jobId || "0")}
                    onStatusChange={handleCandidateStatusChange}
                  />
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="flex justify-center py-8 px-4 sm:px-6 lg:px-8">
          <Pagination>
            <PaginationContent className="flex flex-wrap items-center gap-2 justify-center">
              <PaginationItem>
                <PaginationPrevious
                  onClick={() => handlePageChange(currentPage - 1)}
                  className={`[font-family:'Poppins',Helvetica] font-semibold text-[#192335] ${
                    currentPage === 1
                      ? "opacity-50 cursor-not-allowed"
                      : "cursor-pointer"
                  }`}
                  aria-disabled={currentPage === 1}
                />
              </PaginationItem>

              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (pageNumber) => (
                  <PaginationItem key={`page-${pageNumber}`}>
                    <PaginationLink
                      onClick={() => handlePageChange(pageNumber)}
                      className={`w-10 h-10 rounded-lg flex items-center justify-center [font-family:'Poppins',Helvetica] font-semibold text-base cursor-pointer transition-colors duration-200 ${
                        pageNumber === currentPage
                          ? "bg-[#238d94] text-white"
                          : "text-[#192335] hover:bg-gray-100"
                      }`}
                    >
                      {pageNumber}
                    </PaginationLink>
                  </PaginationItem>
                )
              )}

              <PaginationItem>
                <PaginationNext
                  onClick={() => handlePageChange(currentPage + 1)}
                  className={`[font-family:'Poppins',Helvetica] font-semibold text-[#192335] ${
                    currentPage === totalPages
                      ? "opacity-50 cursor-not-allowed"
                      : "cursor-pointer"
                  }`}
                  aria-disabled={currentPage === totalPages}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      </div>
    </div>
  );
};