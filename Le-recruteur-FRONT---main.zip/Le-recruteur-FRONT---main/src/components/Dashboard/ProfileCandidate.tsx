import React, { useState } from "react";
import ProfileHeader from "./Profile/ProfileHeader";
import ProfileStats from "./Profile/ProfileStats";
import ProfileTabs from "./Profile/ProfileTabs";
// import QuickActions from './Profile/QuickActions';
import { Trans } from "@lingui/macro";
import ProfileEducation from "./Profile/ProfileEducation";
import ProfileExperience from "./Profile/ProfileExperience";
import ProfileOverview from "./Profile/ProfileOverview";
import ProfileSkills from "./Profile/ProfileSkills";

const ProfileCandidate: React.FC = () => {
  const [activeTab, setActiveTab] = useState("Overview");

  const renderTabContent = () => {
    switch (activeTab) {
      case "Overview":
        return <ProfileOverview />;
      case "Experience":
        return <ProfileExperience />;
      case "Education":
        return <ProfileEducation />;
      case "Skills":
        return <ProfileSkills />;
      default:
        return <ProfileOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            <Trans>My Profile</Trans>
          </h1>
          <p className="text-gray-600">
            <Trans>
              Manage your professional profile and showcase your skills
            </Trans>
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <ProfileHeader />
              <ProfileTabs activeTab={activeTab} onTabChange={setActiveTab} />
              <div className="p-6">{renderTabContent()}</div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <ProfileStats />
            {/* <QuickActions /> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileCandidate;
