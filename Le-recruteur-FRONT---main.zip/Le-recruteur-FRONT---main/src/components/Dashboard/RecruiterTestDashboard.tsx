import { Button } from "@/components/ui/button";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { testService } from "@/lib/network/test";
import {
  Test,
  TestCategory,
  TestDifficulty,
  TestStatus,
  TestAnalytics,
} from "@/lib/types/test";
import {
  FileText,
  Filter,
  Plus,
  Search,
  BarChart3,
  Users,
  CheckCircle,
} from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import RecruiterHeader from "../Layout/RecruiterHeader";
import CreateTestModal from "./recruiterComponents/CreateTestModal";
import EditTestModal from "./recruiterComponents/EditTestModal";
import TestCard from "./recruiterComponents/TestCard";
import ViewTestModal from "./recruiterComponents/ViewTestModal";
import { toast } from "sonner";
import { Trans } from "@lingui/macro";
import { t } from "@lingui/core/macro";

const ITEMS_PER_PAGE = 6; // Show 6 test cards per page

const RecruiterTestDashboard = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  // State variables
  const [tests, setTests] = useState<Test[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalPages, setTotalPages] = useState(0);

  // Analytics state
  const [analytics, setAnalytics] = useState<TestAnalytics | null>(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);

  // Search and filter state
  const [searchTerm, setSearchTerm] = useState(
    searchParams.get("search") || ""
  );
  const [page, setPage] = useState<number>(
    parseInt(searchParams.get("page") || "1", 10)
  );
  const [category, setCategory] = useState<TestCategory | "ALL">(
    (searchParams.get("category") as TestCategory) || "ALL"
  );
  const [difficulty, setDifficulty] = useState<TestDifficulty | "ALL">(
    (searchParams.get("difficulty") as TestDifficulty) || "ALL"
  );
  const [status, setStatus] = useState<TestStatus | "ALL">(
    (searchParams.get("status") as TestStatus) || "ALL"
  );

  // Modal state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingTest, setEditingTest] = useState<Test | null>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [viewingTest, setViewingTest] = useState<Test | null>(null);
  const [deleteConfirmationOpen, setDeleteConfirmationOpen] = useState(false);
  const [testToDelete, setTestToDelete] = useState<string | null>(null);

  // Fetch tests from the API
  const fetchTests = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const queryParams = {
        page,
        limit: ITEMS_PER_PAGE,
        search: searchTerm || undefined,
        category: category === "ALL" ? undefined : (category as TestCategory),
        difficulty:
          difficulty === "ALL" ? undefined : (difficulty as TestDifficulty),
        status: status === "ALL" ? undefined : (status as TestStatus),
      };

      const response = await testService.getTests(queryParams);

      if (response.success) {
        setTests(response.data);
        // Get pagination info from metadata
        if (response.metadata?.pagination) {
          setTotalPages(response.metadata.pagination.totalPages);
        } else {
          setTotalPages(1); // Default to 1 page if pagination metadata is missing
        }
      } else {
        setError(t`Failed to fetch tests`);
        toast.error(t`Failed to load tests. Please try again.`);
      }
    } catch (err) {
      setError(t`An error occurred while fetching tests`);
      toast.error(
        t`Failed to connect to server. Please check your connection.`
      );
      console.error("Error fetching tests:", err);
    } finally {
      setLoading(false);
    }
  }, [page, searchTerm, category, difficulty, status]);

  // Fetch analytics data
  const fetchAnalytics = useCallback(async () => {
    setAnalyticsLoading(true);
    try {
      const response = await testService.getTestAnalytics();
      if (response.success) {
        setAnalytics(response.data);
      } else {
        console.error("Failed to fetch analytics");
      }
    } catch (err) {
      console.error("Error fetching analytics:", err);
    } finally {
      setAnalyticsLoading(false);
    }
  }, []);

  // Update search params when filters change
  useEffect(() => {
    const params: Record<string, string> = {};

    if (searchTerm) params.search = searchTerm;
    params.page = String(page);
    if (category && category !== "ALL") params.category = category;
    if (difficulty && difficulty !== "ALL") params.difficulty = difficulty;
    if (status && status !== "ALL") params.status = status;

    setSearchParams(params);
  }, [searchTerm, page, category, difficulty, status, setSearchParams]);

  // Read search params and set state
  useEffect(() => {
    const pageFromURL = parseInt(searchParams.get("page") || "1", 10);
    const searchFromURL = searchParams.get("search") || "";
    const categoryFromURL =
      (searchParams.get("category") as TestCategory) || "ALL";
    const difficultyFromURL =
      (searchParams.get("difficulty") as TestDifficulty) || "ALL";
    const statusFromURL = (searchParams.get("status") as TestStatus) || "ALL";

    setPage(pageFromURL);
    setSearchTerm(searchFromURL);
    setCategory(categoryFromURL);
    setDifficulty(difficultyFromURL);
    setStatus(statusFromURL);
  }, [searchParams]);

  // Fetch tests when dependencies change
  useEffect(() => {
    fetchTests();
  }, [fetchTests]);

  // Fetch analytics on component mount
  useEffect(() => {
    fetchAnalytics();
  }, [fetchAnalytics]);

  // Handle page change
  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };

  // Handle search
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setPage(1); // Reset to first page when searching
  };

  // Handle filter reset
  const handleClearFilter = () => {
    setSearchTerm("");
    setCategory("ALL");
    setDifficulty("ALL");
    setStatus("ALL");
    setPage(1);
  };

  // Modal handlers
  const handleCreateTest = () => {
    setIsCreateModalOpen(true);
  };

  const handleCloseCreateModal = (refresh: boolean = true) => {
    setIsCreateModalOpen(false);
    if (refresh) {
      fetchTests();
      fetchAnalytics();
    }
  };

  const handleEditTest = async (testId: string) => {
    try {
      setLoading(true);
      const response = await testService.getTestById(testId);

      if (response.success) {
        setEditingTest(response.data);
        setIsEditModalOpen(true);
      } else {
        toast.error(<Trans>Failed to load test details</Trans>);
      }
    } catch (err) {
      toast.error(<Trans>Failed to retrieve test details</Trans>);

      console.error("Error loading test for edit:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleCloseEditModal = (refresh: boolean = true) => {
    setIsEditModalOpen(false);
    setEditingTest(null);
    if (refresh) {
      fetchTests();
      fetchAnalytics();
    }
  };

  const handleViewTest = async (testId: string) => {
    try {
      setLoading(true);
      const response = await testService.getTestById(testId);

      if (response.success) {
        setViewingTest(response.data);
        setIsViewModalOpen(true);
      } else {
        toast.error(<Trans>Failed to load test details</Trans>);
      }
    } catch (err) {
      toast.error(<Trans>Failed to retrieve test details</Trans>);

      console.error("Error loading test for view:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleCloseViewModal = () => {
    setIsViewModalOpen(false);
    setViewingTest(null);
  };

  // Delete test handlers
  const handleDeleteRequest = (testId: string) => {
    setTestToDelete(testId);
    setDeleteConfirmationOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!testToDelete) return;

    try {
      setLoading(true);
      const response = await testService.deleteTest(testToDelete);

      if (response.success) {
        toast.success(<Trans>Test deleted successfully</Trans>);
        fetchTests();
        fetchAnalytics();
      } else {
        toast.error(<Trans>Failed to delete test</Trans>);
      }
    } catch (err) {
      toast.error(<Trans>Failed to delete test</Trans>);
      console.error("Error deleting test:", err);
    } finally {
      setLoading(false);
      setDeleteConfirmationOpen(false);
      setTestToDelete(null);
    }
  };

  const handleCancelDelete = () => {
    setDeleteConfirmationOpen(false);
    setTestToDelete(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 font-poppins">
      {/* Header */}
      <RecruiterHeader />

      {/* Main Content */}
      <main className="flex-1 overflow-auto bg-gray-50 p-6">
        {/* Test Management Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              <Trans>Test Management</Trans>
            </h1>
            <p className="text-gray-600">
              <Trans>Create, manage, and analyze your assessment tests.</Trans>
            </p>
          </div>
          <button
            onClick={handleCreateTest}
            className="flex items-center mr-6 px-5 py-2 bg-[#238D94] text-white rounded-lg hover:bg-[#1a6b75] transition-colors duration-200 font-medium shadow-sm hover:shadow-md"
          >
            <Plus className="w-5 h-5" />
            <span className="text-sm">
              <Trans>Create Test</Trans>
            </span>
          </button>
        </div>

        {/* Modals */}
        <CreateTestModal
          isOpen={isCreateModalOpen}
          onClose={handleCloseCreateModal}
        />

        {editingTest && (
          <EditTestModal
            isOpen={isEditModalOpen}
            onClose={handleCloseEditModal}
            test={editingTest}
          />
        )}

        {viewingTest && (
          <ViewTestModal
            isOpen={isViewModalOpen}
            onClose={handleCloseViewModal}
            testId={viewingTest.id}
            testData={viewingTest}
            onEditTest={handleEditTest}
          />
        )}

        {/* Analytics Section */}
        <div className="mb-6">
          {analyticsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[...Array(4)].map((_, index) => (
                <div
                  key={index}
                  className="bg-white p-6 rounded-lg shadow-sm border animate-pulse"
                >
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          ) : analytics ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Total Tests */}
              <div className="bg-white p-6 rounded-lg shadow-sm border hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      <Trans>Total Tests</Trans>
                    </p>
                    <p className="text-2xl font-bold text-gray-900">
                      {analytics.totalTests}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      <Trans>All created tests</Trans>
                    </p>
                  </div>
                  <div className="p-3 bg-blue-100 rounded-full">
                    <FileText className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </div>

              {/* Active Tests */}
              <div className="bg-white p-6 rounded-lg shadow-sm border hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      <Trans>Active Tests</Trans>
                    </p>
                    <p className="text-2xl font-bold text-green-600">
                      {analytics.activeTests}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      <Trans>Ready to assign</Trans>
                    </p>
                  </div>
                  <div className="p-3 bg-green-100 rounded-full">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </div>

              {/* Total Assignments */}
              <div className="bg-white p-6 rounded-lg shadow-sm border hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      <Trans>Total Assignments</Trans>
                    </p>
                    <p className="text-2xl font-bold text-purple-600">
                      {analytics.totalAssignedTests}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      <Trans>Tests assigned to candidates</Trans>
                    </p>
                  </div>
                  <div className="p-3 bg-purple-100 rounded-full">
                    <Users className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
              </div>

              {/* Completion Rate */}
              <div className="bg-white p-6 rounded-lg shadow-sm border hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      <Trans>Completion Rate</Trans>
                    </p>
                    <p className="text-2xl font-bold text-orange-600">
                      {analytics.totalAssignedTests > 0
                        ? Math.round(
                            (analytics.totalCompletedTests /
                              analytics.totalAssignedTests) *
                              100
                          )
                        : 0}
                      %
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      <Trans>
                        {analytics.totalCompletedTests} of{" "}
                        {analytics.totalAssignedTests} completed
                      </Trans>
                    </p>
                  </div>
                  <div className="p-3 bg-orange-100 rounded-full">
                    <BarChart3 className="h-6 w-6 text-orange-600" />
                  </div>
                </div>
              </div>
            </div>
          ) : null}
        </div>

        {/* Search and Filter Section */}
        <div className="flex items-center flex-wrap gap-4 mb-6 bg-white px-6 py-4 rounded-lg">
          {/* Search Input */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder={t`Search tests...`}
              value={searchTerm}
              onChange={handleSearchChange}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-transparent outline-none transition-all duration-200 bg-white"
            />
          </div>

          {/* Filter Dropdowns */}
          <div className="flex flex-wrap gap-3">
            <div className="w-[150px]">
              <Select
                value={category}
                onValueChange={(value) => setCategory(value as TestCategory)}
              >
                <SelectTrigger>
                  <SelectValue placeholder={<Trans>Category</Trans>} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">
                    <Trans>All Categories</Trans>
                  </SelectItem>
                  <SelectItem value="LANGUAGE">
                    <Trans>Programming</Trans>
                  </SelectItem>
                  <SelectItem value="SKILL">
                    <Trans>Skill</Trans>
                  </SelectItem>
                  <SelectItem value="PERSONALITY">
                    <Trans>Personality</Trans>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="w-[150px]">
              <Select
                value={difficulty}
                onValueChange={(value) =>
                  setDifficulty(value as TestDifficulty)
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder={<Trans>Difficulty</Trans>} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">
                    <Trans>All Difficulties</Trans>
                  </SelectItem>
                  <SelectItem value="EASY">
                    <Trans>Easy</Trans>
                  </SelectItem>
                  <SelectItem value="MEDIUM">
                    <Trans>Medium</Trans>
                  </SelectItem>
                  <SelectItem value="HARD">
                    <Trans>Hard</Trans>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="w-[150px]">
              <Select
                value={status}
                onValueChange={(value) => setStatus(value as TestStatus)}
              >
                <SelectTrigger>
                  <SelectValue placeholder={<Trans>Status</Trans>} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">
                    <Trans>All Statuses</Trans>
                  </SelectItem>
                  <SelectItem value="ACTIVE">
                    <Trans>Active</Trans>
                  </SelectItem>
                  <SelectItem value="DRAFT">
                    <Trans>Draft</Trans>
                  </SelectItem>
                  <SelectItem value="INACTIVE">
                    <Trans>Inactive</Trans>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button
              onClick={handleClearFilter}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Filter className="w-4 h-4" />
              <Trans>Clear</Trans>
            </Button>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="flex justify-center items-center py-12">
            <div className="w-12 h-12 border-4 border-t-4 border-gray-200 border-t-[#238D94] rounded-full animate-spin"></div>
          </div>
        )}

        {/* Error State */}
        {error && !loading && (
          <div className="bg-red-50 border border-red-200 text-red-800 rounded-lg p-4 mb-6">
            <p>{error}</p>
            <button
              onClick={fetchTests}
              className="mt-2 text-sm font-medium text-red-700 hover:text-red-900 underline"
            >
              <Trans>Try again</Trans>
            </button>
          </div>
        )}

        {/* Empty State */}
        {!loading && !error && tests.length === 0 && (
          <div className="bg-white border border-gray-200 rounded-lg p-8 text-center mb-6">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8 text-gray-500" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              <Trans>No tests found</Trans>
            </h3>
            <p className="text-gray-600 mb-6">
              {searchTerm || category || difficulty || status ? (
                <Trans>
                  No tests match your filter criteria. Try adjusting your
                  filters.
                </Trans>
              ) : (
                <Trans>
                  You haven't created any tests yet. Get started by creating
                  your first test.
                </Trans>
              )}
            </p>
            <button
              onClick={handleCreateTest}
              className="inline-flex items-center px-4 py-2 bg-[#238D94] text-white rounded-lg hover:bg-[#1a6b75] transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              <Trans>Create Your First Test</Trans>
            </button>
          </div>
        )}

        {/* Test cards */}
        {!loading && !error && tests.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
            {tests.map((test) => (
              <TestCard
                key={test.id}
                id={test.id}
                title={test.title}
                description={test.description}
                duration={test.duration}
                passedTestCount={test.passedTestCount}
                category={test.category}
                difficulty={test.difficulty}
                status={test.status}
                passingScore={test.passingScore}
                onView={handleViewTest}
                onEdit={handleEditTest}
                onDelete={handleDeleteRequest}
              />
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center">
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      handlePageChange(Math.max(1, page - 1));
                    }}
                    className={
                      page === 1 ? "pointer-events-none opacity-50" : ""
                    }
                  />
                </PaginationItem>

                {Array.from({ length: totalPages }, (_, i) => ({
                  number: i + 1,
                  active: i + 1 === page,
                })).map((item) => (
                  <PaginationItem key={item.number}>
                    <PaginationLink
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        handlePageChange(item.number);
                      }}
                      className={`w-10 h-10 rounded-lg flex items-center justify-center font-semibold text-base ${
                        item.active
                          ? "bg-[#238d94] text-white"
                          : "text-[#192335]"
                      }`}
                    >
                      {item.number}
                    </PaginationLink>
                  </PaginationItem>
                ))}

                <PaginationItem>
                  <PaginationNext
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      handlePageChange(Math.min(totalPages, page + 1));
                    }}
                    className={
                      page === totalPages
                        ? "pointer-events-none opacity-50"
                        : ""
                    }
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        )}

        {/* Delete Confirmation Dialog */}
        {deleteConfirmationOpen && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                <Trans>Confirm Delete</Trans>
              </h3>
              <p className="text-gray-600 mb-6">
                <Trans>
                  Are you sure you want to delete this test? This action cannot
                  be undone.
                </Trans>
              </p>
              <div className="flex justify-end gap-3">
                <button
                  onClick={handleCancelDelete}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  <Trans>Cancel</Trans>
                </button>
                <button
                  onClick={handleConfirmDelete}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  <Trans>Delete</Trans>
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default RecruiterTestDashboard;
