import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import {
  Key,
  Users,
  TrendingUp,
  DollarSign,
  Activity,
  CheckCircle,
  XCircle,
  Clock,
  Zap,
} from "lucide-react";
import { Trans } from "@lingui/macro";

interface LicenseStats {
  totalLicenses: number;
  activeLicenses: number;
  expiredLicenses: number;
  suspendedLicenses: number;
  assignedLicenses: number;
  unassignedLicenses: number;
  totalRevenue: number;
  monthlyRevenue: number;
  expiringThisMonth: number;
  recentActivity: number;
}

interface LicenseStatsCardsProps {
  stats: LicenseStats;
}

export const LicenseStatsCards: React.FC<LicenseStatsCardsProps> = ({
  stats,
}) => {
  const statsCards = [
    {
      title: <Trans>Total Licenses</Trans>,
      value: stats.totalLicenses,
      icon: Key,
      trend: <Trans>+12% from last month</Trans>,
      color: "bg-ehc-green",
      textColor: "text-ehc-green",
      bgGradient: "from-ehc-green/10 to-ehc-green/5",
    },
    {
      title: <Trans>Active Licenses</Trans>,
      value: stats.activeLicenses,
      icon: CheckCircle,
      trend: (
        <Trans>
          {((stats.activeLicenses / stats.totalLicenses) * 100).toFixed(1)}% of
          total
        </Trans>
      ),
      color: "bg-green-500",
      textColor: "text-green-600",
      bgGradient: "from-green-500/10 to-green-500/5",
    },
    {
      title: <Trans>Assigned Users</Trans>,
      value: stats.assignedLicenses,
      icon: Users,
      trend: <Trans>{stats.unassignedLicenses} available</Trans>,
      color: "bg-blue-500",
      textColor: "text-blue-600",
      bgGradient: "from-blue-500/10 to-blue-500/5",
    },
    {
      title: <Trans>Total Revenue</Trans>,
      value: `$${stats.totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      trend: <Trans>+18% growth this month</Trans>,
      color: "bg-purple-500",
      textColor: "text-purple-600",
      bgGradient: "from-purple-500/10 to-purple-500/5",
    },
    {
      title: <Trans>Monthly Revenue</Trans>,
      value: `$${stats.monthlyRevenue.toLocaleString()}`,
      icon: TrendingUp,
      trend: <Trans>Target: $50K</Trans>,
      color: "bg-orange-500",
      textColor: "text-orange-600",
      bgGradient: "from-orange-500/10 to-orange-500/5",
    },
    {
      title: <Trans>Expiring Soon</Trans>,
      value: stats.expiringThisMonth,
      icon: Clock,
      trend: <Trans>Within 30 days</Trans>,
      color: "bg-yellow-500",
      textColor: "text-yellow-600",
      bgGradient: "from-yellow-500/10 to-yellow-500/5",
    },
    {
      title: <Trans>Suspended</Trans>,
      value: stats.suspendedLicenses,
      icon: XCircle,
      trend: <Trans>Requires attention</Trans>,
      color: "bg-red-500",
      textColor: "text-red-600",
      bgGradient: "from-red-500/10 to-red-500/5",
    },
    {
      title: <Trans>Recent Activity</Trans>,
      value: stats.recentActivity,
      icon: Activity,
      trend: <Trans>Last 24 hours</Trans>,
      color: "bg-indigo-500",
      textColor: "text-indigo-600",
      bgGradient: "from-indigo-500/10 to-indigo-500/5",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statsCards.map((card, index) => (
        <Card
          key={index}
          className={`relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 bg-gradient-to-br ${card.bgGradient} backdrop-blur-sm border border-white/20`}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
            <CardTitle className="text-sm font-medium text-gray-600">
              {card.title}
            </CardTitle>
            <div className={`p-2 rounded-lg ${card.color}/10 backdrop-blur-sm`}>
              <card.icon className={`h-5 w-5 ${card.textColor}`} />
            </div>
          </CardHeader>

          <CardContent className="relative z-10">
            <div className={`text-2xl font-bold ${card.textColor} mb-1`}>
              {card.value}
            </div>
            <p className="text-xs text-gray-500 flex items-center gap-1">
              <Zap className="h-3 w-3" />
              {card.trend}
            </p>
          </CardContent>

          {/* Futuristic glow effect */}
          <div
            className={`absolute inset-0 bg-gradient-to-r ${card.bgGradient} opacity-0 hover:opacity-20 transition-opacity duration-300`}
          ></div>
        </Card>
      ))}
    </div>
  );
};