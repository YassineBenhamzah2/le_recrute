/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect, useMemo } from "react";

import {
  Search,
  Plus,
  Calendar,
  Edit,
  Trash2,
  CheckCircle2Icon,
  AlertCircleIcon,
} from "lucide-react";
import { useDebounce } from "../Auth/hooks/useDebounce";
import { cn } from "@/lib/utils";

// Import Shadcn UI Components
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
  PaginationEllipsis,
} from "@/components/ui/pagination";

// Your project's components and API utility
import ServicesForm from "./AdminComponents/ServicesForm";
import { api } from "../../lib/network/utils/api";
import { settings } from "@/lib/settings/main";
import { Trans, t } from "@lingui/macro";
import { useLingui } from "@lingui/react";

// --- INTERFACES ---
interface ServiceFromDB {
  id: number;
  title: string;
  description: string;
  price: number;
  status: "ACTIVE" | "INACTIVE";
  imageUrl: string;
  createdAt: string;
}

interface PaginatedResponse<T> {
  data: T[];
  totalCount: number;
  currentPage: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

type NotificationState = {
  title: string;
  description?: React.ReactNode;
  variant: "success" | "destructive";
} | null;

const AdminServices: React.FC = () => {
  // --- STATE MANAGEMENT ---
  const [servicesFromAPI, setServicesFromAPI] = useState<ServiceFromDB[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingService, setEditingService] = useState<ServiceFromDB | null>(
    null
  );
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [hasNextPage, setHasNextPage] = useState(false);
  const [hasPreviousPage, setHasPreviousPage] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("All Status");
  const [notification, setNotification] = useState<NotificationState>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const { i18n } = useLingui();
  const isRTL = i18n.locale === "ar";

  // Use the custom debounce hook with 500ms delay
  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  // --- DATA FETCHING & SIDE EFFECTS ---

  // Fetches data from the server. Notice it does NOT use the search term.
  useEffect(() => {
    const fetchData = async () => {
      try {
        const params = new URLSearchParams({
          page: currentPage.toString(),
          size: "2",
          sort: "createdAt,desc",
        });
        if (statusFilter !== "All Status")
          params.append("status", statusFilter.toUpperCase());
        if (debouncedSearchTerm) {
          params.append("searchTerm", debouncedSearchTerm);
        }

        const response = await api.getItem<PaginatedResponse<ServiceFromDB>>(
          `/candidate-services?${params.toString()}`
        );

        setServicesFromAPI(response.data);
        setTotalPages(response.totalPages);
        setTotalElements(response.totalCount);
        // Don't update currentPage from response - we're managing it locally
        // This prevents another source of infinite loops
        // setCurrentPage(response.currentPage);
        setHasNextPage(response.hasNextPage);
        setHasPreviousPage(response.hasPreviousPage);
      } catch (err: any) {
        const errorMessage =
          err.message ||
          err.response?.data?.message ||
          "Could not connect to the server.";
        setNotification({
          title: t`Network Error`,
          description: errorMessage,
          variant: "destructive",
        });
      }
    };

    fetchData();
  }, [currentPage, statusFilter, refreshKey, debouncedSearchTerm]);

  // Use a ref to track previous search term and status filter
  const prevFiltersRef = React.useRef({
    searchTerm: debouncedSearchTerm,
    statusFilter,
  });

  // Resets the page to 0 when the filter changes
  useEffect(() => {
    // Only reset page when filters actually change (not on first render)
    const prevFilters = prevFiltersRef.current;

    if (
      prevFilters.searchTerm !== debouncedSearchTerm ||
      prevFilters.statusFilter !== statusFilter
    ) {
      // Update reference for next comparison
      prevFiltersRef.current = {
        searchTerm: debouncedSearchTerm,
        statusFilter,
      };

      // Reset to page 0 when filters change
      if (currentPage !== 0) {
        setCurrentPage(0);
      }
    }
  }, [statusFilter, debouncedSearchTerm, currentPage]); // 3. Manages the notification timer.
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // --- EVENT HANDLERS ---
  const handleAddService = () => {
    setEditingService(null);
    setShowForm(true);
  };

  const handleEditService = (service: ServiceFromDB) => {
    setEditingService(service);
    setShowForm(true);
  };

  const handleDeleteService = async (serviceId: number) => {
    try {
      await api.delete(`/candidate-services/${serviceId}`);
      setNotification({
        title: t`Success!`,
        description: t`The service has been deleted.`,
        variant: "success",
      });
      setRefreshKey((k) => k + 1);
    } catch (err: any) {
      const errorMessage =
        err.message ||
        err.response?.data?.message ||
        "Failed to delete the service.";
      setNotification({
        title: t`Error!`,
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const handleSaveService = async (
    serviceData: Partial<ServiceFromDB>,
    imageFile: File | null
  ) => {
    const formData = new FormData();
    formData.append("serviceData", JSON.stringify(serviceData));
    if (imageFile) formData.append("imageFile", imageFile);

    try {
      const promise = editingService
        ? api.put(`/candidate-services/${editingService.id}`, formData)
        : api.post("/candidate-services", formData);
      await promise;

      setShowForm(false);
      setEditingService(null);
      setNotification({
        title: t`Success!`,
        description: editingService ? (
          <Trans>Service has been updated.</Trans>
        ) : (
          <Trans>Service has been created.</Trans>
        ),
        variant: "success",
      });
      setRefreshKey((k) => k + 1);
    } catch (err: any) {
      const errorMessage =
        err.message ||
        err.response?.data?.message ||
        `Failed to ${editingService ? "update" : "create"} the service.`;
      setNotification({
        title: t`Unable to Save`,
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  // --- PAGINATION LOGIC ---
  const pageNumbers = useMemo(() => {
    const displayTotalPages = totalPages;

    const siblingCount = 1;
    const totalPageNumbers = siblingCount + 5;

    if (displayTotalPages <= totalPageNumbers) {
      return Array.from({ length: displayTotalPages }, (_, i) => i + 1);
    }

    const middleRangeStart = Math.max(1, currentPage - siblingCount);
    const middleRangeEnd = Math.min(
      displayTotalPages,
      currentPage + siblingCount + 2
    );

    const middleRange = Array.from(
      { length: middleRangeEnd - middleRangeStart },
      (_, i) => middleRangeStart + i
    );

    let items: (number | "...")[] = [...middleRange];

    if (middleRange[0] > 2) {
      items = [1, "...", ...items];
    } else if (middleRange[0] === 2) {
      items = [1, ...items];
    }

    if (+items[items.length - 1] < displayTotalPages - 1) {
      items = [...items, "...", displayTotalPages];
    } else if (items[items.length - 1] === displayTotalPages - 1) {
      items = [...items, displayTotalPages];
    }

    return items;
  }, [currentPage, totalPages]);

  return (
    <div className="flex h-screen bg-gray-50">
      {notification && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 w-full max-w-xl z-[100] animate-in fade-in-5 slide-in-from-top-5">
          <Alert
            variant={
              notification.variant === "destructive" ? "destructive" : "default"
            }
            className={cn(
              "bg-background",
              notification.variant === "success" &&
                "border-green-500/50 text-green-700 dark:border-green-500 [&>[data-slot=icon]]:text-green-700"
            )}
          >
            {notification.variant === "destructive" ? (
              <AlertCircleIcon className="h-4 w-4" data-slot="icon" />
            ) : (
              <CheckCircle2Icon className="h-4 w-4" data-slot="icon" />
            )}
            <AlertTitle>{notification.title}</AlertTitle>
            {notification.description && (
              <AlertDescription>{notification.description}</AlertDescription>
            )}
          </Alert>
        </div>
      )}

      <div className="flex-1 overflow-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-semibold">
              <Trans>Candidate Services</Trans>
            </h1>
            <p className="text-gray-600 mt-1">
              <Trans>Manage all candidate services</Trans>
            </p>
          </div>
          <Button
            onClick={handleAddService}
            className="bg-teal-600 hover:bg-teal-700"
          >
            <Plus size={20} className="mr-2" /> <Trans>Add New Service</Trans>
          </Button>
        </div>

        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
              size={20}
            />
            <input
              type="text"
              placeholder={t`Search all services...`}
              className="w-full pl-10 pr-4 py-2 border rounded-lg"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            title="Filter by Status"
            className={`border rounded-lg  py-2 ${isRTL ? "" : "px-3"}`}
          >
            <option>
              <Trans>All Status</Trans>
            </option>
            <option value="ACTIVE">
              <Trans>Active</Trans>
            </option>
            <option value="INACTIVE">
              <Trans>Inactive</Trans>
            </option>
          </select>
          <div className="text-gray-600 py-2 px-3">
            {totalElements} <Trans>total services</Trans>
          </div>
        </div>

        {servicesFromAPI.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-lg border">
            <h3 className="text-xl font-medium">
              <Trans>No Services Found</Trans>
            </h3>
            <p className="text-gray-500 mt-2">
              {searchTerm ? (
                <Trans>Try a different search term.</Trans>
              ) : (
                <Trans>There are no services for this filter.</Trans>
              )}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {servicesFromAPI.map((service) => (
              <div
                key={service.id}
                className="bg-white rounded-lg shadow-sm border overflow-hidden flex flex-col"
              >
                <img
                  src={`${settings.IMG_ADDRESS}${service.imageUrl}`}
                  alt={service.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4 flex-grow flex flex-col">
                  <h3 className="font-semibold mt-2 truncate">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 text-sm my-2 line-clamp-2 flex-grow">
                    {service.description}
                  </p>
                  <div className="flex justify-between items-center pt-3 mt-4 border-t">
                    <div className="text-gray-500 text-sm flex items-center gap-1">
                      <Calendar size={14} />
                      {new Date(service.createdAt).toLocaleDateString()}
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleEditService(service)}
                        title="Edit Service"
                        className="p-1 text-gray-400 hover:text-teal-600"
                      >
                        <Edit size={16} />
                      </button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <button
                            title="Delete Service"
                            className="p-1 text-gray-400 hover:text-red-600"
                          >
                            <Trash2 size={16} />
                          </button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>
                              <Trans>Confirm Deletion</Trans>
                            </AlertDialogTitle>
                          </AlertDialogHeader>
                          <AlertDialogDescription>
                            <Trans>Are you sure you want to delete</Trans> "
                            {service.title}"?
                            <Trans>This action cannot be undone.</Trans>
                          </AlertDialogDescription>
                          <AlertDialogFooter>
                            <AlertDialogCancel>
                              <Trans>Cancel</Trans>
                            </AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDeleteService(service.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              <Trans>Delete</Trans>
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {totalPages > 1 && (
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    setCurrentPage((p) => p - 1);
                  }}
                  className={
                    !hasPreviousPage ? "pointer-events-none opacity-50" : ""
                  }
                />
              </PaginationItem>
              {pageNumbers.map((pageNumber, index) => {
                if (pageNumber === "...") {
                  return (
                    <PaginationItem key={`ellipsis-${index}`}>
                      <PaginationEllipsis />
                    </PaginationItem>
                  );
                }
                const pageIndex =
                  typeof pageNumber === "number" ? pageNumber - 1 : 0;
                return (
                  <PaginationItem key={pageNumber}>
                    <PaginationLink
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        setCurrentPage(pageIndex);
                      }}
                      isActive={pageIndex === currentPage}
                    >
                      {pageNumber}
                    </PaginationLink>
                  </PaginationItem>
                );
              })}
              <PaginationItem>
                <PaginationNext
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    setCurrentPage((p) => p + 1);
                  }}
                  className={
                    !hasNextPage ? "pointer-events-none opacity-50" : ""
                  }
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        )}

        {showForm && (
          <ServicesForm
            type="candidate"
            service={editingService}
            onSave={handleSaveService}
            onCancel={() => setShowForm(false)}
          />
        )}
      </div>
    </div>
  );
};

export default AdminServices;
