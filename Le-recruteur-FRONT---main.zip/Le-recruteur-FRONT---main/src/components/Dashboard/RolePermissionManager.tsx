/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../ui/card";
import { Badge } from "../ui/badge";
import {
  Search,
  Plus,
  Minus,
  X,
  Edit,
  Trash2,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../ui/alert-dialog";
import { Textarea } from "../ui/textarea";
import { Label } from "../ui/label";

import { roleService, permissionService } from "../../lib/network/roles";
import {
  Role,
  Permission,
  AssignPermissionsRequest,
} from "../../lib/types/license";
import { usePermissions } from "../../hooks/usePermissions";
import { PermissionGuard } from "../guards/PermissionGuard";
import { CreateRoleModal } from "../Modals/CreateRoleModal";
import { Checkbox } from "../ui/checkbox";
import { Trans, t } from '@lingui/macro';

interface RolePermissionManagerProps {
  roleId?: number;
}

export const RolePermissionManager: React.FC<RolePermissionManagerProps> = ({
  roleId,
}) => {
  const { hasPermission, hasAnyPermission, isAdmin } = usePermissions();

  const [roles, setRoles] = useState<Role[]>([]);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [availablePermissions, setAvailablePermissions] = useState<
    Permission[]
  >([]);
  const [selectedPermissions, setSelectedPermissions] = useState<number[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [roleSearchQuery, setRoleSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editRoleData, setEditRoleData] = useState<{
    name: string;
    description: string;
  }>({
    name: "",
    description: "",
  });

  // Permission-based access control
  const canViewRoles =
    isAdmin() || hasAnyPermission(["ADMINISTRATOR", "VIEWER_ROLE"]);
  const canEditRoles = isAdmin() || hasPermission("ADMINISTRATOR");

  // Memoized filtered permissions based on selected role type
  const filteredAvailablePermissions = useMemo(() => {
    if (!selectedRole) return [];

    return availablePermissions.filter((permission) => {
      const matchesSearch =
        permission.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (permission.description &&
          permission.description
            .toLowerCase()
            .includes(searchQuery.toLowerCase()));

      // Filter permissions by role type - only show matching permissions
      const matchesRoleType =
        permission.permissionType === selectedRole.roleType;

      return matchesSearch && matchesRoleType;
    });
  }, [availablePermissions, searchQuery, selectedRole]);

  useEffect(() => {
    if (canViewRoles) {
      loadRoles();
    }
  }, [canViewRoles]);

  useEffect(() => {
    if (roleId && roles.length > 0) {
      const role = roles.find((r) => r.id === roleId);
      if (role) {
        setSelectedRole(role);
      }
    }
  }, [roleId, roles]);

  const loadRoles = async () => {
    try {
      setIsLoading(true);
      const response = await roleService.getAll();
      setRoles(response.data.filter((role) => role.roleType !== "CANDIDATE"));
    } catch (error) {
      console.error("Error loading roles:", error);
      toast.error(t({ id: "role_manager.errors.loading_roles", message: "Error loading roles" }));
    } finally {
      setIsLoading(false);
    }
  };

  const loadAvailablePermissions = useCallback(async () => {
    if (!selectedRole) return;

    try {
      // Fetch permissions by role type from API
      const response = await permissionService.getByType(selectedRole.roleType);
      const allPermissionsForType = response.data;

      // Filter out permissions already assigned to this role
      const assignedPermissionIds = selectedRole.permissions.map((p) => p.id);
      const availablePermissions = allPermissionsForType.filter(
        (permission) => !assignedPermissionIds.includes(permission.id)
      );

      setAvailablePermissions(availablePermissions);
    } catch (error) {
      console.error("Error loading available permissions:", error);
      toast.error(t({ id: "role_manager.errors.loading_permissions", message: "Error loading available permissions" }));
    }
  }, [selectedRole]);

  // Load available permissions when selectedRole changes
  useEffect(() => {
    if (selectedRole) {
      loadAvailablePermissions();
    }
  }, [selectedRole, loadAvailablePermissions]);

  const handleRoleSelect = (role: Role) => {
    setSelectedRole(role);
    setSelectedPermissions([]);
  };

  const handlePermissionToggle = (permissionId: number) => {
    setSelectedPermissions((prev) =>
      prev.includes(permissionId)
        ? prev.filter((id) => id !== permissionId)
        : [...prev, permissionId]
    );
  };

  const handleAssignPermissions = async () => {
    if (!selectedRole || selectedPermissions.length === 0 || !canEditRoles) {
      return;
    }

    try {
      setIsSaving(true);
      const request: AssignPermissionsRequest = {
        roleId: selectedRole.id,
        permissionIds: selectedPermissions,
      };

      const newRole = await roleService.assignPermissions(request);
      setSelectedRole(newRole.data);
      toast.success(
        t({ 
          id: "role_manager.success.permissions_assigned", 
          message: "Assigned {count} permissions to {roleName}",
          values: { count: selectedPermissions.length, roleName: selectedRole.name }
        }),
        {
          className: "bg-ehc-green text-white",
        }
      );

      // Reload data
      await loadRoles();
      await loadAvailablePermissions();
      setSelectedPermissions([]);
    } catch (error) {
      console.error("Error assigning permissions:", error);
      toast.error(t({ id: "role_manager.errors.assigning_permissions", message: "Error assigning permissions" }));
    } finally {
      setIsSaving(false);
    }
  };

  const handleRemovePermission = async (permissionId: number) => {
    if (!selectedRole || !canEditRoles) {
      return;
    }

    try {
      const newRole = await roleService.removePermission(
        selectedRole.id,
        permissionId
      );
      setSelectedRole(newRole.data);
      toast.success(t({ id: "role_manager.success.permission_removed", message: "Permission removed successfully" }), {
        className: "bg-ehc-green text-white",
      });

      // Reload data
      await loadRoles();
      await loadAvailablePermissions();
    } catch (error) {
      console.error("Error removing permission:", error);
      toast.error((error as Error).message || t({ id: "role_manager.errors.removing_permission", message: "Error removing permission" }));
    }
  };

  const getPermissionTypeBadge = (type: string) => {
    const colors = {
      ADMIN:
        "bg-red-100 text-red-800 border-red-200 hover:bg-red-200 hover:text-red-900",
      RECRUITER:
        "bg-blue-100 text-blue-800 border-blue-200 hover:bg-blue-200 hover:text-blue-900",
      CANDIDATE:
        "bg-green-100 text-green-800 border-green-200 hover:bg-green-200 hover:text-green-900",
    };

    return (
      <Badge
        className={
          colors[type as keyof typeof colors] ||
          "bg-gray-100 text-gray-800 border-gray-200 hover:bg-gray-200 hover:text-gray-900"
        }
      >
        {type}
      </Badge>
    );
  };

  const filteredRoles = roles.filter(
    (role) =>
      role.name.toLowerCase().includes(roleSearchQuery.toLowerCase()) ||
      (role.description &&
        role.description.toLowerCase().includes(roleSearchQuery.toLowerCase()))
  );

  const handleCreateRole = () => {
    loadRoles();
  };

  const handleEditRole = async () => {
    if (!selectedRole || !canEditRoles) return;

    try {
      const updateData = {
        name: editRoleData.name,
        description: editRoleData.description,
      };

      await roleService.updateRole(selectedRole.id, updateData);

      toast.success(t({ id: "role_manager.success.role_updated", message: "Role updated successfully" }), {
        className: "bg-ehc-green text-white",
      });

      // Refresh data
      await loadRoles();
      setIsEditModalOpen(false);

      // Update selectedRole if it's still the same
      const updatedRoles = await roleService.getAll();
      const updatedRole = updatedRoles.data.find(
        (r) => r.id === selectedRole.id
      );
      if (updatedRole) {
        setSelectedRole(updatedRole);
      }
    } catch (error) {
      console.error("Error updating role:", error);
      toast.error(t({ id: "role_manager.errors.updating_role", message: "Failed to update role" }));
    }
  };

  const handleDeleteRole = async () => {
    if (!selectedRole || !canEditRoles) return;

    try {
      await roleService.deleteRole(selectedRole.id);

      toast.success(t({ id: "role_manager.success.role_deleted", message: "Role deleted successfully" }), {
        className: "bg-ehc-green text-white",
      });

      // Refresh data and clear selection
      setSelectedRole(null);
      await loadRoles();
      setIsDeleteDialogOpen(false);
    } catch (error: any) {
      console.error("Error deleting role:", error);

      // Handle specific error cases
      if (error.response?.status === 409) {
        toast.error(
          t({ id: "role_manager.errors.delete_assigned_role", message: "Cannot delete role that is currently assigned to licenses" })
        );
      } else {
        toast.error(t({ id: "role_manager.errors.deleting_role", message: "Failed to delete role" }));
      }
    }
  };

  const openEditModal = (role: Role) => {
    setEditRoleData({
      name: role.name,
      description: role.description || "",
    });
    setIsEditModalOpen(true);
  };

  if (!canViewRoles) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <p className="text-gray-500 mb-2">
            <Trans id="role_manager.access_denied.title">Access Denied</Trans>
          </p>
          <p className="text-sm text-gray-400">
            <Trans id="role_manager.access_denied.message">
              You don't have permission to manage roles and permissions.
            </Trans>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Component Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-ehc-green mb-1">
          <Trans id="role_manager.header.title">Role Management</Trans>
        </h2>
        <p className="text-gray-600">
          <Trans id="role_manager.header.description">
            Manage roles and their assigned permissions
          </Trans>
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Role Selection */}
        <Card className="border-ehc-green/10 shadow-lg">
          <CardHeader className="border-b border-ehc-green/10 bg-gradient-to-r from-ehc-green/5 to-transparent">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-ehc-green">
                  <Trans id="role_manager.role_selection.title">Select Role</Trans>
                </CardTitle>
                <CardDescription>
                  <Trans id="role_manager.role_selection.description">
                    Choose a role to manage its permissions
                  </Trans>
                </CardDescription>
              </div>
              <PermissionGuard permissions={["ADMINISTRATOR"]} fallback={null}>
                <Button
                  onClick={() => setIsCreateModalOpen(true)}
                  size="sm"
                  className="flex items-center gap-2 bg-ehc-green hover:bg-ehc-green/90 text-white"
                >
                  <Plus className="h-4 w-4" />
                  <Trans id="role_manager.role_selection.create_button">Create Role</Trans>
                </Button>
              </PermissionGuard>
            </div>
          </CardHeader>
          <CardContent>
            {/* Role Search */}
            <div className="my-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder={t({ id: "role_manager.role_selection.search_placeholder", message: "Search roles by name or description..." })}
                  value={roleSearchQuery}
                  onChange={(e) => setRoleSearchQuery(e.target.value)}
                  className="pl-10 pr-10 border-gray-200 focus:border-ehc-green focus:ring-ehc-green/20 transition-all duration-200"
                />
                {roleSearchQuery && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setRoleSearchQuery("")}
                    className="absolute right-1 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                    title={t({ id: "role_manager.common.clear_search", message: "Clear search" })}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </div>

            {isLoading ? (
              <div className="space-y-2">
                {[...Array(4)].map((_, i) => (
                  <div
                    key={i}
                    className="h-16 bg-gray-200 rounded animate-pulse"
                  ></div>
                ))}
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredRoles.length === 0 ? (
                  <p className="text-gray-500 text-sm">
                    {roleSearchQuery
                      ? t({ id: "role_manager.role_selection.no_results", message: "No roles found matching your search" })
                      : t({ id: "role_manager.role_selection.no_roles", message: "No roles available" })}
                  </p>
                ) : (
                  filteredRoles.map((role) => (
                    <div
                      key={role.id}
                      className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                        selectedRole?.id === role.id
                          ? "border-ehc-green bg-ehc-green/5"
                          : "border-gray-200 hover:border-ehc-green/30"
                      }`}
                      onClick={() => handleRoleSelect(role)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold">{role.name}</h3>
                          {role.description && (
                            <p className="text-sm text-gray-600 mt-1">
                              {role.description}
                            </p>
                          )}
                          <p className="text-xs text-gray-500 mt-1">
                            {role.permissions.length} {" "}
                            {role.permissions.length === 1 
                              ? t({ id: "role_manager.role_selection.permission_singular", message: "permission" })
                              : t({ id: "role_manager.role_selection.permission_plural", message: "permissions" })
                            }
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          {getPermissionTypeBadge(role.roleType)}

                          {canEditRoles && selectedRole?.id === role.id && (
                            <div className="flex gap-1 ml-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 w-7 p-0 text-ehc-green hover:bg-ehc-green/10 hover:text-ehc-green"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openEditModal(role);
                                }}
                                title={t({ id: "role_manager.role_selection.edit_tooltip", message: "Edit role" })}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 w-7 p-0 text-red-600 hover:bg-red-50 hover:text-red-700"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setIsDeleteDialogOpen(true);
                                }}
                                title={t({ id: "role_manager.role_selection.delete_tooltip", message: "Delete role" })}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Current Permissions */}
        <Card className="border-ehc-green/10 shadow-lg">
          <CardHeader className="border-b border-ehc-green/10 bg-gradient-to-r mb-4 from-ehc-green/5 to-transparent">
            <CardTitle className="text-ehc-green">
              <Trans id="role_manager.current_permissions.title">Current Permissions</Trans>
            </CardTitle>
            <CardDescription>
              {selectedRole
                ? t({ 
                    id: "role_manager.current_permissions.description_with_role", 
                    message: "Permissions for {roleName}",
                    values: { roleName: selectedRole.name }
                  })
                : t({ id: "role_manager.current_permissions.description_no_role", message: "Select a role to view permissions" })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {selectedRole ? (
              <div className="space-y-2">
                {selectedRole.permissions.length === 0 ? (
                  <p className="text-gray-500 text-sm">
                    <Trans id="role_manager.current_permissions.no_permissions">No permissions assigned</Trans>
                  </p>
                ) : (
                  selectedRole.permissions.map((permission) => (
                    <div
                      key={permission.id}
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">
                            {permission.name}
                          </span>
                          {getPermissionTypeBadge(permission.permissionType)}
                        </div>
                        {permission.description && (
                          <p className="text-xs text-gray-600">
                            {permission.description}
                          </p>
                        )}
                      </div>
                      <PermissionGuard
                        permissions={["ADMINISTRATOR"]}
                        fallback={null}
                      >
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemovePermission(permission.id)}
                          className="text-red-600 hover:text-red-700"
                          title={t({ id: "role_manager.current_permissions.remove_tooltip", message: "Remove permission" })}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                      </PermissionGuard>
                    </div>
                  ))
                )}
              </div>
            ) : (
              <p className="text-gray-500 text-sm">
                <Trans id="role_manager.current_permissions.select_role_message">
                  Select a role to view its permissions
                </Trans>
              </p>
            )}
          </CardContent>
        </Card>

        {/* Available Permissions */}
        <Card className="border-ehc-green/10 shadow-lg">
          <CardHeader className="border-b border-ehc-green/10 bg-gradient-to-r  from-ehc-green/5 to-transparent">
            <CardTitle className="text-ehc-green">
              <Trans id="role_manager.available_permissions.title">Available Permissions</Trans>
            </CardTitle>
            <CardDescription>
              {selectedRole
                ? t({ 
                    id: "role_manager.available_permissions.description_with_role", 
                    message: "Assign new permissions to {roleName}",
                    values: { roleName: selectedRole.name }
                  })
                : t({ id: "role_manager.available_permissions.description_no_role", message: "Select a role first" })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {selectedRole ? (
              <div className="space-y-4 my-4">
                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder={t({ id: "role_manager.available_permissions.search_placeholder", message: "Search permissions by name or description..." })}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-10 border-gray-200 focus:border-ehc-green focus:ring-ehc-green/20 transition-all duration-200"
                  />
                  {searchQuery && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSearchQuery("")}
                      className="absolute right-1 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                      title={t({ id: "role_manager.common.clear_search", message: "Clear search" })}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  )}
                </div>

                {/* Search Results Count */}
                {searchQuery && (
                  <p className="text-sm text-gray-600">
                    <Trans 
                      id="role_manager.available_permissions.search_results" 
                      values={{ 
                        count: filteredAvailablePermissions.length,
                        query: searchQuery
                      }}
                    >
                      Found {filteredAvailablePermissions.length} permission{filteredAvailablePermissions.length !== 1 ? "s" : ""} matching "{searchQuery}"
                    </Trans>
                  </p>
                )}

                {/* Selection Actions */}
                {selectedPermissions.length > 0 && (
                  <div className="flex items-center justify-between p-3 bg-ehc-green/5 border border-ehc-green/10 rounded-lg">
                    <span className="text-sm text-ehc-green font-medium">
                      <Trans 
                        id="role_manager.available_permissions.selected_count" 
                        values={{ count: selectedPermissions.length }}
                      >
                        {selectedPermissions.length} permission{selectedPermissions.length !== 1 ? "s" : ""} selected
                      </Trans>
                    </span>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={handleAssignPermissions}
                        disabled={isSaving || !canEditRoles}
                        className="bg-ehc-green hover:bg-ehc-green/90 text-white"
                      >
                        {isSaving ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        ) : (
                          <Plus className="h-4 w-4" />
                        )}
                        <Trans id="role_manager.available_permissions.assign_button">Assign</Trans>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedPermissions([])}
                        className="border-ehc-green text-ehc-green hover:bg-ehc-green/5"
                      >
                        <X className="h-4 w-4" />
                        <Trans id="role_manager.available_permissions.clear_button">Clear</Trans>
                      </Button>
                    </div>
                  </div>
                )}

                {/* Permission List */}
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {filteredAvailablePermissions.length === 0 ? (
                    <p className="text-gray-500 text-sm">
                      <Trans id="role_manager.available_permissions.no_permissions">
                        No available permissions found
                      </Trans>
                    </p>
                  ) : (
                    filteredAvailablePermissions.map((permission) => (
                      <div
                        key={permission.id}
                        className="flex items-start gap-3 p-3 border rounded-lg hover:bg-gray-50"
                      >
                        <Checkbox
                          checked={selectedPermissions.includes(permission.id)}
                          onCheckedChange={() =>
                            handlePermissionToggle(permission.id)
                          }
                          disabled={!canEditRoles}
                          className="text-ehc-green border-ehc-green data-[state=checked]:bg-ehc-green data-[state=checked]:border-ehc-green"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm">
                              {permission.name}
                            </span>
                            {getPermissionTypeBadge(permission.permissionType)}
                          </div>
                          {permission.description && (
                            <p className="text-xs text-gray-600">
                              {permission.description}
                            </p>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ) : (
              <p className="text-gray-500 text-sm">
                <Trans id="role_manager.available_permissions.select_role_message">
                  Select a role to view available permissions
                </Trans>
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Create Role Modal */}
      <CreateRoleModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onRoleCreated={handleCreateRole}
      />

      {/* Edit Role Modal */}
      {selectedRole && (
        <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-xl font-semibold flex items-center gap-2">
                <Edit className="h-5 w-5 text-ehc-green" />
                <Trans id="role_manager.edit_modal.title">Edit Role</Trans>
              </DialogTitle>
              <DialogDescription>
                <Trans 
                  id="role_manager.edit_modal.description" 
                  values={{ roleName: selectedRole.name }}
                >
                  Update role information for {selectedRole.name}
                </Trans>
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="font-medium">
                  <Trans id="role_manager.edit_modal.name_label">Role Name</Trans>
                </Label>
                <Input
                  id="name"
                  placeholder={t({ id: "role_manager.edit_modal.name_placeholder", message: "Enter role name" })}
                  value={editRoleData.name}
                  onChange={(e) =>
                    setEditRoleData((prev) => ({
                      ...prev,
                      name: e.target.value,
                    }))
                  }
                  className="border-gray-200 focus:border-ehc-green focus:ring-ehc-green/20"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="font-medium">
                  <Trans id="role_manager.edit_modal.description_label">Description</Trans>
                </Label>
                <Textarea
                  id="description"
                  placeholder={t({ id: "role_manager.edit_modal.description_placeholder", message: "Describe this role's purpose and responsibilities" })}
                  value={editRoleData.description}
                  onChange={(e) =>
                    setEditRoleData((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                  className="min-h-[100px] border-gray-200 focus:border-ehc-green focus:ring-ehc-green/20"
                />
              </div>

              <div className="pt-2 text-sm text-gray-500 flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                <Trans id="role_manager.edit_modal.type_warning">
                  Role type cannot be modified after creation
                </Trans>
              </div>
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsEditModalOpen(false)}
                className="border-gray-200"
              >
                <Trans id="role_manager.edit_modal.cancel_button">Cancel</Trans>
              </Button>
              <Button
                onClick={handleEditRole}
                className="bg-ehc-green hover:bg-ehc-green/90 text-white"
              >
                <Trans id="role_manager.edit_modal.save_button">Save Changes</Trans>
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Role Confirmation */}
      {selectedRole && (
        <AlertDialog
          open={isDeleteDialogOpen}
          onOpenChange={setIsDeleteDialogOpen}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="text-red-600 flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                <Trans id="role_manager.delete_modal.title">Delete Role</Trans>
              </AlertDialogTitle>
              <AlertDialogDescription>
                <Trans 
                  id="role_manager.delete_modal.description" 
                  values={{ roleName: selectedRole.name }}
                >
                  Are you sure you want to delete <span className="font-medium">{selectedRole.name}</span>? This
                  action cannot be undone. If this role is assigned to any
                  licenses, deletion will fail.
                </Trans>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="border-gray-200">
                <Trans id="role_manager.delete_modal.cancel_button">Cancel</Trans>
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteRole}
                className="bg-red-600 text-white hover:bg-red-700"
              >
                <Trans id="role_manager.delete_modal.delete_button">Delete Role</Trans>
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
};
