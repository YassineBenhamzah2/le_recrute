"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { api } from "@/lib/network/utils/api";
import { buildQueryString } from "@/lib/network/utils/main";
import { cn } from "@/lib/utils";
import { t } from "@lingui/core/macro";
import { Trans } from "@lingui/macro";
import {
  BarChart3,
  CreditCard,
  DollarSign,
  Download,
  Filter,
  PlusCircle,
} from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { AddPaymentModal } from "./AdminComponents/AddPaymentModal";
import { MetricCard } from "./AdminComponents/MetricCard";
import {
  PaymentFiltersComponent,
  type PaymentFilters,
} from "./AdminComponents/PaymentFilters";
import { PaymentTable, type Payment } from "./AdminComponents/PaymentTable";

// --- TYPE DEFINITIONS ---
export interface PaginatedResponse {
  data: Payment[];
  totalCount: number;
  currentPage: number;
  totalPages: number;
}

interface PaymentStats {
  totalAmount: number;
  completedCount: number;
  averagePayment: number;
}

// --- API FUNCTIONS ---
type PaymentQueryParams = Record<string, string | number | boolean | undefined>;

const getPayments = (
  params: PaymentQueryParams
): Promise<PaginatedResponse> => {
  const queryString = buildQueryString(params);
  return api.getItem<PaginatedResponse>(`/payments${queryString}`);
};

const getPaymentStats = (): Promise<PaymentStats> => {
  return api.getItem<PaymentStats>("/payments/stats");
};

export function PaymentHistory() {
  // --- COMPONENT STATE ---
  const [showFilters, setShowFilters] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [itemsPerPage] = useState(1);
  const [filters, setFilters] = useState<PaymentFilters>({
    search: "",
    status: "all",
    method: "all",
    dateFrom: "",
    dateTo: "",
    minAmount: "",
    maxAmount: "",
  });
  const [stats, setStats] = useState<PaymentStats>({
    totalAmount: 0,
    completedCount: 0,
    averagePayment: 0,
  });

  // --- MEMOIZED DATA FETCHING LOGIC ---
  const fetchPayments = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const params: PaymentQueryParams = {
        ...filters,
        page: currentPage,
        size: itemsPerPage,
      };
      const response = await getPayments(params);
      setPayments(response.data);
      setTotalPages(response.totalPages);
      setTotalCount(response.totalCount);
      setCurrentPage(response.currentPage);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      setError(t`Failed to fetch payments: ${message}`);
    } finally {
      setIsLoading(false);
    }
  }, [currentPage, itemsPerPage, filters]);

  const fetchPaymentStats = useCallback(async () => {
    try {
      const statsData = await getPaymentStats();
      setStats(statsData);
    } catch (err) {
      console.error("Failed to fetch payment stats:", err);
    }
  }, []);

  // --- SIDE EFFECTS ---
  useEffect(() => {
    const handler = setTimeout(() => {
      setCurrentPage(1);
    }, 500);
    return () => clearTimeout(handler);
  }, [filters]);

  useEffect(() => {
    fetchPayments();
  }, [fetchPayments]);

  useEffect(() => {
    fetchPaymentStats();
  }, [fetchPaymentStats]);

  // --- EVENT HANDLERS ---
  const handlePaymentCreated = async () => {
    setIsModalOpen(false);
    toast.success(<Trans>A new payment has been successfully created.</Trans>);
    await fetchPayments();
    await fetchPaymentStats();
  };

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages && !isLoading) {
      setCurrentPage(page);
    }
  };

  // --- DERIVED STATE ---
  const startIndex = totalCount > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0;
  const endIndex = Math.min(currentPage * itemsPerPage, totalCount);

  return (
    <>
      <div className="min-h-screen bg-gray-50 flex">
        <div className="flex-1 p-4 lg:p-6 space-y-6">
          {/* --- HEADER --- */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                <Trans>Payment History</Trans>
              </h1>
              <p className="text-gray-600">
                <Trans>Track and manage all recruitment payments</Trans>
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <Button
                size="sm"
                onClick={() => setIsModalOpen(true)}
                className="bg-teal-600 hover:bg-teal-700"
              >
                <PlusCircle className="mr-2 h-4 w-4 bb" />
                <Trans>Add Payment</Trans>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="mr-2 h-4 w-4" />
                <Trans>Filter</Trans>
              </Button>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                <Trans>Export</Trans>
              </Button>
            </div>
          </div>

          {showFilters && (
            <PaymentFiltersComponent
              filters={filters}
              setFilters={setFilters}
              onClose={() => setShowFilters(false)}
            />
          )}

          {/* --- STATS CARDS (MetricCard style) --- */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <MetricCard
              icon={DollarSign}
              title={t`Total Revenue`}
              value={`$${stats.totalAmount.toLocaleString()}`}
              subtitle={t`Total collected`}
              // change="+5% from last month"
              chartColor="teal"
            />

            <MetricCard
              icon={CreditCard}
              title={t`Completed Payments`}
              value={stats.completedCount.toString()}
              subtitle={t`Payments completed`}
              // change="+3 this month"
              chartColor="emerald"
            />

            <MetricCard
              icon={BarChart3}
              title={t`Average Payment`}
              value={`$${Math.round(stats.averagePayment).toLocaleString()}`}
              subtitle={t`Average per transaction`}
              // change="-1% from last month"
              chartColor="blue"
            />
          </div>

          {/* --- MAIN CONTENT CARD --- */}
          <Card className="shadow-sm border border-green-200">
            <CardContent className="p-0">
              {isLoading ? (
                <p className="text-center py-20 text-gray-500">
                  <Trans>Loading...</Trans>
                </p>
              ) : error ? (
                <p className="text-center py-20 text-red-600">{error}</p>
              ) : (
                <PaymentTable data={payments} />
              )}
            </CardContent>
            {!isLoading && !error && totalCount > 0 && (
              <CardFooter className="flex flex-col sm:flex-row items-center justify-between py-4 gap-4">
                <p className="text-sm text-gray-600">
                  <Trans>
                    Showing {{ startIndex }} to {{ endIndex }} of{" "}
                    {{ totalCount }} results
                  </Trans>
                </p>

                {/* --- ADVANCED PAGINATION --- */}
                {totalPages > 1 && (
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious
                          href="#"
                          onClick={(e) => {
                            e.preventDefault();
                            handlePageChange(currentPage - 1);
                          }}
                          className={cn(
                            currentPage === 1 || isLoading
                              ? "pointer-events-none text-green-600"
                              : ""
                          )}
                          aria-disabled={currentPage === 1 || isLoading}
                          tabIndex={
                            currentPage === 1 || isLoading ? -1 : undefined
                          }
                        />
                      </PaginationItem>

                      {(() => {
                        const pageNumbers = [];
                        const siblingCount = 1;
                        const totalPageNumbersToShow = siblingCount + 5;

                        if (totalPages <= totalPageNumbersToShow) {
                          for (let i = 1; i <= totalPages; i++) {
                            const isActive = currentPage === i;
                            pageNumbers.push(
                              <PaginationItem key={i}>
                                <PaginationLink
                                  href="#"
                                  isActive={isActive}
                                  className={cn(
                                    isActive
                                      ? "bg-green-600 text-white hover:bg-green-800 hover:text-white rounded-[12px]"
                                      : "text-green-800 hover:bg-green-950 hover:text-white rounded-[12px]"
                                  )}
                                  onClick={(e) => {
                                    e.preventDefault();
                                    handlePageChange(i);
                                  }}
                                >
                                  {i}
                                </PaginationLink>
                              </PaginationItem>
                            );
                          }
                        } else {
                          const leftSiblingIndex = Math.max(
                            currentPage - siblingCount,
                            1
                          );
                          const rightSiblingIndex = Math.min(
                            currentPage + siblingCount,
                            totalPages
                          );
                          const shouldShowLeftDots = leftSiblingIndex > 2;
                          const shouldShowRightDots =
                            rightSiblingIndex < totalPages - 1;

                          pageNumbers.push(
                            <PaginationItem key={1}>
                              <PaginationLink
                                href="#"
                                isActive={currentPage === 1}
                                className={cn(
                                  currentPage === 1
                                    ? "bg-green-600 text-white"
                                    : "border border-[#eaeaea] hover:bg-green-800"
                                )}
                                onClick={(e) => {
                                  e.preventDefault();
                                  handlePageChange(1);
                                }}
                              >
                                1
                              </PaginationLink>
                            </PaginationItem>
                          );

                          if (shouldShowLeftDots) {
                            pageNumbers.push(
                              <PaginationItem key="ellipsis-start">
                                <PaginationEllipsis />
                              </PaginationItem>
                            );
                          }

                          for (
                            let i = leftSiblingIndex;
                            i <= rightSiblingIndex;
                            i++
                          ) {
                            if (i !== 1 && i !== totalPages) {
                              const isActive = currentPage === i;
                              pageNumbers.push(
                                <PaginationItem key={i}>
                                  <PaginationLink
                                    href="#"
                                    isActive={isActive}
                                    className={cn(
                                      isActive
                                        ? "bg-green-600 text-white"
                                        : "border border-[#eaeaea] hover:bg-green-800"
                                    )}
                                    onClick={(e) => {
                                      e.preventDefault();
                                      handlePageChange(i);
                                    }}
                                  >
                                    {i}
                                  </PaginationLink>
                                </PaginationItem>
                              );
                            }
                          }

                          if (shouldShowRightDots) {
                            pageNumbers.push(
                              <PaginationItem key="ellipsis-end">
                                <PaginationEllipsis />
                              </PaginationItem>
                            );
                          }

                          pageNumbers.push(
                            <PaginationItem key={totalPages}>
                              <PaginationLink
                                href="#"
                                isActive={currentPage === totalPages}
                                className={cn(
                                  currentPage === totalPages
                                    ? "bg-green-600 text-white"
                                    : "border border-[#eaeaea] hover:bg-green-800"
                                )}
                                onClick={(e) => {
                                  e.preventDefault();
                                  handlePageChange(totalPages);
                                }}
                              >
                                {totalPages}
                              </PaginationLink>
                            </PaginationItem>
                          );
                        }
                        return pageNumbers;
                      })()}

                      <PaginationItem>
                        <PaginationNext
                          href="#"
                          onClick={(e) => {
                            e.preventDefault();
                            handlePageChange(currentPage + 1);
                          }}
                          className={cn(
                            currentPage === totalPages || isLoading
                              ? "pointer-events-none text-gray-400"
                              : ""
                          )}
                          aria-disabled={
                            currentPage === totalPages || isLoading
                          }
                          tabIndex={
                            currentPage === totalPages || isLoading
                              ? -1
                              : undefined
                          }
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                )}
              </CardFooter>
            )}
          </Card>
        </div>
      </div>
      <AddPaymentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onPaymentCreated={handlePaymentCreated}
      />
    </>
  );
}
