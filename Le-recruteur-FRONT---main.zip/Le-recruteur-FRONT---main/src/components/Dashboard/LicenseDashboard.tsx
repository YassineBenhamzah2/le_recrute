import { useState, useEffect, useCallback } from "react";

import { Button } from "../ui/button";
import { Input } from "../ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { Badge } from "../ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "../ui/alert-dialog";
import {
  Copy,
  Edit,
  Plus,
  Search,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Download,
  Filter,
  Calendar,
  Eye,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";
import { licenseService } from "../../lib/network/license";
import { roleService } from "../../lib/network/roles";
import {
  License,
  Role,
  CreateLicenseRequest,
  UpdateLicenseRequest,
  LicenseStatistics,
} from "../../lib/types/license";
import { LICENSE_STATUS } from "../../lib/utils/permissions";
import { useAuth } from "@/contexts/AuthContext";
import { LicenseStatsCards } from "./LicenseStatsCards";
import { LicenseForm } from "./LicenseForm";
import { useLingui } from '@lingui/react';
import { Trans , t } from "@lingui/macro";

export const LicenseDashboard: React.FC = () => {
  const [licenses, setLicenses] = useState<License[]>([]);
  const { user } = useAuth();
  const [roles, setRoles] = useState<Role[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [selectedLicense, setSelectedLicense] = useState<License | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isCopySuccessModalOpen, setIsCopySuccessModalOpen] = useState(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const itemsPerPage = 10;
  const { i18n } = useLingui();
  const isRTL = i18n.locale === 'ar';
  

  // Mock permission check - in real app this would use proper permission system
  const canViewLicenses = user?.role.type === "ADMIN";
  const canEditLicenses = user?.role.type === "ADMIN";

  // License statistics from API
  const [stats, setStats] = useState<LicenseStatistics>({
    totalLicenses: 0,
    activeLicenses: 0,
    expiredLicenses: 0,
    suspendedLicenses: 0,
    assignedLicenses: 0,
    unassignedLicenses: 0,
    totalRevenue: 0,
    monthlyRevenue: 0,
    expiringThisMonth: 0,
    recentActivity: 0,
  });

  const loadLicenses = useCallback(async () => {
    try {
      setIsLoading(true);

      // Fetch licenses data with pagination
      const response = await licenseService.getAll({
        page: currentPage,
        limit: itemsPerPage,
        search: searchTerm || undefined,
      });
      setLicenses(response.data);

      // Handle pagination metadata if available
      if (response.metadata?.pagination) {
        setTotalPages(response.metadata.pagination.totalPages);
        setTotalItems(response.metadata.pagination.totalItems);
      }

      // Fetch license statistics from the API
      const statsResponse = await licenseService.getStatistics();
      if (statsResponse.data) {
        setStats(statsResponse.data);
      }
    } catch (error) {
      console.error("Error loading licenses:", error);
      toast.error(<Trans>Error loading licenses</Trans>);
    } finally {
      setIsLoading(false);
    }
  }, [currentPage, searchTerm]);

  useEffect(() => {
    if (canViewLicenses) {
      loadLicenses();
      loadRoles();
    }
  }, [canViewLicenses, currentPage, searchTerm, statusFilter, loadLicenses]);

  const loadRoles = async () => {
    try {
      const response = await roleService.getAll();
      setRoles(response.data);
    } catch (error) {
      console.error("Error loading roles:", error);
    }
  };

  const handleCreateLicense = async (
    formData: CreateLicenseRequest | UpdateLicenseRequest
  ) => {
    try {
      const createData = formData as CreateLicenseRequest;
      await licenseService.create(createData);
      toast.success(<Trans>License created successfully!</Trans>);
      setIsCreateDialogOpen(false);
      loadLicenses();
    } catch (error) {
      console.error("Error creating license:", error);
      toast.error(<Trans>Error creating license</Trans>);
    }
  };

  const handleUpdateLicense = async (
    formData: CreateLicenseRequest | UpdateLicenseRequest
  ) => {
    try {
      const updateData = formData as UpdateLicenseRequest;
      if (!updateData.id) {
        toast.error(<Trans>License ID is required for update</Trans>);
        return;
      }
      await licenseService.update(updateData.id, updateData);
      toast.success(<Trans>License updated successfully!</Trans>);
      setIsEditDialogOpen(false);
      setSelectedLicense(null);
      loadLicenses();
    } catch (error) {
      console.error("Error updating license:", error);
      toast.error(<Trans>Error updating license</Trans>);
    }
  };

  const handleDeleteLicense = async (license: License) => {
    try {
      await licenseService.delete(license.id);
      toast.success(<Trans>License deleted successfully!</Trans>);
      loadLicenses();
    } catch (error) {
      console.error("Error deleting license:", error);
      toast.error(<Trans>Error deleting license</Trans>);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setIsCopySuccessModalOpen(true);
      setTimeout(() => {
        setIsCopySuccessModalOpen(false);
      }, 2000);
    } catch {
      toast.error(<Trans>Failed to copy to clipboard</Trans>);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case LICENSE_STATUS.ACTIVE:
        return (
          <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-200 hover:text-green-900">
            <Trans>Active</Trans>
          </Badge>
        );
      case LICENSE_STATUS.SUSPENDED:
        return (
          <Badge className="bg-red-100 text-red-800 border-red-200 hover:bg-red-200 hover:text-red-900">
            <Trans>Suspended</Trans>
          </Badge>
        );
      case LICENSE_STATUS.EXPIRED:
        return (
          <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200 hover:bg-yellow-200 hover:text-yellow-900">
            <Trans>Expired</Trans>
          </Badge>
        );
      default:
        return (
          <Badge className="bg-gray-100 text-gray-800 border-gray-200 hover:bg-gray-200 hover:text-gray-900">
            {status}
          </Badge>
        );
    }
  };

  const getRoleTypeBadge = (roleType: string) => {
    const colors = {
      ADMIN:
        "bg-red-100 text-red-800 border-red-200 hover:bg-red-200 hover:text-red-900",
      RECRUITER:
        "bg-blue-100 text-blue-800 border-blue-200 hover:bg-blue-200 hover:text-blue-900",
      CANDIDATE:
        "bg-green-100 text-green-800 border-green-200 hover:bg-green-200 hover:text-green-900",
    };
    return (
      <Badge
        className={
          colors[roleType as keyof typeof colors] ||
          "bg-gray-100 text-gray-800 border-gray-200 hover:bg-gray-200 hover:text-gray-900"
        }
      >
        {roleType}
      </Badge>
    );
  };

  const filteredLicenses = licenses.filter((license) => {
    const matchesSearch =
      license.licenseKey.toLowerCase().includes(searchTerm.toLowerCase()) ||
      license.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      license.assignedUser?.firstname
        ?.toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      license.assignedUser?.lastname
        ?.toLowerCase()
        .includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === "all" || license.status === statusFilter;
    const matchesRole =
      roleFilter === "all" || license.role?.id.toString() === roleFilter;
    return matchesSearch && matchesStatus && matchesRole;
  });

  const exportLicenses = () => {
    const csvContent = [
      [
        "License Key",
        "Name",
        "Role",
        "Status",
        "Assigned User",
        "Price",
        "Created",
        "Expires",
      ],
      ...filteredLicenses.map((license) => [
        license.licenseKey,
        license.name,
        license.role?.name || "Unknown",
        license.status,
        license.assignedUser
          ? `${license.assignedUser.firstname} ${license.assignedUser.lastname}`
          : "N/A",
        `$${license.price}`,
        new Date(license.createdAt || "").toLocaleDateString(),
        license.expirationDate
          ? new Date(license.expirationDate).toLocaleDateString()
          : "Never",
      ]),
    ]
      .map((row) => row.join(","))
      .join("\\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "licenses.csv";
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success(<Trans>Licenses exported successfully!</Trans>);
  };

  if (!canViewLicenses) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500">
          <Trans>You don't have permission to view licenses</Trans>
        </p>
      </div>
    );
  }

  return (
    <div className={`space-y-8  min-h-screen bg-gradient-to-br from-gray-50 to-white ${isRTL ? 'p-3' : 'p-1'}`}>
      {/* Futuristic Header */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-ehc-green/5 to-ehc-green/10 rounded-2xl"></div>
        <div className="relative p-4 sm:p-6 md:p-8 rounded-2xl border border-white/20 backdrop-blur-sm">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                <Trans>License Management Hub</Trans>
              </h1>
              <p className="text-gray-600 text-base sm:text-lg">
                <Trans>Advanced license control with real-time analytics</Trans>
              </p>
              <div className="flex flex-wrap items-center gap-2 sm:gap-4 mt-4">
                <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-500">
                  <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                  <Trans>Last updated</Trans>: {new Date().toLocaleDateString()}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={loadLicenses}
                  className="h-8 text-xs sm:text-sm text-ehc-green hover:bg-ehc-green/10"
                >
                  <RefreshCw className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  <Trans>Refresh</Trans>
                </Button>
              </div>
            </div>
            {canEditLicenses && (
              <div className="flex flex-wrap gap-2 sm:gap-3 mt-2 md:mt-0">
                <Button
                  variant="outline"
                  onClick={exportLicenses}
                  className="h-9 text-xs sm:text-sm border-ehc-green text-ehc-green hover:bg-ehc-green/10"
                >
                  <Download className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  <Trans>Export CSV</Trans>
                </Button>
                <Dialog
                  open={isCreateDialogOpen}
                  onOpenChange={setIsCreateDialogOpen}
                >
                  <DialogTrigger asChild>
                    <Button className="bg-ehc-green hover:bg-ehc-green/90 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                      <Plus className="w-4 h-4 mr-2" />
                      <Trans>Create License</Trans>
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-[95vw] sm:max-w-[80vw] md:max-w-2xl h-[90vh] sm:h-auto overflow-y-auto">
                    <LicenseForm
                      roles={roles}
                      onSubmit={handleCreateLicense}
                      onCancel={() => setIsCreateDialogOpen(false)}
                    />
                  </DialogContent>
                </Dialog>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <LicenseStatsCards stats={stats} />

      {/* Enhanced Filters */}
      <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-xl p-4 sm:p-6 shadow-lg">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="relative w-full sm:flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder={t`Search by license key, name, or user...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 border-gray-200 focus:border-ehc-green focus:ring-ehc-green/20 transition-all duration-200 w-full"
            />
          </div>

          <div className="flex flex-wrap w-full sm:w-auto gap-2 justify-between sm:justify-start">
            <div className="flex items-center gap-2 w-[48%] sm:w-auto">
              <Filter className="hidden sm:block w-4 h-4 text-gray-500" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-36 md:w-48 border-gray-200 focus:border-ehc-green">
                  <SelectValue placeholder={<Trans>Filter by status</Trans>} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all"><Trans>All Statuses</Trans></SelectItem>
                  <SelectItem value={LICENSE_STATUS.ACTIVE}><Trans>Active</Trans></SelectItem>
                  <SelectItem value={LICENSE_STATUS.SUSPENDED}><Trans>Suspended</Trans></SelectItem>
                  <SelectItem value={LICENSE_STATUS.EXPIRED}><Trans>Expired</Trans></SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="w-[48%] sm:w-auto">
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="w-full sm:w-36 md:w-48 border-gray-200 focus:border-ehc-green">
                  <SelectValue placeholder={<Trans>Filter by role</Trans>} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all"><Trans>All Roles</Trans></SelectItem>
                  {roles.map((role) => (
                    <SelectItem key={role.id} value={role.id.toString()}>
                      {role.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced License Table */}
      <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-xl shadow-xl overflow-hidden">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-xl font-semibold text-gray-900">
            <Trans>License Database</Trans>
          </h2>
          <p className="text-gray-600 text-sm mt-1">
            <Trans>Showing</Trans> {filteredLicenses.length} <Trans>of</Trans> {totalItems} <Trans>licenses</Trans>
          </p>
        </div>

        <Table>
          <TableHeader>
            <TableRow className="border-gray-100">
             <TableHead className={`font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                <Trans>License Key</Trans>
              </TableHead>
              <TableHead className={`font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                <Trans>Name</Trans>
              </TableHead>
              <TableHead className={`font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                <Trans>Role Type</Trans>
              </TableHead>
              <TableHead className={`font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                <Trans>Status</Trans>
              </TableHead>
              <TableHead className={`font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                <Trans>Price</Trans>
              </TableHead>
              <TableHead className={`font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                <Trans>Assigned User</Trans>
              </TableHead>
              <TableHead className={`font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                <Trans>Created</Trans>
              </TableHead>
             <TableHead className={`font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                <Trans>Expires</Trans>
              </TableHead>
              <TableHead className={`font-semibold text-gray-700 ${isRTL ? 'text-right' : 'text-left'}`}>
                <Trans>Actions</Trans>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-12">
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-ehc-green"></div>
                    <span className="ml-3 text-gray-600">
                      <Trans>Loading licenses...</Trans>
                    </span>
                  </div>
                </TableCell>
              </TableRow>
            ) : filteredLicenses.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-12">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Search className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-gray-500 text-lg"><Trans>No licenses found</Trans></p>
                    <p className="text-gray-400 text-sm">
                      <Trans>Try adjusting your search criteria</Trans>
                    </p>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              filteredLicenses.map((license) => (
                <TableRow
                  key={license.id}
                  className="border-gray-50 hover:bg-gray-50/50 transition-colors duration-200"
                >
                  <TableCell className="font-mono">
                    <div className="flex items-center gap-2">
                      <span className="truncate max-w-[120px] text-sm bg-gray-100 px-2 py-1 rounded">
                        {license.licenseKey}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(license.licenseKey)}
                        className="p-1 h-6 w-6 hover:bg-ehc-green/10"
                      >
                        <Copy className="w-3 h-3 text-ehc-green" />
                      </Button>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{license.name}</TableCell>
                  <TableCell>
                    {getRoleTypeBadge(license.role?.roleType || "UNKNOWN")}
                  </TableCell>
                  <TableCell>{getStatusBadge(license.status)}</TableCell>
                  <TableCell className="font-semibold text-ehc-green">
                    ${license.price}
                  </TableCell>
                  <TableCell>
                    {license.assignedUser ? (
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-ehc-green/10 rounded-full flex items-center justify-center">
                          <span className="text-xs font-medium text-ehc-green">
                            {license.assignedUser.firstname[0]}
                            {license.assignedUser.lastname[0]}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm font-medium">
                            {license.assignedUser.firstname}{" "}
                            {license.assignedUser.lastname}
                          </p>
                          <p className="text-xs text-gray-500">
                            {license.assignedUser.email}
                          </p>
                        </div>
                      </div>
                    ) : (
                      <Badge
                        variant="outline"
                        className="text-gray-500 hover:bg-gray-100 hover:text-gray-700 border-gray-300"
                      >
                        <Trans>Unassigned</Trans>
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-sm text-gray-600">
                    {new Date(license.createdAt || "").toLocaleDateString()}
                  </TableCell>
                  <TableCell className="text-sm text-gray-600">
                    {license.expirationDate
                      ? new Date(license.expirationDate).toLocaleDateString()
                      : <Trans>Never</Trans>}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center gap-1 justify-end">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedLicense(license);
                          setIsViewDialogOpen(true);
                        }}
                        className="p-1 h-8 w-8 hover:bg-blue-50 text-blue-600"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      {canEditLicenses && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedLicense(license);
                              setIsEditDialogOpen(true);
                            }}
                            className="p-1 h-8 w-8 hover:bg-orange-50 text-orange-600"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="p-1 h-8 w-8 text-red-600 hover:bg-red-50"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>
                                  <Trans>Delete License</Trans>
                                </AlertDialogTitle>
                                <AlertDialogDescription>
                                  <Trans>Are you sure you want to delete license</Trans> "
                                  {license.name}"? <Trans>This action cannot be undone and will revoke access for any assigned users.</Trans>
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel><Trans>Cancel</Trans></AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDeleteLicense(license)}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  <Trans>Delete License</Trans>
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Enhanced Pagination */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-white/70 backdrop-blur-sm border border-white/20 rounded-xl p-4 shadow-lg gap-3">
        <p className="text-xs sm:text-sm text-gray-700 text-center sm:text-left">
          <Trans>Showing</Trans>{" "}
          <span className="font-medium">
            {(currentPage - 1) * itemsPerPage + 1}
          </span>{" "}
          <Trans>to</Trans>{" "}
          <span className="font-medium">
            {Math.min(currentPage * itemsPerPage, totalItems)}
          </span>{" "}
          <Trans>of</Trans> <span className="font-medium">{totalItems}</span> <Trans>licenses</Trans>
        </p>
        <div className="flex items-center justify-center sm:justify-end gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
            disabled={currentPage <= 1}
            className="h-8 text-xs sm:text-sm border-gray-300 hover:bg-gray-50"
          >
            <ChevronLeft className="w-3 h-3 sm:w-4 sm:h-4 mr-0 sm:mr-1" />
            <span className="hidden sm:inline"><Trans>Previous</Trans></span>
          </Button>
          <span className="text-xs sm:text-sm px-2 sm:px-4 py-1 sm:py-2 bg-ehc-green/10 text-ehc-green rounded-lg font-medium">
            {currentPage}/{totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() =>
              setCurrentPage((prev) => Math.min(totalPages, prev + 1))
            }
            disabled={currentPage >= totalPages}
            className="h-8 text-xs sm:text-sm border-gray-300 hover:bg-gray-50"
          >
            <span className="hidden sm:inline"><Trans>Next</Trans></span>
            <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4 ml-0 sm:ml-1" />
          </Button>
        </div>
      </div>

      {/* Edit Dialog */}
      {selectedLicense && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-[95vw] sm:max-w-[80vw] md:max-w-2xl h-[90vh] sm:h-auto overflow-y-auto">
            <LicenseForm
              roles={roles}
              initialData={selectedLicense}
              onSubmit={handleUpdateLicense}
              onCancel={() => {
                setIsEditDialogOpen(false);
                setSelectedLicense(null);
              }}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* View Dialog */}
      {selectedLicense && (
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-[95vw] sm:max-w-[80vw] md:max-w-2xl h-[90vh] sm:h-auto overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-ehc-green" />
                <Trans>License Details</Trans>
              </DialogTitle>
              <DialogDescription className="break-words">
                <Trans>Complete information for license</Trans>: {selectedLicense.name}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">
                    <Trans>License Key</Trans>
                  </label>
                  <div className="mt-1 p-3 bg-gray-50 rounded-lg font-mono text-sm break-all">
                    {selectedLicense.licenseKey}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">
                    <Trans>Status</Trans>
                  </label>
                  <div className="mt-1">
                    {getStatusBadge(selectedLicense.status)}
                  </div>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">
                  <Trans>Description</Trans>
                </label>
                <p className="mt-1 text-gray-600">
                  {selectedLicense.description || <Trans>No description provided</Trans>}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">
                    <Trans>Price</Trans>
                  </label>
                  <p className="mt-1 text-2xl font-bold text-ehc-green">
                    ${selectedLicense.price}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">
                    <Trans>Role</Trans>
                  </label>
                  <div className="mt-1">
                    {getRoleTypeBadge(
                      selectedLicense.role?.roleType || "UNKNOWN"
                    )}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">
                    <Trans>Created Date</Trans>
                  </label>
                  <p className="mt-1 text-gray-600">
                    {new Date(
                      selectedLicense.createdAt || ""
                    ).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">
                    <Trans>Expiration Date</Trans>
                  </label>
                  <p className="mt-1 text-gray-600">
                    {selectedLicense.expirationDate
                      ? new Date(
                          selectedLicense.expirationDate
                        ).toLocaleDateString()
                      : <Trans>Never expires</Trans>}
                  </p>
                </div>
              </div>

              {selectedLicense.assignedUser && (
                <div>
                  <label className="text-sm font-medium text-gray-700">
                    <Trans>Assigned User</Trans>
                  </label>
                  <div className="mt-1 p-3 bg-gray-50 rounded-lg">
                    <p className="font-medium">
                      {selectedLicense.assignedUser.firstname}{" "}
                      {selectedLicense.assignedUser.lastname}
                    </p>
                    <p className="text-sm text-gray-600 break-all">
                      {selectedLicense.assignedUser.email}
                    </p>
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row justify-end gap-2 pt-4">
              <Button
                variant="outline"
                onClick={() => setIsViewDialogOpen(false)}
                className="w-full sm:w-auto"
              >
                <Trans>Close</Trans>
              </Button>
              <Button
                onClick={() => copyToClipboard(selectedLicense.licenseKey)}
                className="w-full sm:w-auto bg-ehc-green hover:bg-ehc-green/90"
              >
                <Copy className="w-4 h-4 mr-2" />
                <span className="whitespace-nowrap"><Trans>Copy License Key</Trans></span>
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Copy Success Modal */}
      <Dialog
        open={isCopySuccessModalOpen}
        onOpenChange={setIsCopySuccessModalOpen}
      >
        <DialogContent className="max-w-[95vw] sm:max-w-md">
          <div className="flex items-center space-x-4 p-4 sm:p-6">
            <div className="flex-shrink-0">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-green-100 rounded-full flex items-center justify-center">
                <svg
                  className="w-5 h-5 sm:w-6 sm:h-6 text-green-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-medium text-gray-900">
                <Trans>Copied Successfully!</Trans>
              </h3>
              <p className="text-sm text-gray-500">
                <Trans>License key has been copied to your clipboard.</Trans>
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};