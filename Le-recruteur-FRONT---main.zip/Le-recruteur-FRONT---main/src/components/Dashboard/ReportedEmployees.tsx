/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useEffect, useCallback } from "react";
import { ReportedEmployeesHeader } from "./AdminComponents/ReportedEmployeesHeader";
import { CaseHandlingPanel } from "./AdminComponents/CaseHandlingPanel";
import { ReportedEmployeesTable } from "./AdminComponents/ReportedEmployeesTable";
import { ReportedEmployeesSearch } from "./AdminComponents/ReportedEmployeesSearch";

import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

import { api } from "../../lib/network/utils/api";
import { buildQueryString } from "../../lib/network/utils/main";

import { Download, FileSpreadsheet, FileText } from "lucide-react";
import { Trans, t } from "@lingui/macro";

// Interfaces define the shape of the data from the backend
export interface ReportedEmployee {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  reportReason: string;
  reportedOn: string;
  companyId?: number;
  companyName?: string;
}

export interface PaginatedResponse {
  data: ReportedEmployee[];
  totalCount: number;
  currentPage: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

// API functions that communicate with the backend
const getReportedEmployees = (params: {
  page: number;
  size: number;
  searchTerm?: string;
  status?: string;
}): Promise<PaginatedResponse> => {
  const queryString = buildQueryString(params);
  return api.getItem<PaginatedResponse>(`/reported-employees${queryString}`);
};

const downloadReportLog = (format: "csv" | "pdf"): Promise<Blob> => {
  return api.download(`/reported-employees/export/${format}`);
};

// This component manages the UI and calls the API functions defined above.
export default function ReportedEmployees() {
  const [employees, setEmployees] = useState<ReportedEmployee[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [itemsPerPage] = useState(1); // items per page

  const fetchEmployees = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {
        page: currentPage,
        size: itemsPerPage,
        searchTerm,
        status: statusFilter,
      };
      const data = await getReportedEmployees(params);
      setEmployees(data.data);
      setTotalPages(data.totalPages);
      setTotalCount(data.totalCount);
      setCurrentPage(data.currentPage);
    } catch (err: any) {
      setError(
        err.message ||
          t({
            id: "admin.reported_employees.error_unknown",
            message: "An unknown error occurred.",
          })
      );
    } finally {
      setLoading(false);
    }
  }, [currentPage, itemsPerPage, searchTerm, statusFilter]);

  useEffect(() => {
    const closeMenu = (event: MouseEvent) => {
      // We check if the click was outside the dropdown area
      if (isExportMenuOpen && !(event.target as Element).closest(".relative")) {
        setIsExportMenuOpen(false);
      }
    };

    // Add the event listener to the document
    document.addEventListener("mousedown", closeMenu);

    // Clean up the event listener when the component unmounts
    return () => document.removeEventListener("mousedown", closeMenu);
  }, [isExportMenuOpen]);

  // Debounced search effect
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (currentPage !== 1) {
        setCurrentPage(1);
      } else {
        fetchEmployees();
      }
    }, 300);
    return () => clearTimeout(timeoutId);
  }, [searchTerm, statusFilter, currentPage, fetchEmployees]);

  // Fetch employees when page changes
  useEffect(() => {
    fetchEmployees();
  }, [fetchEmployees]);

  const handleExportReportLog = async (format: "csv" | "pdf") => {
    try {
      setLoading(true);
      const blob = await downloadReportLog(format); // Calls function from this file
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `reported_employees.${format}`);
      document.body.appendChild(link);
      link.click();
      if (link.parentNode) link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      setError(
        err.message ||
          t({
            id: "admin.reported_employees.export_failed",
            message: `Failed to export ${format.toUpperCase()} file.`,
          })
      );
    } finally {
      setLoading(false);
    }
  };

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages && page !== currentPage) {
      setCurrentPage(page);
    }
  };

  const handleSearchChange = (value: string) => setSearchTerm(value);

  const handleFilterClick = () => {
    const filters = ["all", "pending", "resolved", "dismissed", "under-review"];
    const currentIndex = filters.indexOf(statusFilter);
    const nextIndex = (currentIndex + 1) % filters.length;
    setStatusFilter(filters[nextIndex]);
  };

  const handleView = (id: number) => console.log("View employee:", id);
  const handleMoreActions = (id: number) =>
    console.log("More actions for:", id);
  const handleOverviewClick = () => console.log("Overview clicked");
  const handleReportsOverview = () => console.log("Reports overview clicked");
  const handleExportClick = () => console.log("Export clicked"); // Simple wrapper for CaseHandlingPanel
  const handleAssignCaseHandler = () =>
    console.log("Assign case handler clicked");
  const handleFilterByReason = () => console.log("Filter by reason clicked");

  const startIndex = (currentPage - 1) * itemsPerPage + 1;
  const endIndex = Math.min(currentPage * itemsPerPage, totalCount);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <ReportedEmployeesHeader onOverviewClick={handleOverviewClick} />
        <CaseHandlingPanel
          onReportsOverview={handleReportsOverview}
          onExportReportLog={handleExportClick}
          onAssignCaseHandler={handleAssignCaseHandler}
          onFilterByReason={handleFilterByReason}
        />
        <div className="my-4 p-4 bg-gray-50 border-t border-b border-gray-200 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-800">
              <Trans id="admin.reported_employees.case_reports_title">
                Case Reports
              </Trans>
            </h3>
            <p className="text-sm text-gray-500">
              <Trans id="admin.reported_employees.case_reports_subtitle">
                Download you data with csv or pdf.
              </Trans>
            </p>
          </div>

          <div className="relative">
            <button
              onClick={() => setIsExportMenuOpen(!isExportMenuOpen)}
              disabled={loading}
              className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-gray-700 bg-white border border-gray-300 rounded-lg shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-all disabled:bg-gray-200 disabled:cursor-not-allowed"
            >
              <Download size={16} />
              <span>
                <Trans id="admin.reported_employees.export_report_button">
                  Export Report
                </Trans>
              </span>
            </button>
            {isExportMenuOpen && (
              <div className="absolute right-0 mt-2 w-56 origin-top-right bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-10">
                <div className="py-1">
                  <button
                    onClick={() => {
                      handleExportReportLog("csv");
                      setIsExportMenuOpen(false);
                    }}
                    className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <FileSpreadsheet size={16} className="text-green-600" />
                    <span>
                      <Trans id="admin.reported_employees.download_csv">
                        Download as CSV
                      </Trans>
                    </span>
                  </button>
                  <button
                    onClick={() => {
                      handleExportReportLog("pdf");
                      setIsExportMenuOpen(false);
                    }}
                    className="w-full text-left flex items-center gap-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <FileText size={16} className="text-red-600" />
                    <span>
                      <Trans id="admin.reported_employees.download_pdf">
                        Download as PDF
                      </Trans>
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <ReportedEmployeesSearch
            searchTerm={searchTerm}
            onSearchChange={handleSearchChange}
            onFilterClick={handleFilterClick}
          />
          {statusFilter !== "all" && (
            <div className="px-6 mb-4">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                <Trans id="admin.reported_employees.filter_label">Filter</Trans>
                :{" "}
                {statusFilter.charAt(0).toUpperCase() +
                  statusFilter.slice(1).replace("-", " ")}
                <button
                  onClick={() => setStatusFilter("all")}
                  className="ml-2 text-blue-600 hover:text-blue-800"
                >
                  ×
                </button>
              </span>
            </div>
          )}
          {loading && (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#238D94]"></div>
            </div>
          )}
          {error && (
            <div className="mx-6 mb-4 bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800">{error}</p>
              <button
                onClick={fetchEmployees}
                className="mt-2 px-4 py-2 bg-red-100 text-red-800 rounded hover:bg-red-200"
              >
                <Trans id="admin.reported_employees.retry_button">Retry</Trans>
              </button>
            </div>
          )}
          {!loading && !error && (
            <>
              <ReportedEmployeesTable
                employees={employees}
                onView={handleView}
                onMoreActions={handleMoreActions}
              />
              <div className="px-6 mt-4 text-sm text-gray-600">
                <Trans id="admin.reported_employees.showing_results">
                  Showing {totalCount > 0 ? startIndex : 0}-{endIndex} of{" "}
                  {totalCount} reported employees
                </Trans>
                {statusFilter !== "all" &&
                  ` (${t({
                    id: "admin.reported_employees.filtered_by",
                    message: "filtered by",
                  })} ${statusFilter})`}
              </div>
              {totalPages > 1 && (
                <div className="mt-6 pb-6">
                  {/* Pagination */}
                  <Pagination className="flex justify-center">
                    <PaginationContent className="flex justify-center gap-2">
                      <PaginationItem>
                        <PaginationPrevious
                          onClick={() => handlePageChange(currentPage - 1)}
                          aria-disabled={currentPage === 1 || loading}
                          className={
                            currentPage === 1 || loading
                              ? "opacity-50 cursor-not-allowed"
                              : ""
                          }
                        />
                      </PaginationItem>

                      {(() => {
                        const displayTotalPages = totalPages;
                        const pageNumbers = [];
                        const siblingCount = 1;
                        const totalPageNumbersToShow = siblingCount + 5;

                        // If the number of pages is small, show all of them
                        if (displayTotalPages <= totalPageNumbersToShow) {
                          for (let i = 1; i <= displayTotalPages; i++) {
                            pageNumbers.push(
                              <PaginationItem key={i}>
                                <PaginationLink
                                  href="#"
                                  className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium ${
                                    currentPage === i
                                      ? "bg-[#238d94] text-white"
                                      : "border border-[#eaeaea] hover:bg-[#f5f5f5]"
                                  }`}
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (!loading) handlePageChange(i);
                                  }}
                                >
                                  {i}
                                </PaginationLink>
                              </PaginationItem>
                            );
                          }
                          return pageNumbers;
                        }
                        // Always add the first page
                        pageNumbers.push(
                          <PaginationItem key={1}>
                            <PaginationLink
                              href="#"
                              className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium ${
                                currentPage === 1
                                  ? "bg-[#238d94] text-white"
                                  : "border border-[#eaeaea] hover:bg-[#f5f5f5]"
                              }`}
                              onClick={(e) => {
                                e.preventDefault();
                                if (!loading) handlePageChange(1);
                              }}
                            >
                              1
                            </PaginationLink>
                          </PaginationItem>
                        );

                        // Add left ellipsis if needed
                        if (currentPage > siblingCount + 2) {
                          pageNumbers.push(
                            <PaginationItem key="ellipsis-start">
                              <PaginationEllipsis />
                            </PaginationItem>
                          );
                        }
                        // Generate the middle page numbers using startPage and endPage
                        const startPage = Math.max(
                          2,
                          currentPage - siblingCount
                        );
                        const endPage = Math.min(
                          displayTotalPages - 1,
                          currentPage + siblingCount
                        );

                        for (let i = startPage; i <= endPage; i++) {
                          pageNumbers.push(
                            <PaginationItem key={i}>
                              <PaginationLink
                                href="#"
                                className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium ${
                                  currentPage === i
                                    ? "bg-[#238d94] text-white"
                                    : "border border-[#eaeaea] hover:bg-[#f5f5f5]"
                                }`}
                                onClick={(e) => {
                                  e.preventDefault();
                                  if (!loading) handlePageChange(i);
                                }}
                              >
                                {i}
                              </PaginationLink>
                            </PaginationItem>
                          );
                        }

                        // ellipsis if needed
                        if (
                          currentPage <
                          displayTotalPages - (siblingCount + 1)
                        ) {
                          pageNumbers.push(
                            <PaginationItem key="ellipsis-end">
                              <PaginationEllipsis />
                            </PaginationItem>
                          );
                        }

                        // Always add the last page
                        pageNumbers.push(
                          <PaginationItem key={displayTotalPages}>
                            <PaginationLink
                              href="#"
                              className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium ${
                                currentPage === displayTotalPages
                                  ? "bg-[#238d94] text-white"
                                  : "border border-[#eaeaea] hover:bg-[#f5f5f5]"
                              }`}
                              onClick={(e) => {
                                e.preventDefault();
                                if (!loading)
                                  handlePageChange(displayTotalPages);
                              }}
                            >
                              {displayTotalPages}
                            </PaginationLink>
                          </PaginationItem>
                        );

                        return pageNumbers;
                      })()}

                      <PaginationItem>
                        <PaginationNext
                          onClick={() => handlePageChange(currentPage + 1)}
                          aria-disabled={
                            currentPage === Math.min(totalPages, 10) || loading
                          }
                          className={
                            currentPage === Math.min(totalPages, 10) || loading
                              ? "opacity-50 cursor-not-allowed"
                              : ""
                          }
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
