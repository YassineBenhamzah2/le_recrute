import React, { useState, useEffect, useCallback } from "react";
import {
  Clock,
  FileText,
  Trophy,
  CheckCircle,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Flag,
  Briefcase,
  Search,
  Calendar,
  Plus,
} from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";
import { testService } from "@/lib/network/test";
import { jobApplicationService } from "@/lib/network/jobApplication";
import { JobApplication } from "@/lib/types/jobApplication";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Trans } from "@lingui/macro";
import { t } from "@lingui/core/macro";

interface TestPreviewProps {
  id?: string;
}

interface TestData {
  id: string;
  title: string;
  description: string;
  duration: number;
  category: string;
  difficulty: string;
  passingScore: number;
  questions: TestQuestion[];
  created: string;
  lastUpdated: string;
}

interface TestQuestion {
  id: string;
  type: string;
  question: string;
  points: number;
  options: TestQuestionOption[];
}

interface TestQuestionOption {
  id: string;
  text: string;
  isCorrect: boolean;
  points: number;
}

// Component Implementation

const TestPreview: React.FC<TestPreviewProps> = ({ id }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [testData, setTestData] = useState<TestData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isTestStarted, setIsTestStarted] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{
    [key: string]: string[];
  }>({});
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [flaggedQuestions, setFlaggedQuestions] = useState<Set<number>>(
    new Set()
  );
  const [isTimeUp, setIsTimeUp] = useState(false);
  const [isTestSubmitted, setIsTestSubmitted] = useState(false);
  const [activeTab, setActiveTab] = useState("details");

  // Job Applications state
  const [jobApplications, setJobApplications] = useState<JobApplication[]>([]);
  const [jobApplicationsLoading, setJobApplicationsLoading] = useState(false);
  const [jobApplicationsPage, setJobApplicationsPage] = useState(1);
  const [jobApplicationsPageSize] = useState(10);
  const [jobApplicationsTotalPages, setJobApplicationsTotalPages] = useState(1);
  const [jobApplicationsTotalCount, setJobApplicationsTotalCount] = useState(0);
  const [jobApplicationsSearchQuery, setJobApplicationsSearchQuery] =
    useState("");

  // Assign Test state
  const [assignTestModalOpen, setAssignTestModalOpen] = useState(false);
  const [selectedCandidates, setSelectedCandidates] = useState<number[]>([]);
  const [dueDate, setDueDate] = useState<string>("");

  // Get user role
  const userRole = user?.role?.name?.toLowerCase() as
    | "admin"
    | "recruiter"
    | "candidate";

  const fetchTestData = useCallback(
    async (testId: string) => {
      setLoading(true);
      try {
        const response = await testService.getTestById(testId);
        setTestData(response.data);
        setTimeRemaining(response.data.duration * 60);
      } catch (error) {
        console.error("Error fetching test:", error);
        toast({
          title: t`Error`,
          description: t`Failed to load test data. Please try again later.`,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    },
    [toast]
  );

  useEffect(() => {
    if (id) {
      fetchTestData(id);
    }
  }, [id, fetchTestData]);

  const fetchJobApplications = useCallback(async () => {
    if (!id) return;

    setJobApplicationsLoading(true);
    try {
      const response = await jobApplicationService.getJobApplicationsByTestId(
        id,
        {
          page: jobApplicationsPage,
          limit: jobApplicationsPageSize,
          search: jobApplicationsSearchQuery || undefined,
        }
      );

      if (response.metadata?.pagination) {
        setJobApplications(response.data);
        setJobApplicationsTotalCount(response.metadata.pagination.totalItems);
        setJobApplicationsTotalPages(response.metadata.pagination.totalPages);
      } else if (Array.isArray(response.data)) {
        setJobApplications(response.data);
        setJobApplicationsTotalCount(
          response.totalCount || response.data.length
        );
        setJobApplicationsTotalPages(response.totalPages || 1);
      } else if (response.data && typeof response.data === "object") {
        const data = response.data as {
          items?: JobApplication[];
          totalItems?: number;
          totalPages?: number;
        };
        setJobApplications(data.items || []);
        setJobApplicationsTotalCount(
          data.totalItems || data.items?.length || 0
        );
        setJobApplicationsTotalPages(data.totalPages || 1);
      } else {
        setJobApplications([]);
        setJobApplicationsTotalCount(0);
        setJobApplicationsTotalPages(1);
      }
    } catch (error) {
      console.error("Error fetching job applications:", error);
      toast({
        title: t`Error`,
        description: t`Failed to load job applications. Please try again later.`,
        variant: "destructive",
      });
    } finally {
      setJobApplicationsLoading(false);
    }
  }, [
    id,
    jobApplicationsPage,
    jobApplicationsPageSize,
    jobApplicationsSearchQuery,
    toast,
  ]);

  useEffect(() => {
    if (activeTab === "applications") {
      fetchJobApplications();
    }
  }, [activeTab, fetchJobApplications]);

  const handleSubmitTest = useCallback(
    (autoSubmit: boolean = false) => {
      if (autoSubmit) {
        console.log("Test auto-submitted due to time expiry");
      } else {
        console.log("Test submitted by user");
        setIsTestSubmitted(true);
      }
      console.log("Selected answers:", selectedAnswers);

      if (userRole === "recruiter") {
        toast({
          title: t`Preview Mode`,
          description: t`  This is just a preview. Test results are not saved to the backend.`,
          variant: "default",
        });
      }
    },
    [selectedAnswers, userRole, toast]
  );

  useEffect(() => {
    if (isTestStarted && timeRemaining > 0 && !isTestSubmitted) {
      const timer = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            setIsTimeUp(true);
            handleSubmitTest(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [isTestStarted, timeRemaining, isTestSubmitted, handleSubmitTest]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs
      .toString()
      .padStart(2, "0")}`;
  };

  const handleCancel = () => {
    window.location.reload();
  };

  const handleStartTest = () => {
    if (userRole === "recruiter") {
      console.log("Preview mode - no results will be saved");
      toast({
        title: t`Preview Mode`,
        description: t`This is just a preview. No results will be saved to the backend.`,
        variant: "default",
      });
    } else if (userRole === "candidate") {
      console.log("Candidate starting test");
    }
    setIsTestStarted(true);
  };

  const handleAnswerSelect = (questionId: string, optionId: string) => {
    const currentQuestion = testData?.questions[currentQuestionIndex];
    if (!currentQuestion) return;

    setSelectedAnswers((prev) => {
      const currentAnswers = prev[questionId] || [];

      if (currentAnswers.includes(optionId)) {
        return {
          ...prev,
          [questionId]: currentAnswers.filter((id) => id !== optionId),
        };
      } else {
        return { ...prev, [questionId]: [...currentAnswers, optionId] };
      }
    });
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleNext = () => {
    if (testData && currentQuestionIndex < testData.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handleFlag = () => {
    console.log(`Question ${currentQuestionIndex + 1} flagged for review`);
    setFlaggedQuestions((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(currentQuestionIndex)) {
        newSet.delete(currentQuestionIndex);
      } else {
        newSet.add(currentQuestionIndex);
      }
      return newSet;
    });
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const handleAssignTest = () => {
    setAssignTestModalOpen(true);
  };

  const handleSearchApplications = (e: React.ChangeEvent<HTMLInputElement>) => {
    setJobApplicationsSearchQuery(e.target.value);
  };

  const handleAssignTestSubmit = async () => {
    if (!id || selectedCandidates.length === 0 || !dueDate) {
      toast({
        title: t`Validation Error`,
        description: t`Please select candidates and due date`,
        variant: "destructive",
      });
      return;
    }

    try {
      const selectedApplications = jobApplications.filter((app) =>
        selectedCandidates.includes(app.candidate.id)
      );

      if (selectedApplications.length === 0) {
        toast({
          title: t`Error`,
          description: t`No valid job applications found for selected candidates`,
          variant: "destructive",
        });
        return;
      }

      const jobOfferId = selectedApplications[0].id;

      await testService.assignTest({
        testId: id,
        candidateIds: selectedCandidates,
        jobOfferId,
        dueDate,
      });

      toast({
        title: t`Success`,
        description: t`Test assigned successfully`,
        variant: "default",
      });

      setAssignTestModalOpen(false);
      setSelectedCandidates([]);
      setDueDate("");
      fetchJobApplications();
    } catch (error) {
      console.error("Error assigning test:", error);
      toast({
        title: t`Error`,
        description: t`Failed to assign test. Please try again later.`,
        variant: "destructive",
      });
    }
  };

  const handleCandidateSelect = (candidateId: number, isSelected: boolean) => {
    if (isSelected) {
      setSelectedCandidates((prev) => [...prev, candidateId]);
    } else {
      setSelectedCandidates((prev) => prev.filter((id) => id !== candidateId));
    }
  };

  const handlePageChange = (page: number) => {
    setJobApplicationsPage(page);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-600">
          <Trans>Loading test data...</Trans>
        </div>
      </div>
    );
  }

  if (!testData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-gray-600 mb-4">
            <Trans>Test not found</Trans>
          </div>
          <button
            onClick={handleCancel}
            className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg"
          >
            <Trans>Go Back</Trans>
          </button>
        </div>
      </div>
    );
  }

  const questionTypes = [
    ...new Set(testData.questions.map((q) => q.type)),
  ].join(", ");

  return (
    <div className="min-h-screen bg-white flex pt-4 justify-center">
      <div className="border-2 border-gray-200 rounded-lg min-w-[75%] my-4">
        <div className="flex items-center justify-between px-8 py-6 border-b border-gray-300">
          <div>
            <h1 className="text-xl font-semibold text-gray-900">
              {testData.title}
            </h1>
            {isTestStarted && (
              <p className="text-gray-500 text-sm mt-1">
                {userRole === "recruiter" ? (
                  <Trans>Recruiter Preview Mode (No data will be saved)</Trans>
                ) : (
                  <Trans>Candidate: Demo User</Trans>
                )}
              </p>
            )}
          </div>

          {isTestStarted ? (
            <button
              onClick={handleCancel}
              className="text-gray-400 hover:text-gray-600 p-2"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          ) : (
            userRole === "recruiter" && (
              <div className="flex gap-2">
                <button
                  onClick={handleStartTest}
                  className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-lg text-sm font-medium"
                >
                  <Trans>Preview Test</Trans>
                  <span className="ml-1 text-xs">
                    <Trans>(Simulation Only)</Trans>
                  </span>
                </button>
                <button
                  onClick={handleAssignTest}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-1"
                >
                  <Plus className="w-4 h-4" />
                  <Trans>Assign Test</Trans>
                </button>
              </div>
            )
          )}
        </div>

        {isTestStarted && userRole === "recruiter" && (
          <div className="bg-blue-50 border-b border-blue-100 px-6 py-2 text-center">
            <p className="text-blue-700 text-sm font-medium">
              <AlertTriangle className="w-4 h-4 inline-block mr-1" />
              <Trans>
                Preview Mode: This is a simulation only. No results will be
                saved to the backend.
              </Trans>
            </p>
          </div>
        )}

        {!isTestStarted && userRole === "recruiter" ? (
          <div className="px-6 py-4">
            <Tabs
              defaultValue="details"
              className="w-full"
              onValueChange={handleTabChange}
            >
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="details">
                  <Trans>Test Details</Trans>
                </TabsTrigger>
                <TabsTrigger value="applications">
                  <Trans>Job Applications</Trans>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="details">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        <Trans>Description</Trans>
                      </h3>
                      <p className="text-gray-600 text-sm">
                        {testData.description}
                      </p>
                    </div>

                    <div className="mb-6">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        <Trans>Test Settings</Trans>
                      </h3>
                      <div className="space-y-3 bg-gray-50 p-4 rounded-lg">
                        <div className="grid grid-cols-2 gap-y-2 gap-x-4">
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-600">
                              <Trans>
                                Duration: {testData.duration} minutes
                              </Trans>
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <Trophy className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-600">
                              <Trans>
                                Passing Score: {testData.passingScore}%
                              </Trans>
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-600">
                              <Trans>
                                Questions: {testData.questions.length}
                              </Trans>
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-600">
                              <Trans>Category: {testData.category}</Trans>
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-600">
                              <Trans>
                                Created:{" "}
                                {format(
                                  new Date(testData.created),
                                  "dd MMM yyyy"
                                )}
                              </Trans>
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-600">
                              <Trans>
                                Last Updated:{" "}
                                {format(
                                  new Date(testData.lastUpdated),
                                  "dd MMM yyyy"
                                )}
                              </Trans>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        <Trans>Questions Preview</Trans>
                      </h3>
                      <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
                        {testData.questions.map((question, index) => (
                          <div
                            key={question.id}
                            className="bg-gray-50 p-4 rounded-lg"
                          >
                            <div className="flex justify-between mb-2">
                              <h4 className="font-medium text-gray-900">
                                <Trans>Question {index + 1}</Trans>
                              </h4>
                              <span className="text-sm text-gray-500">
                                <Trans>{question.points} points</Trans>
                              </span>
                            </div>
                            <p className="text-sm text-gray-600 mb-2">
                              {question.question}
                            </p>
                            <div className="text-xs text-gray-500">
                              <Trans>
                                {question.options.length} options |
                                {
                                  question.options.filter((o) => o.isCorrect)
                                    .length
                                }{" "}
                                correct
                              </Trans>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="applications">
                <div>
                  <div className="mb-6 flex justify-between items-center">
                    <h3 className="text-lg font-semibold text-gray-900">
                      <Trans>Job Applications</Trans>
                    </h3>

                    <div className="flex gap-3">
                      <div className="relative">
                        <Search className="w-4 h-4 absolute top-1/2 transform -translate-y-1/2 left-3 text-gray-400" />
                        <input
                          type="text"
                          placeholder="Search candidates..."
                          className="pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
                          onChange={handleSearchApplications}
                        />
                      </div>

                      <button
                        onClick={handleAssignTest}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-1"
                      >
                        <Plus className="w-4 h-4" />
                        <Trans>Assign Test</Trans>
                      </button>
                    </div>
                  </div>

                  {jobApplicationsLoading ? (
                    <div className="text-center py-8">
                      <div className="text-gray-600">
                        <Trans>Loading job applications...</Trans>
                      </div>
                    </div>
                  ) : jobApplications.length === 0 ? (
                    <div className="text-center py-12 bg-gray-50 rounded-lg">
                      <div className="mb-3">
                        <Briefcase className="w-10 h-10 text-gray-400 mx-auto" />
                      </div>
                      <h4 className="text-gray-700 font-medium mb-1">
                        <Trans>No job applications found</Trans>
                      </h4>
                      <p className="text-gray-500 text-sm mb-4">
                        <Trans>
                          There are no job applications assigned to this test.
                        </Trans>
                      </p>
                      <button
                        onClick={handleAssignTest}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium"
                      >
                        <Trans>Assign Test to Candidates</Trans>
                      </button>
                    </div>
                  ) : (
                    <div>
                      <div className="overflow-x-auto">
                        <table className="min-w-full bg-white">
                          <thead>
                            <tr className="bg-gray-50 text-gray-600 text-left text-sm">
                              <th className="py-3 px-4 font-medium">
                                <Trans>Candidate</Trans>
                              </th>
                              <th className="py-3 px-4 font-medium">
                                <Trans>Applied Date</Trans>
                              </th>
                              <th className="py-3 px-4 font-medium">
                                <Trans>Status</Trans>
                              </th>
                              <th className="py-3 px-4 font-medium">
                                <Trans>Test Status</Trans>
                              </th>
                              <th className="py-3 px-4 font-medium">
                                <Trans>Score</Trans>
                              </th>
                              <th className="py-3 px-4 font-medium">
                                <Trans>Due Date</Trans>
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-200">
                            {jobApplications.map((application) => {
                              const testAssignment =
                                application.testAssignments?.find(
                                  (t) => t.testId === id
                                );

                              return (
                                <tr
                                  key={application.id}
                                  className="hover:bg-gray-50"
                                >
                                  <td className="py-3 px-4">
                                    <div className="flex items-center gap-2">
                                      <div className="w-8 h-8 bg-gray-200 rounded-full overflow-hidden">
                                        <div className="w-full h-full flex items-center justify-center text-gray-500 text-xs font-medium">
                                          {application.candidate.name.charAt(0)}
                                        </div>
                                      </div>
                                      <div>
                                        <div className="font-medium text-gray-900">
                                          {application.candidate.name}
                                        </div>
                                        <div className="text-gray-500 text-xs">
                                          {application.candidate.email}
                                        </div>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="py-3 px-4 text-sm text-gray-600">
                                    {format(
                                      new Date(application.appliedDate),
                                      "dd MMM yyyy"
                                    )}
                                  </td>
                                  <td className="py-3 px-4">
                                    <span
                                      className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium 
                                          ${
                                            application.status === "APPLIED"
                                              ? "bg-yellow-100 text-yellow-800"
                                              : application.status ===
                                                "SHORTLISTED"
                                              ? "bg-green-100 text-green-800"
                                              : application.status ===
                                                "REJECTED"
                                              ? "bg-red-100 text-red-800"
                                              : "bg-gray-100 text-gray-800"
                                          }`}
                                    >
                                      {application.status.charAt(0) +
                                        application.status
                                          .slice(1)
                                          .toLowerCase()}
                                    </span>
                                  </td>
                                  <td className="py-3 px-4">
                                    {testAssignment ? (
                                      <span
                                        className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium 
                                            ${
                                              testAssignment.status ===
                                              "ASSIGNED"
                                                ? "bg-yellow-100 text-yellow-800"
                                                : testAssignment.status ===
                                                  "COMPLETED"
                                                ? "bg-green-100 text-green-800"
                                                : testAssignment.status ===
                                                  "EXPIRED"
                                                ? "bg-red-100 text-red-800"
                                                : "bg-gray-100 text-gray-800"
                                            }`}
                                      >
                                        {testAssignment.status.charAt(0) +
                                          testAssignment.status
                                            .slice(1)
                                            .toLowerCase()}
                                      </span>
                                    ) : (
                                      <span className="text-gray-400 text-sm">
                                        <Trans>Not assigned</Trans>
                                      </span>
                                    )}
                                  </td>
                                  <td className="py-3 px-4 text-sm text-gray-600">
                                    {testAssignment?.score !== undefined
                                      ? `${testAssignment.score}%`
                                      : "-"}
                                  </td>
                                  <td className="py-3 px-4 text-sm text-gray-600">
                                    {testAssignment?.dueDate
                                      ? format(
                                          new Date(testAssignment.dueDate),
                                          "dd MMM yyyy"
                                        )
                                      : "-"}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>

                      <div className="mt-4 flex items-center justify-between">
                        <div className="text-sm text-gray-500">
                          <Trans>
                            Showing {jobApplications.length} of{" "}
                            {jobApplicationsTotalCount} applications
                          </Trans>
                        </div>

                        <div className="flex gap-2">
                          <button
                            onClick={() =>
                              handlePageChange(jobApplicationsPage - 1)
                            }
                            disabled={jobApplicationsPage === 1}
                            className="px-3 py-1 border border-gray-300 rounded text-sm disabled:opacity-50"
                          >
                            <Trans>Previous</Trans>
                          </button>
                          <button
                            onClick={() =>
                              handlePageChange(jobApplicationsPage + 1)
                            }
                            disabled={
                              jobApplicationsPage >= jobApplicationsTotalPages
                            }
                            className="px-3 py-1 border border-gray-300 rounded text-sm disabled:opacity-50"
                          >
                            <Trans>Next</Trans>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        ) : (
          isTestStarted && (
            <>
              <div className="px-8 py-4 border-b border-gray-300 bg-gray-50 mb-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-8">
                    <div className="text-base font-medium text-gray-900">
                      <Trans>
                        Question {currentQuestionIndex + 1} of{" "}
                        {testData.questions.length}
                      </Trans>
                    </div>

                    <button
                      onClick={handleFlag}
                      className={`flex items-center gap-1 p-1 rounded-lg transition-colors ${
                        flaggedQuestions.has(currentQuestionIndex)
                          ? "bg-orange-100 text-orange-600"
                          : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                      }`}
                    >
                      <Flag className="w-5 h-5" />
                      <span className="text-base font-medium">
                        <Trans>Flag</Trans>
                      </span>
                    </button>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="text-base font-medium text-gray-900">
                      <Trans>
                        Points:{" "}
                        {testData.questions[currentQuestionIndex]?.points || 0}
                      </Trans>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-gray-900" />
                      <span
                        className={`text-base font-medium ${
                          timeRemaining < 300 ? "text-red-600" : "text-gray-900"
                        }`}
                      >
                        {formatTime(timeRemaining)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-teal-600 h-2 rounded-full transition-all duration-300"
                    style={{
                      width: `${
                        ((currentQuestionIndex + 1) /
                          testData.questions.length) *
                        100
                      }%`,
                    }}
                  ></div>
                </div>
              </div>

              <div className="px-8 py-8 relative">
                {isTimeUp && (
                  <div className="absolute inset-0 bg-red-50 bg-opacity-95 flex items-center justify-center z-10">
                    <div className="bg-white border border-red-200 rounded-lg p-8 shadow-lg max-w-md mx-auto text-center">
                      <div className="flex justify-center mb-4">
                        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                          <AlertTriangle className="w-8 h-8 text-red-600" />
                        </div>
                      </div>
                      <h4 className="text-xl font-bold text-red-800 mb-2">
                        <Trans>Time's Up!</Trans>
                      </h4>
                      <p className="text-red-700 mb-4">
                        <Trans>
                          Your test has been automatically submitted.
                        </Trans>
                      </p>
                    </div>
                  </div>
                )}

                {isTestSubmitted && (
                  <div className="absolute inset-0 bg-green-50 bg-opacity-95 flex items-center justify-center z-10">
                    <div className="bg-white border border-green-200 rounded-lg p-8 shadow-lg max-w-md mx-auto text-center">
                      <div className="flex justify-center mb-4">
                        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                          <CheckCircle className="w-8 h-8 text-green-600" />
                        </div>
                      </div>
                      <h4 className="text-xl font-bold text-green-800 mb-2">
                        <Trans>Test Submitted Successfully!</Trans>
                      </h4>
                      <p className="text-green-700 mb-4">
                        {userRole === "recruiter" ? (
                          <Trans>
                            This was a preview only. No results were saved to
                            the backend.
                          </Trans>
                        ) : (
                          <Trans>
                            Your answers have been saved and submitted.
                          </Trans>
                        )}
                      </p>
                      <div className="text-sm text-green-600">
                        {userRole === "recruiter" ? (
                          <Trans>Preview mode completed</Trans>
                        ) : (
                          <Trans>Thank you for completing the test!</Trans>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {testData.questions[currentQuestionIndex] && (
                  <div className="mb-8">
                    <div className="flex justify-between items-start mb-6">
                      <h3 className="text-lg font-semibold text-gray-900 flex-1">
                        {testData.questions[currentQuestionIndex].question}
                      </h3>
                    </div>

                    <div className="space-y-3">
                      {testData.questions[currentQuestionIndex].options.map(
                        (option: TestQuestionOption) => {
                          const questionId =
                            testData.questions[currentQuestionIndex].id;
                          const isSelected =
                            selectedAnswers[questionId]?.includes(option.id) ||
                            false;

                          return (
                            <label
                              key={option.id}
                              className={`flex items-center gap-3 p-4 border rounded-lg cursor-pointer transition-colors ${
                                isSelected
                                  ? "border-teal-600 bg-teal-50"
                                  : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                              }`}
                            >
                              <input
                                type="checkbox"
                                name={`question-${questionId}`}
                                checked={isSelected}
                                onChange={() =>
                                  handleAnswerSelect(questionId, option.id)
                                }
                                className="w-4 h-4 text-teal-600 border-gray-300 focus:ring-teal-500 rounded"
                              />
                              <span className="text-gray-900 flex-1">
                                {option.text}
                              </span>
                            </label>
                          );
                        }
                      )}
                    </div>
                  </div>
                )}

                <div className="flex justify-between items-center">
                  <button
                    onClick={handlePrevious}
                    disabled={currentQuestionIndex === 0}
                    className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <Trans>Previous</Trans>
                  </button>

                  <div className="flex gap-3">
                    {currentQuestionIndex === testData.questions.length - 1 ? (
                      <button
                        onClick={() => handleSubmitTest(false)}
                        className="bg-green-600 hover:bg-green-700 text-white py-2 px-6 rounded-lg font-medium transition-colors"
                      >
                        <Trans>Submit Test</Trans>
                      </button>
                    ) : (
                      <button
                        onClick={handleNext}
                        className="flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white py-2 px-4 rounded-lg font-medium transition-colors"
                      >
                        <Trans>Next</Trans>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </>
          )
        )}

        {!isTestStarted && userRole !== "recruiter" && (
          <div className="px-8 py-8">
            <div className="max-w-2xl mx-auto">
              <div className="flex justify-center mb-8">
                <div className="w-16 h-16 bg-teal-50 rounded-full flex items-center justify-center">
                  <FileText className="w-8 h-8 text-teal-600" />
                </div>
              </div>

              <div className="text-center mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-3">
                  {testData.title}
                </h2>
                <p className="text-gray-600 text-sm leading-relaxed max-w-md mx-auto">
                  {testData.description}
                </p>
              </div>
            </div>

            <div className="mb-6 bg-gray-100 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6 text-center">
                <Trans>Test Instructions</Trans>
              </h3>

              <div className="space-y-4 mb-6">
                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Clock className="w-5 h-5 text-teal-600" />
                      <span className="text-sm text-gray-600">
                        <Trans>Duration: {testData.duration} minutes</Trans>
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <Trophy className="w-5 h-5 text-teal-600" />
                      <span className="text-sm text-gray-600">
                        <Trans>Passing Score: {testData.passingScore}%</Trans>
                      </span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-teal-600" />
                      <span className="text-sm text-gray-600">
                        <Trans>Questions: {testData.questions.length}</Trans>
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-teal-600" />
                      <span className="text-sm text-gray-600">
                        <Trans>Question types: {questionTypes}</Trans>
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-teal-600" />
                      <span className="text-sm text-gray-600">
                        <Trans>Category: {testData.category}</Trans>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-yellow-800 mb-2">
                    <Trans>Important Notes:</Trans>
                  </h4>
                  <ul className="text-sm text-yellow-700 space-y-1">
                    <li>
                      <Trans>• You cannot pause the test once started</Trans>
                    </li>
                    <li>
                      <Trans>
                        • You can navigate between questions and change answers
                      </Trans>
                    </li>
                    <li>
                      <Trans>• Flag questions for review if needed</Trans>
                    </li>
                    <li>
                      <Trans>• Submit the test before time runs out</Trans>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex justify-center">
              <button
                onClick={handleStartTest}
                className="bg-teal-600 hover:bg-teal-700 text-white py-3 px-8 rounded-lg font-medium transition-colors"
              >
                <Trans>Start Test</Trans>
              </button>
            </div>
          </div>
        )}
      </div>

      <Dialog open={assignTestModalOpen} onOpenChange={setAssignTestModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              <Trans>Assign Test to Candidates</Trans>
            </DialogTitle>
            <DialogDescription>
              <Trans>
                Select candidates and set a due date for test completion.
              </Trans>
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">
                <Trans>Due Date</Trans>
              </h4>
              <input
                type="date"
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
              />
            </div>

            <div className="space-y-2">
              <h4 className="text-sm font-medium">
                <Trans>Select Candidates</Trans>
              </h4>
              <div className="max-h-60 overflow-y-auto border border-gray-200 rounded-md">
                {jobApplications.map((application) => {
                  const isAssigned = application.testAssignments?.some(
                    (t) => t.testId === id
                  );
                  const isSelected = selectedCandidates.includes(
                    application.candidate.id
                  );

                  if (isAssigned) return null;

                  return (
                    <label
                      key={application.id}
                      className="flex items-center gap-3 p-3 border-b last:border-b-0 hover:bg-gray-50 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={(e) =>
                          handleCandidateSelect(
                            application.candidate.id,
                            e.target.checked
                          )
                        }
                        className="w-4 h-4 text-teal-600 border-gray-300 focus:ring-teal-500 rounded"
                      />
                      <div>
                        <div className="font-medium text-sm">
                          {application.candidate.name}
                        </div>
                        <div className="text-gray-500 text-xs">
                          {application.candidate.email}
                        </div>
                      </div>
                    </label>
                  );
                })}

                {jobApplications.length === 0 && (
                  <div className="p-4 text-center text-gray-500 text-sm">
                    <Trans>No eligible candidates found</Trans>
                  </div>
                )}
              </div>
            </div>
          </div>

          <DialogFooter className="sm:justify-between">
            <button
              type="button"
              onClick={() => setAssignTestModalOpen(false)}
              className="text-gray-500 hover:text-gray-700"
            >
              <Trans>Cancel</Trans>
            </button>
            <button
              type="button"
              onClick={handleAssignTestSubmit}
              disabled={selectedCandidates.length === 0 || !dueDate}
              className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-md disabled:opacity-50"
            >
              <Trans>Assign Test</Trans>
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TestPreview;
