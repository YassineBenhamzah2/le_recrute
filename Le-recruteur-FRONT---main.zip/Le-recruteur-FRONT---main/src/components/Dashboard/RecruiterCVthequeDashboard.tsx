import { useToast } from "@/hooks/use-toast";
import { cvthequeService } from "@/lib/network/recruiter_cvtheque";
import {
  Candidate,
  FilterOptions,
  Filters,
  PaginatedResponse,
} from "@/lib/types/recruiter";
import { t } from "@lingui/macro";
import { useEffect, useState } from "react";
import { useDebounce } from "use-debounce";
import { CandidateFilters } from "./recruiterComponents/CandidateFiltersCvTc";
import { CandidatesTable } from "./recruiterComponents/CandidatesTableCvTc";
import { ServerPagination } from "./recruiterComponents/ServerPagination";

const initialFilters: Filters = {
  name: "",
  positions: [],
  educationLevels: [],
  experienceLevels: [],
  jobTypes: [],
  sectors: [],
  skills: [],
  regions: [],
  companies: [],
  formations: [],
  certifications: [],
  cvStatus: [],
  email: "",
  phone: "",
  address: "",
};

export const CVthequePage: React.FC = () => {
  const [filters, setFilters] = useState<Filters>(initialFilters);
  const [debouncedFilters] = useDebounce(filters, 500);
  const [paginatedData, setPaginatedData] = useState<
    PaginatedResponse<Candidate>
  >({ data: [], totalPages: 0, totalCount: 0, currentPage: 1 });
  const [filterOptions, setFilterOptions] = useState<FilterOptions | null>(
    null
  );
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  // Fetch filter options once on component mount
  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const options = await cvthequeService.getFilterOptions();
        setFilterOptions(options);
      } catch (error) {
        console.error("Failed to fetch filter options:", error);
        toast({
          title: t`Error`,
          description: t`Unable to load filter options.`,
          variant: "destructive",
        });
      }
    };
    fetchOptions();
  }, [toast]);

  // Fetch candidates whenever filters or the current page change
  useEffect(() => {
    const fetchCandidates = async () => {
      setIsLoading(true);
      try {
        const response = await cvthequeService.getCandidates({
          ...debouncedFilters,
          page,
          size: 3,
        });
        setPaginatedData(response);
      } catch (error) {
        console.error("Failed to fetch candidates:", error);
        toast({
          title: t`Error`,
          description: t`Unable to load candidate list.`,
          variant: "destructive",
        });
        setPaginatedData({
          data: [],
          totalPages: 0,
          totalCount: 0,
          currentPage: 1,
        }); // Reset on error
      } finally {
        setIsLoading(false);
      }
    };
    fetchCandidates();
  }, [debouncedFilters, page, toast]);

  const handleFilterChange = (filterType: keyof Filters, value: string) => {
    setFilters((prev) => ({ ...prev, [filterType]: value }));
    setPage(1); // Go back to the first page on any filter change
  };

  const clearAllFilters = () => {
    setFilters(initialFilters);
    setPage(1);
  };

  const handleDownloadCv = async (
    candidateId: number,
    candidateName: string
  ) => {
    toast({
      title: t`Downloading...`,
      description: t`Downloading CV for ${candidateName}.`,
    });
    try {
      const blob = await cvthequeService.downloadCv(candidateId);

      // Create a temporary URL for the blob
      const url = window.URL.createObjectURL(blob);

      // Create a temporary anchor element and trigger download
      const link = document.createElement("a");
      link.href = url;
      link.download = `CV_${candidateName.replace(/\s+/g, "_")}.pdf`; // Clean filename
      document.body.appendChild(link);
      link.click();

      // Cleanup
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: t`Success!`,
        description: t`CV downloaded successfully.`,
      });
    } catch (error) {
      console.error("Failed to download CV:", error);
      toast({
        title: t`Error`,
        description: t`CV download failed.`,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="p-6 space-y-6">
      <CandidateFilters
        filters={filters}
        filterOptions={filterOptions}
        onFilterChange={handleFilterChange}
        onClearFilters={clearAllFilters}
        isLoading={!filterOptions}
        resultsCount={paginatedData.totalCount}
      />
      <CandidatesTable
        candidates={paginatedData.data}
        isLoading={isLoading}
        onDownloadCv={handleDownloadCv}
      />
      <ServerPagination
        currentPage={page}
        totalPages={paginatedData.totalPages}
        onPageChange={setPage}
      />
    </div>
  );
};
