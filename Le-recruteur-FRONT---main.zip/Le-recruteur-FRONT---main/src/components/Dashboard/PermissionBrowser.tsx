import React, { useState, useEffect } from "react";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../ui/card";
import { Badge } from "../ui/badge";
import { Search } from "lucide-react";
import { toast } from "sonner";
import { permissionService } from "../../lib/network/roles";
import { Permission } from "../../lib/types/license";
import { ROLE_TYPES } from "../../lib/utils/permissions";
import { useAuth } from "../../contexts/AuthContext";
import { Trans, t } from "@lingui/macro";

export const PermissionBrowser: React.FC = () => {
  const { user } = useAuth();

  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");

  const canViewPermissions = !!user;

  useEffect(() => {
    if (canViewPermissions) {
      loadPermissions();
    }
  }, [canViewPermissions]);

  const loadPermissions = async () => {
    try {
      setIsLoading(true);
      const response = await permissionService.getAll();
      setPermissions(response.data);
    } catch (error) {
      console.error("Error loading permissions:", error);
      toast.error(t({ id: "permissionBrowser.toast.loadError", message: "Error loading permissions" }));
    } finally {
      setIsLoading(false);
    }
  };

  const getPermissionTypeBadge = (type: string) => {
    const colors = {
      ADMIN: "bg-red-100 text-red-800",
      RECRUITER: "bg-blue-100 text-blue-800",
      CANDIDATE: "bg-green-100 text-green-800",
    };

    return (
      <Badge
        className={
          colors[type as keyof typeof colors] || "bg-gray-100 text-gray-800"
        }
      >
        {type}
      </Badge>
    );
  };

  const getPermissionIcon = (name: string) => {
    if (name.includes("ADMINISTRATOR")) return "🔑";
    if (name.includes("VIEWER")) return "👁️";
    if (name.includes("EDITOR")) return "✏️";
    return "🔒";
  };

  const groupPermissionsByController = (permissions: Permission[]) => {
    const grouped: Record<string, Permission[]> = {};

    permissions.forEach((permission) => {
      const parts = permission.name.split("_");
      const controller = parts.length > 1 ? parts.slice(1).join("_") : "OTHER";

      if (!grouped[controller]) {
        grouped[controller] = [];
      }
      grouped[controller].push(permission);
    });

    return grouped;
  };

  const filteredPermissions = permissions.filter((permission) => {
    const matchesSearch =
      permission.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (permission.description &&
        permission.description
          .toLowerCase()
          .includes(searchQuery.toLowerCase()));

    const matchesType =
      typeFilter === "all" || permission.permissionType === typeFilter;

    return matchesSearch && matchesType;
  });

  const groupedPermissions = groupPermissionsByController(filteredPermissions);

  if (!canViewPermissions) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500">
          <Trans id="permissionBrowser.noAccess">You don't have permission to view permissions.</Trans>
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            <Trans id="permissionBrowser.title">Permission Browser</Trans>
          </h1>
          <p className="text-gray-600">
            <Trans id="permissionBrowser.description">Browse all available system permissions</Trans>
          </p>
        </div>

        <div className="text-sm text-gray-500">
          <Trans id="permissionBrowser.totalPermissions">Total: {permissions.length} permissions</Trans>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-64">
              <Label htmlFor="search">
                <Trans id="permissionBrowser.filter.searchLabel">Search</Trans>
              </Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  id="search"
                  placeholder={t({
                    id: "permissionBrowser.filter.searchPlaceholder",
                    message: "Search permissions by name or description..."
                  })}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="min-w-48">
              <Label htmlFor="typeFilter">
                <Trans id="permissionBrowser.filter.typeLabel">Permission Type</Trans>
              </Label>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">
                    <Trans id="permissionBrowser.filter.allTypes">All Types</Trans>
                  </SelectItem>
                  <SelectItem value={ROLE_TYPES.ADMIN}>
                    <Trans id="permissionBrowser.filter.admin">Admin</Trans>
                  </SelectItem>
                  <SelectItem value={ROLE_TYPES.RECRUITER}>
                    <Trans id="permissionBrowser.filter.recruiter">Recruiter</Trans>
                  </SelectItem>
                  <SelectItem value={ROLE_TYPES.CANDIDATE}>
                    <Trans id="permissionBrowser.filter.candidate">Candidate</Trans>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Permissions grouped by controller */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 rounded"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(groupedPermissions).map(
            ([controller, controllerPermissions]) => (
              <Card key={controller}>
                <CardHeader>
                  <CardTitle className="text-xl flex items-center gap-2">
                    🎛️ {controller.replace("_", " ")} <Trans id="permissionBrowser.controllerLabel">Controller</Trans>
                  </CardTitle>
                  <CardDescription>
                    {controllerPermissions.length} <Trans id="permissionBrowser.permissionLabel">permission</Trans>
                    {controllerPermissions.length !== 1 ? "s" : ""}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {controllerPermissions.map((permission) => (
                      <div
                        key={permission.id}
                        className="p-4 border rounded-lg hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">
                              {getPermissionIcon(permission.name)}
                            </span>
                            <h3 className="font-semibold text-sm">
                              {permission.name}
                            </h3>
                          </div>
                          {getPermissionTypeBadge(permission.permissionType)}
                        </div>

                        {permission.description && (
                          <p className="text-sm text-gray-600 mb-2">
                            {permission.description}
                          </p>
                        )}

                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span><Trans id="permissionBrowser.idLabel">ID</Trans>: {permission.id}</span>
                          <span>
                            {permission.name.includes("VIEWER")
                              ? <Trans id="permissionBrowser.access.readOnly">Read Only</Trans>
                              : permission.name.includes("EDITOR")
                              ? <Trans id="permissionBrowser.access.fullAccess">Full Access</Trans>
                              : permission.name.includes("ADMINISTRATOR")
                              ? <Trans id="permissionBrowser.access.overrideAll">Override All</Trans>
                              : <Trans id="permissionBrowser.access.special">Special</Trans>}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )
          )}
        </div>
      )}

      {filteredPermissions.length === 0 && !isLoading && (
        <Card>
          <CardContent className="text-center py-12">
            <p className="text-gray-500">
              <Trans id="permissionBrowser.noResults">No permissions found matching your criteria.</Trans>
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};