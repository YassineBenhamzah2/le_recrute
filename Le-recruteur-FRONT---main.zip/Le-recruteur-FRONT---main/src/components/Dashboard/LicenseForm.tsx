import React, { useState } from "react";
import { Trans ,t } from "@lingui/macro";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  CreateLicenseRequest,
  UpdateLicenseRequest,
  License,
  Role,
} from "../../lib/types/license";
import { Calendar, DollarSign, FileText, Key, Users } from "lucide-react";

interface LicenseFormProps {
  roles: Role[];
  initialData?: License;
  onSubmit: (data: CreateLicenseRequest | UpdateLicenseRequest) => void;
  onCancel: () => void;
}

export const LicenseForm: React.FC<LicenseFormProps> = ({
  roles,
  initialData,
  onSubmit,
  onCancel,
}) => {
  const [formData, setFormData] = useState<CreateLicenseRequest>({
    name: initialData?.name || "",
    description: initialData?.description || "",
    price: initialData?.price || 0,
    roleId: initialData?.role?.id || 0,
    expirationDate: initialData?.expirationDate || "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      if (initialData) {
        // For updates, include the id
        onSubmit({ ...formData, id: initialData.id });
      } else {
        // For creates, just send the form data
        onSubmit(formData);
      }
    } finally {
      setIsSubmitting(false);
    }
  };


  return (
    <div className="h-[85vh] overflow-y-auto overflow-x-hidden">
      <form onSubmit={handleSubmit} className="space-y-6 m-4 ">
        {/* Header */}
        <div className="text-center pb-4 border-b border-gray-100">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-ehc-green/20 to-ehc-green/10 rounded-full flex items-center justify-center mb-3">
            <Key className="w-8 h-8 text-ehc-green" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">
            {initialData ? <Trans>Update License</Trans> : <Trans>Create New License</Trans>}
          </h2>
          <p className="text-gray-600 mt-1">
            {initialData ? (
              <Trans>Modify license settings and permissions</Trans>
            ) : (
              <Trans>Generate a new license with custom configurations</Trans>
            )}
          </p>
        </div>

        {/* License Name */}
        <div className="space-y-2">
          <Label
            htmlFor="name"
            className="text-sm font-semibold text-gray-700 flex items-center gap-2"
          >
            <FileText className="w-4 h-4 text-ehc-green" />
            <Trans>License Name</Trans>
          </Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder={t`e.g., Premium Recruiter License, Basic Candidate Access`}
            className="border-gray-200 focus:border-ehc-green focus:ring-ehc-green/20 transition-all duration-200"
            required
          />
          <p className="text-xs text-gray-500">
            <Trans>Choose a descriptive name for easy identification</Trans>
          </p>
        </div>

        {/* Description */}
        <div className="space-y-2">
          <Label
            htmlFor="description"
            className="text-sm font-semibold text-gray-700 flex items-center gap-2"
          >
            <FileText className="w-4 h-4 text-ehc-green" />
            <Trans>Description</Trans> <span className="text-gray-400"><Trans>(Optional)</Trans></span>
          </Label>
          <Textarea
            id="description"
            value={formData.description || ""}
            onChange={(e) =>
              setFormData({ ...formData, description: e.target.value })
            }
            placeholder={t`Describe the license features, limitations, and target users...`}
            className="border-gray-200 focus:border-ehc-green focus:ring-ehc-green/20 transition-all duration-200 min-h-[80px]"
            rows={3}
          />
          <p className="text-xs text-gray-500">
            <Trans>Detailed description helps users understand license capabilities</Trans>
          </p>
        </div>

        {/* Price */}
        <div className="space-y-2">
          <Label
            htmlFor="price"
            className="text-sm font-semibold text-gray-700 flex items-center gap-2"
          >
            <DollarSign className="w-4 h-4 text-ehc-green" />
            <Trans>License Price (USD)</Trans>
          </Label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              id="price"
              type="number"
              min="0"
              step="0.01"
              value={formData.price}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  price: parseFloat(e.target.value) || 0,
                })
              }
              placeholder="99.99"
              className="pl-10 border-gray-200 focus:border-ehc-green focus:ring-ehc-green/20 transition-all duration-200"
              required
            />
          </div>
          <p className="text-xs text-gray-500">
            <Trans>Set competitive pricing based on license features and duration</Trans>
          </p>
        </div>

        {/* Role Selection */}
        <div className="space-y-2">
          <Label
            htmlFor="roleId"
            className="text-sm font-semibold text-gray-700 flex items-center gap-2"
          >
            <Users className="w-4 h-4 text-ehc-green" />
            <Trans>Associated Role</Trans>
          </Label>
          <Select
            value={formData.roleId ? formData.roleId.toString() : ""}
            onValueChange={(value) =>
              setFormData({ ...formData, roleId: parseInt(value) })
            }
          >
            <SelectTrigger className="border-gray-200 focus:border-ehc-green focus:ring-ehc-green/20 transition-all duration-200">
              <SelectValue placeholder={<Trans>Select the role this license will grant access to...</Trans>} />
            </SelectTrigger>
            <SelectContent>
              {roles.length === 0 ? (
                <SelectItem value="0" disabled>
                  <Trans>No roles available</Trans>
                </SelectItem>
              ) : (
                roles
                  .filter((role) => role.roleType === "RECRUITER")
                  .map((role) => (
                    <SelectItem key={role.id} value={role.id.toString()}>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                        <span className="font-medium">{role.name}</span>
                        {role.description && (
                          <span className="text-gray-500 text-sm">
                            - {role.description}
                          </span>
                        )}
                      </div>
                    </SelectItem>
                  ))
              )}
            </SelectContent>
          </Select>
          <p className="text-xs text-gray-500">
            <Trans>The role determines what permissions and features this license provides</Trans>
          </p>
        </div>

        {/* Expiration Date */}
        <div className="space-y-2">
          <Label
            htmlFor="expirationDate"
            className="text-sm font-semibold text-gray-700 flex items-center gap-2"
          >
            <Calendar className="w-4 h-4 text-ehc-green" />
            <Trans>Expiration Date</Trans>
          </Label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              id="expirationDate"
              type="date"
              // min={today}
              value={
                formData.expirationDate
                  ? new Date(formData.expirationDate)
                      .toISOString()
                      .split("T")[0]
                  : ""
              }
              onChange={(e) =>
                setFormData({
                  ...formData,
                  expirationDate: e.target.value
                    ? new Date(e.target.value).toISOString()
                    : "",
                })
              }
              className="pl-10 border-gray-200 focus:border-ehc-green focus:ring-ehc-green/20 transition-all duration-200"
              required
            />
          </div>
          <p className="text-xs text-gray-500">
            <Trans>License will automatically expire on this date. Choose wisely based on pricing model.</Trans>
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-6 border-t border-gray-100">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSubmitting}
            className="border-gray-300 hover:bg-gray-50 transition-all duration-200"
          >
            <Trans>Cancel</Trans>
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
            className="bg-ehc-green hover:bg-ehc-green/90 text-white shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105"
          >
            {isSubmitting ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                {initialData ? <Trans>Updating...</Trans> : <Trans>Creating...</Trans>}
              </div>
            ) : (
              <>{initialData ? <Trans>Update License</Trans> : <Trans>Create License</Trans>}</>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};