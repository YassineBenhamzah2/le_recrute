import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { useToast } from "@/hooks/use-toast";
import { adminService } from "@/lib/network/dashboard/admin";
import { settings } from "@/lib/settings/main";
import { admin, admins } from "@/lib/types/dashboard/admin";
import {
  Calendar,
  Mail,
  MapPin,
  Pencil,
  Pickaxe,
  Settings,
  Trash2,
  UserPlus,
  Users
} from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AdminForm from "./AdminComponents/AdminForm";
import { Trans, t } from '@lingui/macro';

// Search and Filter Component
function SearchAndFilter({ searchTerm, onSearchChange, onSearchSubmit }) {
  return (
    <div className="flex flex-col md:flex-row gap-4 p-4">
      <form
        className="flex-1 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          onSearchSubmit();
        }}
      >
        <input
          type="text"
          placeholder={t({ id: "admin_management.search.placeholder", message: "Search admins by name, email, or location..." })}
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ehc-green-light focus:border-transparent"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-ehc-green text-white rounded-lg hover:bg-ehc-green-light"
        >
          <Trans id="admin_management.search.button">Search</Trans>
        </button>
      </form>
      {/* <div className="flex gap-2">
        <select
          onChange={(e) => onFilterChange(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="all">All Status</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div> */}
    </div>
  );
}

// Table Component
function TableAdmins({ admins, loading, onEdit, onDelete }) {
  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#238D94]"></div>
      </div>
    );
  }

  if (!admins || admins.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <Trans id="admin_management.table.no_admins">No admins found.</Trans>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-gray-200">
      <table className="min-w-full">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              <Trans id="admin_management.table.headers.admin">Admin</Trans>
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              <div className="flex items-center gap-1">
                <Mail size={16} />
                <span><Trans id="admin_management.table.headers.email">Email</Trans></span>
              </div>
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              <div className="flex items-center gap-1">
                <MapPin size={16} />
                <span><Trans id="admin_management.table.headers.location">Location</Trans></span>
              </div>
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              <div className="flex items-center gap-1">
                <Calendar size={16} />
                <span><Trans id="admin_management.table.headers.joined">Joined</Trans></span>
              </div>
            </th>
            {/* <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th> */}
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              <div className="flex items-center gap-1">
                <Pickaxe size={16} />
                <span><Trans id="admin_management.table.headers.actions">Actions</Trans></span>
              </div>
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {admins.map((admin) => (
            <tr key={admin.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="h-10 w-10 flex-shrink-0">
                    <img
                      className="h-10 w-10 rounded-full object-cover"
                      src={
                        `${settings.IMG_ADDRESS}${admin.profile_pic}` ||
                           settings.DEFAULT_USER_AVATAR
                      }
                      onError={(e) => {
                        e.currentTarget.src = settings.DEFAULT_USER_AVATAR ;
                      }}
                      alt={t({ id: "admin_management.table.profile_alt", message: "Profile picture" })}
                    />
                  </div>
                  <div className="ml-4">
                    <div className="font-medium text-gray-900">
                      {admin.firstname} {admin.lastname}
                    </div>
                    <div className="text-gray-500">{admin.phone}</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-ehc-green">
                {admin.email}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                {admin.location || t({ id: "admin_management.table.na", message: "N/A" })}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                {new Date(admin.createdAt).toLocaleDateString()}
              </td>
              {/* <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                  admin.status === 'active' ? 'bg-green-100 text-green-800' : 
                  admin.status === 'inactive' ? 'bg-yellow-100 text-yellow-800' : 
                  'bg-red-100 text-red-800'
                }`}>
                  {admin.status}
                </span>
              </td> */}
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex space-x-2">
                  {/* <button className="text-blue-500 hover:text-blue-700">
                    <Eye size={16} />
                  </button> */}
                  <button
                    className="text-green-500 hover:text-green-700"
                    onClick={() => onEdit(admin)}
                    title={t({ id: "admin_management.table.actions.edit_tooltip", message: "Edit admin" })}
                  >
                    <Pencil size={16} />
                  </button>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <button 
                        className="text-red-500 hover:text-red-700"
                        title={t({ id: "admin_management.table.actions.delete_tooltip", message: "Delete admin" })}
                      >
                        <Trash2 size={16} />
                      </button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          <Trans id="admin_management.delete_dialog.title">Confirm Deletion</Trans>
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          <Trans 
                            id="admin_management.delete_dialog.description" 
                            values={{ adminName: admin.firstname }}
                          >
                            Are you sure you want to delete "{admin.firstname}"?
                            This action cannot be undone.
                          </Trans>
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>
                          <Trans id="admin_management.delete_dialog.cancel">Cancel</Trans>
                        </AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => onDelete(admin.id)}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          <Trans id="admin_management.delete_dialog.delete">Delete</Trans>
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Pagination Component
function CustomPagination({ page, totalPages, onPageChange }) {
  const getPageItems = (
    current: number,
    total: number,
    siblingCount = 1
  ): (number | "…")[] => {
    const items: (number | "…")[] = [];
    if (total <= 1) return [1];

    const first = 1;
    const last = total;
    const start = Math.max(first + 1, current - siblingCount);
    const end = Math.min(last - 1, current + siblingCount);

    items.push(first);

    if (start > first + 1) items.push("…");

    for (let i = start; i <= end; i++) items.push(i);

    if (end < last - 1) items.push("…");

    if (last > first) items.push(last);

    return items;
  };

  const pageItems = getPageItems(page, totalPages, 1);

  return (
    <Pagination className="mt-6">
      <PaginationContent>
        <PaginationItem>
          <PaginationPrevious
            onClick={() => page > 1 && onPageChange(page - 1)}
            className={
              page === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"
            }
          />
        </PaginationItem>

        {pageItems.map((item, idx) =>
          item === "…" ? (
            <PaginationItem key={`ellipsis-${idx}`}>
              <PaginationEllipsis />
            </PaginationItem>
          ) : (
            <PaginationItem key={item}>
              <PaginationLink
                onClick={() => onPageChange(item)}
                isActive={page === item}
                className="cursor-pointer"
              >
                {item}
              </PaginationLink>
            </PaginationItem>
          )
        )}

        <PaginationItem>
          <PaginationNext
            onClick={() => page < totalPages && onPageChange(page + 1)}
            className={
              page === totalPages
                ? "pointer-events-none opacity-50"
                : "cursor-pointer"
            }
          />
        </PaginationItem>
      </PaginationContent>
    </Pagination>
  );
}

// Main Component
export default function AllAdmins() {
  const [admins, setAdmins] = useState<admins[]>([]);
  const [filteredAdmins, setFilteredAdmins] = useState<admin[]>([]);
  const [editAdmin, setEditAdmin] = useState<admin | null>(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    fetchAdmins();
  }, [page]);

  useEffect(() => {
    filterAdmins();
  }, [admins, filterStatus]);

  const fetchAdmins = async () => {
    setLoading(true);
    try {
      const response = await adminService.getAllAdmins();
      if (response.success) {
        setAdmins(response.data);
        setTotalPages(response.metadata?.totalPages || 1);
        console.log("all", response.data);
      } else {
        toast({
          title: t({ id: "admin_management.toast.error", message: "Error" }),
          description: response.message || t({ id: "admin_management.toast.fetch_failed", message: "Failed to fetch admins" }),
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error fetching admins:", error);
      toast({
        title: t({ id: "admin_management.toast.error", message: "Error" }),
        description: t({ id: "admin_management.toast.fetch_failed", message: "Failed to fetch admins" }),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const searchAdmins = async () => {
    if (!searchTerm.trim()) {
      fetchAdmins();
      return;
    }

    setLoading(true);
    try {
      const res = await adminService.searchAdmins(searchTerm);
      if (res.success) {
        setAdmins(res.data);
        setTotalPages(1);
      } else {
        toast({
          title: t({ id: "admin_management.toast.error", message: "Error" }),
          description: res.message || t({ id: "admin_management.toast.search_failed", message: "Failed to search admins" }),
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error searching admins:", error);
      toast({
        title: t({ id: "admin_management.toast.error", message: "Error" }),
        description: t({ id: "admin_management.toast.search_failed", message: "Failed to search admins" }),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const filterAdmins = () => {
    let result = admins;

    // Apply status filter
    if (filterStatus !== "all") {
      result = result.filter((admin) => admin.status === filterStatus);
    }

    setFilteredAdmins(result);
  };

  const handleAddAdmin = () => {
    setEditAdmin(null);
    setShowForm(true);
  };

  const handleEditAdmin = (admin: admin) => {
    setEditAdmin(admin);
    setShowForm(true);
  };

  const handleDeleteAdmin = async (id: number) => {
    try {
      const res = await adminService.deleteAdmin(id);
      if (res.success) {
        // Refresh the admin list
        fetchAdmins();
        toast({
          title: t({ id: "admin_management.toast.success", message: "Success" }),
          description: t({ id: "admin_management.toast.delete_success", message: "Admin has been deleted successfully." }),
        });
      } else {
        toast({
          title: t({ id: "admin_management.toast.error", message: "Error" }),
          description: res.message || t({ id: "admin_management.toast.delete_failed", message: "Failed to delete admin" }),
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error deleting admin:", error);
      toast({
        title: t({ id: "admin_management.toast.error", message: "Error" }),
        description: t({ id: "admin_management.toast.delete_failed", message: "Failed to delete admin" }),
        variant: "destructive",
      });
    }
  };

  const handleSaveAdmin = async (formData: FormData) => {
    try {
      let res;

      if (editAdmin) {
        // Update existing admin
        res = await adminService.updateAdmin(editAdmin.id, formData);
      } else {
        // Create new admin
        res = await adminService.createAdmin(formData);
        console.log("formData", formData);
      }

      if (res.success) {
        setShowForm(false);
        setEditAdmin(null);
        // Refresh the admin list
        fetchAdmins();
        toast({
          title: t({ id: "admin_management.toast.success", message: "Success" }),
          description: editAdmin
            ? t({ id: "admin_management.toast.update_success", message: "Admin updated successfully" })
            : t({ id: "admin_management.toast.create_success", message: "Admin created successfully" }),
        });
      } else {
        toast({
          title: t({ id: "admin_management.toast.error", message: "Error" }),
          description:
            res.message ||
            (editAdmin 
              ? t({ id: "admin_management.toast.update_failed", message: "Failed to update admin" })
              : t({ id: "admin_management.toast.create_failed", message: "Failed to create admin" })),
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error saving admin:", error);
      toast({
        title: t({ id: "admin_management.toast.error", message: "Error" }),
        description: editAdmin
          ? t({ id: "admin_management.toast.update_error", message: "Error updating admin" })
          : t({ id: "admin_management.toast.create_error", message: "Error creating admin" }),
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            <Trans id="admin_management.header.title">Admin Management</Trans>
          </h1>
          <p className="text-gray-600">
            <Trans id="admin_management.header.description">
              View, track, and manage all administrators and their activity in one place
            </Trans>
          </p>
        </div>

        <h2 className="font-bold text-xl mb-5">
          <Trans id="admin_management.quick_actions.title">Quick Actions</Trans>
        </h2>

        {/* Quick actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 mx-5">
          <button
            className="flex items-center space-x-3 p-4 bg-white border-2 border-gray-200 rounded-lg hover:border-[#238D94] hover:text-[#238D94] transition-colors shadow-md"
            onClick={handleAddAdmin}
          >
            <div className="p-2 border-2 border-gray-300 rounded-md">
              <UserPlus size={24} className="text-[#238D94]" />
            </div>
            <div className="text-left">
              <div className="font-medium">
                <Trans id="admin_management.quick_actions.add_admin.title">Add Admin</Trans>
              </div>
              <div className="text-sm text-gray-500">
                <Trans id="admin_management.quick_actions.add_admin.description">
                  Add one or multiple new admins to the platform.
                </Trans>
              </div>
            </div>
          </button>

          <button className="flex items-center space-x-3 p-4 bg-white border-2 border-gray-200 rounded-lg hover:border-[#238D94] hover:text-[#238D94] transition-colors shadow-md" onClick={() => navigate("/admin/roles")}>
            <div className="p-2 border-2 border-gray-300 rounded-md">
              <Settings size={24} className="text-[#238D94]" />
            </div>
            <div className="text-left">
              <div className="font-medium">
                <Trans id="admin_management.quick_actions.manage_roles.title">Manage Roles</Trans>
              </div>
              <div className="text-sm text-gray-500">
                <Trans id="admin_management.quick_actions.manage_roles.description">
                  Define role permissions and assign them to admins.
                </Trans>
              </div>
            </div>
          </button>

          <button
            className="flex items-center space-x-3 p-4 bg-white border-2 border-gray-200 rounded-lg hover:border-[#238D94] hover:text-[#238D94] transition-colors shadow-md"
            onClick={() => navigate("/admin/allCandidates")}
          >
            <div className="p-2 border-2 border-gray-300 rounded-md">
              <Users size={24} className="text-[#238D94]" />
            </div>
            <div className="text-left">
              <div className="font-medium">
                <Trans id="admin_management.quick_actions.view_candidates.title">View Candidates</Trans>
              </div>
              <div className="text-sm text-gray-500">
                <Trans id="admin_management.quick_actions.view_candidates.description">
                  Monitor admin activities and access logs.
                </Trans>
              </div>
            </div>
          </button>
        </div>

        {/* Search and filter */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-6">
          <SearchAndFilter
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            onSearchSubmit={searchAdmins}
          />
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold text-lg">
              <Trans id="admin_management.table.title">All Administrators</Trans>
            </h3>
            <span className="text-sm text-gray-500">
              <Trans 
                id="admin_management.table.results_count" 
                values={{ count: filteredAdmins.length }}
              >
                {filteredAdmins.length} results
              </Trans>
            </span>
          </div>
          <TableAdmins
            admins={filteredAdmins}
            loading={loading}
            onEdit={handleEditAdmin}
            onDelete={handleDeleteAdmin}
          />
        </div>

        {/* Pagination */}
        <CustomPagination
          page={page}
          totalPages={totalPages}
          onPageChange={setPage}
        />
      </div>

      {/* Admin Form Modal */}
      {showForm && (
        <AdminForm
          adminData={editAdmin}
          onSave={handleSaveAdmin}
          onCancel={() => {
            setShowForm(false);
            setEditAdmin(null);
          }}
        />
      )}
    </div>
  );
}