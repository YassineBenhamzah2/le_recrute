import {
  Calendar,
  Clock,
  Crown,
  FileText,
  TrendingUp,
  Users,
} from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { recruiterDashboardService } from "../../lib/network/dashboard/recruiter";
import {
  DashboardInterview,
  DashboardJobOfferApplication,
  DashboardStatistics,
  InterviewStatistics,
} from "../../lib/types/dashboard/recruiter";
import { DashboardFilter } from "../../lib/types/subtype/main";
import BarChartComponent from "./recruiterComponents/BarChart";
import CalendarComponent from "./recruiterComponents/Calendar";
import { Trans } from "@lingui/macro";

function RecruiterDashboard() {
  const [selectedFilter, setSelectedFilter] = useState<DashboardFilter>("week");

  // API Data states
  const [dashboardStats, setDashboardStats] =
    useState<DashboardStatistics | null>(null);
  const [jobApplications, setJobApplications] = useState<
    DashboardJobOfferApplication[]
  >([]);
  const [interviews, setInterviews] = useState<DashboardInterview[]>([]);
  const [interviewStats, setInterviewStats] =
    useState<InterviewStatistics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Calendar and UI states
  const [range, setRange] = useState([
    {
      startDate: new Date(),
      endDate: new Date(),
      key: "selection" as const,
    },
  ]);

  // Fetch dashboard data
  const fetchDashboardData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const [statsResponse, applicationsResponse, interviewStatsResponse] =
        await Promise.all([
          recruiterDashboardService.getDashboardStatistics(selectedFilter),
          recruiterDashboardService.getJobOfferApplication(),
          recruiterDashboardService.getInterviewStatistics(),
        ]);

      if (statsResponse.success) {
        setDashboardStats(statsResponse.data);
      }

      if (applicationsResponse.success) {
        setJobApplications(applicationsResponse.data);
      }

      if (interviewStatsResponse.success) {
        setInterviewStats(interviewStatsResponse.data);
      }
    } catch (err) {
      setError("Failed to fetch dashboard data");
      console.error("Dashboard fetch error:", err);
    } finally {
      setLoading(false);
    }
  }, [selectedFilter]);

  // Fetch interviews with date range
  const fetchInterviews = useCallback(async () => {
    try {
      const startTime = range[0].startDate.toISOString();
      const endTime = range[0].endDate.toISOString();

      const response = await recruiterDashboardService.getDashboardInterviews({
        startTime,
        endTime,
      });

      if (response.success) {
        setInterviews(response.data);
      }
    } catch (err) {
      console.error("Interviews fetch error:", err);
    }
  }, [range]);

  // Initialize data
  useEffect(() => {
    fetchDashboardData();
  }, [selectedFilter, fetchDashboardData]);

  // Fetch interviews when date range changes
  useEffect(() => {
    fetchInterviews();
  }, [range, fetchInterviews]);

  const handleFilterChange = (filter: DashboardFilter) => {
    setSelectedFilter(filter);
  };

  // Create dynamic main metrics from API data
  const getMainMetrics = () => {
    if (!dashboardStats) return [];

    return [
      {
        title: <Trans>Active Job Openings</Trans>,
        value: dashboardStats.totalActiveJobOffers.toString(),
        icon: Users,
        iconColor: "bg-[#238D94]",
      },
      {
        title: <Trans>Total Jobs</Trans>,
        value: dashboardStats.totalJobOffers.toLocaleString(),
        icon: TrendingUp,
        iconColor: "bg-[#238D94]",
      },
      {
        title: <Trans>Scheduled Interviews</Trans>,
        value: dashboardStats.scheduledInterviews.toString(),
        icon: Calendar,
        iconColor: "bg-[#238D94]",
      },
      {
        title: <Trans>Candidate Rating</Trans>,
        value: `${dashboardStats.candidateRating}/5`,
        icon: FileText,
        iconColor: "bg-[#238D94]",
      },
    ];
  };

  // Create recruitment metrics from API data
  const getRecruitmentMetrics = () => {
    if (!dashboardStats) return [];

    return [
      {
        title: <Trans>Avg Response Time</Trans>,
        value: dashboardStats.avgResponseTime,
        icon: Clock,
        iconColor: "bg-[#238D94]",
      },
    ];
  };

  // Transform job applications data for chart
  const getChartData = () => {
    return jobApplications.map((app) => ({
      name: app.title,
      value: app.numberOfApplications,
    }));
  };

  // Get upcoming meetings from interviews
  const getUpcomingMeetings = () => {
    return interviews
      .filter((interview) => interview.status === "SCHEDULED")
      .map((interview) => ({
        title: <Trans>Interview - {interview.candidateName}</Trans>,
        time: new Date(interview.scheduledAt).toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
        }),
        date: new Date(interview.scheduledAt),
      }))
      .slice(0, 5); // Show only next 5 meetings
  };

  const currentDate = new Date();
  const mainMetrics = getMainMetrics();
  const recruitmentMetrics = getRecruitmentMetrics();
  const chartData = getChartData();
  const upcomingMeetings = getUpcomingMeetings();

  // Get values from dashboard stats or use defaults
  const hiringSuccess = dashboardStats?.hiringSuccess || 0;
  // The candidate rating is value between 0 - 5 We will make the candidateSatisfaction between 0 - 100
  const candidateSatisfaction = dashboardStats?.candidateRating
    ? (dashboardStats?.candidateRating / 5) * 100
    : 0;

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 font-poppins flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#238D94] mx-auto"></div>
          <p className="mt-4 text-gray-600"><Trans>Loading dashboard...</Trans></p>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 font-poppins flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">{error}</p>
          <button
            onClick={fetchDashboardData}
            className="px-4 py-2 bg-[#238D94] text-white rounded-lg hover:bg-[#1a6b75] transition-colors"
          >
            <Trans>Retry</Trans>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 font-poppins">
      {/* Main Content with sidebar offset */}
      <div className="flex-1">
        {/* Main Content */}
        <main className="p-6 space-y-6">
          {/* Welcome Section */}
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6">
              <div className="mb-4 lg:mb-0">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  <Trans>Welcome back</Trans>
                </h2>
                <p className="text-gray-600">
                  <Trans>Ready to dive into your team today</Trans>
                </p>
              </div>
              {/* Filter Section Options : this week , All , This month */}
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-600 font-medium">
                  <Trans>Filter by:</Trans>
                </span>
                <button
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    selectedFilter === "week"
                      ? "bg-[#238D94] text-white hover:bg-[#1a6b75]"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                  onClick={() => handleFilterChange("week")}
                >
                  <Trans>This Week</Trans>
                </button>
                <button
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    selectedFilter === "all"
                      ? "bg-[#238D94] text-white hover:bg-[#1a6b75]"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                  onClick={() => handleFilterChange("all")}
                >
                  <Trans>All</Trans>
                </button>
                <button
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    selectedFilter === "month"
                      ? "bg-[#238D94] text-white hover:bg-[#1a6b75]"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                  onClick={() => handleFilterChange("month")}
                >
                  <Trans>This Month</Trans>
                </button>
              </div>
              <div className="text-left lg:text-right">
                <p className="text-sm text-gray-500"><Trans>Today</Trans></p>
                <p className="text-lg font-semibold text-gray-900">
                  {currentDate.toLocaleDateString("en-US", {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-3 p-4 bg-[#238D94] bg-opacity-10 rounded-lg hover:bg-opacity-15 transition-all duration-200 cursor-pointer">
                <div className="p-2 bg-[#238D94] rounded-lg shadow-md">
                  <Users className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 font-medium">
                    <Trans>Post New Jobs</Trans>
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">
                    <Trans>Create and publish job openings</Trans>
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-4 bg-[#238D94] bg-opacity-10 rounded-lg hover:bg-opacity-15 transition-all duration-200 cursor-pointer">
                <div className="p-2 bg-[#238D94] rounded-lg shadow-md">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 font-medium">
                    <Trans>Manage Team</Trans>
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">
                    <Trans>View and manage candidate progress</Trans>
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-4 bg-[#238D94] bg-opacity-10 rounded-lg hover:bg-opacity-15 transition-all duration-200 cursor-pointer">
                <div className="p-2 bg-[#238D94] rounded-lg shadow-md">
                  <Calendar className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 font-medium">
                    <Trans>Analytics & Reports</Trans>
                  </p>
                  <p className="font-semibold text-gray-900 text-sm">
                    <Trans>Track performance and metrics</Trans>
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Metrics */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              <Trans>Recruitment Overview</Trans>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {mainMetrics.length > 0 ? (
                mainMetrics.map((metric, index) => {
                  const Icon = metric.icon;
                  return (
                    <div
                      key={index}
                      className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div
                          className={`p-3 rounded-lg ${metric.iconColor} shadow-sm`}
                        >
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium text-gray-600 mb-1">
                          {metric.title}
                        </h4>
                        <p className="text-3xl font-bold text-gray-900">
                          {metric.value}
                        </p>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="col-span-full text-center py-8 text-gray-500">
                  <p><Trans>Loading metrics...</Trans></p>
                </div>
              )}
            </div>
          </div>

          {/* Performance Metrics */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              <Trans>Recruitment Metrics</Trans>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Regular metrics */}
              {recruitmentMetrics.map((metric, index) => {
                const Icon = metric.icon;
                return (
                  <div
                    key={index}
                    className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div
                        className={`p-3 rounded-lg ${metric.iconColor} shadow-sm`}
                      >
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-600 mb-1">
                        {metric.title}
                      </h4>
                      <p className="text-3xl font-bold text-gray-900">
                        {metric.value}
                      </p>
                    </div>
                  </div>
                );
              })}

              {/* Interview Statistics Card */}
              {interviewStats && (
                <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 rounded-lg bg-[#238D94] shadow-sm">
                      <Calendar className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-sm font-semibold px-2 py-1 rounded-full text-[#238D94] bg-[#238D94] bg-opacity-10">
                      <Trans>Today: {interviewStats.interviewsToday}</Trans>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-600 mb-1">
                      <Trans>Total Interviews</Trans>
                    </h4>
                    <p className="text-3xl font-bold text-gray-900">
                      {interviewStats.totalInterviews}
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                      <Trans>
                        {interviewStats.interviewsCompleted} completed,{" "}
                        {interviewStats.interviewsScheduled} scheduled
                      </Trans>
                    </p>
                  </div>
                </div>
              )}

              {/* Hiring Success */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer">
                <div className="flex flex-col items-center">
                  <div className="relative w-20 h-20 mb-4">
                    <svg
                      className="w-20 h-20 transform -rotate-90"
                      viewBox="0 0 100 100"
                    >
                      {/* Background circle */}
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        className="text-gray-200"
                      />
                      {/* Progress circle */}
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        strokeDasharray={`${hiringSuccess * 2.83} ${
                          100 * 2.83
                        }`}
                        className="text-[#238D94] transition-all duration-300"
                        strokeLinecap="round"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-xl font-bold text-gray-900">
                        {hiringSuccess}%
                      </span>
                    </div>
                  </div>
                  <h4 className="text-sm font-medium text-gray-600 text-center">
                    <Trans>Hiring Success</Trans>
                  </h4>
                </div>
              </div>

              {/* Candidate Satisfaction */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer">
                <div className="flex flex-col items-center">
                  <div className="relative w-20 h-20 mb-4">
                    <svg
                      className="w-20 h-20 transform -rotate-90"
                      viewBox="0 0 100 100"
                    >
                      {/* Background circle */}
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        className="text-gray-200"
                      />
                      {/* Progress circle */}
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        strokeDasharray={`${candidateSatisfaction * 2.83} ${
                          100 * 2.83
                        }`}
                        className="text-[#238D94] transition-all duration-300"
                        strokeLinecap="round"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-xl font-bold text-gray-900">
                        {candidateSatisfaction}%
                      </span>
                    </div>
                  </div>
                  <h4 className="text-sm font-medium text-gray-600 text-center">
                    <Trans>Candidate Satisfaction</Trans>
                  </h4>
                </div>
              </div>
            </div>
          </div>

          {/* Candidates Chart and Calendar Section */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Candidates Chart - Spans 2 columns */}
            <div className="xl:col-span-2">
              {chartData.length > 0 ? (
                <BarChartComponent data={chartData} />
              ) : (
                <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 h-80 flex items-center justify-center">
                  <div className="text-center">
                    <div className="animate-pulse flex space-x-4">
                      <div className="flex-1 space-y-6 py-1">
                        <div className="h-2 bg-gray-200 rounded"></div>
                        <div className="space-y-3">
                          <div className="grid grid-cols-3 gap-4">
                            <div className="h-2 bg-gray-200 rounded col-span-2"></div>
                            <div className="h-2 bg-gray-200 rounded col-span-1"></div>
                          </div>
                          <div className="h-2 bg-gray-200 rounded"></div>
                        </div>
                      </div>
                    </div>
                    <p className="mt-4 text-gray-500">
                      <Trans>Loading job application data...</Trans>
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Calendar and Upgrade Section */}
            <div className="space-y-6">
              {/* Calendar */}
              <CalendarComponent range={range} setRange={setRange} />

              <div className="mt-6 pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between text-sm mb-4">
                  <span className="text-gray-700 font-semibold">
                    <Trans>Upcoming Events</Trans>
                  </span>
                  <span className="text-[#238D94] font-bold bg-[#238D94] bg-opacity-10 px-3 py-1 rounded-full text-xs border border-[#238D94] border-opacity-20">
                    <Trans>{upcomingMeetings.length} events</Trans>
                  </span>
                </div>
                <div className="space-y-3">
                  {upcomingMeetings.map((meeting, idx) => (
                    <div
                      key={idx}
                      className="flex items-center space-x-3 text-sm p-3 hover:bg-gray-50 rounded-lg transition-colors duration-200 border border-gray-100"
                    >
                      <div className="w-3 h-3 bg-[#238D94] rounded-full shadow-sm"></div>
                      <div className="flex-1">
                        <span className="text-gray-800 font-medium">
                          {meeting.title}
                        </span>
                        <p className="text-xs text-gray-500 mt-1">
                          {meeting.time}
                        </p>
                      </div>
                    </div>
                  ))}
                  {upcomingMeetings.length === 0 && (
                    <div className="text-center py-4 text-gray-500">
                      <Trans>No upcoming interviews scheduled</Trans>
                    </div>
                  )}
                </div>
              </div>

              {/* Upgrade Card */}
              <div className="bg-gradient-to-br from-[#238D94] via-[#2da5b3] to-[#1a6b75] rounded-xl p-6 text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 relative overflow-hidden">
                {/* Background pattern */}
                <div className="absolute inset-0 opacity-10">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full -translate-y-16 translate-x-16"></div>
                  <div className="absolute bottom-0 left-0 w-24 h-24 bg-white rounded-full translate-y-12 -translate-x-12"></div>
                </div>

                <div className="relative z-10">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="p-3 bg-white bg-opacity-20 rounded-xl backdrop-blur-sm shadow-lg">
                      <Crown className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold"><Trans>Upgrade to Pro</Trans></h3>
                  </div>
                  <p className="text-sm text-white text-opacity-95 mb-6 leading-relaxed font-medium">
                    <Trans>Unlock advanced analytics, team collaboration features, and AI-powered insights to supercharge your HR workflow</Trans>
                  </p>
                  <button className="w-full bg-white text-[#238D94] px-6 py-3 rounded-xl font-bold hover:bg-gray-50 transition-all duration-200 hover:shadow-lg hover:scale-105 text-sm">
                    <Trans>Learn More & Upgrade</Trans>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default RecruiterDashboard;