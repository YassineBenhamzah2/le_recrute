import { Header } from "@/components/Dashboard/recruiterComponents/profileComponents/Header";
import React, { useState } from "react";
import { CompanyPage } from "./recruiterComponents/profileComponents/CompanyPage";
import { OverviewPage } from "./recruiterComponents/profileComponents/OverviewPage";
import { PermissionsPage } from "./recruiterComponents/profileComponents/PermissionsPage";
import { SecurityPage } from "./recruiterComponents/profileComponents/SecurityPage";
import { RecruiterInfoProfile } from "./recruiterComponents/profileComponents/RecruiterInfoProfile";


type TabName = "Overview" | "Company" | "Permissions & Licenses" | "Security";

const RecruiterProfileDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabName>("Overview");

  const renderActiveTabContent = () => {
    switch (activeTab) {
      case "Overview":
        return <OverviewPage />;
      case "Company":
        return <CompanyPage />;
      case "Permissions & Licenses":
        return <PermissionsPage />;
      case "Security":
        return <SecurityPage />;
      default:
        return <OverviewPage />;
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen flex text-gray-800">
      <div className="flex-1 flex flex-col">
        <div className="flex-1 p-6 lg:p-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
            <div className="lg:col-span-2 space-y-8">
              <Header activeTab={activeTab} onTabChange={(tab) => setActiveTab(tab as TabName)} />
                
                <div className="mt-6">
                    {renderActiveTabContent()}
                </div>
            </div>
           
            <div className="lg:col-span-1">
              <RecruiterInfoProfile />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecruiterProfileDashboard;
