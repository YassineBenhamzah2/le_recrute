import React, { useState, useEffect, useCallback } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { Badge } from "../ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "../ui/alert-dialog";
import {
  Copy,
  Edit,
  Plus,
  Search,
  Trash2,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { toast } from "sonner";
import { licenseService } from "../../lib/network/license";
import { roleService } from "../../lib/network/roles";
import {
  License,
  Role,
  CreateLicenseRequest,
  UpdateLicenseRequest,
} from "../../lib/types/license";
import { LICENSE_STATUS } from "../../lib/utils/permissions";
import { useAuth } from "@/contexts/AuthContext";

export const LicenseDashboardTable: React.FC = () => {
  const [licenses, setLicenses] = useState<License[]>([]);
  const { user } = useAuth();
  const [roles, setRoles] = useState<Role[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedLicense, setSelectedLicense] = useState<License | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isCopySuccessModalOpen, setIsCopySuccessModalOpen] = useState(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const itemsPerPage = 10;

  // Mock permission check - in real app this would use proper permission system
  const canViewLicenses = user?.role.type === "ADMIN";
  const canEditLicenses = user?.role.type === "ADMIN";

  const loadLicenses = useCallback(async () => {
    try {
      setIsLoading(true);
      const response = await licenseService.getAll({
        page: currentPage,
        limit: itemsPerPage,
        search: searchTerm || undefined,
      });
      setLicenses(response.data);

      // Handle pagination metadata if available
      if (response.metadata?.pagination) {
        setTotalPages(response.metadata.pagination.totalPages);
        setTotalItems(response.metadata.pagination.totalItems);
      }
    } catch (error) {
      console.error("Error loading licenses:", error);
      toast.error("Error loading licenses");
    } finally {
      setIsLoading(false);
    }
  }, [currentPage, searchTerm]);

  useEffect(() => {
    if (canViewLicenses) {
      loadLicenses();
      loadRoles();
    }
  }, [canViewLicenses, currentPage, searchTerm, statusFilter, loadLicenses]);

  const loadRoles = async () => {
    try {
      const response = await roleService.getAll();
      setRoles(response.data);
    } catch (error) {
      console.error("Error loading roles:", error);
    }
  };

  const handleCreateLicense = async (
    formData: CreateLicenseRequest | UpdateLicenseRequest
  ) => {
    try {
      // For create, we only need CreateLicenseRequest fields
      const createData = formData as CreateLicenseRequest;
      await licenseService.create(createData);
      toast.success("License created successfully");
      setIsCreateDialogOpen(false);
      loadLicenses();
    } catch (error) {
      console.error("Error creating license:", error);
      toast.error("Error creating license");
    }
  };

  const handleUpdateLicense = async (
    formData: CreateLicenseRequest | UpdateLicenseRequest
  ) => {
    try {
      // For update, we need the UpdateLicenseRequest with id
      const updateData = formData as UpdateLicenseRequest;
      if (!updateData.id) {
        toast.error("License ID is required for update");
        return;
      }
      await licenseService.update(updateData.id, updateData);
      toast.success("License updated successfully");
      setIsEditDialogOpen(false);
      setSelectedLicense(null);
      loadLicenses();
    } catch (error) {
      console.error("Error updating license:", error);
      toast.error("Error updating license");
    }
  };

  const handleDeleteLicense = async (license: License) => {
    try {
      await licenseService.delete(license.id);
      toast.success("License deleted successfully");
      loadLicenses();
    } catch (error) {
      console.error("Error deleting license:", error);
      toast.error("Error deleting license");
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setIsCopySuccessModalOpen(true);
      // Auto-close the modal after 2 seconds
      setTimeout(() => {
        setIsCopySuccessModalOpen(false);
      }, 2000);
    } catch {
      toast.error("Failed to copy to clipboard");
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case LICENSE_STATUS.ACTIVE:
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case LICENSE_STATUS.SUSPENDED:
        return <Badge className="bg-red-100 text-red-800">Suspended</Badge>;
      case LICENSE_STATUS.EXPIRED:
        return <Badge className="bg-yellow-100 text-yellow-800">Expired</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  const filteredLicenses = licenses.filter((license) => {
    const matchesSearch =
      license.licenseKey.toLowerCase().includes(searchTerm.toLowerCase()) ||
      license.name?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === "all" || license.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  if (!canViewLicenses) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500">
          You don't have permission to view licenses
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            License Management
          </h1>
          <p className="text-gray-600">
            Manage system licenses and permissions
          </p>
        </div>
        {canEditLicenses && (
          <Dialog
            open={isCreateDialogOpen}
            onOpenChange={setIsCreateDialogOpen}
          >
            <DialogTrigger asChild>
              <Button className="bg-[#238D94] hover:bg-[#1a6b72]">
                <Plus className="w-4 h-4 mr-2" />
                Create License
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New License</DialogTitle>
                <DialogDescription>
                  Create a new license with specific permissions and settings.
                </DialogDescription>
              </DialogHeader>
              <LicenseForm
                roles={roles}
                onSubmit={handleCreateLicense}
                onCancel={() => setIsCreateDialogOpen(false)}
              />
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Filters */}
      <div className="flex gap-4 items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search licenses..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value={LICENSE_STATUS.ACTIVE}>Active</SelectItem>
            <SelectItem value={LICENSE_STATUS.SUSPENDED}>Suspended</SelectItem>
            <SelectItem value={LICENSE_STATUS.EXPIRED}>Expired</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* License Table */}
      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>License Key</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Assigned User</TableHead>
              <TableHead>Created</TableHead>
              <TableHead>Expires</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8">
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#238D94]"></div>
                    <span className="ml-2">Loading licenses...</span>
                  </div>
                </TableCell>
              </TableRow>
            ) : filteredLicenses.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8">
                  <p className="text-gray-500">No licenses found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredLicenses.map((license) => (
                <TableRow key={license.id}>
                  <TableCell className="font-mono">
                    <div className="flex items-center gap-2">
                      <span className="truncate max-w-[120px]">
                        {license.licenseKey}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(license.licenseKey)}
                        className="p-1 h-6 w-6"
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </TableCell>
                  <TableCell>{license.name}</TableCell>
                  <TableCell>{license.role?.name || "Unknown"}</TableCell>
                  <TableCell>{getStatusBadge(license.status)}</TableCell>
                  <TableCell>
                    {license.assignedUser
                      ? `${license.assignedUser.firstname} ${license.assignedUser.lastname}`
                      : "N/A"}
                  </TableCell>
                  <TableCell>
                    {new Date(license.createdAt || "").toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    {license.expirationDate
                      ? new Date(license.expirationDate).toLocaleDateString()
                      : "Never"}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center gap-1 justify-end">
                      {canEditLicenses && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedLicense(license);
                              setIsEditDialogOpen(true);
                            }}
                            className="p-1 h-8 w-8"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="p-1 h-8 w-8 text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>
                                  Delete License
                                </AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to delete this license?
                                  This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDeleteLicense(license)}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-700">
          Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
          {Math.min(currentPage * itemsPerPage, totalItems)} of {totalItems}{" "}
          licenses
        </p>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
            disabled={currentPage <= 1}
          >
            <ChevronLeft className="w-4 h-4" />
            Previous
          </Button>
          <span className="text-sm px-3 py-1 bg-gray-100 rounded">
            Page {currentPage} of {totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() =>
              setCurrentPage((prev) => Math.min(totalPages, prev + 1))
            }
            disabled={currentPage >= totalPages}
          >
            Next
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Edit Dialog */}
      {selectedLicense && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit License</DialogTitle>
              <DialogDescription>
                Update license information and settings.
              </DialogDescription>
            </DialogHeader>
            <LicenseForm
              roles={roles}
              initialData={selectedLicense}
              onSubmit={handleUpdateLicense}
              onCancel={() => {
                setIsEditDialogOpen(false);
                setSelectedLicense(null);
              }}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Copy Success Modal */}
      <Dialog
        open={isCopySuccessModalOpen}
        onOpenChange={setIsCopySuccessModalOpen}
      >
        <DialogContent className="sm:max-w-md">
          <div className="flex items-center space-x-4 p-6">
            <div className="flex-shrink-0">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <svg
                  className="w-6 h-6 text-green-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-medium text-gray-900">
                Copied Successfully!
              </h3>
              <p className="text-sm text-gray-500">
                License key has been copied to your clipboard.
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// License Form Component
interface LicenseFormProps {
  roles: Role[];
  initialData?: License;
  onSubmit: (data: CreateLicenseRequest | UpdateLicenseRequest) => void;
  onCancel: () => void;
}

const LicenseForm: React.FC<LicenseFormProps> = ({
  roles,
  initialData,
  onSubmit,
  onCancel,
}) => {
  const [formData, setFormData] = useState<CreateLicenseRequest>({
    name: initialData?.name || "",
    description: initialData?.description || "",
    price: initialData?.price || 0,
    roleId: initialData?.role?.id || 0,
    expirationDate: initialData?.expirationDate || "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (initialData) {
      // For updates, include the id
      onSubmit({ ...formData, id: initialData.id });
    } else {
      // For creates, just send the form data
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">License Name</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Description (Optional)</Label>
        <Input
          id="description"
          value={formData.description || ""}
          onChange={(e) =>
            setFormData({ ...formData, description: e.target.value })
          }
        />
      </div>

      <div>
        <Label htmlFor="price">Price</Label>
        <Input
          id="price"
          type="number"
          min="0"
          step="0.01"
          value={formData.price}
          onChange={(e) =>
            setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })
          }
          required
        />
      </div>

      <div>
        <Label htmlFor="roleId">Role</Label>
        <Select
          value={formData.roleId.toString()}
          onValueChange={(value) =>
            setFormData({ ...formData, roleId: parseInt(value) })
          }
        >
          <SelectTrigger>
            <SelectValue placeholder="Select a role" />
          </SelectTrigger>
          <SelectContent>
            {roles.map((role) => (
              <SelectItem key={role.id} value={role.id.toString()}>
                {role.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="expirationDate">Expiration Date</Label>
        <Input
          id="expirationDate"
          type="date"
          value={
            formData.expirationDate
              ? new Date(formData.expirationDate).toISOString().split("T")[0]
              : ""
          }
          onChange={(e) =>
            setFormData({
              ...formData,
              expirationDate: e.target.value
                ? new Date(e.target.value).toISOString()
                : "",
            })
          }
          required
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" className="bg-[#238D94] hover:bg-[#1a6b72]">
          {initialData ? "Update" : "Create"} License
        </Button>
      </div>
    </form>
  );
};

export { LicenseDashboardTable as LicenseDashboard };
