import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import FullCalendar from "@fullcalendar/react";
import { format, isSameDay, parseISO } from "date-fns";
import { useEffect, useMemo, useRef, useState } from "react";
import { DayPicker } from "react-day-picker";
import { interviewService } from "@/lib/network/interview";
import { Interview } from "@/lib/types/interview";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import { Trans } from "@lingui/macro";

export default function RecruiterCalendar() {
  const [selectedDay, setSelectedDay] = useState<Date | undefined>(new Date());
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [loading, setLoading] = useState(true);
  const calendarRef = useRef<FullCalendar | null>(null);

  // Fetch interviews from API
  const fetchInterviews = async () => {
    try {
      setLoading(true);
      const response = await interviewService.getRecruiterInterviews();
      if (response.success && response.data) {
        setInterviews(response.data);
      } else {
        toast.error(<Trans>Failed to load interviews</Trans>);
      }
    } catch (error) {
      console.error("Error fetching interviews:", error);
      toast.error(<Trans>Error loading interviews</Trans>);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInterviews();
  }, []);

  // Convert interviews to calendar events format
  const events = useMemo(() => {
    return interviews.map((interview) => ({
      id: interview.id.toString(),
      title: interview.position,
      candidate: interview.candidate?.name || <Trans>Unknown Candidate</Trans>,
      start: interview.date + "T" + interview.time,
      end: interview.date + "T" + interview.time, // You might want to add duration logic
      status: interview.status,
    }));
  }, [interviews]);

  const filteredEvents = useMemo(() => {
    if (!selectedDay) return [];
    return events.filter((e) => isSameDay(parseISO(e.start), selectedDay));
  }, [selectedDay, events]);

  const renderEventContent = (arg: { event: { id: string } }) => {
    const ev = events.find((e) => e.id === arg.event.id);
    return (
      <div
        className="flex flex-col border border-emerald-200 rounded-md shadow-sm overflow-hidden hover:shadow-md w-32 transition"
        style={{ borderLeftWidth: "4px", borderLeftColor: "#065f46" }} // Dark emerald
      >
        {ev?.start && ev?.end && (
          <div className="px-2 py-0.5 bg-white border-t border-emerald-100 text-[10px] text-gray-500">
            {new Date(ev.start).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
            {" - "}
            {new Date(ev.end).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </div>
        )}
        <div className="px-2 py-1 bg-emerald-50">
          <div className="text-[11px] font-semibold text-emerald-900 leading-snug line-clamp-1">
            {ev?.title}
          </div>
          <div className="text-[10px] text-gray-600 line-clamp-1">
            {ev?.candidate}
          </div>
          <div className="text-[9px] text-gray-500">{ev?.status}</div>
        </div>
      </div>
    );
  };

  const handleDaySelect = (date?: Date) => {
    if (!date) return;
    setSelectedDay(date);

    const calendarApi = calendarRef.current?.getApi();
    if (calendarApi) {
      calendarApi.gotoDate(date); // jumps to date in FullCalendar
    }
  };

  return (
    <div className="flex flex-col md:max-w-[1600px] mx-auto gap-6">
      <header className="flex justify-between items-center py-8 px-6">
        <div className="flex items-center">
          <img className="w-16 h-16" alt="/Hero Jobs" src="/HeroJobs.png" />
          <div className="ml-4">
            <h1 className="text-4xl font-bold [font-family:'Segoe_UI-Bold',Helvetica] bg-gradient-to-r from-[rgba(35,141,148,1)] to-[rgba(20,184,166,1)] bg-clip-text text-transparent">
              <Trans>Interview Schedule</Trans>
            </h1>
            <p className="text-lg text-gray-600 [font-family:'Segoe_UI-Regular',Helvetica]">
              <Trans>Manage your interview schedule efficiently</Trans>
            </p>
          </div>
        </div>

        <Button
          onClick={fetchInterviews}
          disabled={loading}
          variant="outline"
          size="sm"
          className="flex items-center gap-2"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          <Trans>Refresh</Trans>
        </Button>
      </header>
      <div className="flex w-full md:max-w-[1500px] mx-auto gap-6">
        {/* Sidebar */}
        <aside className="w-fit bg-white rounded-xl border p-4 shadow-sm">
          <h2 className="text-lg font-bold text-emerald-700 mb-3">
            <Trans>Select Date</Trans>
          </h2>
          <DayPicker
            mode="single"
            selected={selectedDay}
            onSelect={handleDaySelect}
            className="mb-6"
            classNames={{
              today: "custom-today",
              selected: "custom-selected",
              day: "custom-day",
            }}
            styles={{
              day_selected: {
                backgroundColor: "#238D94",
                color: "white",
              },
              day_today: {
                color: "#238D94",
                fontWeight: "bold",
              },
              today: {
                color: "#238D94",
                fontWeight: "bold",
              },
              selected: {
                color: "white",
                outline: "2px solid #238D94",
              },
              day: {
                borderRadius: "6px",
              },
            }}
          />
          <h3 className="text-md font-semibold text-gray-700 mb-2">
            <Trans>Daily Interviews</Trans>
          </h3>
          <div className="space-y-2">
            {loading ? (
              <div className="text-xs text-gray-500">
                <Trans>Loading interviews...</Trans>
              </div>
            ) : filteredEvents.length > 0 ? (
              filteredEvents.map((ev) => (
                <div
                  key={`${ev.id}-${ev.start}`}
                  className="border border-emerald-300 rounded-lg p-2 bg-emerald-50"
                >
                  <div className="text-sm font-bold text-emerald-800">
                    {ev.title}
                  </div>
                  <div className="text-xs text-gray-600">{ev.candidate}</div>
                  <div className="text-xs text-gray-500">
                    {format(parseISO(ev.start), "HH:mm")} -{" "}
                    {format(parseISO(ev.end), "HH:mm")}
                  </div>
                  <div className="text-xs text-blue-600 font-medium">
                    {ev.status}
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-gray-500">
                <Trans>No interviews scheduled</Trans>
              </p>
            )}
          </div>
        </aside>

        {/* Full Calendar */}
        <div className="flex-1 bg-white rounded-xl border shadow-sm p-4">
          <FullCalendar
            plugins={[dayGridPlugin, interactionPlugin]}
            initialView="dayGridMonth"
            events={events}
            ref={calendarRef}
            height="auto"
            dayMaxEventRows={2}
            firstDay={1}
            eventContent={renderEventContent}
            headerToolbar={{
              left: "title",
              center: "",
              right: "",
            }}
          />
        </div>
      </div>
    </div>
  );
}