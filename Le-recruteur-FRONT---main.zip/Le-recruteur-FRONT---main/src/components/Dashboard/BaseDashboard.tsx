import { ReactNode } from "react";

interface DashboardProps {
  SideBar: ReactNode;
  Header?: ReactNode;
  children?: ReactNode;
  Footer?: ReactNode;
}

const Dashboard = ({ SideBar, Header, children, Footer }: DashboardProps) => {
  return (
    <div className="flex h-screen bg-gray-50">
      <div className="flex-shrink-0 w-20 ">{SideBar}</div>
      <div className="flex-1 flex flex-col overflow-hidden">
        {Header}
        <main className="flex-1 overflow-y-auto pb-16">{children}</main>
        {Footer && <div className="flex-shrink-0 w-full">{Footer}</div>}
      </div>
    </div>
  );
};
export default Dashboard;
