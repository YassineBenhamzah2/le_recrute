import {
  BriefcaseIcon,
  LineChartIcon,
  PauseIcon,
  PlusIcon,
  UsersIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { DashboardSection } from "./recruiterComponents/DashboardSection";
import {
  JobListSection,
  JobListSectionHandle,
} from "./recruiterComponents/JobListSection";
import { CreateJobModal } from "./recruiterComponents/CreateJobModal";
import { useState, useEffect, useRef } from "react";
import type { FilterOption } from "./recruiterComponents/DashboardSection";
import { recruiterDashboardService } from "@/lib/network/dashboard/recruiter";
import { JobStatistics } from "@/lib/types/dashboard/recruiter";
import { JobStatus, JobType } from "@/lib/types/subtype/main";
import { Trans } from "@lingui/macro";
import { t } from "@lingui/core/macro";

interface StatCard {
  icon: JSX.Element;
  bgGradient: string;
  title: React.ReactNode;
  value: string;
  loading?: boolean;
}

export const RecruiterJobsDashboard = (): JSX.Element => {
  // Controlled state for filters and search
  const [search, setSearch] = useState("");
  const [location, setLocation] = useState<FilterOption | null>(null);
  const [type, setType] = useState<JobType | null>(null);
  const [status, setStatus] = useState<JobStatus | null>(null);
  const [isCreateJobModalOpen, setIsCreateJobModalOpen] = useState(false);

  // Reference to the JobListSection component
  const refreshJobsRef = useRef<JobListSectionHandle | null>(null);

  // Dynamic statistics state
  const [jobStats, setJobStats] = useState<JobStatistics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch job statistics on component mount
  useEffect(() => {
    fetchJobStatistics();
  }, []);

  const fetchJobStatistics = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await recruiterDashboardService.getJobStatistics();

      if (response.success && response.data) {
        setJobStats(response.data);
      } else {
        setError(t`Failed to fetch job statistics`);
      }
    } catch (err) {
      console.error("Error fetching job statistics:", err);
      setError(t`Failed to load statistics`);
    } finally {
      setLoading(false);
    }
  };

  // Create stat cards with dynamic data
  const getStatCards = (): StatCard[] => {
    const defaultCards: StatCard[] = [
      {
        icon: <BriefcaseIcon className="h-6 w-6 text-white" />,
        bgGradient:
          "bg-gradient-to-r from-[rgba(35,141,148,1)] to-[rgba(20,184,166,1)]",
        title: <Trans>Total Jobs</Trans>,
        value: loading ? "..." : jobStats?.totalJobs.toString() || "0",
        loading,
      },
      {
        icon: <LineChartIcon className="h-6 w-6 text-white" />,
        bgGradient:
          "bg-gradient-to-r from-[rgba(16,185,129,1)] to-[rgba(20,184,166,1)]",
        title: <Trans>Active Jobs</Trans>,
        value: loading ? "..." : jobStats?.activeJobs.toString() || "0",
        loading,
      },
      {
        icon: <UsersIcon className="h-6 w-6 text-white" />,
        bgGradient:
          "bg-gradient-to-r from-[rgba(35,141,148,1)] to-[rgba(20,184,166,1)]",
        title: <Trans>Total Applicants</Trans>,
        value: loading ? "..." : jobStats?.totalApplications.toString() || "0",
        loading,
      },
      {
        icon: <PauseIcon className="h-6 w-6 text-white" />,
        bgGradient:
          "bg-gradient-to-r from-[rgba(35,141,148,1)] to-[rgba(20,184,166,1)]",
        title: <Trans>Paused Jobs</Trans>,
        value: loading ? "..." : jobStats?.pausedJobs.toString() || "0",
        loading,
      },
    ];

    return defaultCards;
  };

  const statCards = getStatCards();

  return (
    <div className="w-full   md:max-w-[1440px]  2xl:max-w-[1440px] mx-auto overflow-y-auto">
      <header className="flex justify-between items-center py-8 px-6">
        <div className="flex items-center">
          <img className="w-16 h-16" alt="/Hero Jobs" src="/HeroJobs.png" />
          <div className="ml-4">
            <h1 className="text-4xl font-bold [font-family:'Segoe_UI-Bold',Helvetica] bg-gradient-to-r from-[rgba(35,141,148,1)] to-[rgba(20,184,166,1)] bg-clip-text text-transparent">
              <Trans>Job Management</Trans>
            </h1>
            <p className="text-lg text-gray-600 [font-family:'Segoe_UI-Regular',Helvetica]">
              <Trans>Manage your job postings efficiently</Trans>
            </p>
          </div>
        </div>

        <Button
          className="bg-gradient-to-r from-[rgba(35,141,148,1)] to-[rgba(20,184,166,1)] text-white rounded-xl h-12 px-6 shadow-[0px_4px_6px_-4px_#0000001a,0px_10px_15px_-3px_#0000001a]"
          onClick={() => setIsCreateJobModalOpen(true)}
        >
          <PlusIcon className="h-5 w-5 mr-2" />
          <span className="[font-family:'Segoe_UI-Semibold',Helvetica]">
            <Trans>Create New Job</Trans>
          </span>
        </Button>

        <CreateJobModal
          open={isCreateJobModalOpen}
          onOpenChange={setIsCreateJobModalOpen}
          onJobCreated={() => {
            // Refresh statistics when a job is created
            fetchJobStatistics();
            // Refresh job list to display the newly created job
            if (refreshJobsRef.current) {
              refreshJobsRef.current.refreshJobs();
            }
          }}
        />
      </header>

      {/* Error Message */}
      {error && (
        <div className="mx-6 mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 px-6">
        {statCards.map((card, index) => (
          <Card
            key={index}
            className="border shadow-[0px_2px_4px_-2px_#0000001a,0px_4px_6px_-1px_#0000001a] rounded-xl"
          >
            <CardContent className="p-6">
              <div
                className={`w-12 h-12 rounded-lg flex items-center justify-center ${card.bgGradient}`}
              >
                {card.icon}
              </div>
              <div className="mt-5 [font-family:'Segoe_UI-Semibold',Helvetica] text-gray-600">
                {card.title}
              </div>
              <div className="mt-3 text-3xl font-bold [font-family:'Segoe_UI-Bold',Helvetica] text-gray-900">
                {card.loading ? (
                  <div className="animate-pulse">
                    <div className="h-8 bg-gray-200 rounded w-12"></div>
                  </div>
                ) : (
                  card.value
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-6 px-6">
        <DashboardSection
          search={search}
          onSearch={setSearch}
          location={location}
          onLocationChange={setLocation}
          type={type}
          onTypeChange={setType}
          status={status}
          onStatusChange={setStatus}
        />
      </div>

      <div className="mt-6 px-6">
        <JobListSection
          search={search}
          location={location}
          type={type}
          status={status}
          onJobsChanged={() => {
            // Refresh statistics when jobs are updated or deleted
            fetchJobStatistics();
          }}
          ref={refreshJobsRef}
        />
      </div>
    </div>
  );
};
