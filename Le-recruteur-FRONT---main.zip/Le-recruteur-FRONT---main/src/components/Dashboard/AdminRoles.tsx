import { useState, useEffect } from "react";
import {
  Plus,
  UserPlus,
  Settings,
  Users,
  Pencil,
  Trash2,
  Briefcase,
  Text,
  Hammer,
  Check,
  X,
} from "lucide-react";
import { api } from "@/lib/network/utils/api";

interface Role {
  id: number;
  name: string;
  description: string;
}

let RoleDescriptions: Role[];
function TableRoles() {
  async function fetchRoles() {
    try {
      const res = await api.getAll<Role>("/api/admin/allRoles");
      RoleDescriptions = res;
    } catch (err) {
      console.error(err);
    }
  }

  useEffect(() => {
    fetchRoles();
  }, []);

  return (
    <div className="mt-10">
      {/* Header */}
      <div className="flex items-center  mb-4">
        <h2 className="text-xl font-bold text-gray-800">Admin Roles</h2>
        <button className="flex items-center gap-1 border border-green-600 text-green-600 px-2 py-1 m-2 rounded hover:bg-green-100 ">
          <Plus size={16} />
        </button>
      </div>

      {/* Table */}
      <div className="shadow rounded-lg overflow-hidden border border-gray-200">
        <table className="min-w-full bg-white">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">
                <div className="flex items-center gap-2">
                  <Briefcase size={16} />
                  <span>Role</span>
                </div>
              </th>
              <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">
                <div className="flex items-center gap-2">
                  <Text size={16} />
                  <span>Description</span>
                </div>
              </th>
              <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">
                <div className="flex items-center gap-2">
                  <Hammer size={16} />
                  <span>Actions</span>
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
            {RoleDescriptions &&
              RoleDescriptions.map((role, idx) => (
                <tr key={idx} className="border-t hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">
                    {role.name}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-700 max-w-4xl">
                    {role.description}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    <div className="flex items-center space-x-3">
                      <button className="text-blue-600 hover:text-blue-800">
                        <Pencil size={16} />
                      </button>
                      <button className="text-red-600 hover:text-red-800">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const Roles: string[] = [
  "Super Administrator",
  "Recruitment Manager",
  "Recruiter",
  "Compliance Auditor",
  "Support/Admin Assistant",
];

type Permission = {
  action: string;
  permissions: {
    [role in Roles]: boolean;
  };
};

const permissionsData: Permission[] = [
  {
    action: "Manage Admin Roles",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: false,
      "Compliance Auditor": false,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "View Platform Stats",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: false,
      "Compliance Auditor": false,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "Manage Job Postings",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: true,
      "Compliance Auditor": false,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "View Candidate Data",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: true,
      "Compliance Auditor": true,
      "Support/Admin Assistant": true,
    },
  },
  {
    action: "Approve/Reject Candidates",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: true,
      "Compliance Auditor": false,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "Assign Admin Roles",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": false,
      Recruiter: false,
      "Compliance Auditor": false,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "Assign Recruiter Roles",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: false,
      "Compliance Auditor": false,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "Schedule Interviews",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: true,
      "Compliance Auditor": false,
      "Support/Admin Assistant": true,
    },
  },
  {
    action: "View User Activity Logs",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": false,
      Recruiter: false,
      "Compliance Auditor": true,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "View Uploaded Documents",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: true,
      "Compliance Auditor": true,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "Download Documents",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: true,
      "Compliance Auditor": true,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "Modify/Delete Job Listings or Posts",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: false,
      "Compliance Auditor": false,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "Edit Candidate Status",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: false,
      "Compliance Auditor": false,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "Access Permissions Matrix",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: false,
      "Compliance Auditor": false,
      "Support/Admin Assistant": false,
    },
  },
  {
    action: "Assist with Document Uploads",
    permissions: {
      "Super Admin": true,
      "Recruitment Manager": true,
      Recruiter: false,
      "Compliance Auditor": false,
      "Support/Admin Assistant": true,
    },
  },
];

function PermissionsMatrix() {
  return (
    <div className="mt-10">
      {/* header */}
      <h2 className="text-xl font-bold text-gray-800 mb-2">Admin Roles</h2>

      <div className="overflow-x-auto">
        {/* table permissions */}
        <table className="min-w-full text-sm text-left border-separate border-spacing-y-3">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-4 py-3 font-semibold text-gray-700">
                Permission / Action
              </th>
              {Roles.map((role) => (
                <th
                  key={role}
                  className="px-4 py-3 font-semibold text-gray-700 text-center"
                >
                  {role}
                </th>
              ))}
              <th className="px-4 py-3 font-semibold text-gray-700 text-center">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {permissionsData.map((item, i) => (
              <tr key={i} className="bg-white rounded-md shadow-sm">
                <td className="px-4 py-2">{item.action}</td>
                {Roles.map((role) => (
                  <td key={role} className="px-4 py-2 text-center">
                    {item.permissions[role] ? (
                      <Check className="text-green-600 mx-auto" size={18} />
                    ) : (
                      <X className="text-red-500 mx-auto" size={18} />
                    )}
                  </td>
                ))}
                <td className="px-4 py-2 flex justify-center gap-2 text-gray-500">
                  <Plus
                    size={16}
                    className="cursor-pointer hover:text-blue-600"
                  />
                  <Pencil
                    size={16}
                    className="cursor-pointer hover:text-green-600"
                  />
                  <Trash2
                    size={16}
                    className="cursor-pointer hover:text-red-600"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const PERMISSIONS = [
  "Manage Admin Roles",
  "View Platform Stats",
  "Manage Job Postings",
  "View Candidate Data",
  "Approve/Reject Candidates",
  "Assign Admin Roles",
  "Assign Recruiter Roles",
  "Assist with Document Uploads",
  "Schedule Interviews",
  "View User Activity Logs",
  "View Uploaded Documents",
  "Download Documents",
  "Modify/Delete Job Listings or Posts",
  "Edit Candidate Status",
  "Access Permissions Matrix",
];

type AddRoleFormProps = {
  onClose: () => void;
};

function AddRoleForm({ onClose }: AddRoleFormProps) {
  const [roleName, setRoleName] = useState("");
  const [description, setDescription] = useState("");
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);

  const togglePermission = (permission: string) => {
    setSelectedPermissions((prev) =>
      prev.includes(permission)
        ? prev.filter((p) => p !== permission)
        : [...prev, permission]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Envoie les données ici
    console.log({ roleName, description, selectedPermissions });
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/50 overflow-y-auto p-3">
      <form
        onSubmit={handleSubmit}
        className="relative w-full max-w-xl max-h-[90vh] bg-[#e7f6f7] p-4 rounded-2xl overflow-y-auto shadow-lg"
      >
        <h1 className="text-xl font-bold mb-4 text-gray-800">Add a New Role</h1>

        {/* Role Name */}
        <div className="mb-6">
          <label className="block text-gray-700 font-semibold mb-2">
            Role Name
          </label>
          <div className="flex items-center border border-gray-300 rounded-lg px-4 py-2 bg-white">
            <Briefcase className="text-gray-400 mr-2" />
            <input
              type="text"
              placeholder="Role Name"
              value={roleName}
              onChange={(e) => setRoleName(e.target.value)}
              className="flex-1 outline-none bg-transparent"
              required
            />
          </div>
        </div>

        {/* Description */}
        <div className="mb-6">
          <label className="block text-gray-700 font-semibold mb-2">
            Role Description
          </label>
          <div className="flex items-center border border-gray-300 rounded-lg px-4 py-2 bg-white">
            <Text className="text-gray-400 mr-2" />
            <input
              type="text"
              placeholder="Description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="flex-1 outline-none bg-transparent"
              required
            />
          </div>
        </div>

        {/* Permissions */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">
            Permissions
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {PERMISSIONS.map((permission) => (
              <label
                key={permission}
                className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer"
              >
                <div className="relative">
                  <input
                    type="checkbox"
                    checked={selectedPermissions.includes(permission)}
                    onChange={() => togglePermission(permission)}
                    className="sr-only"
                    id={`toggle-${permission}`}
                  />
                  <div
                    className={`w-8 h-4 rounded-full transition-colors duration-200 
                              ${
                                selectedPermissions.includes(permission)
                                  ? "bg-[#238D94]"
                                  : "bg-gray-300"
                              }`}
                  ></div>
                  <div
                    className={`absolute top-0 left-0 w-4 h-4 bg-white rounded-full shadow-md transform transition-transform duration-200
                              ${
                                selectedPermissions.includes(permission)
                                  ? "translate-x-5"
                                  : "translate-x-0"
                              }`}
                  ></div>
                </div>
                <span>{permission}</span>
              </label>
            ))}
          </div>

          {/* Add Permission (optionnel) */}
          <div className="mt-4">
            <button
              type="button"
              className="text-sm text-teal-700 flex items-center gap-2 group"
            >
              <span className="text-teal-700 text-xl border border-teal-700 rounded-md w-6 h-6 flex items-center justify-center">
                +
              </span>
              <span className="group-hover:underline">Add a Permission</span>
            </button>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end space-x-3 mt-8">
          <button
            type="submit"
            className="bg-[#238D94] text-white px-6 py-2 rounded-full font-medium hover:bg-[#1a6b72] transition"
          >
            Save
          </button>
          <button
            onClick={onClose}
            className="bg-white border border-gray-300 text-gray-700 px-6 py-2 rounded-full font-medium hover:bg-gray-100 transition"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}

export default function AdminRoles() {
  const [RoleForm, setRoleForm] = useState(false); // RoleForm=true => la page popup s'ouvre

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Admin Roles
            </h1>
            <p className="text-gray-600">
              View, create, and manage admin roles and their permissions .
            </p>
          </div>
          <div className="inline-block border-2 border-gray-300 rounded-xl p-1">
            <button
              onClick={() => setRoleForm(true)}
              className="flex items-center gap-2 px-3 py-1 bg-[#238D94] text-white text-sm font-medium rounded-lg shadow-sm hover:bg-[#1a6b72] transition"
            >
              <span className="text-lg">+</span> Add Role
            </button>
          </div>
        </div>

        {RoleForm && <AddRoleForm onClose={() => setRoleForm(false)} />}

        {/*Quick actions*/}
        <h2 className="font-bold text-xl mb-5">Quick Actions</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 ">
          <button className="flex items-center  space-x-3 p-1 bg-white border-2 border-gray-200  rounded-lg hover:border-[#238D94] hover:text-[#238D94] transition-colors shadow-md ">
            <div className="p-1 border-2 border-gray-300 rounded-md">
              <UserPlus size={30} className="text-[#238D94]" />
            </div>
            <div className="text-left">
              <div className="font-medium">Add New Role</div>
              <div className="text-sm opacity-90">
                Create one or multiple custom roles for platform admins .
              </div>
            </div>
          </button>

          <button className="flex items-center space-x-3 p-1 bg-white border-2 border-gray-200 rounded-lg hover:border-[#238D94] hover:text-[#238D94] transition-colors shadow-md">
            <div className="p-1 border-2 border-gray-300 rounded-md">
              <Settings size={30} className="text-[#238D94]" />
            </div>
            <div className="text-left">
              <div className="font-medium">Edit Existing Roles</div>
              <div className="text-sm text-gray-500">
                Modify permissions, rename roles, or update access levels .
              </div>
            </div>
          </button>

          <button className="flex items-center space-x-3 p-1 bg-white border-2 border-gray-200 rounded-lg hover:border-[#238D94] hover:text-[#238D94] transition-colors shadow-md">
            <div className="p-1 border-2 border-gray-300 rounded-md">
              <Users size={30} className="text-[#238D94]" />
            </div>
            <div className="text-left">
              <div className="font-medium">Assign Admins to Roles</div>
              <div className="text-sm text-gray-500">
                Select users and assign them to specific admin roles .
              </div>
            </div>
          </button>
        </div>

        <TableRoles />

        <PermissionsMatrix />
      </div>
    </div>
  );
}
