import React, { useState, useEffect, useRef } from "react";
import { X, UploadCloud, Tag, Plus, Trash2, ChevronDown } from "lucide-react";
import { BlogDetails } from "@/lib/types/Blog";
import { categoryService } from "@/lib/network/pages/Category";
import { tagService } from "@/lib/network/pages/Tag";
import { settings } from "@/lib/settings/main";
import { Trans, t } from '@lingui/macro';


interface Category {
  id: number;
  name: string;
}

interface Tag {
  id: number;
  name: string;
}

// Define a custom type for the data that will be sent to the server
interface BlogFormData {
  title: string;
  content?: string;
  subtitle?: string;
  category: string[];
  tags: string[];
  featuredImageUrl?: string;
  featured?: boolean;
  creator?: string;
}

interface BlogFormProps {
  post?: BlogDetails | null;
  onSave: (postData: BlogFormData, imageFile: File | null) => void;
  onCancel: () => void;
}

export default function BlogForm({ post, onSave, onCancel }: BlogFormProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [categoryInput, setCategoryInput] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState(false);
  const [isTagDropdownOpen, setIsTagDropdownOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const categoryDropdownRef = useRef<HTMLDivElement>(null);
  const tagDropdownRef = useRef<HTMLDivElement>(null);

  const [formData, setFormData] = useState({
    title: "",
    subtitle: "",
    category: [] as string[],
    tags: [] as string[],
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [resCategories, resTags] = await Promise.all([
          categoryService.getCategories(),
          tagService.getTags(),
        ]);

        if (resCategories.success) {
          setCategories(resCategories.data || []);
        }
        if (resTags.success) {
          setTags(resTags.data || []);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        categoryDropdownRef.current &&
        !categoryDropdownRef.current.contains(event.target as Node)
      ) {
        setIsCategoryDropdownOpen(false);
      }
      if (tagDropdownRef.current && !tagDropdownRef.current.contains(event.target as Node)) {
        setIsTagDropdownOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (post) {
      // Extraire les noms des catégories et des tags
      const categoryNames = post.categories
        ? post.categories.map((cat) => cat.name)
        : [];
      const tagNames = post.tags ? post.tags.map((tag) => tag.name) : [];

      setFormData({
        title: post.title || "",
        subtitle: post.description || "",
        category: categoryNames,
        tags: tagNames,
      });

      if (post.image?.url) {
        setPreviewUrl(`${settings.IMG_ADDRESS}${post.image?.url}`);
      }
    }
  }, [post]);

  useEffect(() => {
    if (imageFile) {
      const objectUrl = URL.createObjectURL(imageFile);
      setPreviewUrl(objectUrl);
      return () => URL.revokeObjectURL(objectUrl);
    }
  }, [imageFile]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();

    const files = e.dataTransfer.files;
    if (files && files[0] && files[0].type.startsWith("image/")) {
      setImageFile(files[0]);
    }
  };

  const handleAddCategory = (category?: string) => {
    const catToAdd = category || categoryInput.trim();
    if (catToAdd && !formData.category.includes(catToAdd)) {
      const newCategories = [...formData.category, catToAdd];
      setFormData({
        ...formData,
        category: newCategories,
      });
      setCategoryInput("");
      setIsCategoryDropdownOpen(false);
    }
  };

  const handleRemoveCategory = (categoryToRemove: string) => {
    const newCategories = formData.category.filter(
      (cat) => cat !== categoryToRemove
    );
    setFormData({
      ...formData,
      category: newCategories,
    });
  };

  const handleAddTag = (tagName?: string) => {
    const tagToAdd = tagName || tagInput.trim();
    if (tagToAdd && !formData.tags.includes(tagToAdd)) {
      const newTags = [...formData.tags, tagToAdd];

      setFormData({
        ...formData,
        tags: newTags,
      });

      setTagInput('');
      setIsTagDropdownOpen(false);
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    const newTags = formData.tags.filter((tag) => tag !== tagToRemove);
    setFormData({
      ...formData,
      tags: newTags,
    });
  };

  const handleTagInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddTag();
    }
  };

  const handleCategoryInputKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddCategory();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Just pass the form data directly since we updated the type definition
    onSave(formData, imageFile);
  };

  // Filtrer les catégories disponibles pour n'afficher que celles qui ne sont pas déjà sélectionnées
  const filteredCategories = categories
    .map((cat) => cat.name)
    .filter((cat) => !formData.category.includes(cat));
  // Filtrer les tags disponibles pour n'afficher que ceux qui ne sont pas déjà sélectionnés
  const filteredTags = tags
    .map(t => t.name)
    .filter(tagName => !formData.tags.includes(tagName));


  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-xl font-semibold">

              <Trans id="blog_form.title">Edit Post Settings</Trans>
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              <Trans id="blog_form.description">
                Update the title, subtitle, category and image shown at the top of
                this post.
              </Trans>

            </p>
          </div>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-gray-500 p-1 rounded-full hover:bg-gray-100"
            title={t({ id: "blog_form.close", message: "Close" })}
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Title Field */}
          <div>
            <label
              htmlFor="title"
              className="block text-sm font-medium text-gray-700 mb-2"
            >

              <Trans id="blog_form.title_label">Title</Trans>

            </label>
            <input
              id="title"
              type="text"
              required
              value={formData.title}
              onChange={(e) =>
                setFormData({ ...formData, title: e.target.value })
              }

              placeholder={t({ id: "blog_form.title_placeholder", message: "Enter article title..." })}

              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Subtitle Field */}
          <div>
            <label
              htmlFor="subtitle"
              className="block text-sm font-medium text-gray-700 mb-2"
            >

              <Trans id="blog_form.subtitle_label">Subtitle</Trans>
=
            </label>
            <input
              id="subtitle"
              type="text"
              required
              value={formData.subtitle}
              onChange={(e) =>
                setFormData({ ...formData, subtitle: e.target.value })
              }

              placeholder={t({ id: "blog_form.subtitle_placeholder", message: "Add a short summary..." })}

              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Category Field */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans id="blog_form.category_label">Category</Trans>

            </label>
            <div className="relative" ref={categoryDropdownRef}>
              <div className="flex items-center gap-2 mb-2">
                <input
                  type="text"
                  value={categoryInput}
                  onChange={(e) => setCategoryInput(e.target.value)}
                  onKeyDown={handleCategoryInputKeyDown}
                  onFocus={() => setIsCategoryDropdownOpen(true)}
                  placeholder={t({ id: "blog_form.category_placeholder", message: "Select a category or type a new one" })}

                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <button
                  type="button"
                  onClick={() =>
                    setIsCategoryDropdownOpen(!isCategoryDropdownOpen)
                  }
                  className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200"
                  title={t({ id: "blog_form.toggle_dropdown", message: "Toggle dropdown" })}
                >
                  <ChevronDown size={16} />
                </button>
                <button
                  type="button"
                  onClick={() => handleAddCategory()}
                  className="p-2 bg-ehc-green text-ehc-green-dark rounded-lg hover:bg-ehc-green-light"
                  title={t({ id: "blog_form.add_category", message: "Add category" })}
                >
                  <Plus size={16} />
                </button>
              </div>

              {/* Dropdown de catégories */}
              {isCategoryDropdownOpen && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredCategories.length > 0 ? (
                    filteredCategories.map((cat, index) => (
                      <div
                        key={index}
                        className="px-4 py-2 cursor-pointer hover:bg-blue-50"
                        onClick={() => handleAddCategory(cat)}
                      >
                        {cat}
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-2 text-gray-500">

                      <Trans id="blog_form.no_categories">No categories available. Type to create a new one.</Trans>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Categories list */}
            {formData.category && formData.category.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.category.map((cat, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center bg-green-100 text-green-800 text-sm px-3 py-1 rounded-full"
                  >
                    {cat}
                    <button
                      type="button"
                      onClick={() => handleRemoveCategory(cat)}
                      className="ml-2 text-green-600 hover:text-green-800"
                      title={t({ id: "blog_form.remove_category", message: "Remove category" })}
                    >
                      <X size={12} />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Tags Field */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans id="blog_form.tags_label">Tags</Trans>

            </label>
            <div className="relative" ref={tagDropdownRef}>
              <div className="flex items-center gap-2 mb-2">
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={handleTagInputKeyDown}
                  onFocus={() => setIsTagDropdownOpen(true)}
                  placeholder={t({ id: "blog_form.tags_placeholder", message: "Select a tag or type a new one" })}

                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ehc-green-light focus:border-transparent"
                />
                <button
                  type="button"
                  onClick={() => setIsTagDropdownOpen(!isTagDropdownOpen)}
                  className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200"
                  title={t({ id: "blog_form.toggle_dropdown", message: "Toggle dropdown" })}
                >
                  <ChevronDown size={16} />
                </button>
                <button
                  type="button"
                  onClick={() => handleAddTag()}
                  className="p-2 bg-ehc-green text-ehc-green-dark rounded-lg hover:bg-ehc-green-light"
                  title={t({ id: "blog_form.add_tag", message: "Add tag" })}
                >
                  <Plus size={16} />
                </button>
              </div>
              
              {/* Dropdown de tags */}
              {isTagDropdownOpen && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredTags.length > 0 ? (
                    filteredTags.map((tagName, index) => (
                      <div
                        key={index}
                        className="px-4 py-2 cursor-pointer hover:bg-blue-50"
                        onClick={() => handleAddTag(tagName)}
                      >
                        {tagName}
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-2 text-gray-500">
                      <Trans id="blog_form.no_tags">No tags available. Type to create a new one.</Trans>
                    </div>
                  )}
                </div>
              )}
            </div>
            
            {/* Tags list */}
            {formData.tags && formData.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center bg-blue-100 text-ehc-green text-sm px-3 py-1 rounded-full"
                  >
                    <Tag size={12} className="mr-1" />
                    {tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="ml-2 text-ehc-green hover:text-ehc-green-light"
                      title={t({ id: "blog_form.remove_tag", message: "Remove tag" })}
                    >
                      <X size={12} />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Cover Image Field */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans id="blog_form.cover_image_label">Cover image</Trans>

            </label>

            <div
              className="relative w-full h-48 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-center cursor-pointer"
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              // onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />

              {previewUrl ? (
                <div className="relative w-full h-full">
                  <img
                    src={previewUrl}
                    alt={t({ id: "blog_form.preview_alt", message: "Preview" })}
                    className="w-full h-full object-cover rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setImageFile(null);
                      setPreviewUrl(null);
                    }}
                    className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full"
                    title={t({ id: "blog_form.remove_image", message: "Remove image" })}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ) : (
                <>
                  <UploadCloud className="mx-auto h-10 w-10 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">
                    <span className="font-semibold text-ehc-green">
                      <Trans id="blog_form.drop_upload">Drop here to attach or upload</Trans>
                    </span>
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    <Trans id="blog_form.max_size">Max size: 5MG</Trans>

                  </p>
                </>
              )}
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              <Trans id="blog_form.cancel">Cancel</Trans>

            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-ehc-green text-white rounded-lg hover:bg-ehc-green-light"
            >
              <Trans id="blog_form.save">Save</Trans>

            </button>
          </div>
        </form>
      </div>
    </div>
  );
}