import { categoryService } from "@/lib/network/pages/Category";
import { tagService } from "@/lib/network/pages/Tag";
import { tag } from "@/lib/types/Blog";
import { t } from "@lingui/macro";
import { ChevronDown, Plus, Trash2, UploadCloud, X } from "lucide-react";
import React, { useEffect, useRef, useState } from "react";

interface CreateBlog {
  id?: number;
  title: string;
  subtitle: string;
  content: string;
  creator: string;
  category: string[];
  tags: string[];
  imageUrl?: string;
}

interface Category {
  id: number;
  name: string;
}

interface BlogFormProps {
  post?: CreateBlog | null;
  onSave: (postData: Partial<CreateBlog>, imageFile: File | null) => void;
  onCancel: () => void;
}

export default function CreateBlogForm({
  post,
  onSave,
  onCancel,
}: BlogFormProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<tag[]>([]);
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState(false);
  const categoryDropdownRef = useRef<HTMLDivElement>(null);
  const tagDropdownRef = useRef<HTMLDivElement>(null);
  const [isTagDropdownOpen, setIsTagDropdownOpen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const resCategories = await categoryService.getCategories();
        const resTags = await tagService.getTags();
        if (resCategories.success) {
          setCategories(resCategories.data || []);
        }
        if (resTags.success) {
          setTags(resTags.data || []);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        categoryDropdownRef.current &&
        !categoryDropdownRef.current.contains(event.target as Node)
      ) {
        setIsCategoryDropdownOpen(false);
      }
      if (
        tagDropdownRef.current &&
        !tagDropdownRef.current.contains(event.target as Node)
      ) {
        setIsTagDropdownOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const [formData, setFormData] = useState({
    title: "",
    subtitle: "",
    content: "",
    creator: "",
    category: [] as string[],
    tags: [] as string[],
  });
  const [tagInput, setTagInput] = useState("");
  const [categoryInput, setCategoryInput] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const editorRef = useRef<HTMLDivElement>(null);

  // Réf pour ignorer les changements de contenu lors de la mise à jour de l'éditeur
  const ignoreContentChange = useRef(false);

  useEffect(() => {
    if (post) {
      setFormData({
        title: post.title,
        subtitle: post.subtitle,
        content: post.content,
        creator: post.creator,
        category: post.category || [],
        tags: post.tags || [],
      });

      if (editorRef.current) {
        ignoreContentChange.current = true;
        editorRef.current.innerHTML = post.content;
      }
    }
  }, [post]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData, imageFile);
  };

  const handleInputChange =
    (field: keyof typeof formData) =>
    (e: React.ChangeEvent<HTMLInputElement>) => {
      setFormData({
        ...formData,
        [field]: e.target.value,
      });
    };

  useEffect(() => {
    if (imageFile) {
      const objectUrl = URL.createObjectURL(imageFile);
      setPreviewUrl(objectUrl);
      return () => URL.revokeObjectURL(objectUrl);
    }
  }, [imageFile]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();

    const files = e.dataTransfer.files;
    if (files && files[0] && files[0].type.startsWith("image/")) {
      setImageFile(files[0]);
    }
  };

  const handleAddTag = (tag?: string) => {
    const tagToAdd = tag || tagInput.trim();
    if (tagToAdd && !formData.tags.includes(tagToAdd)) {
      setFormData({
        ...formData,
        tags: [...formData.tags, tagToAdd],
      });
      setTagInput("");
      setIsTagDropdownOpen(false);
    }
  };

  const filteredTags = tags
    .map((t) => t.name)
    .filter((tagName) => !formData.tags.includes(tagName));

  const handleRemoveTag = (tagToRemove: string) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter((tag) => tag !== tagToRemove),
    });
  };

  const handleTagInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddTag();
    }
  };

  const handleAddCategory = (category?: string) => {
    const catToAdd = category || categoryInput.trim();
    if (catToAdd && !formData.category.includes(catToAdd)) {
      setFormData({
        ...formData,
        category: [...formData.category, catToAdd],
      });
      setCategoryInput("");
      setIsCategoryDropdownOpen(false);
    }
  };

  const handleRemoveCategory = (categoryToRemove: string) => {
    setFormData({
      ...formData,
      category: formData.category.filter((cat) => cat !== categoryToRemove),
    });
  };

  const handleCategoryInputKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddCategory();
    }
  };

  const filteredCategories = categories
    .map((cat) => cat.name)
    .filter((cat) => !formData.category.includes(cat));

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-xl font-semibold">
              {post ? t`Edit Blog Post` : t`Create New Blog`}
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              {t`Add the title, subtitle, category, content and image for your blog post.`}
            </p>
          </div>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-gray-500 p-1 rounded-full hover:bg-gray-100"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Title Field */}
          <div>
            <label
              htmlFor="title"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              {t`Title`}
            </label>
            <input
              id="title"
              type="text"
              required
              value={formData.title}
              onChange={handleInputChange("title")}
              placeholder={t`Enter article title...`}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ehc-green-light focus:border-transparent"
            />
          </div>

          {/* Subtitle Field */}
          <div>
            <label
              htmlFor="subtitle"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              {t`Subtitle`}
            </label>
            <input
              id="subtitle"
              type="text"
              required
              value={formData.subtitle}
              onChange={handleInputChange("subtitle")}
              placeholder={t`Add a short summary...`}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ehc-green-light focus:border-transparent"
            />
          </div>

          {/* Creator Field */}
          <div>
            <label
              htmlFor="creator"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              {t`Creator`}
            </label>
            <input
              id="creator"
              type="text"
              required
              value={formData.creator}
              onChange={handleInputChange("creator")}
              placeholder={t`Add a creator`}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ehc-green-light focus:border-transparent"
            />
          </div>

          {/* Category Field */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t`Category`}
            </label>
            <div className="relative" ref={categoryDropdownRef}>
              <div className="flex items-center gap-2 mb-2">
                <input
                  type="text"
                  value={categoryInput}
                  onChange={(e) => setCategoryInput(e.target.value)}
                  onKeyDown={handleCategoryInputKeyDown}
                  onFocus={() => setIsCategoryDropdownOpen(true)}
                  placeholder={t`Select a category or type a new one`}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ehc-green-light focus:border-transparent"
                />
                <button
                  type="button"
                  onClick={() =>
                    setIsCategoryDropdownOpen(!isCategoryDropdownOpen)
                  }
                  className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200"
                >
                  <ChevronDown size={16} />
                </button>
                <button
                  type="button"
                  onClick={() => handleAddCategory()}
                  className="p-2 bg-ehc-green text-ehc-green-dark rounded-lg hover:bg-ehc-green-light"
                >
                  <Plus size={16} />
                </button>
              </div>

              {/* Dropdown de catégories */}
              {isCategoryDropdownOpen && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredCategories.length > 0 ? (
                    filteredCategories.map((cat, index) => (
                      <div
                        key={index}
                        className="px-4 py-2 cursor-pointer hover:bg-blue-50"
                        onClick={() => handleAddCategory(cat)}
                      >
                        {cat}
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-2 text-gray-500">
                      {t`No categories available. Type to create a new one.`}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Categories list */}
            {formData.category && formData.category.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.category.map((cat, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center bg-green-100 text-ehc-green text-sm px-3 py-1 rounded-full"
                  >
                    {cat}
                    <button
                      type="button"
                      onClick={() => handleRemoveCategory(cat)}
                      className="ml-2 text-green-600 hover:text-ehc-green"
                    >
                      <X size={12} />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Tags Field */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t`Tags`}
            </label>
            <div className="relative" ref={tagDropdownRef}>
              <div className="flex items-center gap-2 mb-2">
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={handleTagInputKeyDown}
                  onFocus={() => setIsTagDropdownOpen(true)}
                  placeholder={t`Select a tag or type a new one`}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-offset-ehc-green-light focus:border-transparent"
                />
                <button
                  type="button"
                  onClick={() => setIsTagDropdownOpen(!isTagDropdownOpen)}
                  className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200"
                >
                  <ChevronDown size={16} />
                </button>
                <button
                  type="button"
                  onClick={() => handleAddTag()}
                  className="p-2 bg-ehc-green text-ehc-green-dark rounded-lg hover:bg-ehc-green-light"
                >
                  <Plus size={16} />
                </button>
              </div>

              {/* Dropdown de tags */}
              {isTagDropdownOpen && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredTags.length > 0 ? (
                    filteredTags.map((tagName, index) => (
                      <div
                        key={index}
                        className="px-4 py-2 cursor-pointer hover:bg-blue-50"
                        onClick={() => handleAddTag(tagName)}
                      >
                        {tagName}
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-2 text-gray-500">
                      {t`No tags available. Type to create a new one.`}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Tags list */}
            {formData.tags && formData.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center bg-blue-100 text-ehc-green text-sm px-3 py-1 rounded-full"
                  >
                    {tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="ml-2 text-ehc-green hover:text-ehc-green-light"
                    >
                      <X size={12} />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Cover Image Field */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t`Cover image`}
            </label>

            <div
              className="relative w-auto h-[30vh] border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-center cursor-pointer"
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              // onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />

              {previewUrl ? (
                <div className="relative w-full h-full">
                  <img
                    src={previewUrl}
                    alt="Preview"
                    className="w-full h-full object-cover object-center rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setImageFile(null);
                      setPreviewUrl(null);
                    }}
                    className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ) : (
                <>
                  <UploadCloud className="mx-auto h-10 w-10 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">
                    <span className="font-semibold text-ehc-green">
                      {t`Drop here to attach or upload`}
                    </span>
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {t`Max size: 5MB`}
                  </p>
                </>
              )}
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              {t`Cancel`}
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-ehc-green text-white rounded-lg hover:bg-ehc-green-light"
            >
              {post ? t`Update` : t`Publish`}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
