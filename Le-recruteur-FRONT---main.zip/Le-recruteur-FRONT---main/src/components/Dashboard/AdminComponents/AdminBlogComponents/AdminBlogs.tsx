import React, { useState, useEffect } from "react";
import {
  Plus,
  Search,
  Filter,
  Edit,
  Trash2,
  User,
  ChevronLeft,
  ChevronRight,
  AlertCircleIcon,
  CheckCircle2Icon,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useNavigate } from "react-router-dom";
import BlogForm from "./BlogForm";
import CreateBlogForm from "./CreateBlogForm";
import { blogService } from "@/lib/network/pages/Blogs";
import { BlogDetails } from "@/lib/types/Blog";
import { api } from "@/lib/network/utils/api";
import { settings } from "@/lib/settings/main";
import { cn } from "@/lib/utils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { t } from "@lingui/macro";
import { i18n } from "@lingui/core";

const AdminBlogs: React.FC = () => {
  // States for data management and UI
  const [blogs, setBlogs] = useState<BlogDetails[]>([]);
  const [editBlog, setEditBlog] = useState<BlogDetails | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage] = useState<number>(8);
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);

  interface PaginationMetadata {
    page: number;
    pageSize: number;
    totalPages: number;
    totalItems: number;
  }

  const [paginationMetadata, setPaginationMetadata] =
    useState<PaginationMetadata | null>(null);
  const [notification, setNotification] = useState<{
    title: string;
    description: string;
    variant: string;
  } | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const navigate = useNavigate();

  // States for filters
  const [filters, setFilters] = useState({
    author: "",
    category: "",
    tag: "",
    publicationDate: "",
    language: "",
  });

  // Auto-hide notifications after 5 seconds
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [notification]);

  // Load data
  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        setLoading(true);
        const response = await blogService.getBlogs({
          page: currentPage,
          size: itemsPerPage,
          sortBy: "createdAt",
          sortOrder: "desc",
        });

        if (response.success) {
          setBlogs(response.data);

          if (response.metadata && response.metadata.pagination) {
            setPaginationMetadata({
              totalPages: response.metadata.pagination.totalPages,
              page: response.metadata.pagination.page,
              totalItems: response.metadata.pagination.totalItems,
              pageSize: response.metadata.pagination.pageSize,
            });
          } else {
            console.warn("Pagination metadata not found in response");
            setPaginationMetadata({
              totalPages: Math.ceil(response.data.length / itemsPerPage),
              page: currentPage,
              totalItems: response.data.length,
              pageSize: itemsPerPage,
            });
          }
        } else {
          setError(t`Error loading blogs`);
        }
      } catch (err: unknown) {
        const error = err instanceof Error ? err : new Error(t`Unknown error`);
        console.error("Error loading blogs:", error);
        const errorMessage = error.message;
        setError(t`Error loading blogs: ${errorMessage}`);
      } finally {
        setLoading(false);
      }
    };

    fetchBlogs();
  }, [currentPage, refreshKey, itemsPerPage]);

  // Handle blog editing
  const handleEditBlog = async (blogId: number) => {
    setShowEditForm(true);
    const response = await blogService.getBlogById(blogId);
    if (response.success) {
      setEditBlog(response.data);
    }
  };

  // Define the type for blog post data
  interface BlogPostData {
    id?: number;
    title: string;
    content?: string;
    subtitle?: string;
    category?: string[] | string;
    tags?: string[] | Array<{ name: string } | string> | null;
    imageUrl?: string;
    featuredImageUrl?: string;
    image?: { url?: string };
    featured?: boolean;
    creator?: string;
  }

  const handleSaveBlog = async (
    postData: Partial<BlogPostData>,
    imageFile: File | null
  ) => {
    try {
      if (!editBlog || !editBlog.id) {
        setNotification({
          title: t`Error!`,
          description: t`Blog ID is missing. Cannot update.`,
          variant: "destructive",
        });
        return;
      }

      const formData = new FormData();

      // Handle all possible formats for tags and categories
      const processedTags = Array.isArray(postData.tags)
        ? postData.tags.map((tag) =>
            typeof tag === "object" && tag !== null
              ? (tag as { name: string }).name
              : (tag as string)
          )
        : [];

      const processedCategories = Array.isArray(postData.category)
        ? postData.category
        : postData.category
        ? [postData.category]
        : [];

      // Créer un objet avec les données du blog comme attendu par le backend
      const blogData = {
        title: postData.title || "",
        content: postData.content || "",
        excerpt: postData.subtitle || "",
        categoryNames: processedCategories,
        tagNames: processedTags,
        featuredImageUrl:
          postData.featuredImageUrl || postData.image?.url || "",
        featured: postData.featured || false,
      };

      // Ajouter les données du blog en tant que JSON
      formData.append(
        "blogData",
        new Blob([JSON.stringify(blogData)], {
          type: "application/json",
        })
      );

      // Ajouter le fichier image s'il existe
      if (imageFile) {
        formData.append("imageFile", imageFile);
      }

      // Envoyer la requête
      const response = (await api.put(`/blogs/${editBlog.id}`, formData)) as {
        success: boolean;
        data?: { message?: string; blog?: BlogDetails };
        message?: string;
      };

      if (response && response.success) {
        setShowEditForm(false);
        setEditBlog(null);
        setNotification({
          title: t`Success!`,
          description: t`Blog has been updated successfully.`,
          variant: "success",
        });
        setRefreshKey((k) => k + 1);
      } else {
        const errorMsg = response?.data?.message || "Unknown error";
        setNotification({
          title: t`Error!`,
          description: t`Error saving blog: ${errorMsg}`,
          variant: "destructive",
        });
      }
    } catch (error: unknown) {
      console.error("Error saving blog:", error);

      // CORRECTION : Formater l'erreur d'abord
      const errorMessage =
        error instanceof Error
          ? error.message
          : t`Error saving blog. Please try again.`;

      setNotification({
        title: t`Error!`,
        description: t`Error saving blog: ${errorMessage}`,
        variant: "destructive",
      });
    }
  };

  // Handle blog deletion
  const handleDeleteBlog = async (blogId: number) => {
    try {
      const response = await blogService.deleteBlog(blogId);
      if (response.success) {
        setNotification({
          title: t`Success!`,
          description: t`Blog has been deleted successfully.`,
          variant: "success",
        });
        setRefreshKey((k) => k + 1);
      } else {
        setNotification({
          title: t`Error!`,
          description: response.message || t`Failed to delete the blog.`,
          variant: "destructive",
        });
      }
    } catch (err: unknown) {
      const error = err instanceof Error ? err : new Error(t`Unknown error`);
      console.error("Error deleting blog:", error);
      // CORRECTION : Formater l'erreur d'abord
      const errorMessage = error.message;
      setNotification({
        title: t`Error!`,
        description: t`Failed to delete the blog: ${errorMessage}`,
        variant: "destructive",
      });
    }
  };

  // Handle adding a new blog
  const handleAddNewBlog = () => {
    setShowCreateForm(true);
  };

  // Handle saving a new blog
  const handleAddBlog = async (
    postData: Partial<BlogPostData>,
    imageFile: File | null
  ) => {
    try {
      const formData = new FormData();

      // Handle all possible formats for tags and categories
      const processedTags = Array.isArray(postData.tags)
        ? postData.tags.map((tag) =>
            typeof tag === "object" && tag !== null ? tag.name : tag
          )
        : [];

      const processedCategories = Array.isArray(postData.category)
        ? postData.category
        : postData.category
        ? [postData.category]
        : [];

      // Créer un objet avec les données du blog comme attendu par le backend
      const blogData = {
        title: postData.title || "",
        content: postData.content || "",
        excerpt: postData.subtitle || "",
        creator: postData.creator || "",
        categoryNames: processedCategories,
        tagNames: processedTags,
      };

      // Ajouter les données du blog en tant que JSON
      formData.append(
        "blogData",
        new Blob([JSON.stringify(blogData)], {
          type: "application/json",
        })
      );

      // Ajouter le fichier image s'il existe
      if (imageFile) {
        formData.append("imageFile", imageFile);
      }

      // Envoyer la requête
      console.log("formData", formData);

      const response = (await api.post(`/blogs/blog`, formData, {
        addAuthHeaders: true,
      })) as {
        success: boolean;
        data?: { message?: string };
        message?: string;
      };

      if (response && response.success) {
        setShowCreateForm(false);
        setEditBlog(null);
        setNotification({
          title: t`Success!`,
          description: t`Blog has been saved successfully.`,
          variant: "success",
        });
        setRefreshKey((k) => k + 1);
      } else {
        const errorMsg = response?.data?.message || "Unknown error";
        setNotification({
          title: t`Error!`,
          description: t`Error saving blog: ${errorMsg}`,
          variant: "destructive",
        });
      }
    } catch (error: unknown) {
      console.error("Error saving blog:", error);

      // CORRECTION : Formater l'erreur d'abord
      const errorMessage =
        error instanceof Error
          ? error.message
          : t`Error saving blog. Please try again.`;

      setNotification({
        title: t`Error!`,
        description: t`Error saving blog: ${errorMessage}`,
        variant: "destructive",
      });
    }
  };

  // Define a type for blog response data
  interface BlogResponse {
    success: boolean;
    data: BlogDetails[] | { content: BlogDetails[] };
    message?: string;
  }

  // Helper function to handle response data which may be in different formats
  const extractBlogsFromResponse = (response: BlogResponse): BlogDetails[] => {
    if (Array.isArray(response.data)) {
      return response.data;
    } else if (
      response.data &&
      typeof response.data === "object" &&
      "content" in response.data
    ) {
      return response.data.content;
    }
    return [];
  };

  // Handle filter changes
  const handleFilterChange = async (filterName: string, value: string) => {
    setFilters((prev) => ({ ...prev, [filterName]: value }));

    try {
      let response: BlogResponse;

      if (filterName === "author" && value) {
        response = await blogService.searchBlogByAuthor(value);
      } else if (filterName === "category" && value) {
        response = await blogService.searchBlogByCategory(value);
      } else if (filterName === "tag" && value) {
        response = await blogService.searchBlogByTag(value);
      } else {
        // If search is empty, reload all blogs
        setRefreshKey((k) => k + 1);
        return;
      }

      if (response && response.success) {
        const blogs = extractBlogsFromResponse(response);
        setBlogs(blogs);
      }
    } catch (error) {
      console.error(`Error filtering by ${filterName}:`, error);
    }
  };

  const handleFilterByDate = async (date: string) => {
    setFilters((prev) => ({ ...prev, publicationDate: date }));

    try {
      setLoading(true);
      // Convert string date to Date object
      const dateObject = new Date(date);
      const response = await blogService.searchBlogByDate(dateObject);

      if (response.success) {
        const blogs = extractBlogsFromResponse(response);
        setBlogs(blogs);
      } else {
        console.error("Failed to filter by date");
      }
    } catch (error) {
      console.error("Error filtering by date:", error);
    } finally {
      setLoading(false);
    }
  };

  // Handle search changes
  const handleSearchChange = async (value: string) => {
    setSearchTerm(value);
    if (value) {
      try {
        const response = await blogService.searchBlogByKeyword(value);
        if (response.success) {
          const blogs = extractBlogsFromResponse(response);
          setBlogs(blogs);
        }
      } catch (error) {
        console.error("Error searching blogs:", error);
      }
    } else {
      // If search is empty, reload all blogs
      setRefreshKey((k) => k + 1);
    }
  };

  if (error) {
    return (
      <div className="p-6 flex justify-center items-center h-64">
        <div className="text-lg text-red-600">{error}</div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {notification && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 w-full max-w-xl z-[100] animate-in fade-in-5 slide-in-from-top-5">
          <Alert
            variant={
              notification.variant === "destructive" ? "destructive" : "default"
            }
            className={cn(
              "bg-background",
              notification.variant === "success" &&
                "border-green-500/50 text-green-700 dark:border-green-500 [&>[data-slot=icon]]:text-green-700"
            )}
          >
            {notification.variant === "destructive" ? (
              <AlertCircleIcon className="h-4 w-4" data-slot="icon" />
            ) : (
              <CheckCircle2Icon className="h-4 w-4" data-slot="icon" />
            )}
            <AlertTitle>{notification.title}</AlertTitle>
            {notification.description && (
              <AlertDescription>{notification.description}</AlertDescription>
            )}
          </Alert>
        </div>
      )}

      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">{t`Blogs`}</h1>
          <p className="text-sm text-gray-600 mt-1">
            {t`Create, manage, and publish articles to share knowledge, updates, and insights with your audience.`}
          </p>
        </div>
        <button
          onClick={handleAddNewBlog}
          className="bg-[#238D94] hover:bg-[#1a6b72] text-white py-2 px-4 rounded-lg flex items-center transition-colors"
        >
          <Plus size={20} className="mr-2" />
          {t`New Blog`}
        </button>
      </div>

      {/* Search and filters bar */}
      <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
        <div className="flex flex-col md:flex-row gap-4 items-stretch">
          {/* Search field with icon */}
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder={t`Search by blog title, author, keyword...`}
              value={searchTerm}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-[#238D94] outline-none transition-colors"
            />
          </div>

          {/* Filters button */}
          <div className="relative">
            <button
              className="h-full flex items-center space-x-2 bg-white border border-gray-300 rounded-lg px-4 py-2 text-gray-700 hover:bg-gray-50 transition-colors focus:ring-2 focus:ring-[#238D94] focus:outline-none"
              onClick={() => setShowFilters(!showFilters)}
            >
              <span>{t`Filter: All`}</span>
              <Filter size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* Main container with filters and content */}
      <div className="flex flex-col h-full lg:flex-row gap-6">
        {/* Filters panel */}
        <div className="lg:w-1/4 bg-white border border-[#1a6b72] p-3 rounded-lg shadow-sm flex-1">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">{t`Filters`}</h2>

          <div className="space-y-4">
            {/* Author filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t`Author`}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  className="w-full pl-8 border border-gray-300 rounded-md text-sm p-2 focus:outline-none focus:ring-2 focus:ring-[#238D94] focus:border-transparent"
                  type="text"
                  placeholder={t`Search by author...`}
                  value={filters.author}
                  onChange={(e) => handleFilterChange("author", e.target.value)}
                />
              </div>
            </div>

            {/* Category filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t`Category`}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  className="w-full pl-8 border border-gray-300 rounded-md text-sm p-2 focus:outline-none focus:ring-2 focus:ring-[#238D94] focus:border-transparent"
                  type="text"
                  placeholder={t`Search by category...`}
                  value={filters.category}
                  onChange={(e) =>
                    handleFilterChange("category", e.target.value)
                  }
                />
              </div>
            </div>

            {/* Tag filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t`Tag`}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  className="w-full pl-8 border border-gray-300 rounded-md text-sm p-2 focus:outline-none focus:ring-2 focus:ring-[#238D94] focus:border-transparent"
                  type="text"
                  placeholder={t`Search by tag...`}
                  value={filters.tag}
                  onChange={(e) => handleFilterChange("tag", e.target.value)}
                />
              </div>
            </div>

            {/* Publication Date filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t`Publication Date`}
              </label>
              <input
                type="date"
                value={filters.publicationDate}
                onChange={(e) => handleFilterByDate(e.target.value)}
                className="w-full text-sm p-2 border border-gray-300 rounded-md focus:ring-[#238D94] focus:border-[#238D94]"
              />
            </div>
          </div>
        </div>

        {/* Blog content */}
        <div className="lg:w-3/4">
          {/* Blog grid */}
          {loading ? (
            <div className="p-6 flex justify-center items-center h-64">
              <div className="text-lg text-gray-600">{t`Loading blogs...`}</div>
            </div>
          ) : blogs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {blogs.map((blog) => (
                <div
                  key={blog.id}
                  className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 hover:shadow-lg transition-all duration-300"
                >
                  {/* Blog image */}
                  <div className="h-48 bg-gray-100 overflow-hidden relative">
                    <img
                      src={`${settings.IMG_ADDRESS}${blog.image?.url}`}
                      alt={blog.image?.filename || blog.title}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                      onError={(e) => {
                        e.currentTarget.src = "/placeholder-blog.jpg";
                      }}
                    />

                    {/* Edit and delete buttons */}
                    <div className="absolute top-2 right-2 flex space-x-1">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <button
                            className="bg-white/80 hover:bg-white p-1.5 rounded-full transition-colors shadow-sm"
                            title={t`Delete`}
                          >
                            <Trash2 size={16} className="text-gray-600" />
                          </button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>
                              {t`Confirm Deletion`}
                            </AlertDialogTitle>
                          </AlertDialogHeader>
                          <AlertDialogDescription>
                            {/* CORRECTION : Formater le titre du blog d'abord */}
                            {t`Are you sure you want to delete "${blog.title}"? This action cannot be undone.`}
                          </AlertDialogDescription>
                          <AlertDialogFooter>
                            <AlertDialogCancel>{t`Cancel`}</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDeleteBlog(blog.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              {t`Delete`}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>

                      <button
                        onClick={() => handleEditBlog(blog.id)}
                        className="bg-white/80 hover:bg-white p-1.5 rounded-full transition-colors shadow-sm"
                        title={t`Edit`}
                      >
                        <Edit size={16} className="text-gray-600" />
                      </button>
                    </div>
                  </div>

                  {/* Card content */}
                  <div className="p-6">
                    {/* Blog title */}
                    <h3 className="text-lg font-bold text-gray-800 mb-2 line-clamp-2 hover:text-[#238D94] transition-colors min-h-[3rem]">
                      {blog.title}
                    </h3>

                    {/* Author and date */}
                    <div className="flex items-center mb-4">
                      <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                        <User size={16} className="text-gray-500" />
                      </div>

                      <p className="font-semibold text-gray-700 text-sm">
                        {blog.creator}
                      </p>
                      <p className="text-xs ml-2 text-gray-500">
                        {blog.updatedAt}
                      </p>
                    </div>

                    {/* Content excerpt */}
                    <p className="text-gray-600 text-sm mb-4 leading-relaxed line-clamp-3 flex-1">
                      {blog.description}
                    </p>

                    {/* View Post button and actions */}
                    <div className="flex justify-between items-center">
                      <button
                        className="text-[#000000] hover:text-[#1a6b72] text-sm font-medium py-2 px-2 border-b border-[#000000] hover:border-[#1a6b72] transition-colors flex items-center"
                        onClick={() => {
                          navigate(`/admin/blogDetails/${blog.id}`);
                        }}
                      >
                        {t`View Post`}
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-4 w-4 ml-1"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M14 5l7 7m0 0l-7 7m7-7H3"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white p-8 rounded-lg shadow-sm text-center">
              <p className="text-gray-500">
                {t`No blogs found matching your criteria.`}
              </p>
            </div>
          )}

          {/* Pagination */}
          {paginationMetadata && paginationMetadata.totalPages > 1 && (
            <div className="mt-6 flex justify-between items-center bg-white p-4 rounded-lg shadow-sm">
              <div className="text-sm text-gray-600">
                {/* CORRECTION : Formater les nombres d'abord */}
                {i18n._(
                  t`Showing ${blogs.length} of ${paginationMetadata.totalItems} blogs`
                )}
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() =>
                    setCurrentPage((prev) => Math.max(prev - 1, 1))
                  }
                  disabled={currentPage === 1}
                  className="p-2 rounded-lg border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                >
                  <ChevronLeft size={16} />
                </button>

                {Array.from(
                  { length: paginationMetadata.totalPages },
                  (_, i) => i + 1
                ).map((page) => (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`w-10 h-10 rounded-lg border ${
                      currentPage === page
                        ? "border-[#238D94] bg-[#238D94] text-white"
                        : "border-gray-300 hover:bg-gray-50"
                    }`}
                  >
                    {page}
                  </button>
                ))}

                <button
                  onClick={() =>
                    setCurrentPage((prev) =>
                      Math.min(prev + 1, paginationMetadata.totalPages)
                    )
                  }
                  disabled={currentPage === paginationMetadata.totalPages}
                  className="p-2 rounded-lg border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {showCreateForm && (
        <CreateBlogForm
          onCancel={() => setShowCreateForm(false)}
          onSave={(data, file) =>
            handleAddBlog(data as Partial<BlogPostData>, file)
          }
        />
      )}
      {showEditForm && editBlog && (
        <BlogForm
          post={editBlog}
          onSave={(data, file) =>
            handleSaveBlog(data as Partial<BlogPostData>, file)
          }
          onCancel={() => {
            setShowEditForm(false);
            setEditBlog(null);
          }}
        />
      )}
    </div>
  );
};

export default AdminBlogs;
