/* eslint-disable @typescript-eslint/no-explicit-any */
import { blogService } from "@/lib/network/pages/Blogs";
import { api } from "@/lib/network/utils/api";
import { settings } from "@/lib/settings/main";
import { ApiResponse } from "@/lib/types/base";
import { BlogDetails } from "@/lib/types/Blog";
import { i18n } from "@lingui/core";
import { Trans, t } from "@lingui/macro";
import {
  ArrowLeft,
  ChevronRight,
  Clock,
  Edit,
  Redo,
  Tag,
  Undo,
  User,
} from "lucide-react";
import React, { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import BlogForm from "./BlogForm";

const AdminBlogDetails: React.FC = () => {
  const [blogPost, setBlogPost] = useState<BlogDetails | null>(null);
  const [relatedPosts, setRelatedPosts] = useState<BlogDetails[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [showEdit, setShowEdit] = useState(false);
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  // Réf pour l'éditeur
  const editorRef = useRef<HTMLDivElement>(null);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  useEffect(() => {
    const fetchBlogPost = async () => {
      try {
        setLoading(true);
        const response = await blogService.getBlogById(Number(id));

        if (response.success) {
          setBlogPost(response.data);

          // Formater le contenu pour l'affichage
          if (response.data?.content) {
            let formattedContent = "";

            if (Array.isArray(response.data.content)) {
              formattedContent = response.data.content
                .map((para) => (para.startsWith("<") ? para : `<p>${para}</p>`))
                .join("");
            } else {
              formattedContent = response.data.content;
            }

            // Initialiser l'éditeur avec le contenu formaté
            if (editorRef.current) {
              editorRef.current.innerHTML = formattedContent;
            }
          }

          // Charger les articles connexes
          try {
            const creator = response.data.creator;
            const relatedResponse = await blogService.searchBlogByAuthor(
              creator
            );
            if (relatedResponse.success) {
              const filteredPosts = (relatedResponse.data?.content || [])
                .filter((post: BlogDetails) => post.id !== response.data.id)
                .slice(0, 3);

              setRelatedPosts(filteredPosts);
            }
          } catch (err) {
            console.error("Error fetching related posts", err);
            setRelatedPosts([]);
          }
        } else {
          setError(
            t({
              id: "blog_details.errors.not_found",
              message: "Blog post not found",
            })
          );
        }

        setLoading(false);
      } catch (err) {
        const errorMessageText = i18n._(
          t`Error fetching blog post: {errorMessage}`, // The simple string for extraction
          { errorMessage: (err as any).message || String(err) } // Variables
        );
        setError(errorMessageText);
        setLoading(false);
      }
    };

    fetchBlogPost();
  }, [id]);

  useEffect(() => {
    if (isEditing && editorRef.current && blogPost) {
      // Formater le contenu pour l'éditeur
      let formattedContent = "";

      if (Array.isArray(blogPost.content)) {
        formattedContent = blogPost.content
          .map((para) => {
            // Nettoyer chaque paragraphe
            const cleanPara = para
              .replace(/\\n/g, "")
              .replace(/^"|"$/g, "")
              .trim();
            return cleanPara.startsWith("<")
              ? cleanPara
              : `<p>${cleanPara}</p>`;
          })
          .join("");
      } else {
        formattedContent = blogPost.content
          .replace(/\\n/g, "")
          .replace(/^"|"$/g, "")
          .trim();
      }

      // Initialiser l'éditeur avec le contenu formaté
      editorRef.current.innerHTML = formattedContent;
    }
  }, [isEditing, blogPost]);

  // Fonctions simplifiées pour l'éditeur
  const saveCursorPosition = () => {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      return selection.getRangeAt(0);
    }
    return null;
  };

  const restoreCursorPosition = (range: Range | null) => {
    if (range) {
      const selection = window.getSelection();
      if (selection) {
        selection.removeAllRanges();
        selection.addRange(range);
      }
    }
  };

  const formatText = (command: string, value: string = "") => {
    if (editorRef.current) {
      // 1. Save the current selection/cursor position
      const selectionRange = saveCursorPosition();

      // 2. Focus the editor (to make execCommand work)
      editorRef.current.focus();

      // 3. Execute the command
      document.execCommand(command, false, value);

      // 4. Restore the cursor/selection
      restoreCursorPosition(selectionRange);

      // 5. Update form state (missing in your provided snippet, but essential)
      // You should re-add your content update logic here, e.g.:
      // updateEditorContent();

      checkUndoState();
    }
  };

  const handleUndo = () => {
    if (editorRef.current) {
      editorRef.current.focus();
      document.execCommand("undo", false, undefined);
      checkUndoState();
    }
  };

  const handleRedo = () => {
    if (editorRef.current) {
      editorRef.current.focus();
      document.execCommand("redo", false, undefined);
      checkUndoState();
    }
  };

  const checkUndoState = () => {
    // Implémentation simplifiée - dans une vraie app, utilisez un gestionnaire d'état
    setCanUndo(true);
    setCanRedo(true);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "z") {
      e.preventDefault();
      if (e.shiftKey) {
        handleRedo();
      } else {
        handleUndo();
      }
    } else if ((e.ctrlKey || e.metaKey) && e.key === "y") {
      e.preventDefault();
      handleRedo();
    }
  };

  const handleEditForm = () => {
    setShowEdit(true);
  };

  const handleSaveBlog = async (postData: any, imageFile: File | null) => {
    try {
      const formData = new FormData();

      const blogData = {
        title: postData.title,
        content: postData.content,
        excerpt: postData.subtitle || "",
        categoryName: postData.categoryName || postData.category?.name || "",
        tagNames: postData.tags
          ? Array.isArray(postData.tags)
            ? postData.tags.map((tag: any) =>
                typeof tag === "object" ? tag.name : tag
              )
            : []
          : [],
        featuredImageUrl:
          postData.featuredImageUrl || postData.image?.url || "",
        featured: postData.featured || false,
      };

      formData.append(
        "blogData",
        new Blob([JSON.stringify(blogData)], {
          type: "application/json",
        })
      );

      if (imageFile) {
        formData.append("imageFile", imageFile);
      }

      const response = await api.put<ApiResponse<BlogDetails>>(
        `/blogs/${id}`,
        formData
      );

      if (response.success) {
        setShowEdit(false);
        setBlogPost(response.data);
        const successMessage =
          t({
            id: "blog_details.notifications.success_title_exclamation",
            message: "Success!",
          }) +
          " " +
          t({
            id: "blog_details.notifications.blog_updated",
            message: "Blog content has been updated successfully.",
          });
        toast.success(successMessage);
      } else {
        const errorMessage =
          t({
            id: "blog_details.notifications.error_title",
            message: "Error!",
          }) +
          " " +
          t({
            id: "blog_details.notifications.save_error",
            message: "Error saving blog:",
          }) +
          " " +
          response.data.message;
        toast.error(errorMessage);
      }
    } catch (error: any) {
      console.error("Error saving blog:", error);
      const errorMessage =
        error.response?.data?.message ||
        error.message ||
        t({
          id: "blog_details.notifications.generic_save_error",
          message: "Error saving blog. Please try again.",
        });
      toast.error(errorMessage);
    }
  };

  const handleSaveChanges = async () => {
    if (blogPost && id && editorRef.current) {
      try {
        const content = editorRef.current.innerHTML;

        // Nettoyer le contenu des retours à la ligne et guillemets indésirables
        const cleanContent = content
          .replace(/\\n/g, "") // Supprimer les \n
          .replace(/^"|"$/g, "") // <-- Use this simple pattern for one quote at start/end
          .replace(/<br>/g, "<br/>") // Standardiser les balises br
          .trim();
        const response = await blogService.updateBlogContent(+id, cleanContent);
        if (response.success) {
          setBlogPost(response.data);
          setIsEditing(false);
          toast.success(
            t({
              id: "blog_details.notifications.success_title",
              message: "Success",
            }) +
              " " +
              t({
                id: "blog_details.notifications.content_updated",
                message: "Blog has been updated successfully.",
              })
          );
        } else {
          toast.error(
            t({
              id: "blog_details.notifications.save_failed",
              message: "Failed to save changes",
            })
          );
        }
      } catch (err) {
        console.error("Error saving changes", err);
        toast.error(
          t({
            id: "blog_details.notifications.save_error_generic",
            message: "Error saving changes",
          })
        );
      }
    }
  };

  const handleCancelEdit = () => {
    if (blogPost?.content) {
      let formattedContent = "";

      if (Array.isArray(blogPost.content)) {
        formattedContent = blogPost.content
          .map((para) => (para.startsWith("<") ? para : `<p>${para}</p>`))
          .join("");
      } else {
        formattedContent = blogPost.content;
      }

      if (editorRef.current) {
        editorRef.current.innerHTML = formattedContent;
      }
    }
    setIsEditing(false);
  };

  // Fonction pour calculer le temps de lecture en ignorant le HTML
  const calculateReadingTime = (
    content: string | string[] | null | undefined
  ): number => {
    if (!content) return 1;

    let textContent = "";

    if (Array.isArray(content)) {
      textContent = content.join(" ");
    } else {
      textContent = content;
    }

    // Supprimer les balises HTML pour ne compter que le texte
    const cleanText = textContent.replace(/<[^>]*>/g, "");

    // Compter les mots (approximativement) et estimer le temps de lecture
    const wordCount = cleanText.split(/\s+/).length;

    // Estimation: 200 mots par minute
    const readingTime = Math.ceil(wordCount / 200);

    // Retourner au moins 1 minute
    return Math.max(1, readingTime);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-lg text-gray-600">
          <Trans id="blog_details.loading">Loading blog post...</Trans>
        </div>
      </div>
    );
  }

  if (error || !blogPost) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-lg text-red-600">
          {error ||
            t({ id: "blog_details.not_found", message: "Blog post not found" })}
        </div>
        <button
          onClick={() => navigate(-1)}
          className="ml-4 px-4 py-2 bg-blue-500 text-white rounded-md"
        >
          <Trans id="blog_details.go_back">Go Back</Trans>
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-8">
      {/* Image principale avec détails superposés */}
      <div className="relative h-96 w-full">
        <img
          src={`${settings.IMG_ADDRESS}${blogPost.image?.url}`}
          alt={blogPost.image?.filename || blogPost.title}
          className="w-full h-full object-cover"
        />

        <div className="absolute inset-0 bg-black bg-opacity-50"></div>

        <div className="absolute inset-0 flex flex-col justify-end p-8 text-white">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate(-1)}
              className="absolute top-6 left-6 flex items-center text-white hover:text-gray-200 transition-colors"
            >
              <ArrowLeft size={24} className="mr-2" />
              <Trans id="blog_details.back_to_blogs">Back to Blogs</Trans>
            </button>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="absolute top-6 right-9 flex items-center text-white bg-white/20 hover:bg-white/30 transition-colors p-2 rounded-md"
            >
              <Edit size={18} className="mr-1" />
              {isEditing ? (
                <Trans id="blog_details.preview">Preview</Trans>
              ) : (
                <Trans id="blog_details.edit_content">Edit Content</Trans>
              )}
            </button>
          </div>

          <div className="max-w-4xl mx-auto w-full">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">
              {blogPost.title}
            </h1>
            <p className="text-xl mb-6">{blogPost.description}</p>

            <div className="flex flex-wrap items-center gap-4 md:gap-6">
              <div className="flex items-center">
                <User size={20} className="mr-2" />
                <span className="font-medium">
                  <Trans id="blog_details.by_author">
                    By {blogPost.creator}
                  </Trans>
                </span>
              </div>
              <div className="flex items-center w-5 border bottom-1"></div>
              <div className="flex items-center">
                <Clock size={20} className="mr-2" />
                <span>
                  <Trans id="blog_details.reading_time">
                    {calculateReadingTime(blogPost.content)} min read
                  </Trans>
                </span>
              </div>
            </div>
            <div className="flex justify-start mt-4">
              <button
                onClick={handleEditForm}
                className="flex items-center text-white bg-white/20 hover:bg-white/30 font-medium py-2 px-4 transition-colors rounded-md"
              >
                <Edit size={18} className="mr-2" />
                <Trans id="blog_details.edit_post_settings">
                  Edit Post Settings
                </Trans>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 mt-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="w-full lg:w-2/3 bg-white rounded-xl shadow-md p-6 md:p-8">
            {isEditing ? (
              <div className="prose space-y-6">
                <div className="toolbar flex flex-wrap gap-1 p-2 bg-white border border-gray-200 rounded-xl shadow-md">
                  {/* Undo/Redo Group */}
                  <div className="tool-group flex items-center border-r border-gray-200 pr-1">
                    <button
                      onClick={handleUndo}
                      disabled={!canUndo}
                      className="p-2 text-gray-700 rounded-lg hover:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed transition-colors duration-150"
                      title={t({
                        id: "blog_details.editor.undo",
                        message: "Undo (Ctrl+Z)",
                      })}
                    >
                      {/* Assuming Undo is an imported icon component */}
                      <Undo size={18} />
                    </button>
                    <button
                      onClick={handleRedo}
                      disabled={!canRedo}
                      className="p-2 text-gray-700 rounded-lg hover:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed transition-colors duration-150"
                      title={t({
                        id: "blog_details.editor.redo",
                        message: "Redo (Ctrl+Y)",
                      })}
                    >
                      {/* Assuming Redo is an imported icon component */}
                      <Redo size={18} />
                    </button>
                  </div>

                  {/* Format Block Select Group */}
                  <div className="tool-group flex items-center border-r border-gray-200 pr-2">
                    <select
                      // IMPORTANT FIX: Wrap value in <> for formatBlock to work reliably
                      onChange={(e) =>
                        formatText("formatBlock", `<${e.target.value}>`)
                      }
                      className="appearance-none bg-white p-2 border-0 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-100 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors duration-150 cursor-pointer"
                      style={{ minWidth: "130px" }} // Tailwind doesn't have a good default for min-width on select
                    >
                      <option value="p">
                        {t({
                          id: "blog_details.editor.normal_text",
                          message: "Normal text",
                        })}
                      </option>
                      <option value="h1">
                        {t({
                          id: "blog_details.editor.heading1",
                          message: "Heading 1",
                        })}
                      </option>
                      <option value="h2">
                        {t({
                          id: "blog_details.editor.heading2",
                          message: "Heading 2",
                        })}
                      </option>
                      <option value="h3">
                        {t({
                          id: "blog_details.editor.heading3",
                          message: "Heading 3",
                        })}
                      </option>
                      <option value="h4">
                        {t({
                          id: "blog_details.editor.heading4",
                          message: "Heading 4",
                        })}
                      </option>
                      <option value="h5">
                        {t({
                          id: "blog_details.editor.heading5",
                          message: "Heading 5",
                        })}
                      </option>
                      <option value="h6">
                        {t({
                          id: "blog_details.editor.heading6",
                          message: "Heading 6",
                        })}
                      </option>
                      <option value="blockquote">
                        {t({
                          id: "blog_details.editor.quote",
                          message: "Quote",
                        })}
                      </option>
                    </select>
                  </div>

                  {/* Text Style Group (Bold, Italic, Underline) */}
                  <div className="tool-group flex items-center border-r border-gray-200 pr-1">
                    <button
                      onClick={() => formatText("bold")}
                      className="p-2 text-gray-700 rounded-lg hover:bg-gray-100 font-bold transition-colors duration-150"
                      title={t({
                        id: "blog_details.editor.bold",
                        message: "Bold",
                      })}
                    >
                      <span className="text-base">B</span>{" "}
                      {/* Using a span for better control */}
                    </button>
                    <button
                      onClick={() => formatText("italic")}
                      className="p-2 text-gray-700 rounded-lg hover:bg-gray-100 italic transition-colors duration-150"
                      title={t({
                        id: "blog_details.editor.italic",
                        message: "Italic",
                      })}
                    >
                      <span className="text-base">I</span>
                    </button>
                    <button
                      onClick={() => formatText("underline")}
                      className="p-2 text-gray-700 rounded-lg hover:bg-gray-100 underline transition-colors duration-150"
                      title={t({
                        id: "blog_details.editor.underline",
                        message: "Underline",
                      })}
                    >
                      <span className="text-base">U</span>
                    </button>
                  </div>

                  {/* Alignment Group */}
                  <div className="tool-group flex items-center border-r border-gray-200 pr-1">
                    <button
                      onClick={() => formatText("justifyLeft")}
                      className="p-2 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors duration-150"
                      title={t({
                        id: "blog_details.editor.align_left",
                        message: "Align Left",
                      })}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path d="M3 6h18M3 12h15M3 18h10" />
                      </svg>
                    </button>
                    <button
                      onClick={() => formatText("justifyCenter")}
                      className="p-2 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors duration-150"
                      title={t({
                        id: "blog_details.editor.align_center",
                        message: "Align Center",
                      })}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path d="M6 6h12M8 12h8M6 18h12" />
                      </svg>
                    </button>
                    <button
                      onClick={() => formatText("justifyRight")}
                      className="p-2 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors duration-150"
                      title={t({
                        id: "blog_details.editor.align_right",
                        message: "Align Right",
                      })}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path d="M3 6h18M9 12h12M7 18h14" />
                      </svg>
                    </button>
                  </div>

                  {/* Insert/List Group */}
                  <div className="tool-group flex items-center">
                    <button
                      onClick={() => formatText("insertUnorderedList")}
                      className="p-2 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors duration-150"
                      title={t({
                        id: "blog_details.editor.bullet_list",
                        message: "Bullet List",
                      })}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
                      </svg>
                    </button>
                    <button
                      onClick={() => formatText("insertOrderedList")}
                      className="p-2 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors duration-150"
                      title={t({
                        id: "blog_details.editor.numbered_list",
                        message: "Numbered List",
                      })}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path d="M9 6h11M9 12h11M9 18h11M4 6h1v4H4V6zm0 6h1v4H4v-4zm0 6h1v4H4v-4z" />
                      </svg>
                    </button>
                  </div>
                </div>

                <div
                  ref={editorRef}
                  contentEditable
                  className="editor min-h-96 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  onKeyDown={handleKeyDown}
                  style={{
                    whiteSpace: "pre-wrap",
                  }}
                />

                <div className="flex justify-end space-x-4 pt-4">
                  <button
                    onClick={handleCancelEdit}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    <Trans id="blog_details.cancel">Cancel</Trans>
                  </button>
                  <button
                    onClick={handleSaveChanges}
                    className="px-4 py-2 bg-[#238D94] text-white rounded-md hover:bg-[#1a6b72] transition-colors"
                  >
                    <Trans id="blog_details.save_changes">Save Changes</Trans>
                  </button>
                </div>
              </div>
            ) : (
              <div className="prose max-w-none text-justify">
                {(() => {
                  const rawContent = String(blogPost.content || "");
                  const cleanContent = rawContent.replace(/^"|"$/g, "").trim();

                  // 3. Return the div with the cleaned content
                  return (
                    <div dangerouslySetInnerHTML={{ __html: cleanContent }} />
                  );
                })()}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="w-full lg:w-1/3">
            <div className="bg-white rounded-xl shadow-md p-6 mb-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">
                <Trans id="blog_details.post_details">Post Details</Trans>
              </h3>

              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-500 mb-1">
                    <Trans id="blog_details.publication_date">
                      Publication Date
                    </Trans>
                  </p>
                  <p className="text-gray-800 font-medium">
                    {new Date(blogPost.createdAt).toLocaleDateString()}
                  </p>
                </div>

                <div>
                  <p className="text-sm text-gray-500 mb-1">
                    <Trans id="blog_details.category">Category</Trans>
                  </p>
                  <p className="text-gray-800 font-medium">
                    {blogPost.categories[0]?.name || "Company News"}
                  </p>
                </div>

                <div>
                  <p className="text-sm text-gray-500 mb-1">
                    <Trans id="blog_details.reading_time_label">
                      Reading Time
                    </Trans>
                  </p>
                  <p className="text-gray-800 font-medium">
                    <Trans id="blog_details.min_read">
                      {calculateReadingTime(blogPost.content)} min
                    </Trans>
                  </p>
                </div>

                <div>
                  <p className="text-sm text-gray-500 mb-1">
                    <Trans id="blog_details.author_name">Author Name</Trans>
                  </p>
                  <p className="text-gray-800 font-medium">
                    {blogPost.creator}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 mt-4 mb-4">
          <div className="flex items-center mb-4">
            <Tag size={20} className="text-gray-700 mr-2" />
            <h3 className="text-lg font-semibold text-gray-800">
              <Trans id="blog_details.tags">Tags</Trans>
            </h3>
          </div>

          <div className="flex flex-wrap gap-2">
            {blogPost.tags &&
              blogPost.tags.map((tag) => (
                <span
                  key={tag.id}
                  className="bg-[#d9fcff] text-[#1a6b72] px-3 py-1 rounded-full text-sm font-medium"
                >
                  {tag.name}
                </span>
              ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 md:p-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4 md:mb-0">
              <Trans id="blog_details.you_may_like">You May Also Like</Trans>
            </h2>
            <button
              className="flex items-center text-[#238D94] hover:text-[#1a6b72] font-medium"
              onClick={() => navigate("/admin/blogs")}
            >
              <Trans id="blog_details.view_all_blogs">View All Blogs</Trans>
              <ChevronRight size={18} className="ml-1" />
            </button>
          </div>

          {relatedPosts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedPosts.map((post) => (
                <div
                  key={post.id}
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => navigate(`/admin/blogDetails/${post.id}`)}
                >
                  <div className="h-40 mb-3 overflow-hidden rounded">
                    <img
                      src={`${settings.IMG_ADDRESS}${post.image?.url}`}
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="font-semibold text-gray-800 mb-2 line-clamp-2">
                    {post.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                    {post.description}
                  </p>
                  <div className="flex items-center text-gray-500 text-xs">
                    <span>{post.creator}</span>
                    <span className="mx-2">•</span>
                    <span>
                      <Trans id="blog_details.related_min_read">
                        {Math.ceil((post.content || "").length / 200)} min read
                      </Trans>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-4">
              <Trans id="blog_details.no_related_posts">
                No related posts found
              </Trans>
            </p>
          )}
        </div>
      </div>

      {showEdit && blogPost && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-screen overflow-y-auto">
            <BlogForm
              post={blogPost}
              onSave={handleSaveBlog}
              onCancel={() => {
                setShowEdit(false);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminBlogDetails;
