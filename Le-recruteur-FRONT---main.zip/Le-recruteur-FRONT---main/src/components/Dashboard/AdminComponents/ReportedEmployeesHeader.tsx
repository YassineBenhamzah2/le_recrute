import { Eye } from 'lucide-react';
import { Trans } from '@lingui/macro';

interface ReportedEmployeesHeaderProps {
  onOverviewClick?: () => void;
}

export function ReportedEmployeesHeader({ onOverviewClick }: ReportedEmployeesHeaderProps) {
  return (
    <div className="flex items-center justify-between mb-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          <Trans id="admin.reported_employees.header_title">Reported Employees</Trans>
        </h1>
        <p className="text-gray-600">
          <Trans id="admin.reported_employees.header_description">
            View and manage employees who have been reported by users.
          </Trans>
        </p>
      </div>
      <button 
        onClick={onOverviewClick}
        className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg transition-colors duration-200"
      >
        <Eye size={18} />
        <Trans id="admin.reported_employees.overview_button">Overview</Trans>
      </button>
    </div>
  );
}