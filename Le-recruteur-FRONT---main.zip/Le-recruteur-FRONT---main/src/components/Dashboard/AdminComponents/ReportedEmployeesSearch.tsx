import { Search, Filter } from 'lucide-react';
import { Trans, t } from '@lingui/macro';

interface ReportedEmployeesSearchProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  onFilterClick?: () => void;
}

export function ReportedEmployeesSearch({
  searchTerm,
  onSearchChange,
  onFilterClick
}: ReportedEmployeesSearchProps) {
  return (
    <div className="p-6 border-b border-gray-200">
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder={t({ 
              id: "admin.reported_employees.search_placeholder", 
              message: "Search by name, company, or report reason..." 
            })}
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          />
        </div>
        <button
          onClick={onFilterClick}
          className="ml-4 flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <Filter size={16} />
          <Trans id="admin.reported_employees.filter_all_button">Filter All</Trans>
        </button>
      </div>
    </div>
  );
}
