import { Candidate } from '@/lib/types/cvtheque';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Mail, Phone, MapPin, Briefcase } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface CandidatesTableProps {
    candidates: Candidate[];
    isLoading: boolean;
    selectedCandidateIds: number[];
    onSelectionChange: (ids: number[]) => void;
}

export function CandidatesTable({ candidates, isLoading, selectedCandidateIds, onSelectionChange }: CandidatesTableProps) {
    const handleSelectAll = (checked: boolean) => {
        onSelectionChange(checked ? candidates.map(c => c.id) : []);
    };

    const handleSelectOne = (id: number, checked: boolean) => {
        if (checked) {
            onSelectionChange([...selectedCandidateIds, id]);
        } else {
            onSelectionChange(selectedCandidateIds.filter(cid => cid !== id));
        }
    };

    return (
        <Table>
            <TableHeader className="sticky top-0 bg-white z-10">
                <TableRow>
                    <TableHead className="w-[50px]"><Checkbox onCheckedChange={(checked) => handleSelectAll(Boolean(checked))} /></TableHead>
                    <TableHead>Candidat</TableHead>
                    <TableHead>Fonction & Expérience</TableHead>
                    <TableHead>Contact</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {isLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                        <TableRow key={i}>
                            <TableCell><Skeleton className="h-4 w-4" /></TableCell>
                            <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                            <TableCell><Skeleton className="h-4 w-48" /></TableCell>
                            <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                        </TableRow>
                    ))
                ) : candidates.length > 0 ? (
                    candidates.map((candidate) => (
                        <TableRow key={candidate.id}>
                            <TableCell><Checkbox checked={selectedCandidateIds.includes(candidate.id)} onCheckedChange={(checked) => handleSelectOne(candidate.id, Boolean(checked))} /></TableCell>
                            <TableCell><div className="font-medium">{candidate.name}</div><div className="text-sm text-gray-500 flex items-center"><MapPin size={12} className="mr-1" />{candidate.location}</div></TableCell>
                            <TableCell><div className="font-medium">{candidate.currentPosition}</div><div className="text-sm text-gray-500 flex items-center"><Briefcase size={12} className="mr-1" />{candidate.experience}</div></TableCell>
                            <TableCell><div className="text-sm text-gray-700 flex items-center"><Mail size={12} className="mr-1" />{candidate.email}</div><div className="text-sm text-gray-700 flex items-center"><Phone size={12} className="mr-1" />{candidate.phone}</div></TableCell>
                        </TableRow>
                    ))
                ) : (
                    <TableRow><TableCell colSpan={4} className="text-center h-24">Aucun candidat trouvé.</TableCell></TableRow>
                )}
            </TableBody>
        </Table>
    );
}