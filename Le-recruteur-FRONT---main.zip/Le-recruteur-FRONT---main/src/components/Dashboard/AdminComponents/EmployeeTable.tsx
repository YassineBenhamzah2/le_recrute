import { UserCheck, UserX, Ban, UserMinus } from 'lucide-react';
import { Trans, t } from '@lingui/macro';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Employee {
  id: number;
  firstname: string;
  lastname: string;
  company: string;
  department: string;
  location: string;
  joined: string;
  phone: string;
  status: 'ACTIVE' | 'INACTIVE' | 'REPORTED' | 'SUSPENDED' | 'REJECTED';
}

interface EmployeeTableProps {
  employees: Employee[];
  onApprove: (id: number) => void;
  onDeactivate: (id: number) => void;
  onSuspend: (id: number) => void;    
  onReject: (id: number) => void;
  isLoading: boolean;
}

const getStatusColor = (status: string) => {
    switch (status) {
      case 'ACTIVE':
        return 'bg-green-100 text-green-800';
      case 'INACTIVE':
        return 'bg-gray-100 text-gray-800';
      case 'REPORTED':
        return 'bg-yellow-100 text-yellow-800';
      case 'SUSPENDED':
        return 'bg-red-100 text-red-800'
      case 'REJECTED':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-red-100 text-red-800';
    }
  };

  const getStatusDot = (status: string) => {
    switch (status) {
      case 'ACTIVE':
        return 'bg-green-500';
      case 'INACTIVE':
        return 'bg-gray-500';
      case 'REPORTED':
        return 'bg-yellow-500';
      case 'SUSPENDED':
        return 'bg-red-500 ';
      case 'REJECTED':
        return 'bg-purple-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'ACTIVE':
        return t({ id: "employee.status.active", message: "Active" });
      case 'INACTIVE':
        return t({ id: "employee.status.inactive", message: "Inactive" });
      case 'REPORTED':
        return t({ id: "employee.status.reported", message: "Reported" });
      case 'SUSPENDED':
        return t({ id: "employee.status.suspended", message: "Suspended" });
      case 'REJECTED':
        return t({ id: "employee.status.rejected", message: "Rejected" });
      default:
        return t({ id: "employee.status.unknown", message: "Unknown" });
    }
  };

export function EmployeeTable({ employees, onApprove, onDeactivate, onSuspend, onReject, isLoading }: EmployeeTableProps) {
  if (!employees || employees.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">
          <Trans id="employee.no_employees">No employees found</Trans>
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead className="bg-gray-50 border-b border-gray-200">
          <tr>
            <th className="text-left py-3 px-4 font-medium text-gray-700 text-sm">
              <Trans id="employee.table.name">Name</Trans>
            </th>
            <th className="text-left py-3 px-4 font-medium text-gray-700 text-sm">
              <Trans id="employee.table.company">Company</Trans>
            </th>
            <th className="text-left py-3 px-4 font-medium text-gray-700 text-sm">
              <Trans id="employee.table.department">Department</Trans>
            </th>
            <th className="text-left py-3 px-4 font-medium text-gray-700 text-sm">
              <Trans id="employee.table.location">Location</Trans>
            </th>
            <th className="text-left py-3 px-4 font-medium text-gray-700 text-sm">
              <Trans id="employee.table.joined">Joined</Trans>
            </th>
            <th className="text-left py-3 px-4 font-medium text-gray-700 text-sm">
              <Trans id="employee.table.phone">Phone</Trans>
            </th>
            <th className="text-left py-3 px-4 font-medium text-gray-700 text-sm">
              <Trans id="employee.table.status">Status</Trans>
            </th>
            <th className="text-left py-3 px-4 font-medium text-gray-700 text-sm">
              <Trans id="employee.table.actions">Actions</Trans>
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {employees.map((employee) => (
            <tr key={employee.id} className="hover:bg-gray-50 transition-colors">
              <td className="py-3 px-4">
                <div className="font-medium text-gray-900">
                  {employee.firstname} {employee.lastname}
                </div>
              </td>
              <td className="py-3 px-4 text-gray-600 text-sm">{employee.company}</td>
              <td className="py-3 px-4 text-gray-600 text-sm">{employee.department}</td>
              <td className="py-3 px-4 text-gray-600 text-sm">{employee.location}</td>
              <td className="py-3 px-4 text-gray-600 text-sm">{employee.joined}</td>
              <td className="py-3 px-4 text-gray-600 text-sm">{employee.phone}</td>
              <td className="py-4 px-4">
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${getStatusColor(employee.status)}`}>
                  <span className={`w-2 h-2 rounded-full mr-2 ${getStatusDot(employee.status)}`}></span>
                  {getStatusText(employee.status)}
                </span>
              </td>
              <td className="py-3 px-4">
                <div className="flex items-center space-x-2">
                  {/* === ACTION: APPROVE (Make Active) === */}
                  {/* Show if user is INACTIVE, SUSPENDED, or REPORTED */}
                  {['INACTIVE', 'SUSPENDED', 'REPORTED'].includes(employee.status) && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <button
                          disabled={isLoading}
                          className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          title={t({ id: "employee.action.approve_tooltip", message: "Approve (Set to Active)" })}
                        >
                          <UserCheck className="w-4 h-4" />
                        </button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>
                            <Trans id="employee.dialog.approve.title">Confirm Approval</Trans>
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            <Trans id="employee.dialog.approve.description">
                              Are you sure you want to approve "{employee.firstname} {employee.lastname}"? Their status will be set to ACTIVE.
                            </Trans>
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>
                            <Trans id="employee.dialog.cancel">Cancel</Trans>
                          </AlertDialogCancel>
                          <AlertDialogAction onClick={() => onApprove(employee.id)}>
                            <Trans id="employee.dialog.approve.action">Approve</Trans>
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}

                  {/* === ACTION: DEACTIVATE (Make Inactive) === */}
                  {/* Show only if user is ACTIVE */}
                  {employee.status === 'ACTIVE' && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <button
                          disabled={isLoading}
                          className="p-1.5 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          title={t({ id: "employee.action.deactivate_tooltip", message: "Deactivate (Set to Inactive)" })}
                        >
                          <UserMinus className="w-4 h-4" />
                        </button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>
                            <Trans id="employee.dialog.deactivate.title">Confirm Deactivation</Trans>
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            <Trans id="employee.dialog.deactivate.description">
                              Are you sure you want to deactivate "{employee.firstname} {employee.lastname}"? Their status will be set to INACTIVE.
                            </Trans>
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>
                            <Trans id="employee.dialog.cancel">Cancel</Trans>
                          </AlertDialogCancel>
                          <AlertDialogAction onClick={() => onDeactivate(employee.id)}>
                            <Trans id="employee.dialog.deactivate.action">Deactivate</Trans>
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                  
                  {/* === ACTION: SUSPEND === */}
                  {/* Show only if user is ACTIVE */}
                  {employee.status === 'ACTIVE' && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <button
                          disabled={isLoading}
                          className="p-1.5 text-orange-600 hover:bg-orange-50 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          title={t({ id: "employee.action.suspend_tooltip", message: "Suspend" })}
                        >
                          <Ban className="w-4 h-4" />
                        </button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>
                            <Trans id="employee.dialog.suspend.title">Confirm Suspension</Trans>
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            <Trans id="employee.dialog.suspend.description">
                              Are you sure you want to suspend "{employee.firstname} {employee.lastname}"?
                            </Trans>
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>
                            <Trans id="employee.dialog.cancel">Cancel</Trans>
                          </AlertDialogCancel>
                          <AlertDialogAction onClick={() => onSuspend(employee.id)}>
                            <Trans id="employee.dialog.suspend.action">Suspend</Trans>
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}

                  {/* === ACTION: REJECT (Permanent) === */}
                  {/* Show for any status EXCEPT already rejected */}
                  {employee.status !== 'REJECTED' && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <button
                          disabled={isLoading}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          title={t({ id: "employee.action.reject_tooltip", message: "Reject Permanently" })}
                        >
                          <UserX className="w-4 h-4" />
                        </button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>
                            <Trans id="employee.dialog.reject.title">Confirm Rejection</Trans>
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            <Trans id="employee.dialog.reject.description">
                              This action is permanent and cannot be undone. Are you sure you want to reject "{employee.firstname} {employee.lastname}"?
                            </Trans>
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>
                            <Trans id="employee.dialog.cancel">Cancel</Trans>
                          </AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => onReject(employee.id)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            <Trans id="employee.dialog.reject.action">Reject</Trans>
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
