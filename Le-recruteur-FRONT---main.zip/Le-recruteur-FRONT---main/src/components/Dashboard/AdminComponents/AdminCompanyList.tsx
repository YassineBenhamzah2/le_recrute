import { useEffect, useState } from "react";
import { Pencil, Trash2,Building, Plus } from "lucide-react";
import { settings } from "@/lib/settings/main";
import { companyCmsApi } from "@/lib/network/companyCmsApi";
import { AdminCompanyCmsResponse, Company } from "@/lib/types/company";

export default function AdminCompanies() {
  const [companies, setCompanies] = useState<AdminCompanyCmsResponse[]>([]);
  const [allCompanies, setAllCompanies] = useState<Company[]>([]);
  const [page, setPage] = useState(0);
  const pageSize = 3;
  const [totalPages, setTotalPages] = useState(1);

  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState<number | "">("");
  const [destinationLink, setDestinationLink] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<number>(0);

  const [editCompanyId, setEditCompanyId] = useState<number | null>(null);
  const [editDestinationLink, setEditDestinationLink] = useState("");
  const [editOrder, setEditOrder] = useState<number>(0);

  // Pour popup suppression
  const [deleteCmsId, setDeleteCmsId] = useState<number | null>(null);

  const fetchCmsCompanies = async () => {
    try {
      const res = await companyCmsApi.getCmsCompanies(page, pageSize);
      setCompanies(res.content || []);
      setTotalPages(res.totalPages || 1);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchAllCompanies = async () => {
    try {
      const res = await companyCmsApi.getAllCompanies();
      setAllCompanies(res);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchCmsCompanies();
    fetchAllCompanies();
  }, [page]);

  const handleAdd = async () => {
    if (selectedCompanyId === "") return;
    try {
      const company = allCompanies.find((c) => c.id === selectedCompanyId);
      if (!company) return;
      await companyCmsApi.addCompanyToCms(
        selectedCompanyId,
        selectedOrder,
        destinationLink
      );
      setShowAddModal(false);
      setSelectedCompanyId("");
      setSelectedOrder(0);
      setDestinationLink("");
      fetchCmsCompanies();
    } catch (error) {
      console.error(error);
    }
  };

  const handleEdit = (company: AdminCompanyCmsResponse) => {
    setEditCompanyId(company.cmsId!);
    setEditDestinationLink(company.destinationLink || "");
    setEditOrder(company.displayOrder || 0);
  };

  const saveEdit = async () => {
    if (editCompanyId === null) return;
    try {
      await companyCmsApi.updateDisplayOrder(
        editCompanyId,
        editOrder,
        editDestinationLink
      );
      setEditCompanyId(null);
      setEditDestinationLink("");
      setEditOrder(0);
      fetchCmsCompanies();
    } catch (error) {
      console.error(error);
    }
  };

  // Supprimer CMS company avec confirmation
  const confirmDelete = (cmsId: number) => {
    setDeleteCmsId(cmsId);
  };

  const handleDelete = async () => {
    if (deleteCmsId === null) return;
    try {
      await companyCmsApi.deleteCmsCompany(deleteCmsId);
      setDeleteCmsId(null);
      fetchCmsCompanies();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="space-y-6 p-6 bg-gray-50 ">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-[#0e2426]">Companies CMS</h2>
          <p className="text-gray-600 mt-2">
            Manage the companies featured on the homepage.
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-white text-[#238D94] border border-teal-600 px-5 py-2 rounded-lg shadow hover:bg-[#1d757c] hover:text-white transition mt-4 md:mt-0"
        >
          Ajouter une company
        </button>
      </div>



      {companies.length === 0 ? (

        // --- Message si aucune entreprise n'est trouvée ---
        <div className="text-center bg-white border-2 border-dashed border-gray-300 rounded-lg p-12 mt-8">
          <div className="mx-auto w-16 h-16 flex items-center justify-center bg-gray-100 rounded-full text-gray-400">
            <Building size={32} />
          </div>
          <h3 className="mt-4 text-xl font-semibold text-gray-800">
            No Featured Companies
          </h3>
          <p className="mt-2 text-sm text-gray-500">
            Get started by adding a company to the homepage CMS.
          </p>
          <button
            onClick={() => setShowAddModal(true)}
            className="mt-6 inline-flex items-center gap-2 bg-[#238D94] text-white px-5 py-2.5 rounded-lg shadow hover:bg-[#1d757c] transition font-semibold"
          >
            <Plus size={18} />
            Add First Company
          </button>
        </div>

      ) : (

    
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {companies.map((company) => (
          <div
            key={company.cmsId}
            className="bg-white rounded-lg shadow relative cursor-pointer hover:shadow-lg transition p-4 flex flex-col"
          >
            <img
              src={
                company.logoUrl
                  ? `${settings.IMG_ADDRESS}${company.logoUrl}`
                  : ""
              }
              alt={company.name}
              className="w-full h-48 object-cover rounded-t-lg"
            />
            <div className="mt-2 flex-1 flex flex-col">
              <h3
                className="font-bold text-lg mb-1 truncate"
                title={company.name}
              >
                {company.name}
              </h3>
              {company.destinationLink && (
                <p
                  className="text-teal-600 underline cursor-pointer mb-1 truncate"
                  title={company.destinationLink}
                  onClick={() => window.open(company.destinationLink, "_blank")}
                >
                  {company.destinationLink}
                </p>
              )}
              <p className="text-gray-700 text-sm break-words overflow-hidden max-h-16">
                {company.description}
              </p>
            </div>

            <div className="absolute top-2 right-2 flex gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleEdit(company);
                }}
                className="p-2 bg-white rounded-full shadow hover:bg-gray-100 transition"
              >
                <Pencil className="text-[#238D94]" size={18} />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  confirmDelete(company.cmsId!);
                }}
                className="p-2 bg-white rounded-full shadow hover:bg-gray-100 transition"
              >
                <Trash2 className="text-gray-500" size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>)}

      {/* Pagination */}
      {companies.length != 0 && (
      <div className="flex justify-center mt-4 space-x-2">
        <button
          disabled={page === 0}
          onClick={() => setPage(page - 1)}
          className="px-3 py-1 border rounded disabled:opacity-50"
        >
          &lt;
        </button>
        {Array.from({ length: totalPages }, (_, i) => (
          <button
            key={i}
            onClick={() => setPage(i)}
            className={`px-3 py-1 border rounded ${
              i === page ? "bg-[#238D94] text-white" : "text-gray-600"
            }`}
          >
            {i + 1}
          </button>
        ))}
        <button
          disabled={page === totalPages - 1}
          onClick={() => setPage(page + 1)}
          className="px-3 py-1 border rounded disabled:opacity-50"
        >
          &gt;
        </button>
      </div>)}

      {/* Modal Ajouter */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-2xl p-6 relative">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-3 right-3 w-10 h-10 border border-teal-600 bg-teal-600 text-white rounded-full flex items-center justify-center text-xl hover:bg-teal-50 transition hover:text-teal-600"
            >
              ×
            </button>
            <h2 className="text-xl font-bold mb-4">Ajouter une Company</h2>

            <label className="block mb-2">Choisir une company</label>
            <select
              className="w-full mb-4 border p-2 rounded"
              value={selectedCompanyId}
              onChange={(e) =>
                setSelectedCompanyId(
                  e.target.value === "" ? "" : Number(e.target.value)
                )
              }
            >
              <option value="">-- Sélectionner --</option>
              {allCompanies.map((c) =>
                c.id ? (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ) : null
              )}
            </select>

            <label className="block mb-2">Lien de destination</label>
            <input
              type="text"
              className="w-full mb-4 border p-2 rounded"
              value={destinationLink}
              onChange={(e) => setDestinationLink(e.target.value)}
              placeholder="https://..."
            />

            <label className="block mb-2">Ordre d’affichage</label>
            <input
              type="number"
              className="w-full mb-4 border p-2 rounded"
              value={selectedOrder}
              onChange={(e) => setSelectedOrder(Number(e.target.value))}
            />

            <div className="flex justify-end space-x-2">
              <button
                className="px-4 py-2 bg-gray-300 rounded"
                onClick={() => setShowAddModal(false)}
              >
                Annuler
              </button>
              <button
                className="px-4 py-2 border border-teal-600 bg-teal-600 text-white rounded hover:bg-teal-50 transition hover:text-teal-600"
                onClick={handleAdd}
              >
                Ajouter
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Éditer */}
      {editCompanyId !== null && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-2xl p-6 relative">
            <button
              onClick={() => setEditCompanyId(null)}
              className="absolute top-3 right-3 w-10 h-10 border border-teal-600 bg-teal-600 text-white rounded-full flex items-center justify-center text-xl hover:bg-teal-50 transition hover:text-teal-600"
            >
              ×
            </button>
            <h2 className="text-xl font-bold mb-4">Éditer Company</h2>

            <label className="block mb-2">Lien de destination</label>
            <input
              type="text"
              className="w-full mb-4 border p-2 rounded"
              value={editDestinationLink}
              onChange={(e) => setEditDestinationLink(e.target.value)}
              placeholder="https://..."
            />

            <label className="block mb-2">Ordre d’affichage</label>
            <input
              type="number"
              className="w-full mb-4 border p-2 rounded"
              value={editOrder}
              onChange={(e) => setEditOrder(Number(e.target.value))}
            />

            <div className="flex justify-end space-x-2">
              <button
                className="px-4 py-2 bg-gray-300 rounded"
                onClick={() => setEditCompanyId(null)}
              >
                Annuler
              </button>
              <button
                className="px-4 py-2 border border-teal-600 bg-teal-600 text-white rounded hover:bg-teal-50 transition"
                onClick={saveEdit}
              >
                Sauvegarder
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Confirmation Suppression */}
      {deleteCmsId !== null && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-lg p-8 relative">
            {/* Bouton X pour fermer */}
            <button
              onClick={() => setDeleteCmsId(null)}
              className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center rounded-full bg-teal-600 text-white text-xl hover:bg-teal-700 transition"
            >
              ×
            </button>

            <h2 className="text-2xl font-bold mb-6 text-center">
              Confirmer la suppression
            </h2>
            <p className="mb-6 text-center text-gray-700">
              Voulez-vous vraiment supprimer cette company ?
            </p>
            <div className="flex justify-center gap-4">
              <button
                className="px-6 py-3 bg-gray-300 rounded hover:bg-gray-400 transition"
                onClick={() => setDeleteCmsId(null)}
              >
                Non
              </button>
              <button
                className="px-6 py-3 bg-teal-600 text-white rounded hover:bg-teal-700 transition"
                onClick={handleDelete}
              >
                Oui
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
