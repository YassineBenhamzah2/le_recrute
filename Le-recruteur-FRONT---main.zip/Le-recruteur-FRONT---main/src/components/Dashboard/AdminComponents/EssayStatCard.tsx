import StatCard from "@/components/Dashboard/AdminComponents/Statcard.tsx";
import {  FileText, AlertTriangle , Hourglass } from "lucide-react";

import AdminJobCard from '@/components/Dashboard/AdminComponents/AdminJobCard.tsx';


const data1 = [ { value: 1 }, { value: 2 }, { value: 3 },{ value: 2 } ];
const data2 = [ { value: 3 }, { value: 1 }, { value: 4 }, { value: 2 } ];
const data3 = [ { value: 3 }, { value: 1 }, { value: 5 }, { value: 1 } ];





export default function EssayStatCard() {
    
   
   
  
  
  
    const jobs = [
  {
    id: 1,
    title: "Frontend Developer",
    company: "EHC Team",
    location: "Paris",
    type: "Full Time",
    salary: { min: 40000, max: 55000, currency: "€" },
    postedTime: "2 days ago",
    skills: ["React", "TypeScript", "Tailwind"],
    applicationsCount: 5,
    postedBy: "AdminUser"
  },
  // autres jobs...
];
  return  (

   
 <div className="p-4">

      {/* 👉 DIV AVANT LES CARTES */}
      <div className="text-2xl font-semibold text-gray-800">
       All Jobs 
       <br /> 
       
       <div className=" text-slate-600 text-xs "> Track, edit, or publish job postings in one place.</div>
      </div>
     
  <div className="text-xl font-semibold">Overview</div> 
  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 p-4">
   
      <StatCard
        icon={<Hourglass className="w-6 h-6" />}
        title="Active Job Postings "
        value={32}
        trend="+5% ce mois"
        trendColor="green"
        chartData={data1}
        chartColor="#00cba9"
      />
      
      <StatCard
        icon={<Hourglass className="w-6 h-6" />}
        title="Applications Received"
        value={32}
        trend="+5% ce mois"
        trendColor="green"
        chartData={data1}
        chartColor="#00cba9"
      />

      <StatCard
        icon={<FileText className="w-6 h-6" />}
        title="Jobs With No Applicants"
        value={197}
        trend="+8% ce mois"
        trendColor="green"
        chartData={data2}
        chartColor="#000000"
      />
      <StatCard
        icon={<AlertTriangle className="w-6 h-6" />}
        title="Expiring This Week"
        value={7}
        trend="-2 ce mois"
        trendColor="blue"
        chartData={data3}
        chartColor="#ff0000"
      />
    </div>




         
 <div>
      {jobs.map(job => (
        <AdminJobCard 
          key={job.id} 
          {...job} 
          onViewApplications={(id) => console.log("Voir candidatures pour", id)}
        />
      ))}
    </div>
  

    </div>



  );
}