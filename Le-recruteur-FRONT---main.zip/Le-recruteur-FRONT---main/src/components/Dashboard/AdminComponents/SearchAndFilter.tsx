import { Search, Filter } from "lucide-react";
import { Trans, t } from "@lingui/macro";

interface SearchAndFilterProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  onFilterClick: (value: string) => void;
}

export function SearchAndFilter({
  searchTerm,
  onSearchChange,
  onFilterClick,
}: SearchAndFilterProps) {
  return (
    <div className="p-6 border-b border-gray-100">
      <div className="flex items-center justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder={t({
              id: "search.placeholder",
              message: "Search by name, role, or department...",
            })}
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          />
        </div>
        <button
          onClick={() => onFilterClick("all")}
          className="ml-4 flex items-center space-x-2 px-4 py-2.5 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <Filter className="w-4 h-4 text-gray-500" />
          <span className="text-gray-700 font-medium">
            <Trans id="search.filter_all">Filter All</Trans>
          </span>
        </button>
      </div>
    </div>
  );
}
