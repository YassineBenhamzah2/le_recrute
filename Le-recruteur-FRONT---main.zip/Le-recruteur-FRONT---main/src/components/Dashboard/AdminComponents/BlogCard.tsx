import { useEffect, useState } from "react";
import { Blog, BlogCms, PaginatedBlogs } from "@/lib/types/blogs";
import { Pencil, Trash2, Newspaper, Plus } from "lucide-react";
import { settings } from "@/lib/settings/main";
import { blogCmsApi } from "@/lib/network/blogService";
import { Trans, t } from "@lingui/macro";

export default function AdminBlogs() {
  const [blogs, setBlogs] = useState<BlogCms[]>([]);
  const [allBlogs, setAllBlogs] = useState<Blog[]>([]);
  const [page, setPage] = useState(0);
  const pageSize = 3;
  const [totalPages, setTotalPages] = useState(1);

  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedBlogId, setSelectedBlogId] = useState<number | "">("");
  const [destinationLink, setDestinationLink] = useState("");
  const [selectedBlogOrder, setSelectedBlogOrder] = useState<number>(0);

  const [editBlogId, setEditBlogId] = useState<number | null>(null);
  const [editDestinationLink, setEditDestinationLink] = useState("");
  const [editBlogOrder, setEditBlogOrder] = useState<number>(0);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [currentDeleteBlog, setCurrentDeleteBlog] = useState<BlogCms | null>(
    null
  );

  // Charger les blogs CMS
  const fetchCmsBlogs = async () => {
    try {
      const res: PaginatedBlogs = await blogCmsApi.getCmsBlogs(page, pageSize);
      setBlogs(res.content || []);
      setTotalPages(res.totalPages || 1);
    } catch (error) {
      console.error(error);
    }
  };

  // Charger tous les blogs pour le select
  const fetchAllBlogs = async () => {
    try {
      const res: Blog[] = await blogCmsApi.getAllBlogs();
      setAllBlogs(res);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchCmsBlogs();
    fetchAllBlogs();
  }, [page]);

  // Ajouter un blog CMS
  const handleAdd = async () => {
    if (selectedBlogId === "") return;
    try {
      await blogCmsApi.addBlogToCms(
        selectedBlogId,
        selectedBlogOrder,
        destinationLink
      );
      setShowAddModal(false);
      setSelectedBlogId("");
      setDestinationLink("");
      setSelectedBlogOrder(0);
      fetchCmsBlogs();
    } catch (error) {
      console.error(error);
    }
  };

  // Éditer un blog CMS
  const handleEdit = (blog: BlogCms) => {
    setEditBlogId(blog.cmsId);
    setEditDestinationLink(blog.destinationLink || "");
    setEditBlogOrder(blog.displayOrder);
  };

  const saveEdit = async () => {
    if (editBlogId === null) return;
    try {
      await blogCmsApi.updateBlogCms(
        editBlogId,
        editBlogOrder,
        editDestinationLink
      );
      setEditBlogId(null);
      setEditDestinationLink("");
      setEditBlogOrder(0);
      fetchCmsBlogs();
    } catch (error) {
      console.error(error);
    }
  };

  // Supprimer un blog CMS
  const handleDelete = async () => {
    if (!currentDeleteBlog) return;
    try {
      await blogCmsApi.deleteBlogCms(currentDeleteBlog.cmsId);
      setShowDeleteModal(false);
      setCurrentDeleteBlog(null);
      fetchCmsBlogs();
    } catch (error) {
      console.error(error);
    }
  };

  const confirmDelete = (blog: BlogCms) => {
    setCurrentDeleteBlog(blog);
    setShowDeleteModal(true);
  };

  return (
    <div className="space-y-6 p-6 bg-gray-50 ">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-[#0e2426]">
            <Trans id="admin_blogs.title">Blogs CMS</Trans>
          </h2>
          <p className="text-gray-600 mt-2">
            <Trans id="admin_blogs.description">
              Manage the blog posts featured on the homepage.
            </Trans>
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-white text-[#238D94] border border-teal-600 px-5 py-2 rounded-lg shadow hover:bg-[#1d757c] hover:text-white transition flex items-center gap-2 mt-4 md:mt-0"
        >
          <Trans id="admin_blogs.add_blog">Ajouter un blog</Trans>
        </button>
      </div>

      {blogs.length === 0 ? (
        // --- Message si aucun blog n'est trouvé ---
        <div className="text-center bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-12 mt-8">
          <div className="mx-auto w-16 h-16 flex items-center justify-center bg-gray-200 rounded-full text-gray-500">
            <Newspaper size={32} />
          </div>
          <h3 className="mt-4 text-xl font-semibold text-gray-800">
            <Trans>No Blog Posts Found</Trans>
          </h3>
          <p className="mt-2 text-sm text-gray-500">
            <Trans>Get started by writing your first blog post.</Trans>
          </p>
          <button
            onClick={() => setShowAddModal(true)}
            className="mt-6 inline-flex items-center gap-2 bg-[#238D94] text-white px-5 py-2.5 rounded-lg shadow hover:bg-[#1d757c] transition font-semibold"
          >
            <Plus size={18} />
            <Trans>Create First Blog</Trans>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogs.map((blog) => (
            <div
              key={blog.cmsId}
              className="bg-white rounded-lg shadow relative cursor-pointer hover:shadow-lg transition"
              onClick={() =>
                blog.destinationLink &&
                window.open(blog.destinationLink, "_blank")
              }
            >
              <img
                src={`${settings.IMG_ADDRESS}${blog.imageUrl}`}
                alt={blog.title}
                className="w-full h-48 object-cover rounded-t-lg"
              />
              <div className="p-4">
                <h3 className="font-bold text-lg mb-1">{blog.title}</h3>
                <p className="text-gray-600 text-sm mb-2 flex items-center gap-1">
                  <img
                    src={blog.creatorPhoto?.url || "/avatars/Miles.png"}
                    alt={t({ id: "admin_blogs.author_alt", message: "author" })}
                    className="w-5 h-5 rounded-full"
                  />
                  {blog.creator || "Admin"} •{" "}
                  {blog.createdAt
                    ? new Date(blog.createdAt).toLocaleDateString()
                    : "—"}
                </p>
                <p className="text-gray-700 text-sm">{blog.description}</p>
              </div>

              <div className="absolute top-2 right-2 flex gap-2">
                <button
                  className="p-2 bg-white rounded-full shadow hover:bg-gray-100"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleEdit(blog);
                  }}
                  title={t({
                    id: "admin_blogs.edit_tooltip",
                    message: "Edit blog",
                  })}
                >
                  <Pencil className="text-[#0fd6e4]" size={18} />
                </button>
                <button
                  className="p-2 bg-white rounded-full shadow hover:bg-gray-100"
                  onClick={(e) => {
                    e.stopPropagation();
                    confirmDelete(blog);
                  }}
                  title={t({
                    id: "admin_blogs.delete_tooltip",
                    message: "Delete blog",
                  })}
                >
                  <Trash2 className="text-[#687778]" size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {blogs.length != 0 && (
        <div className="flex justify-center mt-4 space-x-2">
          <button
            disabled={page === 0}
            onClick={() => setPage(page - 1)}
            className="px-3 py-1 border rounded disabled:opacity-50"
            title={t({
              id: "admin_blogs.pagination.previous",
              message: "Previous page",
            })}
          >
            &lt;
          </button>
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i}
              onClick={() => setPage(i)}
              className={`px-3 py-1 border rounded ${
                i === page ? "bg-[#238D94] text-white" : "text-gray-600"
              }`}
            >
              {i + 1}
            </button>
          ))}
          <button
            disabled={page === totalPages - 1}
            onClick={() => setPage(page + 1)}
            className="px-3 py-1 border rounded disabled:opacity-50"
            title={t({
              id: "admin_blogs.pagination.next",
              message: "Next page",
            })}
          >
            &gt;
          </button>
        </div>
      )}

      {/* Modal Ajouter */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-2xl p-6 relative">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center rounded-full bg-teal-600 text-white text-xl hover:bg-teal-700"
              title={t({ id: "admin_blogs.close_modal", message: "Close" })}
            >
              ×
            </button>
            <h2 className="text-xl font-bold mb-4">
              <Trans id="admin_blogs.create_blog_modal_title">
                Create Blog
              </Trans>
            </h2>
            <label className="block mb-2">
              <Trans id="admin_blogs.blog_post_label">Blog post</Trans>
            </label>
            <select
              className="w-full mb-4 border p-2 rounded"
              title="blogSelect"
              value={selectedBlogId}
              onChange={(e) =>
                setSelectedBlogId(
                  e.target.value === "" ? "" : Number(e.target.value)
                )
              }
            >
              <option value="">
                <Trans id="admin_blogs.select_option">-- Sélectionner --</Trans>
              </option>
              {allBlogs.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title}
                </option>
              ))}
            </select>
            <label className="block mb-2">
              <Trans id="admin_blogs.destination_link_label">
                Destination Link
              </Trans>
            </label>
            <input
              type="text"
              className="w-full mb-4 border p-2 rounded"
              value={destinationLink}
              onChange={(e) => setDestinationLink(e.target.value)}
              placeholder="https://..."
            />
            <label className="block mb-2">
              <Trans id="admin_blogs.display_order_label">Display Order</Trans>
            </label>
            <input
              type="number"
              title="blogOrderInput"
              className="w-full mb-4 border p-2 rounded"
              value={selectedBlogOrder}
              onChange={(e) => setSelectedBlogOrder(Number(e.target.value))}
            />
            <div className="flex justify-end space-x-2">
              <button
                className="px-4 py-2 bg-gray-300 rounded"
                onClick={() => setShowAddModal(false)}
              >
                <Trans id="admin_blogs.cancel">Cancel</Trans>
              </button>
              <button
                className="px-4 py-2 bg-[#238D94] text-white rounded"
                onClick={handleAdd}
              >
                <Trans id="admin_blogs.create_blog">Create Blog</Trans>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Éditer */}
      {editBlogId !== null && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-2xl p-6 relative">
            <button
              onClick={() => setEditBlogId(null)}
              className="absolute top-3 right-3 w-10 h-10 border border-teal-600 bg-teal-600 text-white rounded-full flex items-center justify-center text-xl hover:bg-teal-50 transition hover:text-teal-600 "
              title={t({ id: "admin_blogs.close_modal", message: "Close" })}
            >
              ×
            </button>

            <h2 className="text-xl font-bold mb-4">
              <Trans id="admin_blogs.edit_blog_modal_title">Edit Blog</Trans>
            </h2>

            <label className="block mb-2">
              <Trans id="admin_blogs.destination_link_label">
                Destination Link
              </Trans>
            </label>
            <input
              type="text"
              className="w-full mb-4 border p-2 rounded"
              value={editDestinationLink}
              onChange={(e) => setEditDestinationLink(e.target.value)}
              placeholder="https://..."
            />

            <label className="block mb-2">
              <Trans id="admin_blogs.display_order_label">Display Order</Trans>
            </label>
            <input
              type="number"
              title="editBlogOrderInput"
              className="w-full mb-4 border p-2 rounded"
              value={editBlogOrder}
              onChange={(e) => setEditBlogOrder(Number(e.target.value))}
            />

            <div className="flex justify-end space-x-2">
              <button
                className="px-4 py-2 bg-gray-300 rounded"
                onClick={() => setEditBlogId(null)}
              >
                <Trans id="admin_blogs.cancel_edit">Annuler</Trans>
              </button>
              <button
                className="px-4 py-2 bg-[#238D94] text-white rounded"
                onClick={saveEdit}
              >
                <Trans id="admin_blogs.save">Sauvegarder</Trans>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal suppression */}
      {showDeleteModal && currentDeleteBlog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white border-2 border-teal-600 rounded-lg shadow-lg w-full max-w-md p-6 text-center relative">
            <button
              onClick={() => setShowDeleteModal(false)}
              className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center rounded-full bg-teal-600 text-white text-xl hover:bg-teal-700 transition"
              title={t({ id: "admin_blogs.close_modal", message: "Close" })}
            >
              ×
            </button>
            <h3 className="text-lg font-bold mb-4">
              <Trans id="admin_blogs.delete_confirmation_title">
                Supprimer ce blog ?
              </Trans>
            </h3>
            <p className="text-gray-600 mb-6">{currentDeleteBlog.title}</p>
            <div className="flex justify-center gap-4">
              <button
                onClick={handleDelete}
                className="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 transition"
              >
                <Trans id="admin_blogs.yes">Oui</Trans>
              </button>
              <button
                onClick={() => setShowDeleteModal(false)}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition"
              >
                <Trans id="admin_blogs.cancel_delete">Annuler</Trans>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
