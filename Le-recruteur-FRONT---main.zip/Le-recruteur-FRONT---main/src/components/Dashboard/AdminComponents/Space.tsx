import { useEffect, useState } from "react";
import { Pencil, Trash2,Megaphone,Plus } from "lucide-react";
import { adSpaceService } from "@/lib/network/adSpaceService";
import { AdSpace } from "@/lib/types/adSpace";
import { settings } from "@/lib/settings/main";
import { Trans, t } from '@lingui/macro';

interface AdSpaceForm extends Partial<AdSpace> {
  imageFile?: File | null;
}

export default function AdminAds() {
  const [ads, setAds] = useState<AdSpace[]>([]);
  const [currentAd, setCurrentAd] = useState<AdSpaceForm | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [mode, setMode] = useState<"create" | "edit">("create");
  const [page, setPage] = useState(0);
  const [pageSize] = useState(3);

  // Récupérer les ads
  const fetchAds = async () => {
    try {
      const data = await adSpaceService.getAdSpaces();
      setAds(data);
    } catch (err) {
      console.error("Erreur fetch ads:", err);
    }
  };

  useEffect(() => {
    fetchAds();
  }, []);

  // Sauvegarde (create ou edit)
  const handleSave = async () => {
    if (!currentAd) return;
    try {
      const formData = new FormData();
      if (currentAd.title) formData.append("title", currentAd.title);
      if (currentAd.description) formData.append("description", currentAd.description);
      if (currentAd.link) formData.append("link", currentAd.link);
      if (currentAd.imageFile) formData.append("imageFile", currentAd.imageFile);

      let savedAd: AdSpace;
      if (mode === "create") {
        savedAd = await adSpaceService.createAdSpace(formData);
        setAds([savedAd, ...ads]);
      } else if (mode === "edit" && currentAd.id) {
        savedAd = await adSpaceService.updateAdSpace(currentAd.id, formData);
        setAds(ads.map(ad => ad.id === savedAd.id ? savedAd : ad));
      }

      setShowModal(false);
      setCurrentAd(null);
    } catch (err) {
      console.error("Erreur lors de la sauvegarde :", err);
    }
  };

  // Suppression définitive via backend
  const handleDelete = async () => {
    if (!currentAd?.id) return;
    try {
      await adSpaceService.deleteAdSpace(currentAd.id);
      setAds(ads.filter(ad => ad.id !== currentAd.id));
      setShowDeleteModal(false);
      setCurrentAd(null);
    } catch (err) {
      console.error("Erreur suppression Ad:", err);
    }
  };

  const handleCreateClick = () => {
    setMode("create");
    setCurrentAd({ title: "", description: "", link: "", imageFile: null });
    setShowModal(true);
  };

  // Pagination
  const paginatedAds = ads.slice(page * pageSize, (page + 1) * pageSize);
  const totalPages = Math.ceil(ads.length / pageSize);

  return (
    <section className="px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-[#0e2426]">
              <Trans id="admin.ads.title">Ad Space</Trans>
            </h2>
            <p className="text-gray-600 mt-2">
              <Trans id="admin.ads.subtitle">Manage homepage promotional banners..</Trans>
            </p>
          </div>
          <button
            onClick={handleCreateClick}
            className="mt-4 md:mt-0 border border-teal-600 bg-white text-[#238D94] px-5 py-2 rounded-lg shadow hover:bg-[#1d757c] hover:text-white transition"
          >
            <Trans id="admin.ads.create_button">Create new Ad</Trans>
          </button>
        </div>


        {ads.length === 0 ? (
          
          // --- Message si aucune publicité n'est trouvée ---
          <div className="text-center bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-12 mt-8">
            <div className="mx-auto w-16 h-16 flex items-center justify-center bg-gray-200 rounded-full text-gray-500">
              <Megaphone size={32} />
            </div>
            <h3 className="mt-4 text-xl font-semibold text-gray-800">
              <Trans>No Ads Found</Trans>
            </h3>
            <p className="mt-2 text-sm text-gray-500">
              <Trans>Get started by creating a new promotional ad.</Trans>
            </p>
            <button
              onClick={handleCreateClick} // <-- On réutilise la même fonction
              className="mt-6 inline-flex items-center gap-2 bg-[#238D94] text-white px-5 py-2.5 rounded-lg shadow hover:bg-[#1d757c] transition font-semibold"
            >
              <Plus size={18} />
              <Trans>Create New Ad</Trans>
            </button>
          </div>

        ) : (

        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {paginatedAds.map(ad => (
            <div
              key={ad.id}
              className="relative group cursor-pointer"
            >
              {/* Carte avec image */}
              <div 
                onClick={() => ad.link && window.open(ad.link, "_blank")}
                className="relative border-2 border-[#238D94] rounded-lg overflow-visible h-64 lg:h-72 transition-transform duration-300 group-hover:scale-105"
              >
                <img
                  src={ad.imageUrl ? `${settings.IMG_ADDRESS}${ad.imageUrl}` : ""}
                  alt={ad.title}
                  className="w-full h-full object-cover rounded-lg"
                />
                
                {/* Edit/Delete */}
                <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition pointer-events-auto">
                  <button
                    onClick={e => { e.stopPropagation(); setMode("edit"); setCurrentAd({ ...ad, imageFile: null }); setShowModal(true); }}
                    className="p-2 bg-white rounded-full shadow hover:bg-gray-100"
                    title={t({ id: "admin.ads.edit_tooltip", message: "Edit Ad" })}
                  >
                    <Pencil className="text-[#238D94]" size={18} />
                  </button>
                  <button
                    onClick={e => { e.stopPropagation(); setCurrentAd(ad); setShowDeleteModal(true); }}
                    className="p-2 bg-white rounded-full shadow hover:bg-gray-100"
                    title={t({ id: "admin.ads.delete_tooltip", message: "Delete Ad" })}
                  >
                    <Trash2 className="text-gray-400" size={18} />
                  </button>
                </div>
              </div>
              
              {/* Titre qui dépasse en bas */}
              <div className="absolute left-1/2 -translate-x-1/2 bottom-[-16px] bg-white bg-opacity-90 text-gray-800 px-4 py-2 text-xl font-medium text-center shadow-lg rounded-lg inline-block max-w-[90%] break-words">
                {ad.title}
              </div>
            </div>
          ))}
        </div>)}

        {/* Pagination */}
        { ads.length != 0 && <div className="flex justify-center mt-8 gap-2">
          <button 
            onClick={() => setPage(p => Math.max(p - 1, 0))} 
            className="px-3 py-1 rounded border border-gray-300 hover:bg-gray-100"
            title={t({ id: "admin.ads.pagination.previous", message: "Previous page" })}
          >
            &lt;
          </button>
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i}
              onClick={() => setPage(i)}
              className={`px-3 py-1 rounded border ${i === page ? "border-[#238D94] bg-[#238D94] text-white" : "border-gray-300 text-gray-600 hover:bg-gray-100"}`}
            >
              {i + 1}
            </button>
          ))}
          <button 
            onClick={() => setPage(p => Math.min(p + 1, totalPages - 1))} 
            className="px-3 py-1 rounded border border-gray-300 hover:bg-gray-100"
            title={t({ id: "admin.ads.pagination.next", message: "Next page" })}
          >
            &gt;
          </button>
        </div> }
      </div>

      {/* Modal Création / Edition */}
      {showModal && currentAd && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-2xl p-6 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-3 right-3 w-8 h-8 flex items-center border border-teal-600 justify-center rounded-full bg-teal-600 text-white text-xl hover:text-teal-700 hover:bg-teal-50 transition"
              title={t({ id: "admin.ads.modal.close", message: "Close" })}
            >
              ×
            </button>
            <h3 className="text-xl font-bold text-[#238D94] mb-4">
              {mode === "create" ? (
                <Trans id="admin.ads.modal.create_title">Create an Ad</Trans>
              ) : (
                <Trans id="admin.ads.modal.edit_title">Edit an Ad</Trans>
              )}
            </h3>

            <label className="block mb-3">
              <span className="text-gray-700 font-medium">
                <Trans id="admin.ads.form.title_label">Title</Trans>
              </span>
              <input 
                type="text" 
                value={currentAd.title || ""} 
                onChange={e => setCurrentAd({ ...currentAd, title: e.target.value })} 
                className="w-full mt-1 p-2 border rounded"
                placeholder={t({ id: "admin.ads.form.title_placeholder", message: "Enter ad title" })}
              />
            </label>

            <label className="block mb-3">
              <span className="text-gray-700 font-medium">
                <Trans id="admin.ads.form.description_label">Description</Trans>
              </span>
              <input 
                type="text" 
                value={currentAd.description || ""} 
                onChange={e => setCurrentAd({ ...currentAd, description: e.target.value })} 
                className="w-full mt-1 p-2 border rounded"
                placeholder={t({ id: "admin.ads.form.description_placeholder", message: "Enter ad description" })}
              />
            </label>

            <label className="block mb-3">
              <span className="text-gray-700 font-medium">
                <Trans id="admin.ads.form.link_label">Link</Trans>
              </span>
              <input 
                type="url" 
                value={currentAd.link || ""} 
                onChange={e => setCurrentAd({ ...currentAd, link: e.target.value })} 
                className="w-full mt-1 p-2 border rounded"
                placeholder={t({ id: "admin.ads.form.link_placeholder", message: "Enter ad link (https://...)" })}
              />
            </label>

            <label className="block mb-4">
              <span className="text-gray-700 font-medium">
                <Trans id="admin.ads.form.image_label">Image</Trans>
              </span>
              <input 
                type="file" 
                onChange={e => setCurrentAd({ ...currentAd, imageFile: e.target.files?.[0] })} 
                className="w-full mt-2"
                accept="image/*"
              />
            </label>

            <button 
              onClick={handleSave} 
              className="w-full bg-[#238D94] text-white py-2 rounded-lg shadow hover:bg-[#1d757c] transition"
            >
              {mode === "create" ? (
                <Trans id="admin.ads.form.create_button">Create</Trans>
              ) : (
                <Trans id="admin.ads.form.save_button">Save</Trans>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Modal suppression */}
      {showDeleteModal && currentAd && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md p-6 text-center relative">
            {/* Bouton X */}
            <button
              onClick={() => setShowDeleteModal(false)}
              className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center rounded-full bg-teal-600 text-white text-xl hover:bg-teal-700 transition"
              title={t({ id: "admin.ads.delete_modal.close", message: "Close" })}
            >
              ×
            </button>

            <h3 className="text-lg font-bold mb-4">
              <Trans id="admin.ads.delete_modal.title">Delete this Ad?</Trans>
            </h3>
            <p className="text-gray-600 mb-6">{currentAd.title}</p>
            <div className="flex justify-center gap-4">
              <button
                onClick={handleDelete}
                className="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 transition"
              >
                <Trans id="admin.ads.delete_modal.confirm_button">Yes</Trans>
              </button>
              <button
                onClick={() => setShowDeleteModal(false)}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition"
              >
                <Trans id="admin.ads.delete_modal.cancel_button">Cancel</Trans>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
