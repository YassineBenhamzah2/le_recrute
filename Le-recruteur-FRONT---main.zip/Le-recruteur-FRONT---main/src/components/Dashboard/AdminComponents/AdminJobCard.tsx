import React from "react";
import { AdminJobResponse } from "@/lib/types/jobOffer";
import { Company } from "@/lib/types/company";
import { Trans, t } from "@lingui/macro";
import { i18n } from "@lingui/core";

interface AdminJobCardProps {
  job: AdminJobResponse;
  companies?: Company[];
  companyLogos?: Record<number, string>;
  onViewDetails?: (job: AdminJobResponse) => void;
}

export const AdminJobCard: React.FC<AdminJobCardProps> = ({
  job,
  companies,
  onViewDetails,
}) => {
  const formatSalary = () => {
    const currency = job.currency || "$";
    const min = job.minSalary ?? 0;
    const max = job.maxSalary ?? 0;
    return `${currency}${min.toLocaleString()} - ${currency}${max.toLocaleString()}`;
  };

  const formatTimeAgo = (dateString: string | null | undefined) => {
    if (!dateString)
      return t({ id: "admin.job_card.date.unknown", message: "Unknown date" });
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

    if (diffInDays === 0)
      return i18n._({ id: "admin.job_card.date.today", message: "Today" });
    if (diffInDays === 1)
      return i18n._({
        id: "admin.job_card.date.yesterday",
        message: "Yesterday",
      });
    if (diffInDays < 7)
      return i18n._({
        id: "admin.job_card.date.days_ago",
        message: "{count} days ago",
        values: { count: diffInDays },
      });
    if (diffInDays < 30)
      return i18n._({
        id: "admin.job_card.date.weeks_ago",
        message: "{count} weeks ago",
        values: { count: Math.floor(diffInDays / 7) },
      });
    return i18n._({
      id: "admin.job_card.date.months_ago",
      message: "{count} months ago",
      values: { count: Math.floor(diffInDays / 30) },
    });
  };

  const getCompanyName = (id: number | null | undefined) =>
    companies?.find((c) => c.id === id)?.name;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ACTIVE":
        return "bg-green-100 text-green-800 border-green-200";
      case "INACTIVE":
        return "bg-red-100 text-red-800 border-red-200";
      case "PAUSE":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "PENDING":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "EXPIRED":
        return "bg-gray-100 text-gray-800 border-gray-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getWorkModeIcon = (workMode: string) => {
    switch (workMode) {
      case "REMOTE":
        return (
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
            ></path>
          </svg>
        );
      case "HYBRID":
        return (
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
            ></path>
          </svg>
        );
      default:
        return (
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
            ></path>
          </svg>
        );
    }
  };

  const getWorkModeText = (workMode: string) => {
    switch (workMode) {
      case "REMOTE":
        return t({ id: "admin.job_card.work_mode.remote", message: "Remote" });
      case "HYBRID":
        return t({ id: "admin.job_card.work_mode.hybrid", message: "Hybrid" });
      default:
        return t({ id: "admin.job_card.work_mode.onsite", message: "On-site" });
    }
  };

  return (
    <div className="group bg-white border border-gray-200 rounded-xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 hover:border-teal-200 relative overflow-hidden">
      {/* Subtle gradient effect on hover */}
      <div className="absolute inset-0 bg-gradient-to-r from-teal-50/0 to-cyan-50/0 group-hover:from-teal-50/30 group-hover:to-cyan-50/20 transition-all duration-300 rounded-xl"></div>

      <div className="relative">
        {/* Global flex left / right */}
        <div className="flex justify-between items-start gap-6">
          {/* Left column - Without logo */}
          <div className="flex flex-1">
            {/* Main info */}
            <div className="flex flex-col flex-1">
              {/* Title + badges */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="text-2xl font-bold text-gray-900 group-hover:text-teal-700 transition-colors duration-300">
                      {job.title}
                    </h3>
                    {/* Work mode badge with icon */}
                    <div className="flex items-center gap-1.5 bg-teal-100 text-teal-700 px-3 py-1.5 rounded-full border border-teal-200">
                      {getWorkModeIcon(job.workMode || "ONSITE")}
                      <span className="text-sm font-medium">
                        {getWorkModeText(job.workMode || "ONSITE")}
                      </span>
                    </div>
                  </div>

                  {/* Company name with icon */}
                  <div className="flex items-center gap-2 mb-4">
                    <svg
                      className="w-5 h-5 text-teal-600"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                      ></path>
                    </svg>
                    <span className="text-lg font-semibold text-gray-800">
                      {getCompanyName(job.companyId)}
                    </span>
                  </div>
                </div>

                {/* Status badge */}
                <span
                  className={`px-4 py-2 rounded-full text-sm font-medium border ${getStatusColor(
                    job.status || "PENDING"
                  )}`}
                >
                  {job.status}
                </span>
              </div>

              {/* Information line with modern icons */}
              <div className="flex items-center gap-6 text-sm text-gray-600">
                {/* Location */}
                <div className="flex items-center gap-2 bg-gray-50 px-3 py-2 rounded-lg">
                  <svg
                    className="w-4 h-4 text-teal-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                    ></path>
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                    ></path>
                  </svg>
                  <span className="font-medium">{job.location}</span>
                </div>

                {/* Contract */}
                <div className="flex items-center gap-2 bg-gray-50 px-3 py-2 rounded-lg">
                  <svg
                    className="w-4 h-4 text-teal-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414A1 1 0 0119 9v10a2 2 0 01-2 2z"
                    ></path>
                  </svg>
                  <span className="font-medium">{job.contractType}</span>
                </div>

                {/* Date with improved style */}
                <div className="flex items-center gap-2 bg-gray-50 px-3 py-2 rounded-lg">
                  <svg
                    className="w-4 h-4 text-teal-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                    ></path>
                  </svg>
                  <span className="font-medium">
                    {formatTimeAgo(job.publicationDate)}
                  </span>
                </div>

                {/* Applications */}
                {job.numberOfApplications !== undefined && (
                  <div className="flex items-center gap-2 bg-blue-50 px-3 py-2 rounded-lg border border-blue-200">
                    <svg
                      className="w-4 h-4 text-blue-600"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                      ></path>
                    </svg>
                    <span className="font-semibold text-blue-700">
                      {job.numberOfApplications}{" "}
                      <Trans id="admin.job_card.applicants">applicants</Trans>
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right column (salary + actions) */}
          <div className="flex flex-col items-end justify-between min-w-[240px] pl-4">
            {/* Salary with improved design */}
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 px-4 py-3 rounded-xl border border-green-200 mb-4">
              <div className="flex items-center gap-2 mb-1">
                <svg
                  className="w-4 h-4 text-green-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"
                  ></path>
                </svg>
                <span className="text-xs font-medium text-green-600 uppercase tracking-wide">
                  <Trans id="admin.job_card.salary.label">Salary</Trans>
                </span>
              </div>
              <span className="text-lg font-bold text-green-800 block">
                {formatSalary()}
              </span>
              <span className="text-xs text-green-600">{job.salaryType}</span>
            </div>

            {/* Action buttons with animations */}
            <div className="flex gap-3">
              <button
                onClick={() => onViewDetails?.(job)}
                className="group/btn bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-lg flex items-center gap-2"
              >
                <svg
                  className="w-4 h-4 transition-transform group-hover/btn:scale-110"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                  ></path>
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                  ></path>
                </svg>
                <Trans id="admin.job_card.button.view_details">
                  View details
                </Trans>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
