import React, { useState, useEffect } from 'react';

import { X, Image as ImageIcon, UploadCloud } from 'lucide-react';

// Import Shadcn UI Components
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { settings } from '@/lib/settings/main';
import { Trans } from '@lingui/macro';

interface CandidateService {
  id?: number;
  title: string;
  description: string;
  price: number;
  imageUrl?: string;
  status?: 'ACTIVE' | 'INACTIVE';
}

interface ServiceFormProps {
  type: 'candidate';
  service?: CandidateService | null;
  onSave: (serviceData: Partial<CandidateService>, imageFile: File | null) => void;
  onCancel: () => void;
}

export default function ServiceForm({ service, onSave, onCancel }: ServiceFormProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: 0,
    status: 'ACTIVE' as 'ACTIVE' | 'INACTIVE',
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  useEffect(() => {
    if (service) {
      setFormData({
        title: service.title,
        description: service.description,
        price: service.price,
        status: service.status || 'ACTIVE',
      });
      if (service.imageUrl) {
        setPreviewUrl(`${settings.IMG_ADDRESS}${service.imageUrl}`);
      }
    }
  }, [service]);

  useEffect(() => {
    if (imageFile) {
      const objectUrl = URL.createObjectURL(imageFile);
      setPreviewUrl(objectUrl);
      return () => URL.revokeObjectURL(objectUrl);
    }
  }, [imageFile]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0]);
    }
  };
  
  // The actual save function, called only after confirmation
  const handleSubmit = () => {
    onSave(formData, imageFile);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold">
            {service ? (
              <Trans>Edit Candidate Service</Trans>
            ) : (
              <Trans>Add New Candidate Service</Trans>
            )}
          </h2>
          <button onClick={onCancel} className="text-gray-400 hover:text-gray-500 p-1 rounded-full hover:bg-gray-100">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Image Uploader */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Service Image</Trans>
            </label>
            <div className="flex items-center space-x-6">
              <div className="flex-shrink-0">
                {previewUrl ? (
                  <img src={previewUrl} alt="Preview" className="h-24 w-24 rounded-lg object-cover border" />
                ) : (
                  <div className="h-24 w-24 rounded-lg border bg-gray-50 flex items-center justify-center">
                    <ImageIcon className="h-10 w-10 text-gray-400" />
                  </div>
                )}
              </div>
              <div className="relative flex-1 w-full h-24 border-2 border-dashed rounded-lg flex flex-col items-center justify-center text-center">
                <input type="file" accept="image/*" onChange={handleFileChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                <UploadCloud className="mx-auto h-8 w-8 text-gray-400" />
                <p className="mt-1 text-sm text-gray-500">
                  <span className="font-semibold text-teal-600">
                    <Trans>Click to upload</Trans>
                  </span>{' '}
                  <Trans>or drag and drop</Trans>
                </p>
              </div>
            </div>
          </div>
          
          {/* Form Inputs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                <Trans>Title *</Trans>
              </label>
              <input id="title" type="text" required value={formData.title} onChange={(e) => setFormData(p => ({ ...p, title: e.target.value }))} className="w-full px-3 py-2 border rounded-lg" />
            </div>
            <div>
              <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-2">
                <Trans>Price ($) *</Trans>
              </label>
              <input id="price" type="number" required min="0" value={formData.price} onChange={(e) => setFormData(p => ({ ...p, price: parseFloat(e.target.value) || 0 }))} className="w-full px-3 py-2 border rounded-lg" />
            </div>
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
              <Trans>Description *</Trans>
            </label>
            <textarea id="description" required rows={4} value={formData.description} onChange={(e) => setFormData(p => ({ ...p, description: e.target.value }))} className="w-full px-3 py-2 border rounded-lg" />
          </div>

          {/* Form Actions with Confirmation Dialog */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <Button variant="outline" onClick={onCancel}>
              <Trans>Cancel</Trans>
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button className="bg-teal-600 hover:bg-teal-700">
                  {service ? <Trans>Update Service</Trans> : <Trans>Create Service</Trans>}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>
                    <Trans>Confirm Action</Trans>
                  </AlertDialogTitle>
                  <AlertDialogDescription>
                    <Trans>
                      Are you sure you want to {service ? 'update this' : 'create this new'} service with the provided details?
                    </Trans>
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>
                    <Trans>Cancel</Trans>
                  </AlertDialogCancel>
                  <AlertDialogAction onClick={handleSubmit} className="bg-teal-600 hover:bg-teal-700">
                    <Trans>Confirm & Save</Trans>
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </div>
  );
}