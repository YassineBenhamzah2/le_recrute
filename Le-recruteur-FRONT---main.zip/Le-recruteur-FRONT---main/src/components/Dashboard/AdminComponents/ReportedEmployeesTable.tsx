import { Eye, Check, X, MoreHorizontal, Mail, Phone, AlertTriangle, Calendar, BarChart3, Target, Building } from 'lucide-react';
import { Trans } from '@lingui/macro';

interface ReportedEmployee {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  reportReason: string;
  reportedOn: string;
  companyName?: string;
}

interface ReportedEmployeesTableProps {
  employees: ReportedEmployee[];
  onView?: (id: number) => void;
  onMoreActions?: (id: number) => void;
}

export function ReportedEmployeesTable({ 
  employees, 
  onView, 
  onMoreActions
}: ReportedEmployeesTableProps) {

  if (!employees || employees.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">
          <Trans id="admin.employees_table.no_data_message">No reported employees found</Trans>
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead className="bg-gray-50 border-b border-gray-200">
          <tr>
            <th className="text-left py-4 px-6 font-medium text-gray-700 text-sm">
              <Trans id="admin.employees_table.header_first_name">First Name</Trans>
            </th>
            <th className="text-left py-4 px-6 font-medium text-gray-700 text-sm">
              <Trans id="admin.employees_table.header_last_name">Last Name</Trans>
            </th>
            <th className="text-left py-4 px-6 font-medium text-gray-700 text-sm">
              <div className="flex items-center gap-2">
                <Mail size={16} className="text-gray-500" />
                <Trans id="admin.employees_table.header_email">Email</Trans>
              </div>
            </th>
            <th className="text-left py-4 px-6 font-medium text-gray-700 text-sm">
              <div className="flex items-center gap-2">
                <Building size={16} className="text-gray-500" />
                <Trans id="admin.employees_table.header_company">Company</Trans>
              </div>
            </th>
            <th className="text-left py-4 px-6 font-medium text-gray-700 text-sm">
              <div className="flex items-center gap-2">
                <Phone size={16} className="text-gray-500" />
                <Trans id="admin.employees_table.header_phone">Phone</Trans>
              </div>
            </th>
            <th className="text-left py-4 px-6 font-medium text-gray-700 text-sm">
              <div className="flex items-center gap-2">
                <AlertTriangle size={16} className="text-gray-500" />
                <Trans id="admin.employees_table.header_report_reason">Report Reason</Trans>
              </div>
            </th>
            <th className="text-left py-4 px-6 font-medium text-gray-700 text-sm">
              <div className="flex items-center gap-2">
                <Calendar size={16} className="text-gray-500" />
                <Trans id="admin.employees_table.header_reported_on">Reported On</Trans>
              </div>
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {employees.map((employee) => (
            <tr key={employee.id} className="hover:bg-gray-50 transition-colors">
              <td className="py-4 px-6">
                <div className="font-medium text-gray-900">{employee.firstName}</div>
              </td>
              <td className="py-4 px-6">
                <div className="font-medium text-gray-900">{employee.lastName}</div>
              </td>
              <td className="py-4 px-6 text-gray-600 text-sm">{employee.email}</td>
              <td className='py-4 px-6 text-gray-600 text-sm'>{employee.companyName || 'N/A'}</td>
              <td className="py-4 px-6 text-gray-600 text-sm">{employee.phone}</td>
              <td className="py-4 px-6 text-gray-600 text-sm">{employee.reportReason}</td>
              <td className="py-4 px-6 text-gray-600 text-sm">{employee.reportedOn}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
