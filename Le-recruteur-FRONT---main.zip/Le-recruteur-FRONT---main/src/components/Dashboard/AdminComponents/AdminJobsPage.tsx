import { useEffect, useState, useCallback } from "react";
import { adminService, PagedResponse } from "@/lib/network/jobOfferService";
import { departmentService } from "@/lib/network/department";
import { companyService } from "@/lib/network/company";
import { AdminJobResponse } from "@/lib/types/jobOffer";
import { Department } from "@/lib/types/department";
import { Company } from "@/lib/types/company";
import { AdminJobCard } from "@/components/Dashboard/AdminComponents/AdminJobCard";
import JobSearchFilter from "@/components/ui/JobSearchFilter";
import { Trans, t } from "@lingui/macro";

export default function AdminJobsPage() {
  const [jobs, setJobs] = useState<AdminJobResponse[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [companyLogos, setCompanyLogos] = useState<Record<number, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [page, setPage] = useState(0);
  const [size] = useState(5);
  const [totalPages, setTotalPages] = useState(0);

  const [selectedJob, setSelectedJob] = useState<AdminJobResponse | null>(null);

  // For search and filters
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState<{
    status?: AdminJobResponse["status"];
    contractType?: AdminJobResponse["contractType"];
    workMode?: AdminJobResponse["workMode"];
  }>({});

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    try {
      const jobsRes = await adminService.getAllJobs(page, size);
      if (jobsRes.success) {
        const paged: PagedResponse<AdminJobResponse> = jobsRes.data;
        setJobs(paged.content);
        setTotalPages(paged.totalPages);
      }

      const deptRes = await departmentService.getDepartments();
      if (deptRes.success) setDepartments(deptRes.data);

      const compRes = await companyService.getCompanies();
      if (compRes.success) {
        setCompanies(compRes.data);
        const logos: Record<number, string> = {};
        compRes.data.forEach((company) => {
          if (company.id && company.logo) logos[company.id] = company.logo;
        });
        setCompanyLogos(logos);
      }
    } catch (err) {
      setError(
        (err as Error).message ||
          t({
            id: "admin.jobs.error.failed_to_load",
            message: "Failed to load jobs",
          })
      );
    } finally {
      setLoading(false);
    }
  }, [page, size]);

  useEffect(() => {
    fetchJobs();
  }, [page, fetchJobs]);

  const handleSearch = (query: string) => setSearchQuery(query);

  const handleFilterChange = (newFilters: typeof filters) =>
    setFilters(newFilters);

  const getDepartmentName = (id: number | null) =>
    departments.find((d) => d.id === id)?.name ||
    t({ id: "admin.jobs.department.unknown", message: "Unknown" });

  const getCompanyName = (id: number | null) =>
    companies.find((c) => c.id === id)?.name ||
    t({ id: "admin.jobs.company.unknown", message: "Unknown" });

  // Filter jobs based on search and filters
  const filteredJobs = jobs.filter((job) => {
    const matchesSearch =
      searchQuery === "" ||
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.location?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (job.description &&
        job.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (job.departmentId &&
        getDepartmentName(job.departmentId)
          .toLowerCase()
          .includes(searchQuery.toLowerCase())) ||
      (job.companyId &&
        getCompanyName(job.companyId)
          .toLowerCase()
          .includes(searchQuery.toLowerCase()));

    const matchesStatus = !filters.status || job.status === filters.status;
    const matchesContract =
      !filters.contractType || job.contractType === filters.contractType;
    const matchesWorkMode =
      !filters.workMode || job.workMode === filters.workMode;

    return matchesSearch && matchesStatus && matchesContract && matchesWorkMode;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-teal-500 border-t-transparent mb-4"></div>
          <p className="text-gray-600 text-lg">
            <Trans id="admin.jobs.loading.text">Loading job offers...</Trans>
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg
              className="w-8 h-8 text-red-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              ></path>
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            <Trans id="admin.jobs.error.loading_error">Loading Error</Trans>
          </h3>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header Section with gradient and statistics */}
      <div className="bg-gradient-to-r from-teal-600 via-teal-700 to-cyan-600 text-white">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-white to-teal-100 bg-clip-text text-transparent">
                <Trans id="admin.jobs.header.title">
                  Job Offers Management
                </Trans>
              </h1>
              <p className="text-teal-100 text-lg max-w-2xl">
                <Trans id="admin.jobs.header.description">
                  Manage and supervise all job offers from this centralized
                  interface. Search, filter and efficiently administer your
                  portfolio of opportunities.
                </Trans>
              </p>
            </div>

            {/* Quick statistics */}
            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 min-w-[120px]">
                <div className="text-3xl font-bold">{jobs.length}</div>
                <div className="text-teal-100 text-sm">
                  <Trans id="admin.jobs.stats.total_jobs">Total Jobs</Trans>
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 min-w-[120px]">
                <div className="text-3xl font-bold">{filteredJobs.length}</div>
                <div className="text-teal-100 text-sm">
                  <Trans id="admin.jobs.stats.filtered">Filtered</Trans>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Search bar and filters with improved design */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8 border border-gray-100">
          <JobSearchFilter
            onSearch={handleSearch}
            onFilterChange={handleFilterChange}
            currentFilters={filters}
          />
        </div>

        {/* Job list with animation */}
        <div className="space-y-6">
          {filteredJobs.length === 0 ? (
            <div className="bg-white rounded-xl shadow-lg p-12 text-center border border-gray-100">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg
                  className="w-12 h-12 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.5"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  ></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                <Trans id="admin.jobs.no_results.title">
                  No job offers found
                </Trans>
              </h3>
              <p className="text-gray-500 mb-6">
                <Trans id="admin.jobs.no_results.description">
                  Try modifying your search criteria or your filters
                </Trans>
              </p>
              <button
                onClick={() => {
                  setSearchQuery("");
                  setFilters({});
                  handleSearch("");
                  handleFilterChange({});
                }}
                className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
              >
                <Trans id="admin.jobs.no_results.reset_button">
                  Reset filters
                </Trans>
              </button>
            </div>
          ) : (
            filteredJobs.map((job, index) => (
              <div
                key={job.id}
                className="transform hover:scale-[1.01] transition-all duration-300"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <AdminJobCard
                  job={job}
                  companies={companies}
                  companyLogos={companyLogos}
                  onViewDetails={setSelectedJob}
                />
              </div>
            ))
          )}
        </div>

        {/* Improved pagination */}
        {totalPages > 1 && (
          <div className="bg-white rounded-xl shadow-lg p-6 mt-8 border border-gray-100">
            <div className="flex justify-between items-center">
              <div className="text-sm text-gray-600">
                <Trans id="admin.jobs.pagination.info">
                  Page {page + 1} of {totalPages} ({filteredJobs.length}{" "}
                  results)
                </Trans>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setPage((p) => Math.max(p - 1, 0))}
                  disabled={page === 0}
                  className={`px-4 py-2 rounded-lg border transition-colors ${
                    page === 0
                      ? "border-gray-200 text-gray-400 cursor-not-allowed bg-gray-50"
                      : "border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400"
                  }`}
                  title={t({
                    id: "admin.jobs.pagination.previous",
                    message: "Previous page",
                  })}
                >
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M15 19l-7-7 7-7"
                    ></path>
                  </svg>
                </button>

                {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
                  let pageNum = i;
                  if (totalPages > 7) {
                    if (page > 3) pageNum = page - 3 + i;
                    if (page > totalPages - 4) pageNum = totalPages - 7 + i;
                  }
                  return (
                    <button
                      key={pageNum}
                      onClick={() => setPage(pageNum)}
                      className={`px-4 py-2 rounded-lg border transition-all ${
                        pageNum === page
                          ? "border-teal-500 bg-teal-600 text-white shadow-md"
                          : "border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400"
                      }`}
                    >
                      {pageNum + 1}
                    </button>
                  );
                })}

                <button
                  onClick={() =>
                    setPage((p) => Math.min(p + 1, totalPages - 1))
                  }
                  disabled={page >= totalPages - 1}
                  className={`px-4 py-2 rounded-lg border transition-colors ${
                    page >= totalPages - 1
                      ? "border-gray-200 text-gray-400 cursor-not-allowed bg-gray-50"
                      : "border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400"
                  }`}
                  title={t({
                    id: "admin.jobs.pagination.next",
                    message: "Next page",
                  })}
                >
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M9 5l7 7-7 7"
                    ></path>
                  </svg>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Job detail modal - Improved design */}
      {selectedJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
            {/* Modal header */}
            <div className="bg-gradient-to-r from-teal-600 to-cyan-600 text-white p-6 relative">
              <button
                onClick={() => setSelectedJob(null)}
                className="absolute top-4 right-4 w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white hover:text-gray-100 transition-colors"
                title={t({ id: "admin.jobs.modal.close", message: "Close" })}
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M6 18L18 6M6 6l12 12"
                  ></path>
                </svg>
              </button>

              <div className="flex items-start gap-4 justify-center">
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-2">
                    {selectedJob.title}
                  </h3>
                  <p className="text-teal-100">
                    {getCompanyName(selectedJob.companyId)}
                  </p>
                </div>
              </div>
            </div>

            {/* Modal content */}
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                {/* Main information */}
                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-gray-900 border-b border-gray-200 pb-2">
                    <Trans id="admin.jobs.modal.main_info.title">
                      Main Information
                    </Trans>
                  </h4>

                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <svg
                        className="w-5 h-5 text-teal-600"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        ></path>
                      </svg>
                      <span className="font-medium text-gray-700">
                        <Trans id="admin.jobs.modal.main_info.location">
                          Location:
                        </Trans>
                      </span>
                      <span className="text-gray-900">
                        {selectedJob.location}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <svg
                        className="w-5 h-5 text-teal-600"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                        ></path>
                      </svg>
                      <span className="font-medium text-gray-700">
                        <Trans id="admin.jobs.modal.main_info.department">
                          Department:
                        </Trans>
                      </span>
                      <span className="text-gray-900">
                        {getDepartmentName(selectedJob.departmentId)}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <svg
                        className="w-5 h-5 text-teal-600"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2-2v2m8 0H8m8 0v2a2 2 0 01-2 2H10a2 2 0 01-2-2V6"
                        ></path>
                      </svg>
                      <span className="font-medium text-gray-700">
                        <Trans id="admin.jobs.modal.main_info.type">
                          Type:
                        </Trans>
                      </span>
                      <span className="text-gray-900">
                        {selectedJob.jobType}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <svg
                        className="w-5 h-5 text-teal-600"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414A1 1 0 0119 9v10a2 2 0 01-2 2z"
                        ></path>
                      </svg>
                      <span className="font-medium text-gray-700">
                        <Trans id="admin.jobs.modal.main_info.contract">
                          Contract:
                        </Trans>
                      </span>
                      <span className="text-gray-900">
                        {selectedJob.contractType}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <svg
                        className="w-5 h-5 text-teal-600"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                        ></path>
                      </svg>
                      <span className="font-medium text-gray-700">
                        <Trans id="admin.jobs.modal.main_info.mode">
                          Mode:
                        </Trans>
                      </span>
                      <span className="text-gray-900">
                        {selectedJob.workMode}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Financial information and statistics */}
                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-gray-900 border-b border-gray-200 pb-2">
                    <Trans id="admin.jobs.modal.financial_info.title">
                      Financial Details & Statistics
                    </Trans>
                  </h4>

                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <div className="flex items-center gap-2 mb-2">
                      <svg
                        className="w-5 h-5 text-green-600"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"
                        ></path>
                      </svg>
                      <span className="font-semibold text-green-800">
                        <Trans id="admin.jobs.modal.financial_info.salary">
                          Salary
                        </Trans>
                      </span>
                    </div>
                    <p className="text-lg font-bold text-green-800">
                      {selectedJob.currency}
                      {selectedJob.minSalary?.toLocaleString()} -{" "}
                      {selectedJob.currency}
                      {selectedJob.maxSalary?.toLocaleString()}
                    </p>
                    <p className="text-sm text-green-600">
                      ({selectedJob.salaryType})
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="font-medium text-gray-700">
                        <Trans id="admin.jobs.modal.financial_info.status">
                          Status:
                        </Trans>
                      </span>
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          selectedJob.status === "ACTIVE"
                            ? "bg-green-100 text-green-800"
                            : selectedJob.status === "INACTIVE"
                            ? "bg-red-100 text-red-800"
                            : selectedJob.status === "PAUSE"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {selectedJob.status}
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="font-medium text-gray-700">
                        <Trans id="admin.jobs.modal.financial_info.bonus">
                          Bonus:
                        </Trans>
                      </span>
                      <span className="text-gray-900">
                        {selectedJob.bonus ||
                          t({
                            id: "admin.jobs.modal.financial_info.no_bonus",
                            message: "None",
                          })}
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="font-medium text-gray-700">
                        <Trans id="admin.jobs.modal.financial_info.published_on">
                          Published on:
                        </Trans>
                      </span>
                      <span className="text-gray-900">
                        {selectedJob.publicationDate
                          ? new Date(
                              selectedJob.publicationDate
                            ).toLocaleDateString("en-US")
                          : t({
                              id: "admin.jobs.modal.financial_info.not_specified",
                              message: "Not specified",
                            })}
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="font-medium text-gray-700">
                        <Trans id="admin.jobs.modal.financial_info.deadline">
                          Deadline:
                        </Trans>
                      </span>
                      <span className="text-gray-900">
                        {selectedJob.deadlineDate
                          ? new Date(
                              selectedJob.deadlineDate
                            ).toLocaleDateString("en-US")
                          : t({
                              id: "admin.jobs.modal.financial_info.not_specified",
                              message: "Not specified",
                            })}
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="font-medium text-gray-700">
                        <Trans id="admin.jobs.modal.financial_info.applications">
                          Applications:
                        </Trans>
                      </span>
                      <span className="bg-teal-100 text-teal-800 px-2 py-1 rounded-full text-sm font-semibold">
                        {selectedJob.numberOfApplications || 0}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Description if available */}
              {selectedJob.description && (
                <div className="mb-6">
                  <h4 className="text-lg font-semibold text-gray-900 border-b border-gray-200 pb-2 mb-4">
                    <Trans id="admin.jobs.modal.description.title">
                      Description
                    </Trans>
                  </h4>
                  <div className="bg-gray-50 p-4 rounded-lg border">
                    <p className="text-gray-700 leading-relaxed">
                      {selectedJob.description}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
