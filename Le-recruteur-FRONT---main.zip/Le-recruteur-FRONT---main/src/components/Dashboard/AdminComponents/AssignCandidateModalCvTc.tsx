import { useState, useEffect } from 'react';
import { useDebounce } from 'use-debounce';
import { cvthequeService } from '@/lib/network/cvtheque';
import { Candidate, CandidateFiltersState, PaginatedResponse, FilterOptionsResponse } from '@/lib/types/cvtheque';
import { useToast } from '@/hooks/use-toast';

import { CandidateFilters } from './CandidateFiltersForCvTc';
import { CandidatesTable } from './CandidatesTableCvTc';
import { ServerPagination } from './ServerPagination';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, X, CheckCircle2 } from 'lucide-react';
import { cn } from "@/lib/utils";

interface AssignCandidateModalProps {
    isOpen: boolean;
    onClose: () => void;
    recruiterId: number;
    recruiterName: string;
    onAssignSuccess: () => void;
}

type NotificationState = {
  title: string;
  description?: string;
  variant: "success" | "destructive";
} | null;

const ITEMS_PER_PAGE = 3;

export function AssignCandidateModal({ isOpen, onClose, recruiterId, recruiterName, onAssignSuccess }: AssignCandidateModalProps) {
    // State for the filter values themselves
    const [filters, setFilters] = useState<Omit<CandidateFiltersState, 'page' | 'size'>>({});
    const [page, setPage] = useState(1);
    
    // State for the data and UI
    const [selectedCandidateIds, setSelectedCandidateIds] = useState<number[]>([]);
    const [paginatedResponse, setPaginatedResponse] = useState<PaginatedResponse<Candidate> | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isAssigning, setIsAssigning] = useState(false);
    
    // State for the dynamic filter options
    const [filterOptions, setFilterOptions] = useState<FilterOptionsResponse | null>(null);
    const [isLoadingOptions, setIsLoadingOptions] = useState(true);

    //for alert
    const [notification, setNotification] = useState<NotificationState>(null);

    const { toast } = useToast();
    const [debouncedFilters] = useDebounce(filters, 500);

    // Fetch the dynamic filter options once when the modal is opened
    useEffect(() => {
        if (isOpen) {
            setIsLoadingOptions(true);
            const fetchOptions = async () => {
                try {
                    const options = await cvthequeService.getFilterOptions();
                    setFilterOptions(options);
                } catch (error) {
                    console.error("Failed to fetch filter options", error);
                    toast({ title: "Erreur", description: "Impossible de charger les options de filtre.", variant: "destructive" });
                } finally {
                    setIsLoadingOptions(false);
                }
            };
            fetchOptions();
        }
    }, [isOpen, toast]);

    // Effect 2: Fetch the list of available candidates whenever filters or page change
    useEffect(() => {
        if (isOpen) {
            const fetchAvailableCandidates = async () => {
                setIsLoading(true);
                try {
                    const response = await cvthequeService.getAvailableCandidates({
                        recruiterId: recruiterId,
                        ...debouncedFilters,
                        page,
                        size: ITEMS_PER_PAGE
                    });
                    setPaginatedResponse(response);
                } catch (error) {
                    console.error("Failed to fetch available candidates:", error);
                    toast({ title: "Erreur", description: "Impossible de charger la liste des candidats.", variant: "destructive" });
                } finally {
                    setIsLoading(false);
                }
            };
            fetchAvailableCandidates();
        }
    }, [isOpen, recruiterId, debouncedFilters, page, toast]);

    useEffect(() => {
        if (notification) {
            const timer = setTimeout(() => {
                setNotification(null);
            }, 5000); // Notification disappears after 5 seconds
            return () => clearTimeout(timer);
        }
    }, [notification]);

    // Handler to update filters from the child component
    const handleFilterChange = (newFilters: Omit<CandidateFiltersState, 'page' | 'size'>) => {
        setPage(1); // Reset to the first page whenever a filter is changed
        setFilters(newFilters);
    };

    // Handler for the assign button
    const handleAssign = async () => {
        if (selectedCandidateIds.length === 0) return;

        setIsAssigning(true);
        try {
            await cvthequeService.assignCandidatesToRecruiter(recruiterId, selectedCandidateIds);
            // SET SUCCESS NOTIFICATION
            setNotification({
                title: "Succès!",
                description: `${selectedCandidateIds.length} candidat(s) ont été assigné(s).`,
                variant: "success",
            });

            onAssignSuccess(); // This will trigger a refetch on the parent modal
            setSelectedCandidateIds([]);

            setTimeout(() => {
                onClose();
            }, 1500);

        } catch (error: string) {
            // SET ERROR NOTIFICATION
            setNotification({
                title: "Erreur!",
                description: error.message || "L'assignation a échoué.",
                variant: "destructive",
            });
            
        } finally {
            setIsAssigning(false);
        }
    };
    
    const candidates = paginatedResponse?.data || [];
    const totalPages = paginatedResponse?.totalPages || 0;

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
            {/* --- ADD NOTIFICATION JSX HERE --- */}
            {notification && (
                <div className="absolute top-5 left-1/2 -translate-x-1/2 w-full max-w-xl z-[100] animate-in fade-in-5 slide-in-from-top-5">
                    <Alert
                        variant={notification.variant === 'destructive' ? 'destructive' : 'default'}
                        className={cn(
                          "bg-white shadow-lg",
                          notification.variant === "success" && "border-green-500/50 text-green-700 [&>svg]:text-green-700"
                        )}
                    >
                        {notification.variant === "success" ? (
                            <CheckCircle2 className="h-4 w-4" />
                        ) : (
                            <AlertCircle className="h-4 w-4" />
                        )}
                        <AlertTitle>{notification.title}</AlertTitle>
                        {notification.description && (
                            <AlertDescription>{notification.description}</AlertDescription>
                        )}
                    </Alert>
                </div>
            )}
            {/* --- Main Modal Structure --- */}
            <div className="bg-white rounded-2xl w-full max-w-7xl h-[90vh] flex flex-col overflow-hidden">
                
                {/* --- Header --- */}
                <div className="bg-gradient-to-r from-[#238D94] to-[#1a6b72] p-6 flex-shrink-0 border-b border-white/20">
                    <div className="flex items-center justify-between">
                        <h2 className="text-xl font-bold text-white">
                            Assigner des Candidats à {recruiterName}
                        </h2>
                        <button 
                            onClick={onClose} 
                            className="p-1.5 text-white/80 hover:text-white hover:bg-white/20 rounded-lg transition-colors"
                        >
                            <X size={22} />
                        </button>
                    </div>
                </div>

                {/* --- Content Area --- */}
                <div className="flex-grow p-6 flex flex-col gap-4 overflow-hidden">
                    <Alert className="flex-shrink-0 bg-gray-200 hover:bg-gray-300">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Ajouter des candidats existants</AlertTitle>
                        <AlertDescription>Utilisez les filtres pour trouver et sélectionner les candidats à assigner à ce recruteur.</AlertDescription>
                    </Alert>

                    {/* Grid for Filters and Table */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 flex-grow overflow-hidden">
                        {/* Filter Panel */}
                        <div className="col-span-1 border rounded-lg p-4 overflow-y-auto">
                            <CandidateFilters 
                                currentFilters={filters} 
                                onFilterChange={handleFilterChange}
                                options={filterOptions}
                                isLoading={isLoadingOptions}
                            />
                        </div>

                        {/* Candidates Table and Pagination */}
                        <div className="md:col-span-3 flex flex-col overflow-hidden gap-4">
                            <div className="flex-grow overflow-auto border rounded-lg">
                               <CandidatesTable
                                    candidates={candidates}
                                    isLoading={isLoading}
                                    selectedCandidateIds={selectedCandidateIds}
                                    onSelectionChange={setSelectedCandidateIds}
                                />
                            </div>
                            <div className="flex-shrink-0">
                                <ServerPagination currentPage={page} totalPages={totalPages} onPageChange={setPage} />
                            </div>
                        </div>
                    </div>
                </div>

                {/* --- Footer --- */}
                <div className="p-6 border-t bg-gray-50 flex-shrink-0 flex justify-end space-x-3">
                    <Button variant="ghost" onClick={onClose} disabled={isAssigning}>Annuler</Button>
                    <Button className="bg-teal-600 text-white hover:bg-teal-700" onClick={handleAssign} disabled={selectedCandidateIds.length === 0 || isAssigning}>
                        {isAssigning ? 'Assignation en cours...' : `Assigner (${selectedCandidateIds.length})`}
                    </Button>
                </div>
            </div>
        </div>
    );
}