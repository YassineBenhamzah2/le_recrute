import { useState, useEffect } from "react";
import { Plus } from "lucide-react";
import { cvthequeService } from "@/lib/network/cvtheque"; 
import { User } from "@/lib/types/cvtheque";
import { useDebounce } from "@/hooks/useDebounce";

import { Button } from "@/components/ui/button";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface AddRecruiterControlProps {
    onAddSuccess: () => void;
}

export function AddRecruiterControl({ onAddSuccess }: AddRecruiterControlProps) {
  const [open, setOpen] = useState(false);
  const [view, setView] = useState<'list' | 'confirm'>('list');
  const [search, setSearch] = useState("");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const { toast } = useToast();

  const debouncedSearch = useDebounce(search, 300);

  useEffect(() => {
    // This effect is now solely responsible for fetching data based on the search term.
    // It runs when the component mounts and whenever the debounced search term changes.
    const fetchUsers = async () => {
      try {
        const result = await cvthequeService.findRecruitersWithoutCvTc(debouncedSearch);
        setUsers(result);
      } catch (error) {
        console.error("Failed to fetch users", error);
        setUsers([]);
      }
    };
    
    // We only need to fetch if the popover is open.
    if (open) {
      fetchUsers();
    }
  }, [debouncedSearch, open]); 

  const handleSelectUser = (user: User) => {
    setSelectedUser(user);
    setView('confirm');
  };

  const handleCancel = () => {
    setSelectedUser(null);
    setView('list');
  };

  const handleAddRecruiter = async () => {
    if (!selectedUser) return;
    
    setIsLoading(true);
    try {
      await cvthequeService.createCvThequeForRecruiter(selectedUser.id);
      toast({ title: "Succès", description: `La CVthèque pour ${selectedUser.firstname} ${selectedUser.lastname} a été créée.` });
      onAddSuccess(); 
      setSelectedUser(null);
      setSearch("");
      setView('list');
      setOpen(false);
    } catch (error: any) {
      toast({ title: "Erreur", description: error.message || "Une erreur est survenue.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const onOpenChange = (isOpen: boolean) => {
    setOpen(isOpen);
    if (!isOpen) {
        setTimeout(() => {
            setView('list');
            setSelectedUser(null);
            setSearch("");
        }, 150);
    }
  };

  return (
    <Popover open={open} onOpenChange={onOpenChange}>
      <PopoverTrigger asChild>
        <button className="bg-gradient-to-r from-[#238D94] to-[#1a6b72] hover:from-[#1a6b72] hover:to-[#238D94] text-white px-6 py-3 rounded-lg flex items-center space-x-2 transition-all duration-200 font-medium shadow-md hover:shadow-lg">
          <Plus size={20} />
          <span>Ajouter à la CVthèque</span>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-[350px] p-0" align="end">
        {view === 'list' && (
          <Command shouldFilter={false}>
            <CommandInput placeholder="Rechercher un recruteur..." onValueChange={setSearch} value={search} />
            <CommandList>
              <CommandEmpty>Aucun recruteur trouvé.</CommandEmpty>
              <CommandGroup>
                {users.map((user) => (
                  // --- THIS IS THE CORRECTED LAYOUT ---
                  <CommandItem
                    key={user.id}
                    onSelect={() => handleSelectUser(user)}
                    // We apply the flexbox styles directly to the CommandItem
                    className="flex items-center space-x-3 cursor-pointer"
                  >
                    {/* The Avatar and span are now direct children */}
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.profile_pic || ''} alt={`${user.firstname} ${user.lastname}`} />
                      <AvatarFallback>
                        {(user.firstname?.[0] || 'R')}{(user.lastname?.[0] || '')}
                      </AvatarFallback>
                    </Avatar>
                    <span>{user.firstname} {user.lastname}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        )}

        {view === 'confirm' && selectedUser && (
          <div className="p-4 flex flex-col items-center space-y-4">
            <p className="font-semibold">Ajouter ce recruteur ?</p>
            <div className="flex items-center space-x-3 bg-slate-50 p-3 rounded-lg w-full">
                <Avatar className="h-10 w-10">
                    <AvatarImage src={selectedUser.profile_pic || ''} alt={`${selectedUser.firstname} ${selectedUser.lastname}`} />
                    <AvatarFallback>
                        {(selectedUser.firstname?.[0] || 'R')}{(selectedUser.lastname?.[0] || '')}
                    </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                    <p className="font-medium text-sm">{selectedUser.firstname} {selectedUser.lastname}</p>
                    <p className="text-xs text-muted-foreground">{selectedUser.email}</p>
                </div>
            </div>
            <div className="flex w-full justify-end space-x-2 pt-2">
                <Button variant="ghost" onClick={handleCancel} disabled={isLoading}>
                    Annuler
                </Button>
                <Button onClick={handleAddRecruiter} disabled={isLoading}>
                    {isLoading ? "Ajout..." : "Ajouter"}
                </Button>
            </div>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}