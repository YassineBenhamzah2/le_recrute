import AdminServices from "@/components/Dashboard/AdminComponents/ServiceSection";
import AdminBlogs from "./BlogCard";
import AdminAds from "./Space";

import AdminCompanyList from "./AdminCompanyList";
import { Trans } from '@lingui/macro';

export default function Cms() {
  return (
    <main className="min-h-screen px-4 bg-gray-50">
      <div className="max-w-7xl  px-4 space-y-6">

        {/* PAGE TITLE */}
        <h2 className="text-3xl  px-4 font-bold">
          <Trans id="front.cms.title">Front CMS</Trans>
        </h2>
        <p className="text-gray-600 px-5">
          <Trans id="front.cms.description">Manage and edit your website content in real time, no coding required.</Trans>
        </p>

       
        <AdminAds />

        <AdminCompanyList />

        <AdminServices />

        <AdminBlogs />

      </div>
    </main>
  );
}
