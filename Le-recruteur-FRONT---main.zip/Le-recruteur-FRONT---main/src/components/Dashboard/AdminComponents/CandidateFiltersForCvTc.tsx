import { useState } from 'react';
import { Filter, ChevronDown, MapPin, Briefcase, GraduationCap, Award, Download, Calendar } from 'lucide-react';
import { CandidateFiltersState, FilterOptionsResponse } from '@/lib/types/cvtheque';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { MultiSelectDropdown } from './MultiSelectDropdown';
import { Skeleton } from '@/components/ui/skeleton';

// Static options that do not come from the database
const moroccoRegions = [
    "Tanger-Tétouan-Al Hoceïma", "L'Oriental", "Fès-Meknès", "Rabat-Salé-Kénitra",
    "Béni Mellal-Khénifra", "Casablanca-Settat", "Marrakech-Safi", "Drâa-Tafilalet",
    "Souss-Massa", "Guelmim-Oued Noun", "Laâyoune-Sakia El Hamra", "Dakhla-Oued Ed-Dahab"
];
const cvStatusOptions = ['CV disponible', 'CV non disponible'];

interface CandidateFiltersProps {
    currentFilters: Omit<CandidateFiltersState, 'page' | 'size'>;
    onFilterChange: (newFilters: Omit<CandidateFiltersState, 'page' | 'size'>) => void;
    options: FilterOptionsResponse | null;
    isLoading: boolean;
}

export function CandidateFilters({ currentFilters, onFilterChange, options, isLoading }: CandidateFiltersProps) {
    const [showAdvanced, setShowAdvanced] = useState(false);

    const handleFilterUpdate = (key: string, value: any) => {
        const newFilters = { ...currentFilters };
        
        // If value is empty, remove the key from filters, otherwise set it
        if (value === '' || (Array.isArray(value) && value.length === 0)) {
            delete (newFilters as any)[key];
        } else {
            (newFilters as any)[key] = value;
        }
        
        onFilterChange(newFilters); // Notify the parent component of the change
    };

    const clearAllFilters = () => {
        onFilterChange({});
    };

    // Display a loading state while fetching options
    if (isLoading) {
        return (
            <div className="p-4 space-y-4">
                <div className="flex items-center gap-2 mb-4">
                    <Filter className="w-5 h-5 text-gray-400" />
                    <h3 className="text-lg font-semibold text-gray-400">Filtres</h3>
                </div>
                {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-12 w-full rounded-lg" />)}
            </div>
        );
    }
    
    return (
        <div className="p-4 space-y-4 bg-slate-50/50 rounded-lg">
            <div className="flex items-center gap-2 mb-4">
                <Filter className="w-5 h-5 text-[#238D94]" />
                <h3 className="text-lg font-semibold">Filtres</h3>
            </div>
            
            <div className="grid grid-cols-1 gap-y-4">
                {/* Text Inputs */}
                <div>
                    <Label className="text-sm font-medium text-gray-700 mb-1 block">Nom et prénom</Label>
                    <Input placeholder="Ex: Marie Dubois" value={currentFilters.name || ''} onChange={(e) => handleFilterUpdate('name', e.target.value)} />
                </div>

                {/* Dynamic Dropdowns */}
                <div>
                    <Label className="text-sm font-medium text-gray-700 mb-1 block">Fonction actuelle</Label>
                    <MultiSelectDropdown options={options?.positions || []} placeholder="Ex: Développeur" selectedValues={currentFilters.positions || []} onChange={(v) => handleFilterUpdate('positions', v)} icon={Briefcase} />
                </div>
                <div>
                    <Label className="text-sm font-medium text-gray-700 mb-1 block">Niveau d'étude</Label>
                    <MultiSelectDropdown options={options?.educationLevels || []} placeholder="Ex: BAC5" selectedValues={currentFilters.educationLevels || []} onChange={(v) => handleFilterUpdate('educationLevels', v)} icon={GraduationCap} />
                </div>
                <div>
                    <Label className="text-sm font-medium text-gray-700 mb-1 block">Niveau d'expérience</Label>
                    <MultiSelectDropdown options={options?.experienceLevels || []} placeholder="Ex: SENIOR" selectedValues={currentFilters.experienceLevels || []} onChange={(v) => handleFilterUpdate('experienceLevels', v)} icon={Calendar} />
                </div>
                 <div>
                    <Label className="text-sm font-medium text-gray-700 mb-1 block">Secteur d'activité / Typologie</Label>
                    <MultiSelectDropdown options={options?.sectors || []} placeholder="Ex: Informatique, Finance..." selectedValues={currentFilters.sectors || []} onChange={(v) => handleFilterUpdate('sectors', v)} />
                </div>
                 <div>
                    <Label className="text-sm font-medium text-gray-700 mb-1 block">Compétences</Label>
                    <MultiSelectDropdown options={options?.skills || []} placeholder="Ex: React, Python..." selectedValues={currentFilters.skills || []} onChange={(v) => handleFilterUpdate('skills', v)} icon={Award} />
                </div>

                {/* Static Dropdown */}
                <div>
                    <Label className="text-sm font-medium text-gray-700 mb-1 block">Région</Label>
                    <MultiSelectDropdown options={moroccoRegions} placeholder="Ex: Casablanca-Settat" selectedValues={currentFilters.regions || []} onChange={(v) => handleFilterUpdate('regions', v)} icon={MapPin} />
                </div>
            </div>

            <Button variant="link" className="p-0 h-auto text-[#1a6b72] text-sm" onClick={() => setShowAdvanced(!showAdvanced)}>
                Recherche avancée
                <ChevronDown className={`w-4 h-4 ml-1 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
            </Button>

            {showAdvanced && (
                <div className="space-y-4 pt-4 border-t">
                    {/* Dynamic Dropdowns */}
                    <div>
                        <Label className="text-sm font-medium text-gray-700 mb-1 block">Employeur actuel</Label>
                        <MultiSelectDropdown options={options?.companies || []} placeholder="Ex: Orange, L'Oréal..." selectedValues={currentFilters.companies || []} onChange={(v) => handleFilterUpdate('companies', v)} />
                    </div>
                    <div>
                        <Label className="text-sm font-medium text-gray-700 mb-1 block">Formation</Label>
                        <MultiSelectDropdown options={options?.formations || []} placeholder="Ex: Licence, Master..." selectedValues={currentFilters.formations || []} onChange={(v) => handleFilterUpdate('formations', v)} icon={GraduationCap} />
                    </div>
                    <div>
                        <Label className="text-sm font-medium text-gray-700 mb-1 block">Certification</Label>
                        <MultiSelectDropdown options={options?.certifications || []} placeholder="Ex: AWS certified..." selectedValues={currentFilters.certifications || []} onChange={(v) => handleFilterUpdate('certifications', v)} icon={Award} />
                    </div>
                    
                    {/* Text Inputs */}
                    <div>
                        <Label className="text-sm font-medium text-gray-700 mb-1 block">Contact (email)</Label>
                        <Input placeholder="Ex: nom.prenom@email.com" value={currentFilters.email || ''} onChange={(e) => handleFilterUpdate('email', e.target.value)} />
                    </div>
                    <div>
                        <Label className="text-sm font-medium text-gray-700 mb-1 block">Téléphone</Label>
                        <Input placeholder="Ex: +212 6 12 34 56 78" value={currentFilters.phone || ''} onChange={(e) => handleFilterUpdate('phone', e.target.value)} />
                    </div>
                    <div>
                        <Label className="text-sm font-medium text-gray-700 mb-1 block">Adresse complète</Label>
                        <Input placeholder="Ex: 15 Rue Victor Hugo, Casablanca" value={currentFilters.address || ''} onChange={(e) => handleFilterUpdate('address', e.target.value)} />
                    </div>

                    {/* Static Dropdown */}
                    <div>
                        <Label className="text-sm font-medium text-gray-700 mb-1 block">Statut CV</Label>
                        <MultiSelectDropdown options={cvStatusOptions} placeholder="CV disponible ?" selectedValues={currentFilters.cvStatus || []} onChange={(v) => handleFilterUpdate('cvStatus', v)} icon={Download} />
                    </div>
                </div>
            )}

             <div className="pt-4 mt-4 border-t">
                <Button onClick={clearAllFilters} className="w-full justify-center text-sm bg-teal-600 text-gray-50 hover:bg-teal-650">
                    Effacer tous les filtres
                </Button>
            </div>
        </div>
    );
}