import JobCard from "@/components/Dashboard/AdminComponents/JobCard.tsx"; // adapte le chemin si besoin
import { FC } from "react";

interface JobListing {
  id: number;
  title: string;
  company: string;
  location: string;
  postedTime: string;
  jobType: string;
  salary: string;
  salaryPeriod: string;
  skills: { name: string }[];
  companyLogo: string;
  status:string
}

interface CompanyJobCardsProps {
  jobListing: JobListing[];
}

const CompanyJobCards: FC<CompanyJobCardsProps> = ({ jobListing }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-1 lg:grid-cols-1 gap-6">
      {jobListing.map((job) => (
        <JobCard
          key={job.id}
          title={job.title}
          company={job.company}
          location={job.location}
          type={job.jobType}
          editedAgo={job.postedTime}
          description={`We're looking for a creative and detail-oriented ${job.title} to join our team at ${job.company}.`}
          date={"30 June, 2025"}
          author={"Youssef B."}
          applications={57}
          status={job.status}
        />
      ))}
    </div>
  );
};

export default CompanyJobCards;
