import { useState, useMemo, useEffect } from 'react';
import { Search, Users, TrendingUp, Award, UserCheck, Briefcase } from 'lucide-react';
import { cvthequeService } from '@/lib/network/cvtheque';
import { useDebounce } from '@/hooks/useDebounce';
import { PaginatedResponse, Recruiter, DashboardStats } from '@/lib/types/cvtheque';
import { Trans, t } from '@lingui/macro';

import { AddRecruiterControl } from './AddRecruiterControl';
import { RecruiterCard } from './RecruiterCard';
import { ServerPagination } from './ServerPagination';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';

const ITEMS_PER_PAGE = 1;

export default function AdminCVtheque() {
  // --- Separate state for stats ---
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoadingStats, setIsLoadingStats] = useState(true);

  const [filters, setFilters] = useState({ page: 1, searchTerm: '' });
  const [refetchTrigger, setRefetchTrigger] = useState(0);
  
  // --- STATE MANAGEMENT WITH useState ---
  const [paginatedResponse, setPaginatedResponse] = useState<PaginatedResponse<Recruiter> | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);

  const debouncedSearchTerm = useDebounce(filters.searchTerm, 500);

  const queryParams = useMemo(() => ({
    page: filters.page,
    size: ITEMS_PER_PAGE,
    searchTerm: debouncedSearchTerm,
  }), [filters.page, debouncedSearchTerm]);

  // --- DATA FETCHING WITH useEffect ---
  useEffect(() => {
    const fetchRecruiters = async () => {
      setIsLoading(true);
      setIsError(false);
      try {
        const response = await cvthequeService.getRecruiters(queryParams);
        setPaginatedResponse(response);
      } catch (error) {
        console.error("Failed to fetch recruiters:", error);
        setIsError(true);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRecruiters();
  }, [queryParams, refetchTrigger]); // This effect re-runs whenever the filters or page change

  // useEffect to fetch stats when the component mounts
  useEffect(() => {
    const fetchStats = async () => {
      setIsLoadingStats(true);
      try {
        const statsData = await cvthequeService.getDashboardStats();
        setStats(statsData);
      } catch (error) {
        console.error("Failed to fetch stats:", error);
      } finally {
        setIsLoadingStats(false);
      }
    };
    fetchStats();
  }, []);

  const recruiters = paginatedResponse?.data || [];
  const totalPages = paginatedResponse?.totalPages || 0;
  const currentPage = paginatedResponse?.currentPage || 1;

  const handleUpdateSuccess = () => {
    setRefetchTrigger(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-r from-[#238D94] to-[#1a6b72] rounded-xl flex items-center justify-center">
              <Users className="text-white" size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                <Trans id="cvtheque.title">CV Database Administration</Trans>
              </h1>
              <p className="text-gray-600">
                <Trans id="cvtheque.description">Manage your recruiters and their candidate portfolios</Trans>
              </p>
            </div>
          </div>
          <AddRecruiterControl onAddSuccess={handleUpdateSuccess} />
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm text-gray-600 mb-1">
                          <Trans id="cvtheque.stats.total_recruiters">Total Recruiters</Trans>
                        </p>
                        <div className="text-3xl font-bold text-gray-900">
                            {isLoadingStats ? <Skeleton className="h-8 w-1/2" /> : stats?.totalRecruiters}
                        </div>
                    </div>
                    <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                      <Users className="text-blue-600" size={24} />
                    </div>
                </div>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm text-gray-600 mb-1">
                          <Trans id="cvtheque.stats.active_recruiters">Active Recruiters</Trans>
                        </p>
                        <div className="text-3xl font-bold text-green-600">
                            {isLoadingStats ? <Skeleton className="h-8 w-1/2" /> : stats?.activeRecruiters}
                        </div>
                    </div>
                    <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                      <UserCheck className="text-green-600" size={24} />
                    </div>
                </div>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm text-gray-600 mb-1">
                          <Trans id="cvtheque.stats.total_candidates">Total Candidates</Trans>
                        </p>
                        <div className="text-3xl font-bold text-[#238D94]">
                            {isLoadingStats ? <Skeleton className="h-8 w-1/2" /> : stats?.totalCandidates}
                        </div>
                    </div>
                    <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center">
                      <Briefcase className="text-[#238D94]" size={24} />
                    </div>
                </div>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm text-gray-600 mb-1">
                          <Trans id="cvtheque.stats.placed_candidates">Placed Candidates</Trans>
                        </p>
                        <div className="text-3xl font-bold text-orange-600">
                            {isLoadingStats ? <Skeleton className="h-8 w-1/2" /> : stats?.placedCandidates}
                        </div>
                    </div>
                    <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                      <Award className="text-orange-600" size={24} />
                    </div>
                </div>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm text-gray-600 mb-1">
                          <Trans id="cvtheque.stats.avg_success_rate">Average Success Rate</Trans>
                        </p>
                        <div className="text-3xl font-bold text-purple-600">
                            {isLoadingStats ? <Skeleton className="h-8 w-1/2" /> : `${stats?.avgSuccessRate.toFixed(1)}%`}
                        </div>
                    </div>
                    <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                      <TrendingUp className="text-purple-600" size={24} />
                    </div>
                </div>
            </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 mb-6 p-6">
            <div className="relative">
                <Input
                    type="text"
                    placeholder={t({ 
                      id: "cvtheque.search.placeholder", 
                      message: "Search a recruiter by first name, last name, or email..." 
                    })}
                    value={filters.searchTerm}
                    onChange={(e) => setFilters({ ...filters, page: 1, searchTerm: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#238D94] focus:border-[#238D94]"
                />
                <Search className="absolute left-3 top-3.5 text-gray-400" size={16} />
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {isLoading && Array.from({ length: ITEMS_PER_PAGE }).map((_, i) => <Skeleton key={i} className="h-[450px] w-full rounded-2xl" />)}
          
          {isError && (
            <div className="col-span-full text-center text-red-600 bg-red-50 p-8 rounded-lg">
              <Trans id="cvtheque.error.loading">An error occurred while loading data.</Trans>
            </div>
          )}
          
          {!isLoading && recruiters.map((recruiter) => (
            <RecruiterCard key={recruiter.id} recruiter={recruiter} onUpdateSuccess={handleUpdateSuccess} />
          ))}

          {!isLoading && !isError && recruiters.length === 0 && (
            <div className="col-span-full bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
              <Users className="mx-auto text-gray-400 mb-4" size={48} />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                <Trans id="cvtheque.no_results.title">No recruiters found</Trans>
              </h3>
              <p className="text-gray-600">
                <Trans id="cvtheque.no_results.description">Try changing your search criteria.</Trans>
              </p>
            </div>
          )}
        </div>

        <ServerPagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={(page) => setFilters(prev => ({ ...prev, page }))}
        />
      </div>
    </div>
  );
}
