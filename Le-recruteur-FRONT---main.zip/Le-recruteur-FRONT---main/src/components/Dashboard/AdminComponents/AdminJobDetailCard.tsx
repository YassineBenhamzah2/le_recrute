import React from 'react';
import { AdminJobResponse } from '@/lib/types/jobOffer';

interface AdminJobDetailCardProps extends AdminJobResponse {
  onViewApplications?: (id: number) => void;
}

const AdminJobDetailCard: React.FC<AdminJobDetailCardProps> = ({
  id,
  title,
  description,
  location,
  jobType,
  contractType,
  workMode,
  minSalary,
  maxSalary,
  currency,
  salaryType,
  publicationDate,
  deadlineDate,
  status,
  bonus,
  companyId,
  departmentId,
  numberOfApplications,
  onViewApplications
}) => {
  const formatSalary = () => {
    const curr = currency || '$';
    return `${curr}${minSalary.toLocaleString()} - ${curr}${maxSalary.toLocaleString()}`;
  };

  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4 shadow hover:shadow-lg transition-all duration-300">
      <div className="flex flex-col gap-2">
        <h3 className="text-lg font-semibold text-teal-600">{title}</h3>
        <p className="text-sm text-gray-600">{description}</p>
        <p className="text-sm text-gray-600">
          Localisation : {location} | Type : {jobType}
        </p>
        <p className="text-sm text-gray-600">
          Contrat : {contractType} | Mode : {workMode}
        </p>
        <p className="text-sm text-gray-600">
          Salaire : {formatSalary()} ({salaryType})
        </p>
        <p className="text-xs text-gray-500">
          Publié le {publicationDate?.toString()} | Deadline : {deadlineDate?.toString()}
        </p>
        <p className="text-xs text-gray-500">
          Statut : {status} | Bonus : {bonus || 'Aucun'}
        </p>
        <p className="text-xs text-gray-500">
          Société ID : {companyId} | Département ID : {departmentId}
        </p>
        <p className="text-sm text-gray-700">
          Candidatures : <span className="font-medium">{numberOfApplications}</span>
        </p>

       
      </div>
    </div>
  );
};

export default AdminJobDetailCard;
