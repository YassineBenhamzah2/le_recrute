import React from 'react';

interface MetricCardProps {
  icon: React.ComponentType<any>;
  title: string;
  value: string;
  subtitle: string;
  change?: string;
  chartColor: 'teal' | 'blue' | 'purple' | 'emerald';
}

export function MetricCard({ 
  icon: Icon, 
  title, 
  value,
  change, 
  chartColor 
}: MetricCardProps) {
  const colorClasses = {
    teal: {
      bg: 'bg-teal-100',
      text: 'text-teal-600',
      chart: 'bg-teal-200'
    },
    blue: {
      bg: 'bg-blue-100',
      text: 'text-blue-600',
      chart: 'bg-blue-200'
    },
    purple: {
      bg: 'bg-purple-100',
      text: 'text-purple-600',
      chart: 'bg-purple-200'
    },
    emerald: {
      bg: 'bg-emerald-100',
      text: 'text-emerald-600',
      chart: 'bg-emerald-200'
    },
    gray: {
    bg: 'bg-gray-50',
    text: 'text-gray-600',
    icon: 'bg-gray-100',
    chart: '#9ca3af',
  },
  };

  const colors = colorClasses[chartColor];

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${colors.bg}`}>
          <Icon className={`w-6 h-6 ${colors.text}`} />
        </div>
      </div>
      <div className="space-y-1">
        <p className="text-2xl font-bold text-gray-900">{value}</p>
        <p className="text-sm font-medium text-gray-700">{title}</p>
        {change && (
          <p className="text-xs text-gray-500">{change}</p>
        )}
      </div>
      <div className="mt-4 h-12 flex items-end space-x-1">
        {Array.from({ length: 12 }).map((_, i) => (
          <div
            key={i}
            className={`w-2 ${colors.chart} rounded-sm`}
            style={{ height: `${Math.random() * 40 + 10}px` }}
          />
        ))}
      </div>
    </div>
  );
}