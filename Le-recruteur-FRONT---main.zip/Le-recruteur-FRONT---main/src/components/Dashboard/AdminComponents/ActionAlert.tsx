import React from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";

// Define the props the component will accept
interface ActionAlertProps {
  type: 'success' | 'destructive';
  title: string;
  description?: string;
}

const ActionAlert: React.FC<ActionAlertProps> = ({ type, title, description }) => {
  const Icon = type === 'success' ? CheckCircle2 : AlertCircle;

  return (
    // This div handles the positioning: fixed, top-center
    <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 w-full max-w-xl animate-in fade-in-0 slide-in-from-top-5">
      <Alert variant={type}>
        <Icon className="h-4 w-4" />
        <AlertTitle>{title}</AlertTitle>
        {description && <AlertDescription>{description}</AlertDescription>}
      </Alert>
    </div>
  );
};

export default ActionAlert;