import { useState } from "react";
import { Recruiter } from "@/lib/types/cvtheque";
import { cvthequeService } from "@/lib/network/cvtheque";
import { Eye, Trash2, MapPin, Briefcase, Mail, Phone, Calendar, Star } from "lucide-react";
import RecruiterCandidatesModal from "./RecruiterCandidatesModal";
import { useToast } from "@/hooks/use-toast";
import { ConfirmationDialog } from "@/components/ui/ConfirmationDialog";

interface RecruiterCardProps {
    recruiter: Recruiter;
    onUpdateSuccess: () => void;
}

export function RecruiterCard({ recruiter, onUpdateSuccess }: RecruiterCardProps) {
    const [isCandidatesModalOpen, setIsCandidatesModalOpen] = useState(false);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    const { toast } = useToast();

    const handleRemoveRecruiter = async () => {

        setIsDeleting(true);
        try {
            await cvthequeService.removeRecruiterFromCvTheque(recruiter.id);
            toast({ title: "Succès", description: "Le recruteur a été retiré de la CVthèque.", variant: "default" });
            onUpdateSuccess(); // This tells the parent page to refetch the list
            setIsDeleteDialogOpen(false);
        } catch (error: any) {
            toast({ title: "Erreur", description: error.message || "La suppression a échoué.", variant: "destructive" });
        } finally {
            setIsDeleting(false);
        }
    };

    return (
        <>
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow duration-200">
                <div className="p-6 bg-gradient-to-r from-[#238D94] to-[#1a6b72] text-white relative">
                    <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3">
                            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center text-lg font-bold">
                                {recruiter.prenom.charAt(0)}{recruiter.nom.charAt(0)}
                            </div>
                            <div>
                                <h3 className="text-lg font-semibold">{recruiter.prenom} {recruiter.nom}</h3>
                                <div className="flex items-center space-x-2">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${recruiter.statut === 'ACTIVE' ? 'bg-green-100/20 text-green-100' : 'bg-red-100/20 text-red-100'}`}>
                                        {recruiter.statut}
                                    </span>
                                    <div className="flex items-center space-x-1">
                                        <Star size={12} className="text-yellow-300 fill-current" />
                                        <span className="text-sm ml-1">({recruiter.rating?.toFixed(1)})</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center space-x-2"><MapPin size={14} /><span>{recruiter.region}</span></div>
                        <div className="flex items-center space-x-2"><Briefcase size={14} /><span>{recruiter.secteur}</span></div>
                    </div>
                </div>

                <div className="p-6">
                    <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="text-center">
                            <div className="text-2xl font-bold text-[#238D94]">{recruiter.performance.candidats_total}</div>
                            <div className="text-sm text-gray-600">Total Candidats</div>
                        </div>
                        <div className="text-center">
                            <div className="text-2xl font-bold text-green-600">{recruiter.performance.candidats_places}</div>
                            <div className="text-sm text-gray-600">Placés</div>
                        </div>
                    </div>
                    <div className="space-y-3 mb-6">
                        <div className="flex justify-between items-center"><span className="text-sm text-gray-600">Taux de réussite</span><span className="font-semibold text-gray-900">{recruiter.performance.taux_reussite}%</span></div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-gradient-to-r from-[#238D94] to-[#1a6b72] h-2 rounded-full" style={{ width: `${recruiter.performance.taux_reussite}%` }}></div>
                        </div>
                    </div>
                    <div className="space-y-2 mb-6 text-sm">
                        <div className="flex items-center space-x-2 text-gray-600"><Mail size={14} /><span className="truncate">{recruiter.email}</span></div>
                        <div className="flex items-center space-x-2 text-gray-600"><Phone size={14} /><span>{recruiter.telephone}</span></div>
                        <div className="flex items-center space-x-2 text-gray-600"><Calendar size={14} /><span>Dernière activité: {new Date(recruiter.derniere_activite).toLocaleDateString('fr-FR')}</span></div>
                    </div>

                    <div className="flex space-x-2">
                        <button onClick={() => setIsCandidatesModalOpen(true)} className="flex-1 bg-gradient-to-r from-[#238D94] to-[#1a6b72] text-white py-2 px-3 rounded-lg text-sm font-medium hover:from-[#1a6b72] hover:to-[#238D94] transition-all duration-200 flex items-center justify-center space-x-1">
                            <Eye size={14} />
                            <span>Voir Candidats</span>
                        </button>
                        <button 
                            onClick={() => setIsDeleteDialogOpen(true)} 
                            className="px-3 py-2 text-red-600 border border-red-300 rounded-lg hover:bg-red-50 transition-colors disabled:opacity-50"
                        >
                            <Trash2 size={14} />
                        </button>
                    </div>
                </div>
            </div>
            {/* --- The Confirmation Dialog --- */}
            <ConfirmationDialog
                isOpen={isDeleteDialogOpen}
                onClose={() => setIsDeleteDialogOpen(false)}
                onConfirm={handleRemoveRecruiter}
                title={`Retirer ${recruiter.prenom} ${recruiter.nom} ?`}
                description="Cette action retirera le recruteur de la CVthèque. Il pourra être rajouté plus tard. Êtes-vous sûr de vouloir continuer ?"
                confirmText="Oui, Retirer"
                isLoading={isDeleting}
            />

            {isCandidatesModalOpen && (
                <RecruiterCandidatesModal
                    isOpen={isCandidatesModalOpen}
                    recruiter={recruiter}
                    onClose={() => setIsCandidatesModalOpen(false)}
                />
            )}
        </>
    );
}