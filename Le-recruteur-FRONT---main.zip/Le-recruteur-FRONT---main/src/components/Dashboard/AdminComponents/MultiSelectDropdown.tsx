import * as React from "react";
import { Check, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { cn } from "@/lib/utils";

interface MultiSelectDropdownProps {
  options: string[];
  placeholder: string;
  selectedValues: string[];
  onChange: (values: string[]) => void;
  icon?: React.ComponentType<{ className?: string }>;
}

export function MultiSelectDropdown({
  options,
  placeholder,
  selectedValues,
  onChange,
  icon: Icon,
}: MultiSelectDropdownProps) {
  const [open, setOpen] = React.useState(false);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  const handleOptionToggle = (option: string) => {
    const newSelected = selectedValues.includes(option)
      ? selectedValues.filter((item) => item !== option)
      : [...selectedValues, option];
    onChange(newSelected);
  };

  // close on click outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <Button
        variant="outline"
        role="combobox"
        aria-expanded={open}
        onClick={() => setOpen((prev) => !prev)}
        className="w-full justify-between font-normal h-12 border-gray-200 bg-white hover:border-[#238D94]"
      >
        <div className="flex items-center gap-2 flex-1 overflow-hidden">
          {Icon && <Icon className="w-4 h-4 text-gray-400" />}
          {selectedValues.length > 0 ? (
            <div className="flex flex-wrap gap-1 items-center">
              {selectedValues.slice(0, 2).map((value) => (
                <span
                  key={value}
                  className="inline-flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-800 font-medium text-xs rounded"
                >
                  {value}
                </span>
              ))}
              {selectedValues.length > 2 && (
                <span className="text-xs text-gray-500">
                  +{selectedValues.length - 2} de plus
                </span>
              )}
            </div>
          ) : (
            <span className="text-gray-500">{placeholder}</span>
          )}
        </div>
        <ChevronDown
          className={`ml-auto w-4 h-4 text-gray-400 shrink-0 opacity-50 transition-transform ${
            open ? "rotate-180" : ""
          }`}
        />
      </Button>

      {open && (
        <div className="absolute z-50 mt-1 w-full rounded-md border bg-white shadow-md">
          <Command>
            <CommandInput placeholder="Filtrer les options..." />
            <CommandList>
              <CommandEmpty>Aucun résultat trouvé.</CommandEmpty>
              <CommandGroup>
                {options.map((option) => {
                  const isSelected = selectedValues.includes(option);
                  return (
                    <CommandItem
                      key={option}
                      // this fires for both click & Enter automatically
                      onSelect={() => handleOptionToggle(option)}
                      className="flex items-center gap-2 cursor-pointer"
                    >
                      <div
                        className={cn(
                          "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border transition-colors",
                          isSelected
                            ? "bg-[#238D94] text-white border-[#238D94]"
                            : "border-gray-400"
                        )}
                      >
                        {isSelected && <Check className="h-4 w-4" />}
                      </div>
                      <span>{option}</span>
                    </CommandItem>
                  );
                })}
              </CommandGroup>
            </CommandList>
          </Command>
        </div>
      )}
    </div>
  );
}
