"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search, X } from "lucide-react";
import { Trans } from "@lingui/macro";
import { t } from "@lingui/core/macro"

export interface PaymentFilters {
  search: string;
  status: string;
  method: string;
  dateFrom: string;
  dateTo: string;
  minAmount: string;
  maxAmount: string;
}

interface PaymentFiltersProps {
  filters: PaymentFilters;
  setFilters: (filters: PaymentFilters) => void;
  onClose: () => void; // Add a prop to handle closing the panel
}

export function PaymentFiltersComponent({
  filters,
  setFilters,
  onClose,
}: PaymentFiltersProps) {
  // A generic handler to update any filter field
  const handleFilterChange = (key: keyof PaymentFilters, value: string) => {
    setFilters({ ...filters, [key]: value });
  };

  const clearFilters = () => {
    setFilters({
      search: "",
      status: "all",
      method: "all",
      dateFrom: "",
      dateTo: "",
      minAmount: "",
      maxAmount: "",
    });
  };

  const activeFiltersCount = Object.values(filters).filter(
    (value) => value !== "" && value !== "all"
  ).length;

  return (
    <div className="w-full mt-4">
      <Card className="border border-gray-200 bg-white shadow-sm">
        <CardHeader className="pb-4 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-medium text-teal-700">
              <Trans>Filter Payments</Trans>
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose} // Use the onClose prop to hide the panel
              className="text-teal-600 hover:text-teal-800 hover:bg-teal-50"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div className="space-y-2">
              <Label htmlFor="search">
                <Trans>Search</Trans>
              </Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="search"
                  placeholder={t`Search candidate, service, ID...`}
                  value={filters.search}
                  onChange={(e) => handleFilterChange("search", e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>
                <Trans>Actions</Trans>
              </Label>
              <Button
                variant="outline"
                onClick={clearFilters}
                disabled={activeFiltersCount === 0}
                className="w-full"
              >
                <Trans>Clear All Filters</Trans>
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
            <div className="space-y-3">
              <Label>
                <Trans>Date Range</Trans>
              </Label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="dateFrom" className="text-xs text-gray-500">
                    <Trans>From</Trans>
                  </Label>
                  <Input
                    id="dateFrom"
                    type="date"
                    value={filters.dateFrom}
                    onChange={(e) =>
                      handleFilterChange("dateFrom", e.target.value)
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="dateTo" className="text-xs text-gray-500">
                    <Trans>To</Trans>
                  </Label>
                  <Input
                    id="dateTo"
                    type="date"
                    value={filters.dateTo}
                    onChange={(e) =>
                      handleFilterChange("dateTo", e.target.value)
                    }
                  />
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <Label>
                <Trans>Amount Range ($)</Trans>
              </Label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="minAmount" className="text-xs text-gray-500">
                    <Trans>Min Amount</Trans>
                  </Label>
                  <Input
                    id="minAmount"
                    type="number"
                    placeholder="0"
                    value={filters.minAmount}
                    onChange={(e) =>
                      handleFilterChange("minAmount", e.target.value)
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="maxAmount" className="text-xs text-gray-500">
                    <Trans>Max Amount</Trans>
                  </Label>
                  <Input
                    id="maxAmount"
                    type="number"
                    placeholder="10000"
                    value={filters.maxAmount}
                    onChange={(e) =>
                      handleFilterChange("maxAmount", e.target.value)
                    }
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="status">
                <Trans>Status</Trans>
              </Label>
              <select
                id="status"
                value={filters.status}
                onChange={(e) => handleFilterChange("status", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500 bg-white"
              >
                <option value="all">
                  <Trans>All Statuses</Trans>
                </option>
                <option value="completed">
                  <Trans>Completed</Trans>
                </option>
                <option value="pending">
                  <Trans>Pending</Trans>
                </option>
                <option value="failed">
                  <Trans>Failed</Trans>
                </option>
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="method">
                <Trans>Payment Method</Trans>
              </Label>
              <select
                id="method"
                value={filters.method}
                onChange={(e) => handleFilterChange("method", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500 bg-white"
              >
                <option value="all">
                  <Trans>All Methods</Trans>
                </option>
                <option value="bank transfer">
                  <Trans>Bank Transfer</Trans>
                </option>
                <option value="paypal">
                  <Trans>PayPal</Trans>
                </option>
                <option value="credit card">
                  <Trans>Credit Card</Trans>
                </option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
