import { useEffect, useState } from "react";
import { Pencil, Trash2, ChevronDown, Wrench, Plus } from "lucide-react";
import toast from "react-hot-toast";
import { settings } from "@/lib/settings/main";
import { AdminServiceCmsResponse, PaginatedCmsServices } from "@/lib/types/service";
import { serviceCmsApi } from "@/lib/network/serviceApi";
import { Trans, t } from '@lingui/macro';

function AdAdminCard({
  title,
  imageUrl,
  onEdit,
  onDelete,
}: {
  title: string;
  imageUrl: string;
  onEdit?: () => void;
  onDelete?: () => void;
}) {
  return (
    <div className="relative group cursor-pointer">
      <div className="relative border-2 border-[#238D94] rounded-lg overflow-hidden h-64 lg:h-72 transition-transform duration-300 group-hover:scale-105">
        <img
          src={imageUrl ? `${settings.IMG_ADDRESS}${imageUrl}` : "/default-image.png"}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition">
          {onEdit && (
            <button 
              onClick={onEdit} 
              className="p-2 bg-white rounded-full shadow hover:bg-gray-100"
              title={t({ id: "admin_services.edit_service", message: "Edit service" })}
            >
              <Pencil className="text-[#238D94]" size={18} />
            </button>
          )}
          {onDelete && (
            <button 
              onClick={onDelete} 
              className="p-2 bg-white rounded-full shadow hover:bg-gray-100"
              title={t({ id: "admin_services.delete_service", message: "Delete service" })}
            >
              <Trash2 className="text-[#687778]" size={18} />
            </button>
          )}
        </div>
      </div>
      <div className="absolute left-1/2 -translate-x-1/2 bottom-[-16px] bg-white bg-opacity-90 text-gray-800 px-4 py-2 text-lg font-medium text-center shadow-lg rounded-lg max-w-[90%]">
        {title}
      </div>
    </div>
  );
}

export default function AdminServices() {
  const [services, setServices] = useState<AdminServiceCmsResponse[]>([]);
  const [allServices, setAllServices] = useState<AdminServiceCmsResponse[]>([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [editingService, setEditingService] = useState<AdminServiceCmsResponse | null>(null);
  const [selectedService, setSelectedService] = useState<AdminServiceCmsResponse | null>(null);
  const [order, setOrder] = useState(1);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  // Pour modal suppression
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [currentDeleteService, setCurrentDeleteService] = useState<AdminServiceCmsResponse | null>(null);

  const itemsPerPage = 3;

  const fetchServices = async () => {
    try {
      const res: PaginatedCmsServices = await serviceCmsApi.getCmsServices(page, itemsPerPage);
      setServices(res.content);
      setTotalPages(res.totalPages);
    } catch {
      toast.error(t({ id: "admin_services.error.loading_services", message: "Erreur chargement CMS services" }));
    }
  };

  const fetchAllServices = async () => {
    try {
      const res = await serviceCmsApi.getAllServices();
      setAllServices(res);
    } catch {
      toast.error(t({ id: "admin_services.error.loading_available", message: "Erreur chargement services disponibles" }));
    }
  };

  useEffect(() => {
    fetchServices();
    fetchAllServices();
  }, [page]);

  const handleEdit = (service: AdminServiceCmsResponse) => {
    setEditingService(service);
    setSelectedService(service);
    setOrder(service.displayOrder);
    setShowModal(true);
  };

  const confirmDelete = (service: AdminServiceCmsResponse) => {
    setCurrentDeleteService(service);
    setShowDeleteModal(true);
  };

  const handleDelete = async () => {
    if (!currentDeleteService) return;
    try {
      await serviceCmsApi.deleteCmsService(currentDeleteService.cmsId as number);
      toast.success(t({ id: "admin_services.success.deleted", message: "Service supprimé avec succès !" }));
      setShowDeleteModal(false);
      setCurrentDeleteService(null);
      fetchServices();
    } catch {
      toast.error(t({ id: "admin_services.error.delete_failed", message: "Erreur lors de la suppression" }));
    }
  };

  const handleSubmit = async () => {
    if (!selectedService) return;

    try {
      if (editingService) {
        await serviceCmsApi.updateDisplayOrder(editingService.cmsId as number, order);
        toast.success(t({ id: "admin_services.success.updated", message: "Ordre du service mis à jour !" }));
      } else {
        await serviceCmsApi.addServiceToCms(selectedService.id, order);
        toast.success(t({ id: "admin_services.success.added", message: "Service ajouté au CMS !" }));
      }

      setShowModal(false);
      setEditingService(null);
      setSelectedService(null);
      setOrder(1);
      fetchServices();
    } catch {
      toast.error(t({ id: "admin_services.error.operation_failed", message: "Erreur lors de l'opération" }));
    }
  };

  const handleCreateClick = () => {
    setEditingService(null);
    setSelectedService(null);
    setOrder(1);
    setShowModal(true);
  };



  return (
    <section className="py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-[#0e2426]">
              <Trans id="admin_services.title">CMS Services</Trans>
            </h2>
            <p className="text-gray-600 mt-4 mb-4">
              <Trans id="admin_services.description">
                Sélectionnez et organisez les services affichés sur la homepage.
              </Trans>
            </p>
          </div>
          <button
            onClick={handleCreateClick} 
            className="bg-white text-[#238D94] border border-teal-600 px-5 py-2 rounded-lg shadow hover:bg-[#1d757c] hover:text-white transition flex items-center gap-2 mt-4 md:mt-0"
          >
            <Trans id="admin_services.add_service">Ajouter un service</Trans>
          </button>
        </div>

        {services.length === 0 ? (

          // --- Message si aucun service n'est trouvé ---
          <div className="text-center bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-12 mt-8">
            <div className="mx-auto w-16 h-16 flex items-center justify-center bg-gray-200 rounded-full text-gray-500">
              <Wrench size={32} />
            </div>
            <h3 className="mt-4 text-xl font-semibold text-gray-800">
              <Trans>No Featured Services</Trans>
            </h3>
            <p className="mt-2 text-sm text-gray-500">
              <Trans>Get started by adding a service to the homepage CMS.</Trans>
            </p>
            <button
              onClick={handleCreateClick} // <-- On réutilise la même fonction
              className="mt-6 inline-flex items-center gap-2 bg-[#238D94] text-white px-5 py-2.5 rounded-lg shadow hover:bg-[#1d757c] transition font-semibold"
            >
              <Plus size={18} />
              <Trans>Add First Service</Trans>
            </button>
          </div>

        ) : (

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service) => (
            <AdAdminCard
              key={service.cmsId as number}
              title={service.title}
              imageUrl={service.imageUrl || ""}
              onEdit={() => handleEdit(service)}
              onDelete={() => confirmDelete(service)}
            />
          ))}
        </div> )}

        {/* Pagination stylée */}
        {services.length != 0 && <div className="flex justify-center mt-6">
          <nav className="inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
            {/* Previous */}
            <button
              onClick={() => setPage(Math.max(0, page - 1))}
              disabled={page === 0}
              className="rounded-l-md border border-gray-300 bg-white px-3 py-1 text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              title={t({ id: "admin_services.pagination.previous", message: "Page précédente" })}
            >
              &lt;
            </button>

            {/* Pages */}
            {Array.from({ length: totalPages }, (_, i) => (
              <button
                key={i}
                onClick={() => setPage(i)}
                className={`border border-gray-300 px-3 py-1 ${
                  i === page
                    ? "bg-[#238D94] text-white"
                    : "bg-white text-gray-700 hover:bg-gray-50"
                }`}
              >
                {i + 1}
              </button>
            ))}

            {/* Next */}
            <button
              onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
              disabled={page === totalPages - 1}
              className="rounded-r-md border border-gray-300 bg-white px-3 py-1 text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              title={t({ id: "admin_services.pagination.next", message: "Page suivante" })}
            >
              &gt;
            </button>
          </nav>
        </div>}
      </div>

      {/* Modal Add/Edit */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white border-2 border-teal-600 rounded-lg shadow-lg w-full max-w-2xl p-6 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center rounded-full bg-teal-600 text-white text-xl hover:bg-teal-700"
              title={t({ id: "admin_services.close", message: "Fermer" })}
            >
              ×
            </button>
            <h3 className="text-xl font-bold text-[#238D94] mb-4">
              {editingService ? 
                <Trans id="admin_services.modal.edit_title">Modifier le service CMS</Trans> : 
                <Trans id="admin_services.modal.add_title">Ajouter un service au CMS</Trans>
              }
            </h3>

            {/* Dropdown */}
            <div className="mb-4">
              <label className="block font-medium mb-2">
                <Trans id="admin_services.modal.select_service">Select a Service</Trans>
              </label>
              <div className="relative">
                <button
                  className="w-full p-2 border rounded flex justify-between items-center"
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                >
                  <span>
                    {selectedService ? selectedService.title : t({ id: "admin_services.modal.choose_service", message: "Choose a service..." })}
                  </span>
                  <ChevronDown size={18} className={dropdownOpen ? "rotate-180" : ""} />
                </button>
                {dropdownOpen && (
                  <div className="absolute z-10 w-full mt-1 bg-white border rounded shadow-lg max-h-60 overflow-y-auto">
                    {allServices.map((service) => (
                      <div
                        key={service.id}
                        className="p-2 hover:bg-gray-100 cursor-pointer"
                        onClick={() => {
                          setSelectedService(service);
                          setDropdownOpen(false);
                          setOrder(service.displayOrder || 1);
                        }}
                      >
                        {service.title}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Display Order */}
            <div className="mb-4">
              <label className="block font-medium mb-2">
                <Trans id="admin_services.modal.display_order">Display Order</Trans>
              </label>
              <input
                type="number"
                min={1}
                max={allServices.length + 1}
                value={order}
                onChange={(e) => setOrder(Number(e.target.value))}
                className="w-full p-2 border rounded"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-100 transition"
              >
                <Trans id="admin_services.cancel">Cancel</Trans>
              </button>
              <button
                onClick={handleSubmit}
                disabled={!selectedService}
                className="px-4 py-2 border border-teal-600 bg-teal-600 text-white rounded flex items-center gap-1 hover:bg-teal-50 transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Pencil className="text-[#687778]" size={16} /> 
                {editingService ? 
                  <Trans id="admin_services.save">Save</Trans> : 
                  <Trans id="admin_services.create_service">Create Service</Trans>
                }
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Suppression */}
      {showDeleteModal && currentDeleteService && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white border-2 border-teal-600 rounded-lg shadow-lg w-full max-w-md p-6 text-center relative">
            <button
              onClick={() => setShowDeleteModal(false)}
              className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center rounded-full bg-teal-600 text-white text-xl hover:bg-teal-700"
              title={t({ id: "admin_services.close", message: "Fermer" })}
            >
              ×
            </button>
            <h3 className="text-lg font-bold mb-4">
              <Trans id="admin_services.delete_modal.title">Supprimer ce service ?</Trans>
            </h3>
            <p className="text-gray-600 mb-6">{currentDeleteService.title}</p>
            <div className="flex justify-center gap-4">
              <button
                onClick={handleDelete}
                className="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-00 transition"
              >
                <Trans id="admin_services.delete_modal.confirm">Oui</Trans>
              </button>
              <button
                onClick={() => setShowDeleteModal(false)}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition"
              >
                <Trans id="admin_services.delete_modal.cancel">Annuler</Trans>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
