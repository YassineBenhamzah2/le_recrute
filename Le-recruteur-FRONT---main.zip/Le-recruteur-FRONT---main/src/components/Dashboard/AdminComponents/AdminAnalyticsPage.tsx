import {
  Activity,
  BarChart3,
  Briefcase,
  Clock,
  Copy,
  FileSpreadsheet,
  Globe,
  Hourglass,
  LayoutDashboard,
  MapPin,
  MonitorSmartphone,
  MousePointerClick,
  RefreshCw,
  Search,
  Shrink,
} from "lucide-react";
import React, { useCallback, useEffect, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  exportAnalyticsToCSV,
  getDashboardAnalytics,
  getRecruitmentActivity,
  getWebInteractions,
  getUserDistribution,
  getGAPagePathData,
  getGAEventDistribution,
  clearAnalyticsCache,
} from "../../../lib/network/analyticsApi";
import {
  AnalyticsDashboardData,
  AnalyticsQuery,
  WebInteractionData,
  RecruitmentActivity,
  UserDistribution,
  GAPagePathData,
  GAEventDistribution,
} from "../../../lib/types/analytics";
import { toast } from "sonner";
import { Trans, t } from "@lingui/macro";

const AdminAnalyticsPage: React.FC = () => {
  // State for analytics data
  const [analyticsData, setAnalyticsData] =
    useState<AnalyticsDashboardData | null>(null);
  const [webInteractionData, setWebInteractionData] =
    useState<WebInteractionData | null>(null);
  const [userDistribution, setUserDistribution] = useState<UserDistribution[]>(
    []
  );
  const [pagePathData, setPagePathData] = useState<GAPagePathData[]>([]);
  const [eventDistributionData, setEventDistributionData] = useState<
    GAEventDistribution[]
  >([]);
  const [recruitmentActivity, setRecruitmentActivity] =
    useState<RecruitmentActivity | null>(null);
  const [loading, setLoading] = useState(true);
  const [exportingCsv, setExportingCsv] = useState(false);
  const [dateRange, setDateRange] = useState<{
    startDate: string;
    endDate: string;
  }>({
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
      .toISOString()
      .split("T")[0], // 30 days ago
    endDate: new Date().toISOString().split("T")[0], // Today
  });

  // Load analytics data from the API using useCallback
  const loadAnalyticsData = useCallback(
    async (clearCache = false) => {
      setLoading(true);
      try {
        const query: AnalyticsQuery = {
          startDate: dateRange.startDate,
          endDate: dateRange.endDate,
        };

        try {
          // Clear the cache first when manually refreshing data
          if (clearCache) {
            await clearAnalyticsCache();
          }

          // Fetch all data in parallel for better performance
          const [
            dashboardData,
            interactions,
            userDistData,
            pagePathsData,
            eventDistData,
            recruitmentData,
          ] = await Promise.all([
            getDashboardAnalytics(query),
            getWebInteractions(query),
            getUserDistribution(query),
            getGAPagePathData(query),
            getGAEventDistribution(query),
            getRecruitmentActivity(query),
          ]);

          // Set the fetched data
          setAnalyticsData(dashboardData.data);
          setWebInteractionData(interactions.data);
          setUserDistribution(userDistData.data.userDistribution);
          setPagePathData(pagePathsData.data);
          setEventDistributionData(eventDistData.data);
          setRecruitmentActivity(recruitmentData.data.recruitmentActivity);

          // Show success message
          toast.success("Analytics data refreshed successfully");
        } catch (apiError) {
          console.error("API data fetch failed:", apiError);
          toast.error("Failed to load analytics data. Please try again later.");
        }
      } catch (error) {
        console.error("Error loading analytics data:", error);
      } finally {
        setLoading(false);
      }
    },
    [dateRange]
  );

  useEffect(() => {
    loadAnalyticsData();
  }, [loadAnalyticsData]);

  const formatPercentage = (value: number) => `${value.toFixed(1)}%`;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-teal-500 border-t-transparent mb-4"></div>
          <p className="text-gray-600 text-lg">
            <Trans id="analytics.loading">Loading analytics...</Trans>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-r from-teal-600 via-teal-700 to-cyan-600 text-white rounded-2xl p-8 shadow-xl">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-white to-teal-100 bg-clip-text text-transparent">
                <Trans id="analytics.title">Analytics Dashboard</Trans>
              </h1>
              <p className="text-teal-100 text-lg">
                <Trans id="analytics.description">
                  Monitor global platform performance, recruitment activity, and
                  user engagement in real time
                </Trans>
              </p>
              <div className="mt-4">
                <div className="inline-flex items-center bg-white/20 rounded-lg px-3 py-1 text-sm">
                  <Clock size={14} className="mr-1" />
                  <Trans id="analytics.last_updated">Last updated:</Trans>{" "}
                  {new Date().toLocaleString()}
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <div className="flex items-center bg-white/20 rounded-lg p-2">
                <div>
                  <label className="block text-xs text-teal-100 mb-1">
                    <Trans id="analytics.start_date">Start Date</Trans>
                  </label>
                  <input
                    type="date"
                    value={dateRange.startDate}
                    onChange={(e) =>
                      setDateRange({ ...dateRange, startDate: e.target.value })
                    }
                    placeholder="YYYY-MM-DD"
                    className="bg-transparent border border-white/30 rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-white/50"
                  />
                </div>
                <div className="ml-2">
                  <label className="block text-xs text-teal-100 mb-1">
                    <Trans id="analytics.end_date">End Date</Trans>
                  </label>
                  <input
                    type="date"
                    value={dateRange.endDate}
                    onChange={(e) =>
                      setDateRange({ ...dateRange, endDate: e.target.value })
                    }
                    placeholder="YYYY-MM-DD"
                    className="bg-transparent border border-white/30 rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-white/50"
                  />
                </div>
              </div>
              <button
                onClick={() => loadAnalyticsData(true)}
                className="bg-white text-teal-700 rounded-lg px-4 py-2 text-sm font-medium hover:bg-teal-50 transition-colors"
              >
                <Trans id="analytics.refresh_data">Refresh Data</Trans>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Platform Engagement Section - 8 cartes métriques */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
          <Activity className="text-teal-600" size={28} />
          <Trans id="analytics.platform_engagement">Platform Engagement</Trans>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          {/* Total Visits */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Shrink className="text-[#238D94]" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.total_visits",
                  message: "Total Visits",
                })}
              </span>
            </div>
            <div className="text-3xl font-bold text-[#238D94] mb-1">
              {analyticsData?.platformEngagement?.uniqueVisitors?.toLocaleString() ||
                webInteractionData?.totalApiCalls?.toLocaleString() ||
                "-"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.unique_visitors">
                Unique platform visitors
              </Trans>
            </p>
          </div>

          {/* Avg Session Duration */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <Hourglass className="text-[#238D94]" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.avg_session",
                  message: "Avg Session Duration",
                })}
              </span>
            </div>
            <div className="text-3xl font-bold text-[#238D94] mb-1">
              {analyticsData?.platformEngagement?.averageSessionDuration || "-"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.avg_time">
                Average time per session
              </Trans>
            </p>
          </div>

          {/* Most Active Hour */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-purple-100 p-3 rounded-lg">
                <Clock className="text-[#238D94]" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.most_active",
                  message: "Most Active Hour",
                })}
              </span>
            </div>
            <div className="text-2xl font-bold text-[#238D94] mb-1">
              {analyticsData?.platformEngagement?.peakActivityWindow || "-"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.peak_activity">
                Peak activity window
              </Trans>
            </p>
          </div>

          {/* Returning Users */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-teal-100 p-3 rounded-lg">
                <RefreshCw className="text-[#238D94]" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.returning_users",
                  message: "Returning Users",
                })}
              </span>
            </div>
            <div className="text-3xl font-bold text-[#238D94] mb-1">
              {analyticsData?.platformEngagement?.returningUsers
                ? `${analyticsData.platformEngagement.returningUsers}%`
                : "-"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.active_job_seekers">
                Active job seekers
              </Trans>
            </p>
          </div>
        </div>

        {/* Deuxième ligne de 4 cartes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Total Clicks */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-orange-100 p-3 rounded-lg">
                <MousePointerClick className="text-[#238D94]" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.total_clicks",
                  message: "Total Clicks",
                })}
              </span>
            </div>
            <div className="text-3xl font-bold text-[#238D94] mb-1">
              {webInteractionData?.totalApiCalls?.toLocaleString() || "-"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.user_interactions">
                User interactions
              </Trans>
            </p>
          </div>

          {/* Pages per Session */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-indigo-100 p-3 rounded-lg">
                <Copy className="text-[#238D94]" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.pages_per_session",
                  message: "Pages Per Session",
                })}
              </span>
            </div>
            <div className="text-3xl font-bold text-[#238D94] mb-1">
              {analyticsData?.platformEngagement?.averagePageViews?.toFixed(
                1
              ) || "-"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.avg_pages_viewed">
                Average pages viewed
              </Trans>
            </p>
          </div>

          {/* Desktop vs Mobile */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-pink-100 p-3 rounded-lg">
                <MonitorSmartphone className="text-[#238D94]" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.device_distribution",
                  message: "Device Distribution",
                })}
              </span>
            </div>
            <div className="text-lg font-bold text-[#238D94] mb-1">
              {analyticsData?.platformEngagement?.deviceDistribution
                ? `${analyticsData.platformEngagement.deviceDistribution.desktop}% Desktop • ${analyticsData.platformEngagement.deviceDistribution.mobile}% Mobile`
                : "-"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.device_type_breakdown">
                Device type breakdown
              </Trans>
            </p>
          </div>

          {/* Search Queries */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-cyan-100 p-3 rounded-lg">
                <Search className="text-[#238D94]" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.search_queries",
                  message: "Search Queries Made",
                })}
              </span>
            </div>
            <div className="text-3xl font-bold text-[#238D94] mb-1">
              {webInteractionData?.searchInteractions?.toLocaleString() || "-"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.daily_searches">
                Daily searches made
              </Trans>
            </p>
          </div>
        </div>
      </div>

      {/* Recruitment Activity Section */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
          <Briefcase className="text-teal-600" size={28} />
          <Trans id="analytics.recruitment_activity">
            Recruitment Activity
          </Trans>
        </h2>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          {/* Total Jobs */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Briefcase className="text-blue-600" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.total_jobs",
                  message: "Total Jobs",
                })}
              </span>
            </div>
            <div className="text-3xl font-bold text-blue-600 mb-1">
              {recruitmentActivity?.totalJobsPosted?.toLocaleString() || "0"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.jobs_posted">
                Jobs posted on the platform
              </Trans>
            </p>
          </div>

          {/* Total Applications */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-pink-100 p-3 rounded-lg">
                <FileSpreadsheet className="text-pink-600" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.applications",
                  message: "Applications",
                })}
              </span>
            </div>
            <div className="text-3xl font-bold text-pink-600 mb-1">
              {recruitmentActivity?.totalApplications?.toLocaleString() || "0"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.total_applications">
                Total applications received
              </Trans>
            </p>
          </div>

          {/* Application Ratio */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-teal-100 p-3 rounded-lg">
                <Activity className="text-teal-600" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.app_job_ratio",
                  message: "App/Job Ratio",
                })}
              </span>
            </div>
            <div className="text-3xl font-bold text-teal-600 mb-1">
              {recruitmentActivity?.applicationToJobRatio?.toFixed(1) || "0"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.applications_per_job">
                Applications per job
              </Trans>
            </p>
          </div>

          {/* Most Active Category */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-purple-100 p-3 rounded-lg">
                <LayoutDashboard className="text-purple-600" size={24} />
              </div>
              <span className="text-xs font-medium text-[#6B7280] bg-gray-100 px-2 py-1 rounded-full">
                {t({
                  id: "analytics.metrics.top_category",
                  message: "Top Category",
                })}
              </span>
            </div>
            <div className="text-xl font-bold text-purple-600 mb-1">
              {recruitmentActivity?.mostActiveCategory || "None"}
            </div>
            <p className="text-[#6B7280] text-sm font-bold">
              <Trans id="analytics.metrics.most_active_job_category">
                Most active job category
              </Trans>
            </p>
          </div>
        </div>

        {/* Chart Section */}
        <div className="grid grid-cols-1 gap-6 mb-6">
          {/* Monthly Trends Chart */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              <Trans id="analytics.monthly_trends">
                Monthly Recruitment Trends
              </Trans>
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={recruitmentActivity?.monthlyTrends || []}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis
                  dataKey="month"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#6B7280", fontSize: 12 }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#6B7280", fontSize: 12 }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                    boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
                  }}
                />
                <Bar
                  dataKey="applications"
                  fill="#EC4899"
                  radius={[4, 4, 0, 0]}
                  name={t({
                    id: "analytics.chart.applications_submitted",
                    message: "Applications submitted",
                  })}
                />
                <Bar
                  dataKey="jobs"
                  fill="#3B82F6"
                  radius={[4, 4, 0, 0]}
                  name={t({
                    id: "analytics.chart.jobs_posted",
                    message: "Jobs posted",
                  })}
                />
              </BarChart>
            </ResponsiveContainer>
            <div className="flex justify-center mt-4 space-x-6">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-pink-400 rounded"></div>
                <span className="text-sm text-gray-600">
                  <Trans id="analytics.legend.applications_submitted">
                    Applications submitted
                  </Trans>
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-400 rounded"></div>
                <span className="text-sm text-gray-600">
                  <Trans id="analytics.legend.jobs_posted">Jobs posted</Trans>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* User Distribution by Location */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
          <MapPin className="text-teal-600" size={28} />
          <Trans id="analytics.user_distribution">
            User Distribution by Location
          </Trans>
        </h2>

        <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-4 px-4 font-semibold text-gray-800">
                    <Trans id="analytics.table.region_city">
                      Region / City
                    </Trans>
                  </th>
                  <th className="text-left py-4 px-4 font-semibold text-gray-800">
                    <Trans id="analytics.table.registered_users">
                      Registered Users
                    </Trans>
                  </th>
                  <th className="text-left py-4 px-4 font-semibold text-gray-800">
                    <Trans id="analytics.table.percentage">
                      % of Total Users
                    </Trans>
                  </th>
                  <th className="text-left py-4 px-4 font-semibold text-gray-800">
                    <Trans id="analytics.table.most_common_role">
                      Most Common Role
                    </Trans>
                  </th>
                </tr>
              </thead>
              <tbody>
                {userDistribution.length > 0 ? (
                  userDistribution.map((location, index) => (
                    <tr
                      key={index}
                      className="border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200"
                    >
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center">
                            <Globe className="text-teal-600" size={16} />
                          </div>
                          <div>
                            <div className="font-medium text-gray-900">
                              {location.region}
                            </div>
                            {location.city !== location.region && (
                              <div className="text-sm text-gray-600">
                                {location.city}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <span className="font-semibold text-gray-900">
                          {location.registeredUsers.toLocaleString()}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-teal-600 h-2 rounded-full transition-all duration-500"
                              style={{
                                width: `${Math.min(
                                  location.percentageOfTotal * 2,
                                  100
                                )}%`,
                              }}
                            ></div>
                          </div>
                          <span className="font-medium text-gray-800 min-w-[50px]">
                            {formatPercentage(location.percentageOfTotal)}
                          </span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                          {location.mostCommonRole}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={4}
                      className="py-8 px-4 text-center text-gray-500"
                    >
                      <div className="flex flex-col items-center">
                        <MapPin className="text-gray-400 mb-2" size={24} />
                        <p>
                          <Trans id="analytics.no_location_data">
                            No location data available
                          </Trans>
                        </p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Total row */}
          {userDistribution.length > 0 && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="flex justify-between items-center text-lg font-semibold">
                <span className="text-gray-900">
                  <Trans id="analytics.total">Total</Trans>
                </span>
                <span className="text-teal-600">
                  {userDistribution
                    .reduce(
                      (sum, location) => sum + location.registeredUsers,
                      0
                    )
                    .toLocaleString()}{" "}
                  <Trans id="analytics.users">utilisateurs</Trans>
                </span>
                <span className="text-gray-600">100%</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Page Path and Screen Class Analytics */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
          <LayoutDashboard className="text-teal-600" size={28} />
          <Trans id="analytics.page_path_analytics">Page Path Analytics</Trans>
        </h2>
        <p className="text-gray-600 mb-6">
          <Trans id="analytics.page_path_description">
            User engagement by page and screen class
          </Trans>
        </p>

        <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left py-4 px-6 font-semibold text-gray-800">
                    #
                  </th>
                  <th className="text-left py-4 px-6 font-semibold text-gray-800">
                    <Trans id="analytics.table.page_path">Page Path</Trans>
                  </th>
                  <th className="text-left py-4 px-6 font-semibold text-gray-800">
                    <Trans id="analytics.table.active_users">
                      Active Users
                    </Trans>
                  </th>
                  <th className="text-left py-4 px-6 font-semibold text-gray-800">
                    <Trans id="analytics.table.views">Views</Trans>
                  </th>
                </tr>
              </thead>
              <tbody>
                {pagePathData.length > 0 ? (
                  pagePathData.map((page, index) => (
                    <tr
                      key={index}
                      className="border-b border-gray-100 hover:bg-gray-50 transition-all duration-200"
                    >
                      <td className="py-4 px-6">
                        <div className="flex items-center">
                          <span className="font-medium text-gray-900">
                            {index + 1}
                          </span>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                            <LayoutDashboard size={16} />
                          </div>
                          <div>
                            <span className="font-medium text-gray-900">
                              {page.pagePath}
                            </span>
                            {page.screenClass && (
                              <div className="text-xs text-gray-500 mt-1">
                                {page.screenClass}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span className="font-semibold text-gray-900">
                          {page.activeUsers}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-gray-900">
                            {page.views}
                          </span>
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-teal-600 h-2 rounded-full transition-all duration-500"
                              style={{
                                width: `${Math.min(
                                  (page.views /
                                    Math.max(
                                      ...pagePathData.map((p) => p.views)
                                    )) *
                                    100,
                                  100
                                )}%`,
                              }}
                            ></div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={4}
                      className="py-8 px-4 text-center text-gray-500"
                    >
                      <div className="flex flex-col items-center">
                        <LayoutDashboard
                          className="text-gray-400 mb-2"
                          size={24}
                        />
                        <p>
                          <Trans id="analytics.no_page_path_data">
                            No page path data available
                          </Trans>
                        </p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Event Distribution Analytics */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
          <BarChart3 className="text-teal-600" size={28} />
          <Trans id="analytics.event_distribution">Event Distribution</Trans>
        </h2>
        <p className="text-gray-600 mb-6">
          <Trans id="analytics.event_distribution_description">
            Distribution of tracked events across the platform
          </Trans>
        </p>

        <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left py-4 px-6 font-semibold text-gray-800">
                    <Trans id="analytics.table.event_name">Event Name</Trans>
                  </th>
                  <th className="text-left py-4 px-6 font-semibold text-gray-800">
                    <Trans id="analytics.table.count">Count</Trans>
                  </th>
                  <th className="text-left py-4 px-6 font-semibold text-gray-800">
                    <Trans id="analytics.table.distribution">
                      Distribution
                    </Trans>
                  </th>
                </tr>
              </thead>
              <tbody>
                {eventDistributionData.length > 0 ? (
                  eventDistributionData.map((event, index) => (
                    <tr
                      key={index}
                      className="border-b border-gray-100 hover:bg-gray-50 transition-all duration-200"
                    >
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                            <Activity size={16} />
                          </div>
                          <span className="font-medium text-gray-900">
                            {event.eventName}
                          </span>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span className="font-semibold text-gray-900">
                          {event.count.toLocaleString()}
                        </span>
                      </td>
                      <td className="py-4 px-6 w-1/3">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                              style={{
                                width: `${Math.min(
                                  (event.count /
                                    Math.max(
                                      ...eventDistributionData.map(
                                        (e) => e.count
                                      )
                                    )) *
                                    100,
                                  100
                                )}%`,
                              }}
                            ></div>
                          </div>
                          <span className="font-medium text-gray-800 min-w-[50px] text-right">
                            {(
                              (event.count /
                                eventDistributionData.reduce(
                                  (sum, e) => sum + e.count,
                                  0
                                )) *
                              100
                            ).toFixed(1)}
                            %
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={3}
                      className="py-8 px-4 text-center text-gray-500"
                    >
                      <div className="flex flex-col items-center">
                        <Activity className="text-gray-400 mb-2" size={24} />
                        <p>
                          <Trans id="analytics.no_event_data">
                            No event distribution data available
                          </Trans>
                        </p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <p className="text-gray-600 text-sm">
              <Trans id="analytics.footer.data_updated">
                Analytics data is updated every 24 hours. Last refresh:
              </Trans>{" "}
              {analyticsData?.lastUpdated
                ? new Date(analyticsData.lastUpdated).toLocaleString()
                : new Date().toLocaleString()}
            </p>
            <p className="text-gray-400 text-xs mt-1">
              <Trans id="analytics.footer.data_source">
                Data based on actual user interactions and analytics from our
                servers.
              </Trans>
            </p>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={async () => {
                if (exportingCsv) return; // Prevent multiple clicks

                try {
                  setExportingCsv(true);
                  const csvData = await exportAnalyticsToCSV({
                    startDate: dateRange.startDate,
                    endDate: dateRange.endDate,
                  });

                  // Create a download link for the CSV data
                  const url = window.URL.createObjectURL(csvData);
                  const link = document.createElement("a");
                  link.href = url;
                  link.download = `analytics_${dateRange.startDate}_to_${dateRange.endDate}.csv`;
                  document.body.appendChild(link);
                  link.click();

                  // Cleanup
                  document.body.removeChild(link);
                  window.URL.revokeObjectURL(url);

                  // Show success message
                  toast.success("Analytics data exported successfully");
                } catch (error) {
                  console.error("Error exporting CSV:", error);
                  toast.error(
                    "Failed to export analytics data. Please try again."
                  );
                } finally {
                  setExportingCsv(false);
                }
              }}
              disabled={exportingCsv}
              className={`flex items-center gap-2 text-sm font-medium ${
                exportingCsv
                  ? "text-gray-400 cursor-not-allowed"
                  : "text-teal-600 hover:text-teal-700"
              }`}
            >
              {exportingCsv ? (
                <div className="w-4 h-4 border-2 border-t-transparent border-teal-600 rounded-full animate-spin mr-1" />
              ) : (
                <FileSpreadsheet size={16} />
              )}
              {exportingCsv
                ? t({ id: "analytics.exporting", message: "Exporting..." })
                : t({ id: "analytics.export_csv", message: "Export to CSV" })}
            </button>
            <button
              onClick={() => loadAnalyticsData(true)}
              className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-2 rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              <Activity size={18} />
              <Trans id="analytics.refresh_data">Refresh Data</Trans>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminAnalyticsPage;
