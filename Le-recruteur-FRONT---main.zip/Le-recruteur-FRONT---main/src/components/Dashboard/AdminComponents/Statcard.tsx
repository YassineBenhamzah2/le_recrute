import { AreaChart, Area, ResponsiveContainer } from "recharts";
import { ReactNode } from "react";

interface StatCardProps {
  icon: ReactNode;
  title: string;
  value: number;
  trend: string;
  trendColor: "green" | "blue" | "red";
  chartData: { value: number }[];
  chartColor: string;
}

export default function StatCard({
  icon,
  title,
  value,
  trend,
  trendColor,
  chartData,
  chartColor,
}: StatCardProps) {
  return (
    <div className="bg-white rounded-2xl shadow p-4 w-full max-w-xs">
      <div className="flex items-center justify-between">
        <div className="bg-teal-700 p-2 rounded-xl text-teal-100">
          {icon}
        </div>
        <div className="text-gray-400">•••</div>
      </div>

      <div className="mt-4">
        <h2 className="text-3xl font-bold">{value}</h2>
        <p className="text-gray-500 text-sm">{title}</p>
        <p className={`text-sm mt-1 ${trendColor === "green" ? "text-green-600" : "text-red-600"}`}>
          {trend}
        </p>
      </div>

      <div className="h-12 mt-3">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <Area
              type="monotone"
              dataKey="value"
              stroke={chartColor}
              fill={chartColor}
              strokeWidth={2}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
