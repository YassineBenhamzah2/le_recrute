import { useState, useEffect } from 'react';
import { useDebounce } from 'use-debounce';
import { X, Search, UserPlus, UserMinus } from 'lucide-react';
import { Recruiter, Candidate, PaginatedResponse } from '@/lib/types/cvtheque';
import { cvthequeService } from '@/lib/network/cvtheque';
import { AssignCandidateModal } from './AssignCandidateModalCvTc';
import { CandidatesTable } from './CandidatesTableCvTc';
import { ServerPagination } from './ServerPagination';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

const ITEMS_PER_PAGE = 8;

interface RecruiterCandidatesModalProps {
  isOpen: boolean;
  recruiter: Recruiter;
  onClose: () => void;
}

export default function RecruiterCandidatesModal({ isOpen, recruiter, onClose }: RecruiterCandidatesModalProps) {
  const [page, setPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [paginatedResponse, setPaginatedResponse] = useState<PaginatedResponse<Candidate> | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCandidates, setSelectedCandidates] = useState<number[]>([]);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [isRemoving, setIsRemoving] = useState(false);
  const { toast } = useToast();

  const [refetchTrigger, setRefetchTrigger] = useState(0);

  const [debouncedSearchTerm] = useDebounce(searchTerm, 500);

  useEffect(() => {
    if (isOpen) {
      const fetchAssignedCandidates = async () => {
        setIsLoading(true);
        try {
          const response = await cvthequeService.getAssignedCandidates({
            recruiterId: recruiter.id,
            page,
            size: ITEMS_PER_PAGE,
            search: debouncedSearchTerm
          });
          setPaginatedResponse(response);
        } catch (error) {
          console.error("Failed to fetch assigned candidates:", error);
        } finally {
          setIsLoading(false);
        }
      };
      fetchAssignedCandidates();
    }
  }, [isOpen, recruiter.id, page, refetchTrigger, debouncedSearchTerm]);

  const assignedCandidates = paginatedResponse?.data || [];
  const totalPages = paginatedResponse?.totalPages || 0;
  const currentPage = paginatedResponse?.currentPage || 1;

  const handleActionSuccess = () => {
    setRefetchTrigger(prev => prev + 1);
  };

  const handleRemoveCandidates = async () => {
    if (selectedCandidates.length === 0) return;
    setIsRemoving(true);
    try {
        await cvthequeService.removeCandidatesFromRecruiter(recruiter.id, selectedCandidates);
        toast({ title: "Succès", description: `${selectedCandidates.length} candidat(s) retiré(s) de la CVthèque.` });
        setSelectedCandidates([]);
        handleActionSuccess();
    } catch (error: any) {
        toast({ title: "Erreur", description: error.message || "La suppression a échoué.", variant: "destructive" });
    } finally {
        setIsRemoving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-7xl max-h-[90vh] overflow-hidden flex flex-col">
          <div className="bg-gradient-to-r from-[#238D94] to-[#1a6b72] text-white p-6 flex-shrink-0">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Candidats de {recruiter.prenom} {recruiter.nom}</h2>
              <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-lg"><X size={20} /></button>
            </div>
          </div>

          <div className="p-6 border-b bg-white flex justify-between items-center flex-shrink-0">
            <div className="relative">
              <Input 
                type="text" 
                placeholder="Rechercher un candidat..." 
                className="pl-10 w-64"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
            </div>
            <div className="flex items-center space-x-2">
              {selectedCandidates.length > 0 && (
                <button
                  onClick={handleRemoveCandidates}
                  disabled={isRemoving}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 flex items-center space-x-2 text-sm disabled:opacity-50"
                >
                  <UserMinus size={16} />
                  <span>{isRemoving ? 'Suppression...' : `Retirer (${selectedCandidates.length})`}</span>
                </button>
              )}
              <button onClick={() => setShowAssignModal(true)} className="px-4 py-2 bg-gradient-to-r from-[#238D94] to-[#1a6b72] text-white rounded-lg hover:from-[#1a6b72] hover:to-[#238D94] flex items-center space-x-2 text-sm">
                <UserPlus size={16} /><span>Ajouter Candidat</span>
              </button>
            </div>
          </div>

          {/* --- THIS IS THE CORRECTED LAYOUT --- */}
          {/* We add a container that handles scrolling and padding */}
          <div className="flex-grow overflow-y-auto p-6">
            <div className="border rounded-lg overflow-hidden">
                <CandidatesTable
                  candidates={assignedCandidates}
                  isLoading={isLoading}
                  selectedCandidateIds={selectedCandidates}
                  onSelectionChange={setSelectedCandidates}
                />
            </div>
          </div>

          <div className="p-4 border-t flex-shrink-0">
            <ServerPagination currentPage={currentPage} totalPages={totalPages} onPageChange={setPage} />
          </div>
        </div>
      </div>
      
      <AssignCandidateModal
        isOpen={showAssignModal}
        onClose={() => setShowAssignModal(false)}
        recruiterId={recruiter.id}
        recruiterName={`${recruiter.prenom} ${recruiter.nom}`}
        onAssignSuccess={handleActionSuccess}
      />
    </>
  );
}