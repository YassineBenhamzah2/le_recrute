import React from 'react';
import { Card } from '@/components/ui/card';
import { Trans,t } from "@lingui/macro";
import { i18n } from '@lingui/core';
import { settings } from "@/lib/settings/main";

interface Experience {
  id: number;
  position: string;
  company: Company ;
  industry : Industry ;
  startDate : string ;
  endDate : string ;
  current : boolean ;
  location: string;
  workplaceRating: string;
  description: string;
}
interface Company {
  id : number ;
  name : string ;
  logo : string ;
}
interface Industry {
  id : number ;
  name : string ;
}


interface CandidateViewExperiencesProps {
  experiences : Experience[] ;
}

const CandidateViewExperiences: React.FC<CandidateViewExperiencesProps> = ({ experiences }) => {

  
  function formatDate(dateString: string): string {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString(i18n.locale, { year: "numeric", month: "short" });
  }

  return (
    <Card className="p-6 bg-white shadow-sm">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6"><Trans>Work Experience</Trans></h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {experiences.map((experience) => (
          <div key={experience.id} className="space-y-2">

            <h3 className="text-teal-600 font-bold text-lg">
              {experience.position}
            </h3>

            <p className="text-sm text-gray-700 font-medium flex items-center gap-2">
                <img
                  src={experience.company.logo}
                  alt={experience.company.logo}
                  onError={(e) => {
                    e.currentTarget.src = settings.DEFAULT_COMPANY_AVATAR ;
                  }}
                  className="w-7 h-7 rounded-full object-cover border border-gray-200"
                />
              {experience.company.name}
            </p>
           
            <p className="text-sm text-gray-500">
              {formatDate(experience.startDate)} – {experience.current ? t`Present` : formatDate(experience.endDate)}

            </p>
            {experience.description && (
              <p className="text-sm text-gray-700 mt-2">
                {experience.description}
              </p>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
};

export default CandidateViewExperiences ;
