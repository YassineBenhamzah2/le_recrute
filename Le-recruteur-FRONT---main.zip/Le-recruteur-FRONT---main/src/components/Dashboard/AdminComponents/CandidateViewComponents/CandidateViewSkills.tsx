import React from 'react';
import { Card } from '@/components/ui/card';
import { Trans, t } from '@lingui/macro';

interface Skill {
  id : number ,
  name: string;
  level: number;
  type: 'SOFTSKILL' | 'HARDSKILL';
}

interface CandidateViewSkillsProps {
  skills : Skill[] ;
}

const CandidateViewSkills: React.FC<CandidateViewSkillsProps> = ({ skills }) => {


  const hardSkills = skills.filter((s) => s.type === "HARDSKILL");
  const softSkills = skills.filter((s) => s.type === "SOFTSKILL");


  return (
    <Card className="p-6 bg-white shadow-sm">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6"><Trans>Professional Skills</Trans></h2>

      {hardSkills.length > 0 && (
        <div className="mb-8">
          <h3 className="text-xl font-semibold text-gray-800 mb-4"><Trans>Hard Skills</Trans></h3>
          <div className="space-y-6">
            {hardSkills.map((skill) => (
              <div key={skill.id} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-gray-900">{skill.name}</span>
                  <span className="text-sm text-gray-600">({skill.level}/100)</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-gray-900 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}



      {softSkills.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold text-gray-800 mb-4"><Trans>Soft Skills</Trans></h3>
          <div className="space-y-6">
            {softSkills.map((skill) => (
              <div key={skill.id} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-gray-900">{skill.name}</span>
                  <span className="text-sm text-gray-600">({skill.level}/100)</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-teal-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      
    </Card>
  );
};

export default CandidateViewSkills;
