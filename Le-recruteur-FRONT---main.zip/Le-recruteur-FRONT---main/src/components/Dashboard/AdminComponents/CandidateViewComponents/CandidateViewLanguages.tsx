import React from 'react';
import { Card } from '@/components/ui/card';
import { Trans, t } from '@lingui/macro';

interface Language {
  id : number ,
  name : String ,
  level : number
}


interface CandidateViewLanguagesProps{
  languages : Language[] ;
}

const CandidateViewLanguages: React.FC<CandidateViewLanguagesProps> = ({ languages }) => {
  return (
    <Card className="p-6 bg-white shadow-sm">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6"><Trans>Languages</Trans></h2>
      
      <div className="space-y-6">
        {languages.map((language) => (
          <div key={language.id} className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-medium text-gray-900">
                {language.name}
              </span>
              <span className="text-sm text-gray-600">
                ({language.level}/100)
              </span>
            </div>
            
            {/* Progress Bar */}
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gray-900 h-2 rounded-full transition-all duration-300"
                style={{ width: `${language.level}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default CandidateViewLanguages;
