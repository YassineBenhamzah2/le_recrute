import React from "react";
import { Card } from "@/components/ui/card";
import CandidateViewExperiences from "./CandidateViewExperiences";
import CandidateViewEducations from "./CandidateViewEducations";
import CandidateViewSkills from "./CandidateViewSkills";
import CandidateViewLanguages from "./CandidateViewLanguages";
import { Trans } from "@lingui/macro";

interface Experience {
  id: number;
  position: string;
  company: Company;
  industry: Industry;
  startDate: string;
  endDate: string;
  current: boolean;
  location: string;
  workplaceRating: string;
  description: string;
}
interface Company {
  id: number;
  name: string;
  logo: string;
}
interface Industry {
  id: number;
  name: string;
}

interface CertificationItem {
  id: number;
  name: string;
}

interface EducationItem {
  id: number;
  title: string;
  institution: string;
  location: string;
  startedAt: string;
  endedAt: string;
  current: boolean;
}

interface EducationCertifications {
  educations: EducationItem[];
  certifications: CertificationItem[];
}

interface Skill {
  id: number;
  name: string;
  level: number;
  type: "SOFTSKILL" | "HARDSKILL";
}

interface Language {
  id: number;
  name: string;
  level: number;
}

interface CandidateViewDetailsProps {
  overview: string;
  experiences: Experience[];
  educationCertifications: EducationCertifications | null;
  skills: Skill[];
  languages: Language[];
}

const CandidateViewDetails: React.FC<CandidateViewDetailsProps> = ({
  overview,
  experiences,
  educationCertifications,
  skills,
  languages,
}) => {
  return (
    <div className="space-y-8">
      {/* Overview Section */}
      <Card className="p-6 bg-white shadow-sm">
        <div className="flex justify-between items-start mb-4">
          <h2 className="text-2xl font-semibold text-gray-900">
            <Trans id="candidate.view_details.overview_title">Overview</Trans>
          </h2>
        </div>

        <div className="mb-6">
          <p className="text-gray-700 leading-relaxed">{overview}</p>
        </div>
      </Card>

      {/* Work Experience Section */}
      <CandidateViewExperiences experiences={experiences} />
      {educationCertifications &&
        educationCertifications.educations.length > 0 && (
          <CandidateViewEducations educationCerts={educationCertifications} />
        )}

      {/* Professional Skills Section */}
      <CandidateViewSkills skills={skills} />

      {/* Languages Section */}
      <CandidateViewLanguages languages={languages} />
    </div>
  );
};

export default CandidateViewDetails;
