import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  MapPin,
  Mail,
  Linkedin,
  Phone,
  Briefcase,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import { Trans, t } from "@lingui/macro";
import { settings } from "@/lib/settings/main";
import { CandidateInfo } from "@/pages/AdminCandidateView";

interface CandidateViewSidebarProps {
  candidateInfo: CandidateInfo | null;
}

const CandidateViewSidebar: React.FC<CandidateViewSidebarProps> = ({
  candidateInfo,
}) => {
  const [downloadingCV, setDownloadingCV] = useState(false);

  const handleDownloadCV = () => {
    if (!candidateInfo || !candidateInfo.cvUrl) {
      toast.error(
        t({
          id: "candidate.sidebar.no_cv_error",
          message: "No CV available for download.",
        })
      );
      return;
    }

    setDownloadingCV(true);

    try {
      const fileUrl = `${settings.IMG_ADDRESS}${candidateInfo.cvUrl}`;

      const link = document.createElement("a");
      link.href = fileUrl;

      const fileName = `CV_${candidateInfo.firstName}_${candidateInfo.lastName}.pdf`;
      link.setAttribute("download", fileName);

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch {
      toast.error(
        t({
          id: "candidate.sidebar.download_failed",
          message: "Failed to download CV.",
        })
      );
    } finally {
      setDownloadingCV(false);
    }
  };

  return (
    <Card className="p-6 bg-white shadow-sm">
      <div className="space-y-6">
        {/* Profile Image and Basic Info */}
        <div className="text-center">
          <div className="relative mx-auto w-24 h-24 mb-4">
            <img
              src={candidateInfo?.avatar}
              alt={candidateInfo?.firstName}
              className="w-full h-full rounded-full object-cover border-4 border-white shadow-lg"
              onError={(e) => {
                e.currentTarget.src = settings.DEFAULT_USER_AVATAR ;
              }}
            />
          </div>

          <h1 className="text-xl font-semibold text-gray-900 mb-5">
            {candidateInfo?.firstName + " " + candidateInfo?.lastName}
          </h1>

          <div className="flex items-center justify-center gap-2 text-gray-600 mb-3">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">
              {candidateInfo?.city + " , " + candidateInfo?.country}
            </span>
          </div>

          <div className="flex items-center justify-center gap-2 text-gray-600 mb-3">
            <Briefcase className="w-4 h-4" />
            <span className="text-sm">{candidateInfo?.title}</span>
          </div>

          <div className="flex items-center justify-center gap-2 text-gray-600 mb-3">
            <Mail className="w-4 h-4" />
            <a
              href={`mailto:${candidateInfo?.email}`}
              className="text-sm text-blue-600 hover:underline"
            >
              {candidateInfo?.email}
            </a>
          </div>

          <div className="flex items-center justify-center gap-2 text-gray-600 mb-3">
            <Phone className="w-4 h-4" />
            <span className="text-sm">{candidateInfo?.phone}</span>
          </div>

          <div className="flex items-center justify-center gap-2 mb-3">
            <a
              href={candidateInfo?.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:text-blue-800 transition-colors"
            >
              <Linkedin className="w-6 h-6" />
            </a>
          </div>

          <Button
            onClick={handleDownloadCV}
            disabled={downloadingCV}
            className="w-full bg-teal-500 hover:bg-teal-600 text-white font-medium py-2 px-4 rounded-lg flex items-center justify-center gap-2"
          >
            {downloadingCV ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <Trans id="candidate.sidebar.downloading">Downloading...</Trans>
              </>
            ) : (
              <Trans id="candidate.sidebar.download_cv">Download CV</Trans>
            )}
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default CandidateViewSidebar;
