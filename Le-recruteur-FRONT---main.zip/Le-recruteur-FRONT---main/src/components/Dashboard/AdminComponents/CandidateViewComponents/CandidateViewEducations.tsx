import React from 'react';
import { Card } from '@/components/ui/card';
import { Dot } from 'lucide-react';
import { Trans, t } from '@lingui/macro';
import { i18n } from '@lingui/core';


interface CertificationItem {
  id: number;
  name: string;
}


interface EducationItem{
  id: number;
  title: string;
  institution : string;
  location : string ;
  startedAt : string;
  endedAt : string ;
  current : boolean ;

}


interface EducationCertifications {
  educations : EducationItem[], 
  certifications: CertificationItem[]
}


interface CandidateViewEducationsProps{
  educationCerts : EducationCertifications
}

const CandidateViewEducations: React.FC<CandidateViewEducationsProps> = ({ educationCerts }) => {

  function formatDate(dateString: string): string {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString(i18n.locale, { year: "numeric", month: "short" });
  }


  return (
    <Card className="p-6 bg-white shadow-sm">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6"><Trans>Educations</Trans></h2>
      
      <div className="space-y-4">
        {educationCerts?.educations.map((edu) => (
          <div key={edu.id} className="flex items-start space-x-4">
            <div className="flex-shrink-0">
              <div className="w-2 h-2 bg-teal-500 rounded-full mt-2"></div>
            </div>
            <div className="flex-1 space-y-1">
              <h3 className="font-semibold text-gray-900">{edu.title}</h3>
              <p className="text-sm text-gray-600 flex items-center ">
                {edu.institution} <Dot size={20}   /> {edu.location}
              </p>
              <p className="text-xs text-gray-500">
                {formatDate(edu.startedAt)} – {edu.current ? t`present` : formatDate(edu.endedAt)}
              </p>
            </div>
          </div>
        ))}

      </div>


      <h2 className="text-2xl font-semibold text-gray-900 mb-6 mt-8"><Trans>Certifications</Trans></h2>

      {educationCerts?.certifications.length > 0 && (
        
          <ul className="space-y-2">
            {educationCerts.certifications.map((cert) => (
              <li key={cert.id} className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-gray-800">{cert.name}</span>
              </li>
            ))}
          </ul>
        
      )}
      
      
    </Card>
  );
};

export default CandidateViewEducations;
