import { adminService } from "@/lib/network/dashboard/admin";
import { settings } from "@/lib/settings/main";
import { Admin } from "@/lib/types/dashboard/admin";
import { Role } from "@/lib/types/license";
import { i18n } from "@lingui/core";
import { Trans, t } from "@lingui/macro";
import { Eye, EyeOff, Trash2, UploadCloud, X } from "lucide-react";
import React, { useEffect, useRef, useState } from "react";

interface AdminFormProps {
  adminData?: Admin | null;
  onSave: (formData: FormData) => void;
  onCancel: () => void;
}

export default function AdminForm({
  adminData,
  onSave,
  onCancel,
}: AdminFormProps) {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    location: "",
    profile_pic: "",
    role: "",
    status: "active",
    password: "",
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await adminService.getAdminRoles();
        if (response.success) {
          setRoles(response.data);
          if (!formData.role && response.data.length > 0) {
            setFormData((prev) => ({
              ...prev,
              role: response.data[0].id.toString(),
            }));
          }
        }
      } catch (error) {
        console.error("Failed to fetch roles:", error);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    if (adminData) {
      setFormData({
        firstName: adminData.firstname || "",
        lastName: adminData.lastname || "",
        email: adminData.email || "",
        phone: adminData.phone || "",
        location: adminData.location || "",
        role: adminData.role?.id?.toString() || "",
        status: adminData.status || "active",
        profile_pic: adminData.profile_pic || "",
        password: "",
      });

      if (adminData.profile_pic) {
        const isFullUrl = adminData.profile_pic.startsWith("http");
        setPreviewUrl(
          isFullUrl
            ? adminData.profile_pic
            : `${settings.IMG_ADDRESS}${adminData.profile_pic}`
        );
      }
    }
  }, [adminData]);

  useEffect(() => {
    if (imageFile) {
      const objectUrl = URL.createObjectURL(imageFile);
      setPreviewUrl(objectUrl);
      return () => URL.revokeObjectURL(objectUrl);
    }
  }, [imageFile]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();

    const files = e.dataTransfer.files;
    if (files && files[0] && files[0].type.startsWith("image/")) {
      setImageFile(files[0]);
    }
  };

  const validatePassword = (password: string) => {
    const minLength = 8;
    const hasLetter = /[a-zA-Z]/.test(password);
    const hasDigit = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    if (password.length < minLength) {
      return i18n._({
        id: "admin_form.validation.password_min_length",
        message: "Password must contain at least {minLength} characters",
        values: { minLength },
      });
    }
    if (!hasLetter) {
      return t({
        id: "admin_form.validation.password_letter",
        message: "Password must contain at least one letter",
      });
    }
    if (!hasDigit) {
      return t({
        id: "admin_form.validation.password_digit",
        message: "Password must contain at least one digit",
      });
    }
    if (!hasSpecialChar) {
      return t({
        id: "admin_form.validation.password_special",
        message: "Password must contain at least one special character",
      });
    }
    return null;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if ((!adminData || formData.password) && formData.password) {
      const error = validatePassword(formData.password);
      if (error) {
        setPasswordError(error);
        return;
      }
    }

    setPasswordError(null);

    const formDataToSend = new FormData();

    formDataToSend.append("firstname", formData.firstName);
    formDataToSend.append("lastname", formData.lastName);
    formDataToSend.append("email", formData.email);
    formDataToSend.append("phone", formData.phone);
    formDataToSend.append("location", formData.location);
    formDataToSend.append("roleId", formData.role);
    formDataToSend.append("status", formData.status);

    if (!adminData || formData.password) {
      formDataToSend.append("password", formData.password);
    }

    if (imageFile) {
      formDataToSend.append("imageFile", imageFile);
    }

    onSave(formDataToSend);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-xl font-semibold">
              {adminData ? (
                <Trans id="admin_form.header.edit_title">Edit Admin</Trans>
              ) : (
                <Trans id="admin_form.header.add_title">Add New Admin</Trans>
              )}
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              {adminData
                ? t({
                    id: "admin_form.header.edit_description",
                    message: "Update the admin details.",
                  })
                : t({
                    id: "admin_form.header.add_description",
                    message: "Add a new admin to the system.",
                  })}
            </p>
          </div>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-gray-500 p-1 rounded-full hover:bg-gray-100"
            title={t({
              id: "admin_form.header.close_tooltip",
              message: "Close",
            })}
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Profile Image Field */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trans id="admin_form.fields.profile_image.label">
                Profile Image
              </Trans>
            </label>

            <div
              className="relative w-32 h-32 mx-auto border-2 border-dashed border-gray-300 rounded-full flex flex-col items-center justify-center text-center cursor-pointer"
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              // onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />

              {previewUrl ? (
                <div className="relative w-full h-full">
                  <img
                    src={previewUrl}
                    alt={t({
                      id: "admin_form.fields.profile_image.preview_alt",
                      message: "Preview",
                    })}
                    className="w-full h-full object-cover rounded-full"
                  />
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setImageFile(null);
                      setPreviewUrl(null);
                    }}
                    className="absolute top-0 right-0 p-1 bg-red-500 text-white rounded-full"
                    title={t({
                      id: "admin_form.fields.profile_image.remove_tooltip",
                      message: "Remove image",
                    })}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ) : (
                <>
                  <UploadCloud className="mx-auto h-8 w-8 text-gray-400" />
                  <p className="mt-2 text-xs text-gray-600">
                    <span className="text-blue-600">
                      <Trans id="admin_form.fields.profile_image.upload_text">
                        Upload image
                      </Trans>
                    </span>
                  </p>
                </>
              )}
            </div>
          </div>

          {/* First Name Field */}
          <div>
            <label
              htmlFor="firstName"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="admin_form.fields.first_name.label">First Name</Trans>
            </label>
            <input
              id="firstName"
              type="text"
              required
              value={formData.firstName}
              onChange={(e) =>
                setFormData({ ...formData, firstName: e.target.value })
              }
              placeholder={t({
                id: "admin_form.fields.first_name.placeholder",
                message: "Enter first name...",
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Last Name Field */}
          <div>
            <label
              htmlFor="lastName"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="admin_form.fields.last_name.label">Last Name</Trans>
            </label>
            <input
              id="lastName"
              type="text"
              required
              value={formData.lastName}
              onChange={(e) =>
                setFormData({ ...formData, lastName: e.target.value })
              }
              placeholder={t({
                id: "admin_form.fields.last_name.placeholder",
                message: "Enter last name...",
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Email Field */}
          <div>
            <label
              htmlFor="email"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="admin_form.fields.email.label">Email</Trans>
            </label>
            <input
              id="email"
              type="email"
              required
              value={formData.email}
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
              placeholder={t({
                id: "admin_form.fields.email.placeholder",
                message: "Enter email address...",
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Phone Field */}
          <div>
            <label
              htmlFor="phone"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="admin_form.fields.phone.label">Phone</Trans>
            </label>
            <input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) =>
                setFormData({ ...formData, phone: e.target.value })
              }
              placeholder={t({
                id: "admin_form.fields.phone.placeholder",
                message: "Enter phone number...",
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Location Field */}
          <div>
            <label
              htmlFor="location"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="admin_form.fields.location.label">Location</Trans>
            </label>
            <input
              id="location"
              type="text"
              value={formData.location}
              onChange={(e) =>
                setFormData({ ...formData, location: e.target.value })
              }
              placeholder={t({
                id: "admin_form.fields.location.placeholder",
                message: "Enter location...",
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Role Field */}
          <div>
            <label
              htmlFor="role"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="admin_form.fields.role.label">Role</Trans>
            </label>
            <select
              id="role"
              value={formData.role}
              onChange={(e) =>
                setFormData({ ...formData, role: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            >
              {roles.length === 0 ? (
                <option value="">
                  {t({
                    id: "admin_form.fields.role.loading",
                    message: "Loading roles...",
                  })}
                </option>
              ) : (
                <>
                  <option value="">
                    {t({
                      id: "admin_form.fields.role.select_placeholder",
                      message: "Select a role",
                    })}
                  </option>
                  {roles.map((role) => (
                    <option key={role.id} value={role.id}>
                      {role.name}
                    </option>
                  ))}
                </>
              )}
            </select>
          </div>

          {/* Status Field */}
          <div>
            <label
              htmlFor="status"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="admin_form.fields.status.label">Status</Trans>
            </label>
            <select
              id="status"
              value={formData.status}
              onChange={(e) =>
                setFormData({ ...formData, status: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="active">
                {t({
                  id: "admin_form.fields.status.active",
                  message: "Active",
                })}
              </option>
              <option value="inactive">
                {t({
                  id: "admin_form.fields.status.inactive",
                  message: "Inactive",
                })}
              </option>
              <option value="suspended">
                {t({
                  id: "admin_form.fields.status.suspended",
                  message: "Suspended",
                })}
              </option>
            </select>
          </div>

          {/* Password Field */}
          <div>
            <label
              htmlFor="password"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              <Trans id="admin_form.fields.password.label">Password</Trans>{" "}
              {adminData && (
                <span className="text-sm text-gray-500">
                  (
                  {t({
                    id: "admin_form.fields.password.keep_current",
                    message: "leave blank to keep current",
                  })}
                  )
                </span>
              )}
            </label>
            <div className="relative">
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                required={!adminData}
                value={formData.password}
                onChange={(e) => {
                  setFormData({ ...formData, password: e.target.value });
                  setPasswordError(null);
                }}
                placeholder={
                  adminData
                    ? t({
                        id: "admin_form.fields.password.change_placeholder",
                        message: "Enter new password to change",
                      })
                    : t({
                        id: "admin_form.fields.password.set_placeholder",
                        message: "Set a password...",
                      })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                type="button"
                className="absolute inset-y-0 right-0 pr-3 flex items-center"
                onClick={() => setShowPassword(!showPassword)}
                title={
                  showPassword
                    ? t({
                        id: "admin_form.fields.password.hide_tooltip",
                        message: "Hide password",
                      })
                    : t({
                        id: "admin_form.fields.password.show_tooltip",
                        message: "Show password",
                      })
                }
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            {passwordError && (
              <p className="mt-1 text-sm text-red-600">{passwordError}</p>
            )}
            {!passwordError && formData.password && (
              <p className="mt-1 text-xs text-gray-500">
                <Trans id="admin_form.fields.password.requirements">
                  Password must contain at least 8 characters, one letter, one
                  digit and one special character
                </Trans>
              </p>
            )}
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              <Trans id="admin_form.actions.cancel">Cancel</Trans>
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-ehc-green text-white rounded-lg hover:bg-ehc-green-light"
            >
              {adminData ? (
                <>
                  <Trans id="admin_form.actions.update">Update</Trans>{" "}
                  <Trans id="admin_form.actions.admin">Admin</Trans>
                </>
              ) : (
                <>
                  <Trans id="admin_form.actions.create">Create</Trans>{" "}
                  <Trans id="admin_form.actions.admin">Admin</Trans>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
