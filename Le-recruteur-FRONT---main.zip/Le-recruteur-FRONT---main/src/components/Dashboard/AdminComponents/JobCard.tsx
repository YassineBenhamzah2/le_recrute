import { MapPin, Clock3, Users, LineChart, Pin } from "lucide-react";

interface JobCardProps {
  title: string;
  company: string;
  location: string;
  type: string;
  editedAgo: string;
  description: string;
  date: string;
  author: string;
  status:string;
  applications: number;
}

export default function JobCard({
  title,
  company,
  location,
  type,
  editedAgo,
  description,
  date,
  author,
  applications,status,
}: JobCardProps) {
  return (
    <div className="w-full bg-white border rounded-lg shadow-sm p-4 relative hover:shadow-md transition">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">{title}</h2>
          <div className="text-sm text-gray-500 flex flex-wrap items-center gap-2">
            <span>{company}</span>
            <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> {location}</span>
            <span>•</span>
            <span>{type}</span>
            <span className="flex items-center gap-1 text-xs text-gray-400">• <Clock3 className="w-4 h-4" /> Last Edited {editedAgo}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <LineChart className="w-5 h-5 text-blue-600 cursor-pointer" />
          <Pin className="w-5 h-5 text-red-500 cursor-pointer" />
        </div>
      </div>

      {/* Description */}
      <p className="text-sm text-gray-700 mt-3 line-clamp-2">{description}</p>

      {/* Footer */}
      <div className="flex flex-wrap justify-between items-center mt-4 text-sm text-gray-500">
        <div className="flex items-center gap-2">
          <span>{date}</span>
          <span>•</span>
          <span>{author}</span>
          <span>•</span>
          <Users className="w-4 h-4" />
          <span>{applications} Applications</span>

        </div>
        <div className="flex items-center gap-5">
          <p>{status}</p>
          <button className="bg-ehc-green text-white text-sm px-4 py-1.5 rounded-md hover:bg-ehc-green-dark transition">
            See Details
          </button>
</div>

       
       
      </div>
    </div>
  );
}
