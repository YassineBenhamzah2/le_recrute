import { BarChart3, FileDown, Users, Filter } from "lucide-react";
import { Trans } from "@lingui/macro";

interface CaseHandlingPanelProps {
  onReportsOverview?: () => void;
  onExportReportLog?: () => void;
  onAssignCaseHandler?: () => void;
  onFilterByReason?: () => void;
}

export function CaseHandlingPanel({
  onReportsOverview,
  onExportReportLog,
  onAssignCaseHandler,
  onFilterByReason,
}: CaseHandlingPanelProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
      <h2 className="text-lg font-semibold text-gray-900 mb-6">
        <Trans id="admin.case_handling.panel_title">Case Handling Panel</Trans>
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Reports Overview */}
        <div
          onClick={onReportsOverview}
          className="flex flex-col items-center p-6 bg-white border border-gray-200 hover:border-teal-300 hover:shadow-md rounded-lg transition-all duration-200 text-center cursor-pointer group"
        >
          <div className="w-16 h-16 bg-teal-500 rounded-full flex items-center justify-center mb-4 group-hover:bg-teal-600 transition-colors">
            <BarChart3 className="text-white" size={28} />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">
            <Trans id="admin.case_handling.reports_overview_title">
              Reports Overview
            </Trans>
          </h3>
          <p className="text-sm text-gray-600 leading-relaxed">
            <Trans id="admin.case_handling.reports_overview_desc">
              View weekly/monthly stats on employee reports
            </Trans>
          </p>
        </div>

        {/* Export Report Log */}
        <div
          onClick={onExportReportLog}
          className="flex flex-col items-center p-6 bg-white border border-gray-200 hover:border-teal-300 hover:shadow-md rounded-lg transition-all duration-200 text-center cursor-pointer group"
        >
          <div className="w-16 h-16 bg-teal-500 rounded-full flex items-center justify-center mb-4 group-hover:bg-teal-600 transition-colors">
            <FileDown className="text-white" size={28} />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">
            <Trans id="admin.case_handling.export_log_title">
              Export Report Log
            </Trans>
          </h3>
          <p className="text-sm text-gray-600 leading-relaxed">
            <Trans id="admin.case_handling.export_log_desc">
              Download report data as CSV or PDF
            </Trans>
          </p>
        </div>

        {/* Assign Case Handler */}
        <div
          onClick={onAssignCaseHandler}
          className="flex flex-col items-center p-6 bg-white border border-gray-200 hover:border-teal-300 hover:shadow-md rounded-lg transition-all duration-200 text-center cursor-pointer group"
        >
          <div className="w-16 h-16 bg-teal-500 rounded-full flex items-center justify-center mb-4 group-hover:bg-teal-600 transition-colors">
            <Users className="text-white" size={28} />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">
            <Trans id="admin.case_handling.assign_handler_title">
              Assign Case Handler
            </Trans>
          </h3>
          <p className="text-sm text-gray-600 leading-relaxed">
            <Trans id="admin.case_handling.assign_handler_desc">
              Assign reports to a designated admin or HR agent
            </Trans>
          </p>
        </div>

        {/* Filter by Reason */}
        <div
          onClick={onFilterByReason}
          className="flex flex-col items-center p-6 bg-white border border-gray-200 hover:border-teal-300 hover:shadow-md rounded-lg transition-all duration-200 text-center cursor-pointer group"
        >
          <div className="w-16 h-16 bg-teal-500 rounded-full flex items-center justify-center mb-4 group-hover:bg-teal-600 transition-colors">
            <Filter className="text-white" size={28} />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">
            <Trans id="admin.case_handling.filter_reason_title">
              Filter by Reason
            </Trans>
          </h3>
          <p className="text-sm text-gray-600 leading-relaxed">
            <Trans id="admin.case_handling.filter_reason_desc">
              Focus on specific complaint types
            </Trans>
          </p>
        </div>
      </div>
    </div>
  );
}
