"use client";

import { useState, useEffect, FormEvent, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { X, Search, Loader2 } from "lucide-react";
import { api } from "@/lib/network/utils/api";
import { Trans } from "@lingui/macro";
import { t } from "@lingui/core/macro";

// TYPES & API FUNCTIONS
interface CandidateSearchResult {
  id: number;
  fullName: string;
}

interface ServiceResult {
  id: number;
  title: string;
  price: number;
}

interface PaymentFormData {
  candidateId: string;
  serviceId: string;
  amount: string;
  status: "COMPLETED" | "PENDING" | "FAILED";
  method: "BANK_TRANSFER" | "CREDIT_CARD" | "PAYPAL";
  date: string;
  notes?: string;
}

interface PaymentSubmitData {
  candidateId: number;
  serviceId: number;
  amount: number;
  status: "COMPLETED" | "PENDING" | "FAILED";
  method: "BANK_TRANSFER" | "CREDIT_CARD" | "PAYPAL";
  date: string;
  notes?: string;
}

interface PaymentResponse {
  id: number;
  candidateId: number;
  serviceId: number;
  amount: number;
  status: string;
  method: string;
  date: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

const searchCandidates = (name: string): Promise<CandidateSearchResult[]> => {
  return api.getItem<CandidateSearchResult[]>(
    `/recruiter/candidates/search?name=${name}`
  );
};

const getActiveServices = (): Promise<ServiceResult[]> => {
  return api.getItem<ServiceResult[]>(`/candidate-services/active`);
};

const createPayment = (
  paymentData: PaymentSubmitData
): Promise<PaymentResponse> => {
  return api.post<PaymentResponse>(`/payments`, paymentData);
};

// MODAL COMPONENT
interface AddPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentCreated: () => void;
}

export function AddPaymentModal({
  isOpen,
  onClose,
  onPaymentCreated,
}: AddPaymentModalProps) {
  const [formData, setFormData] = useState<PaymentFormData>({
    candidateId: "",
    serviceId: "",
    amount: "",
    status: "COMPLETED",
    method: "BANK_TRANSFER",
    date: new Date().toISOString().split("T")[0],
    notes: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // State for candidate search
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<CandidateSearchResult[]>(
    []
  );
  const [selectedCandidate, setSelectedCandidate] =
    useState<CandidateSearchResult | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // State for service list
  const [services, setServices] = useState<ServiceResult[]>([]);
  const [isLoadingServices, setIsLoadingServices] = useState(true);

  const searchRef = useRef<HTMLDivElement>(null);

  // Effect to fetch services when the modal opens and reset state when it closes
  useEffect(() => {
    if (isOpen) {
      setIsLoadingServices(true);
      getActiveServices()
        .then((data) => setServices(data))
        .catch(() =>
          setError(t`Could not load the list of available services.`)
        )
        .finally(() => setIsLoadingServices(false));
    } else {
      // Reset form state completely when modal is closed
      setFormData({
        candidateId: "",
        serviceId: "",
        amount: "",
        status: "COMPLETED",
        method: "BANK_TRANSFER",
        date: new Date().toISOString().split("T")[0],
        notes: "",
      });
      setSearchQuery("");
      setSelectedCandidate(null);
      setError(null);
      setIsDropdownOpen(false);
    }
  }, [isOpen]);

  // Debounced search effect for candidates
  useEffect(() => {
    if (searchQuery.length < 2 || selectedCandidate) {
      setSearchResults([]);
      setIsDropdownOpen(false);
      return;
    }

    const handler = setTimeout(async () => {
      setIsSearching(true);
      try {
        const results = await searchCandidates(searchQuery);
        setSearchResults(results);
        setIsDropdownOpen(results.length > 0);
      } catch (e) {
        console.error("Failed to search candidates", e);
      } finally {
        setIsSearching(false);
      }
    }, 500); // 500ms delay after user stops typing

    return () => clearTimeout(handler);
  }, [searchQuery, selectedCandidate]);

  // Handler to select a candidate from the search results
  const handleSelectCandidate = (candidate: CandidateSearchResult) => {
    setSelectedCandidate(candidate);
    setSearchQuery(candidate.fullName);
    setFormData((prev) => ({ ...prev, candidateId: candidate.id.toString() }));
    setIsDropdownOpen(false);
  };

  // Handler to automatically fill the amount when a service is selected
  const handleServiceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const serviceId = e.target.value;
    const selectedService = services.find((s) => s.id.toString() === serviceId);

    setFormData((prev) => ({
      ...prev,
      serviceId: serviceId,
      amount: selectedService ? selectedService.price.toString() : "",
    }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedCandidate || !formData.serviceId) {
      setError(t`Please select a candidate and a service before submitting.`);
      return;
    }
    setIsSubmitting(true);
    setError(null);
    try {
      const paymentData: PaymentSubmitData = {
        ...formData,
        candidateId: parseInt(formData.candidateId),
        serviceId: parseInt(formData.serviceId),
        amount: parseFloat(formData.amount),
      };
      await createPayment(paymentData);
      onPaymentCreated(); // This refreshes the parent table and closes the modal
    } catch (err: unknown) {
      const errorMessage =
        err instanceof Error
          ? err.message
          : t`An unexpected error occurred while creating the payment. Please try again.`;
      setError(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center ">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="add-payment-title"
        className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl mx-auto overflow-hidden"
        ref={searchRef}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-gray-200">
          <div>
            <h2
              id="add-payment-title"
              className="text-2xl font-semibold text-ehc-green-dark"
            >
              <Trans>Add New Payment</Trans>
            </h2>
            <p className="mt-1 text-sm text-ehc-green">
              <Trans>
                Create a payment record and assign it to a candidate and
                service.
              </Trans>
            </p>
          </div>
          <div className="ml-4">
            <button
              onClick={onClose}
              aria-label={t`Close dialog`}
              className="text-ehc-green hover:text-ehc-green-dark rounded-full p-2 hover:bg-ehc-green-light/20 transition duration-150"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Body */}
        <form
          onSubmit={handleSubmit}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6"
        >
          {/* Left/Main Column */}
          <div className="md:col-span-2 space-y-4">
            {error && (
              <div className="rounded-md bg-red-50 border border-red-300 p-3 text-sm text-red-700">
                {error}
              </div>
            )}

            {/* Candidate Search */}
            <div>
              <Label htmlFor="candidateSearch">
                <Trans>Candidate</Trans>
              </Label>
              <div className="relative mt-1">
                <Input
                  id="candidateSearch"
                  type="text"
                  placeholder={t`Search by name or email`}
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setSelectedCandidate(null);
                    setFormData({ ...formData, candidateId: "" });
                  }}
                  onFocus={() => {
                    if (searchQuery.length > 0 && searchResults.length > 0) {
                      setIsDropdownOpen(true);
                    }
                  }}
                  autoComplete="off"
                  required
                  // Input styling is handled by the mock Input component using ehc-green
                />
                {isSearching ? (
                  <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-ehc-green animate-spin" />
                ) : (
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-ehc-green" />
                )}

                {isDropdownOpen && (
                  <div className="absolute z-30 mt-2 w-full max-h-44 overflow-y-auto bg-white border border-gray-200 rounded-lg shadow-xl">
                    {searchResults.length > 0 ? (
                      searchResults.map((c) => (
                        <div
                          key={c.id}
                          onClick={() => handleSelectCandidate(c)}
                          className="p-3 hover:bg-ehc-green-light/20 cursor-pointer transition duration-100"
                        >
                          <div className="text-sm font-medium text-gray-800">
                            {c.fullName}
                          </div>
                          <div className="text-xs text-gray-500">
                            <Trans>ID</Trans>: {c.id}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-3 text-sm text-gray-500 italic">
                        <Trans>No candidates found.</Trans>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Service & Amount */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="service">
                  <Trans>Service</Trans>
                </Label>
                <select
                  id="service"
                  value={formData.serviceId}
                  onChange={handleServiceChange}
                  className="w-full mt-1 p-2 border border-gray-300 rounded-md bg-white focus:ring-2 focus:ring-ehc-green-light focus:border-ehc-green"
                  required
                  disabled={isLoadingServices}
                >
                  <option value="" disabled>
                    {isLoadingServices ? (
                      <Trans>Loading services...</Trans>
                    ) : (
                      <Trans>Select a service</Trans>
                    )}
                  </option>
                  {services.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.title}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="amount">
                  <Trans>Amount (USD)</Trans>
                </Label>
                <Input
                  id="amount"
                  type="number"
                  value={formData.amount}
                  readOnly
                  className="mt-1 bg-green-50 border-green-300 text-green-800 cursor-not-allowed" // Keeping green for money/success
                />
              </div>
            </div>

            {/* Optional Notes (scalable field) */}
            <div>
              <Label htmlFor="notes">
                <Trans>Notes (optional)</Trans>
              </Label>
              <textarea
                id="notes"
                value={formData.notes || ""}
                onChange={(e) =>
                  setFormData({ ...formData, notes: e.target.value })
                }
                rows={3}
                className="w-full mt-1 p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-ehc-green-light focus:border-ehc-green resize-y"
                placeholder={t`Add any relevant notes for this payment`}
              />
            </div>
          </div>

          {/* Right column - compact summary & controls */}
          <div className="md:col-span-1">
            <div className="bg-gradient-to-br from-white to-ehc-green-light/10 p-4 rounded-lg border border-ehc-green/30 h-full flex flex-col justify-between">
              <div>
                <h4 className="text-base font-semibold text-ehc-green-dark border-b pb-2 mb-3 border-ehc-green/20">
                  <Trans>Payment Summary</Trans>
                </h4>
                <div className="mt-3 space-y-3 text-sm text-gray-600">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-800">
                      <Trans>Candidate</Trans>:
                    </span>
                    <span
                      className={
                        selectedCandidate
                          ? "text-green-600 font-semibold"
                          : "text-gray-400 italic"
                      }
                    >
                      {selectedCandidate ? (
                        selectedCandidate.fullName
                      ) : (
                        <Trans>Not selected</Trans>
                      )}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-800">
                      <Trans>Service</Trans>:
                    </span>
                    <span className="text-gray-700">
                      {formData.serviceId ? (
                        services.find(
                          (s) => s.id.toString() === formData.serviceId
                        )?.title
                      ) : (
                        <span className="text-gray-400 italic">—</span>
                      )}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-lg mt-4 pt-2 border-t border-ehc-green/20">
                    <span className="font-bold text-gray-800">
                      <Trans>Total Amount</Trans>:
                    </span>{" "}
                    <span className="text-green-700 font-extrabold">
                      {"$" + (parseFloat(formData.amount) || 0).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-6 space-y-3">
                {/* Date Field */}
                <div>
                  <Label htmlFor="date">
                    <Trans>Payment Date</Trans>
                  </Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) =>
                      setFormData({ ...formData, date: e.target.value })
                    }
                    className="mt-1 focus:ring-2 focus:ring-ehc-green-light focus:border-ehc-green"
                    required
                  />
                </div>

                {/* Status Field */}
                <div>
                  <Label htmlFor="status">
                    <Trans>Status</Trans>
                  </Label>
                  <select
                    id="status"
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        status: e.target.value as PaymentFormData["status"],
                      })
                    }
                    className="w-full mt-1 p-2 border border-gray-300 rounded-md bg-white focus:ring-2 focus:ring-ehc-green-light focus:border-ehc-green"
                  >
                    <option value="COMPLETED">
                      <Trans>Completed</Trans>
                    </option>
                    <option value="PENDING">
                      <Trans>Pending</Trans>
                    </option>
                    <option value="FAILED">
                      <Trans>Failed</Trans>
                    </option>
                  </select>
                </div>

                {/* Method Field */}
                <div>
                  <Label htmlFor="method">
                    <Trans>Method</Trans>
                  </Label>
                  <select
                    id="method"
                    value={formData.method}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        method: e.target.value as PaymentFormData["method"],
                      })
                    }
                    className="w-full mt-1 p-2 border border-gray-300 rounded-md bg-white focus:ring-2 focus:ring-ehc-green-light focus:border-ehc-green"
                  >
                    <option value="BANK_TRANSFER">
                      <Trans>Bank Transfer</Trans>
                    </option>
                    <option value="CREDIT_CARD">
                      <Trans>Credit Card</Trans>
                    </option>
                    <option value="PAYPAL">
                      <Trans>PayPal</Trans>
                    </option>
                  </select>
                </div>
              </div>

              {/* Actions */}
              <div className="pt-6 border-t border-ehc-green/20 mt-6">
                <div className="flex items-center justify-between">
                  {/* Cancel Button (kept red for alert/danger) */}
                  <Button
                    type="button"
                    variant="outline"
                    onClick={onClose}
                    className="w-1/2 mr-2 bg-red-500 hover:bg-red-600 text-white shadow-md hover:shadow-lg"
                  >
                    <Trans>Cancel</Trans>
                  </Button>
                  {/* Save Button (ehc-green primary) */}
                  <Button
                    type="submit"
                    disabled={
                      isSubmitting || !selectedCandidate || !formData.serviceId
                    }
                    className="w-1/2 bg-ehc-green hover:bg-ehc-green-dark text-white shadow-md hover:shadow-lg disabled:hover:bg-ehc-green"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin text-white" />{" "}
                        <Trans>Saving...</Trans>
                      </>
                    ) : (
                      <Trans>Save </Trans>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
