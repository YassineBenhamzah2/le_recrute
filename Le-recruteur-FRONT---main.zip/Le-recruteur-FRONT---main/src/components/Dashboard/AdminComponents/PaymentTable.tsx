"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Search } from "lucide-react"

// This interface now exactly matches the PaymentResponseDto from the backend
export interface Payment {
  id: number;
  candidateName: string;
  serviceName: string;
  amount: number;
  status: string; // Will be "completed", "pending", or "failed"
  paymentDate: string;
  paymentMethod: string;
}

// Props are simplified. The table only needs the data to display.
interface PaymentTableProps {
  data: Payment[]
}

export function PaymentTable({ data }: PaymentTableProps) {
  
  // // Helper to determine badge color based on status
  // const getStatusBadgeVariant = (status: string) => {
  //   switch (status.toLowerCase()) {
  //     case "completed":
  //       return "success";
  //     case "pending":
  //       return "warning";
  //     case "failed":
  //       return "destructive"; // Assuming 'destructive' is your red/error variant
  //     default:
  //       return "outline";
  //   }
  // };

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-medium text-gray-900">
          Payment History
          <span className="ml-2 text-sm font-normal text-gray-500">
            (Showing {data.length} payments)
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {data.length === 0 ? (
          // Simplified "No Results" view
          <div className="text-center py-12 px-6">
            <Search className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900">No Payments Found</h3>
            <p className="text-gray-500">There are no payments that match the current criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-gray-200 bg-gray-50">
                <tr>
                  <th className="text-left py-3 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider">Payment ID</th>
                  <th className="text-left py-3 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider">Candidate</th>
                  <th className="text-left py-3 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                  <th className="text-left py-3 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th className="text-left py-3 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="text-left py-3 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="text-left py-3 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider">Method</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {data.map((payment) => (
                  <tr key={payment.id}>
                    <td className="py-4 px-6 font-medium text-gray-800">PAY-{payment.id}</td>
                    <td className="py-4 px-6 text-gray-600">{payment.candidateName}</td>
                    <td className="py-4 px-6 text-gray-600">{payment.serviceName}</td>
                    <td className="py-4 px-6 font-semibold text-gray-800">${payment.amount.toLocaleString()}</td>
                    <td className="py-4 px-6">
                      <Badge className={`capitalize ${
                        payment.status === "completed" ? "bg-green-100 text-green-800"
                        :payment.status === "pending" ? "bg-yellow-100 text-yellow-800"
                        :"bg-red-100 text-red-800"
                      }`}>
                        {payment.status}
                      </Badge>
                    </td>
                    <td className="py-4 px-6 text-gray-600">{payment.paymentDate}</td>
                    <td className="py-4 px-6 text-gray-600 capitalize">{payment.paymentMethod}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}