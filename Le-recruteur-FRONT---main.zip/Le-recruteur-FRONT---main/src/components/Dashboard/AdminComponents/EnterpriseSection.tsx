// src/components/EnterpriseSection.tsx
import { useState } from "react";
import { ChevronLeft, ChevronRight, Plus, Edit2, Trash2, X, Upload } from "lucide-react";

interface Enterprise {
  id: number;
  name: string;
  website: string;
  description: string;
  image: string;
  order?: number; // ajout pour l'ordre d'affichage
}

const initialEnterprises: Enterprise[] = [
  {
    id: 1,
    name: "TechCorp",
    website: "www.techcorp.com",
    description: "Entreprise spécialisée en IA.",
    image: "/enterprise1.png",
    order: 1
  },
  {
    id: 2,
    name: "DataSoft",
    website: "www.datasoft.com",
    description: "Solutions Big Data innovantes.",
    image: "/enterprise2.png",
    order: 2
  },
    {
    id: 3,
    name: "DataSoft",
    website: "www.datasoft.com",
    description: "Solutions Big Data innovantes.",
    image: "/enterprise2.png",
    order: 2
  },
    {
    id: 4,
    name: "DataSoft",
    website: "www.datasoft.com",
    description: "Solutions Big Data innovantes.",
    image: "/enterprise2.png",
    order: 2
  },
  // autres entreprises...
];

export default function EnterpriseSection() {
  const [enterprises, setEnterprises] = useState(initialEnterprises);
  const [startIndex, setStartIndex] = useState(0);
  const [modalType, setModalType] = useState<"create"|"edit"|"delete"|null>(null);
  const [selected, setSelected] = useState<Enterprise|null>(null);

  const [formName, setFormName] = useState("");
  const [formOrder, setFormOrder] = useState<number>(1);

  const itemsPerPage = 3;

  const getCurrentEnterprises = () => 
    enterprises.slice(startIndex, startIndex + itemsPerPage);

  const prevEnterprises = () => {
    setStartIndex((prev) => Math.max(prev - itemsPerPage, 0));
  };
  
  const nextEnterprises = () => {
    setStartIndex((prev) =>
      prev + itemsPerPage < enterprises.length ? prev + itemsPerPage : prev
    );
  };

  const openModal = (type:"create"|"edit"|"delete", enterprise?:Enterprise) => {
    setSelected(enterprise || null);
    setModalType(type);

    if (type === "edit" && enterprise) {
      setFormName(enterprise.name);
      setFormOrder(enterprise.order || 1);
    } else if (type === "create") {
      setFormName("");
      setFormOrder(1);
    }
  };

  const closeModal = () => {
    setModalType(null);
    setSelected(null);
  };

  const handleCreate = () => {
    const newEnterprise: Enterprise = {
      id: Date.now(),
      name: formName,
      website: "",
      description: "",
      image: "",
      order: formOrder
    };
    setEnterprises([...enterprises, newEnterprise]);
    closeModal();
  };

  const handleEdit = () => {
    if (!selected) return;
    const updatedEnterprise: Enterprise = {
      ...selected,
      name: formName,
      order: formOrder
    };
    setEnterprises(
      enterprises.map((e) => (e.id === selected.id ? updatedEnterprise : e))
    );
    closeModal();
  };

  const handleDelete = () => {
    if (!selected) return;
    setEnterprises(enterprises.filter((e) => e.id !== selected.id));
    closeModal();
  };

  return (
    <section className="py-12 lg:py-16 px-4 bg-gray-100">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-8 lg:mb-12">
          <div><h2 className="text-xl lg:text-xl px-4   font-semibold text-black mb-4 sm:mb-0">
           Manage Homepage Enterprises
          </h2>
          <p className="p-4 text-gray-600">Select and arrange the enterprises displayed on the homepage.</p>
         </div>
          <button 
            onClick={() => openModal("create")}
            className="ml-4 p-2 bg-white text-[#238D94] rounded-lg hover:bg-[#1f7d83] transition-colors flex items-center"
          >
             Create New Entreprise
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {getCurrentEnterprises().map((enterprise) => (
            <div key={enterprise.id} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow relative">
              <div className="absolute top-3 right-3 flex space-x-2">
                <button onClick={() => openModal("edit", enterprise)} className="p-1 bg-yellow-100 rounded hover:bg-yellow-200">
                  <Edit2 className="w-4 h-4 text-yellow-600" />
                </button>
                <button onClick={() => openModal("delete", enterprise)} className="p-1 bg-red-100 rounded hover:bg-red-200">
                  <Trash2 className="w-4 h-4 text-red-600" />
                </button>
              </div>
              <div className="mb-4">
                <img 
                  src={enterprise.image} 
                  alt={enterprise.name}
                  className="w-full h-32 object-cover rounded-lg"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='128' viewBox='0 0 300 128'%3E%3Crect width='300' height='128' fill='%23f3f4f6'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial' font-size='14' fill='%236b7280' text-anchor='middle' dy='0.3em'%3EEnterprise Logo%3C/text%3E%3C/svg%3E";
                  }}
                />
              </div>
              <h3 className="text-xl font-semibold text-black mb-2">{enterprise.name}</h3>
              <p className="font-bold text-[#238D94] mb-2">{enterprise.website}</p>
              <p className="text-[#C3C3C3] mb-4">{enterprise.description}</p>
            </div>
          ))}
        </div>

       {/* Pagination */}
        <div className="flex justify-center mt-8 space-x-2">
          <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-100">&lt;</button>
          <button className="px-3 py-1 rounded border border-[#238D94] bg-[#238D94] text-white">1</button>
          <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-100">2</button>
          <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-100">3</button>
          <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-100">&gt;</button>
        </div>
      </div>

      {/* Modal Create/Edit/Delete */}
      {modalType && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-lg relative">
            <button onClick={closeModal} className="absolute top-3 right-3">
              <X className="w-5 h-5" />
            </button>

            {(modalType === "create" || modalType === "edit") && (
              <>
                <h3 className="text-xl font-bold mb-4">
                  {modalType === "create" ? "Create Enterprise" : "Edit Enterprise"}
                </h3>
                <input 
                  type="text"
                  placeholder="Enterprise Name"
                  className="border w-full p-2 mb-3 rounded"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                />
                <input 
                  type="number"
                  placeholder="Display Order"
                  className="border w-full p-2 mb-3 rounded"
                  value={formOrder}
                  onChange={(e) => setFormOrder(Number(e.target.value))}
                />
                <div className="border-2 border-dashed p-4 mb-4 flex items-center justify-center text-gray-500">
                  <Upload className="w-5 h-5 mr-2"/> Max size: 5GB Drop here to attach or upload
                </div>
                <button 
                  onClick={modalType === "create" ? handleCreate : handleEdit}
                  className="bg-[#238D94] text-white w-full py-2 rounded-lg"
                >
                  {modalType === "create" ? "Create" : "Save Changes"}
                </button>
              </>
            )}

            {modalType === "delete" && selected && (
              <>
                <h3 className="text-xl font-bold mb-4">Delete Enterprise</h3>
                <p>Êtes-vous sûr de vouloir supprimer <strong>{selected.name}</strong> ?</p>
                <div className="flex space-x-4 mt-6">
                  <button onClick={handleDelete} className="bg-red-600 text-white flex-1 py-2 rounded-lg">Oui</button>
                  <button onClick={closeModal} className="bg-gray-200 flex-1 py-2 rounded-lg">Non</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </section> 
  );
}
