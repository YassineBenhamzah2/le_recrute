import { Edit2, Trash2, Upload } from "lucide-react";
import { useState } from "react";

type Blog = {
  id: number;
  image: string;
  title: string;
  author: string;

  photoAuthor: string;
  description: string;
  date: string;
};

export default function BlogList() {
  const [blogs, setBlogs] = useState<Blog[]>([
    {
      id: 1,
      image: "/ad-2.png",
      title: "Boost Your Job Search",
      author: "Admin",
      photoAuthor: "/avatars/Miles.png",
      date: "August 12, 2025",
      description:
        "Discover strategies to make your CV stand out and attract top recruiters.",
    },
    {
      id: 1,
      image: "/ad-2.png",
      title: "Boost Your Job Search",
      author: "Admin",
      photoAuthor: "/avatars/Miles.png",
      date: "August 12, 2025",
      description:
        "Discover strategies to make your CV stand out and attract top recruiters.",
    },
  ]);

  const [showModal, setShowModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [mode, setMode] = useState<"create" | "edit">("create");
  const [currentBlog, setCurrentBlog] = useState<Blog | null>(null);

  const handleEdit = (blog: Blog) => {
    setCurrentBlog(blog);
    setMode("edit");
    setShowModal(true);
  };

  const handleCreate = () => {
    setCurrentBlog({
      id: Date.now(),
      image: "", // image du blog
      title: "",
      author: "",
      photoAuthor: "", // photo de l'auteur
      description: "",
      date: "",
    });
    setMode("create");
    setShowModal(true);
  };
  const handleSave = () => {
    if (!currentBlog) return;
    if (mode === "create") {
      setBlogs([...blogs, currentBlog]);
    } else {
      setBlogs(blogs.map((b) => (b.id === currentBlog.id ? currentBlog : b)));
    }
    setShowModal(false);
  };

  const handleDeleteClick = (blog: Blog) => {
    setCurrentBlog(blog);
    setShowDeleteModal(true);
  };

  const handleDelete = () => {
    if (!currentBlog) return;
    setBlogs(blogs.filter((b) => b.id !== currentBlog.id));
    setShowDeleteModal(false);
  };

  return (
    <div className="mt-10">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-2xl font-semibold text-black">
            Articles du blog
          </h3>
          <p className="text-gray-600">
            Manage the blog posts featured on the homepage.
          </p>
        </div>
        <button
          onClick={handleCreate}
          className="bg-[#238D94] text-white px-4 py-2 rounded-lg shadow hover:bg-[#1d757c] transition"
        >
          Créer un article
        </button>
      </div>

      {/* Grid Blogs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
        {blogs.map((blog) => (
          <div
            key={blog.id}
            className="bg-white p-6 rounded-lg shadow-md relative hover:shadow-lg transition-shadow"
          >
            <img
              src={blog.image}
              alt={blog.title}
              className="w-full h-48 object-cover mb-4 rounded-lg"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='192' viewBox='0 0 400 192'%3E%3Crect width='400' height='192' fill='%23f3f4f6'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial' font-size='16' fill='%236b7280' text-anchor='middle' dy='0.3em'%3E${blog.title}%3C/text%3E%3C/svg%3E`;
              }}
            />
            <h3 className="text-[#238D94] font-semibold mb-1 text-lg">
              {blog.title}
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              {blog.author} • {blog.date}
            </p>

            {/* Edit & Delete icons */}
            <div className="absolute top-4 right-4 flex gap-2">
              <button
                onClick={() => handleEdit(blog)}
                className="bg-gray-100 p-1 rounded hover:bg-gray-200 transition"
                title="Éditer"
              >
                <Edit2 size={18} className="text-[#238D94]" />
              </button>
              <button
                onClick={() => handleDeleteClick(blog)}
                className="bg-gray-100 p-1 rounded hover:bg-gray-200 transition"
                title="Supprimer"
              >
                <Trash2 size={18} className="text-red-500" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      <div className="flex justify-center mt-8 space-x-2">
        <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-100">
          &lt;
        </button>
        <button className="px-3 py-1 rounded border border-[#238D94] bg-[#238D94] text-white">
          1
        </button>
        <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-100">
          2
        </button>
        <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-100">
          3
        </button>
        <button className="px-3 py-1 rounded border border-gray-300 text-gray-600 hover:bg-gray-100">
          &gt;
        </button>
      </div>

      {/* Modal Create / Edit */}
      {showModal && currentBlog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-2xl p-6 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 text-xl"
            >
              ×
            </button>

            <h3 className="text-xl font-bold text-[#238D94] mb-4">
              {mode === "create" ? "Créer un article" : "Éditer l'article"}
            </h3>

            <label className="block mb-3">
              <span className="text-gray-700 font-medium">Titre</span>
              <input
                type="text"
                value={currentBlog.title}
                onChange={(e) =>
                  setCurrentBlog({ ...currentBlog, title: e.target.value })
                }
                className="w-full mt-1 p-2 border rounded"
                placeholder="Entrez le titre"
              />
            </label>

            <label className="block mb-3">
              <span className="text-gray-700 font-medium">Auteur</span>
              <input
                type="text"
                value={currentBlog.author}
                onChange={(e) =>
                  setCurrentBlog({ ...currentBlog, author: e.target.value })
                }
                className="w-full mt-1 p-2 border rounded"
                placeholder="Nom de l'auteur"
              />
            </label>

            <label className="block mb-3">
              <span className="text-gray-700 font-medium">Date</span>
              <input
                type="date"
                value={currentBlog.date}
                onChange={(e) =>
                  setCurrentBlog({ ...currentBlog, date: e.target.value })
                }
                className="w-full mt-1 p-2 border rounded"
              />
            </label>

            <label className="block mb-4">
              <span className="text-gray-700 font-medium">
                Image de couverture
              </span>
              <div className="mt-2 border-2 border-dashed rounded-lg p-6 text-center hover:border-[#238D94] cursor-pointer transition">
                <Upload className="mx-auto text-[#238D94]" size={40} />
                <p className="mt-2 text-gray-600">Max size: 5GB</p>
                <p className="text-gray-500 text-sm">
                  Glissez-déposez ou collez l'URL
                </p>
                <input
                  type="text"
                  value={currentBlog.image}
                  onChange={(e) =>
                    setCurrentBlog({ ...currentBlog, image: e.target.value })
                  }
                  className="w-full mt-3 p-2 border rounded"
                  placeholder="Ou collez l'URL de l'image"
                />
              </div>
            </label>

            <button
              onClick={handleSave}
              className="w-full bg-[#238D94] text-white py-2 rounded-lg shadow hover:bg-[#1d757c] transition"
            >
              {mode === "create" ? "Créer" : "Sauvegarder"}
            </button>
          </div>
        </div>
      )}

      {/* Modal Delete Confirmation */}
      {showDeleteModal && currentBlog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md p-6 relative text-center">
            <button
              onClick={() => setShowDeleteModal(false)}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 text-xl"
            >
              ×
            </button>
            <h3 className="text-lg font-bold text-gray-800 mb-4">
              Êtes-vous sûr de vouloir supprimer ?
            </h3>
            <p className="text-gray-600 mb-6">{currentBlog.title}</p>
            <div className="flex justify-center gap-4">
              <button
                onClick={handleDelete}
                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition"
              >
                Oui
              </button>
              <button
                onClick={() => setShowDeleteModal(false)}
                className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
