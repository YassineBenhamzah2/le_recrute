import { useEffect, useState } from "react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { cn } from "@/lib/utils";
import {
  AlertCircleIcon,
  ArrowDownRight,
  ArrowUpRight,
  BadgeCheck,
  Ban,
  Briefcase,
  CalendarPlus,
  Check,
  CheckCircle2Icon,
  ClipboardPlusIcon,
  Eye,
  Mail,
  Pickaxe,
  Smartphone,
  Users,
} from "lucide-react";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

import { candidateDashboardService } from "@/lib/network/dashboard/candidate";
import { Candidate, statisticsCandidat } from "@/lib/types/dashboard/candidate";
import { Trans, t } from "@lingui/macro";
import { useNavigate } from "react-router-dom";
import { SearchAndFilter } from "./AdminComponents/SearchAndFilter";

interface AnalyticsCardProps {
  title: string;
  value: string;
  subtitle: string;
  trend: number;
  icon: React.ReactNode;
  gradient: string;
  chartColor: string;
}

const statusStyle = {
  ACTIVE: {
    bg: "bg-green-50",
    text: "text-green-700",
    border: "border border-green-200",
  },
  INACTIVE: {
    bg: "bg-yellow-50",
    text: "text-yellow-700",
    border: "border border-yellow-200",
  },
  SUSPENDED: {
    bg: "bg-red-50",
    text: "text-red-700",
    border: "border border-red-200",
  },
  REPORTED: {
    bg: "bg-orange-50",
    text: "text-orange-700",
    border: "border border-orange-200",
  },
  REJECTED: {
    bg: "bg-gray-50",
    text: "text-gray-700",
    border: "border border-gray-200",
  },
};

// Function to get style based on status
const getStatusStyle = (status: string) => {
  // Convert to uppercase to match the keys in statusStyle
  const formattedStatus = status.toUpperCase();
  return (
    statusStyle[formattedStatus as keyof typeof statusStyle] || {
      bg: "bg-gray-50",
      text: "text-gray-700",
      border: "border border-gray-200",
    }
  );
};

function AnalyticsCard({
  title,
  value,
  subtitle,
  trend,
  icon,
  gradient,
  chartColor,
}: AnalyticsCardProps) {
  const isPositive = trend >= 0;

  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 relative overflow-hidden flex flex-col">
      <div className="flex items-start justify-between mb-4">
        <div className={`p-3 rounded-2xl ${gradient}`}>{icon}</div>
      </div>

      <div className="space-y-2 mb-4 min-h-[80px]">
        <h3 className="text-2xl font-bold text-gray-900">{value}</h3>
        <p className="text-gray-600 font-medium text-sm">{title}</p>
        {(trend || subtitle) && (
          <div
            className={`flex items-center space-x-1 text-sm ${
              isPositive ? "text-[#238D94]" : "text-red-500"
            }`}
          >
            {isPositive ? (
              <ArrowUpRight size={14} />
            ) : (
              <ArrowDownRight size={14} />
            )}
            <span className="font-semibold">{Math.abs(trend)}%</span>
            <span className="text-gray-500">{subtitle}</span>
          </div>
        )}
      </div>

      {/* Mini Chart Visualization - Reduced size and aligned bottom */}
      <div className="mt-auto pt-2">
        <div className="relative h-12">
          <svg className="w-full h-full" viewBox="0 0 200 40">
            <defs>
              <linearGradient
                id={`gradient-${title}`}
                x1="0%"
                y1="0%"
                x2="0%"
                y2="100%"
              >
                <stop offset="0%" stopColor={chartColor} stopOpacity="0.3" />
                <stop offset="100%" stopColor={chartColor} stopOpacity="0.05" />
              </linearGradient>
            </defs>
            <path
              d="M0,30 Q25,25 50,27 T100,20 T150,25 T200,15"
              stroke={chartColor}
              strokeWidth="1.5"
              fill="none"
              className="drop-shadow-sm"
            />
            <path
              d="M0,30 Q25,25 50,27 T100,20 T150,25 T200,15 L200,40 L0,40 Z"
              fill={`url(#gradient-${title})`}
            />
          </svg>
        </div>
      </div>
    </div>
  );
}

// --- NOTIFICATION STATE TYPE ---
type NotificationState = {
  title: string;
  description?: React.ReactNode;
  variant: "success" | "destructive";
} | null;

interface TableCandidatesProps {
  searchTerm: string;
  filterStatus: string;
}

function TableCandidates({ searchTerm, filterStatus }: TableCandidatesProps) {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const rowsPerPage = 10;
  const [loading, setLoading] = useState(false);
  const [processingIds, setProcessingIds] = useState<number[]>([]);
  const [notification, setNotification] = useState<NotificationState>(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchCandidates();
  }, [page, searchTerm, filterStatus]);

  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const fetchCandidates = async () => {
    setLoading(true);

    try {
      let response;

      if (searchTerm) {
        response = await candidateDashboardService.searchCandidates(
          searchTerm,
          page - 1,
          rowsPerPage
        );
      } else {
        response = await candidateDashboardService.AllCandidates(
          page - 1,
          rowsPerPage
        );
      }

      setCandidates(response.data);
      setTotalPages(response.metadata ? response.metadata.totalPages : 1);
    } catch (error) {
      console.error("Error fetching candidates:", error);
      setNotification({
        title: t({
          id: "candidate_management.notifications.error",
          message: "Error!",
        }),
        description: t({
          id: "candidate_management.notifications.fetch_failed",
          message: "Failed to fetch candidates",
        }),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSuspendCandidate = async (candidateId: number) => {
    setProcessingIds((prev) => [...prev, candidateId]);
    try {
      await candidateDashboardService.suspendCandidate(candidateId);
      setNotification({
        title: t({
          id: "candidate_management.notifications.success",
          message: "Success!",
        }),
        description: t({
          id: "candidate_management.notifications.suspend_success",
          message: "Candidate has been suspended.",
        }),
        variant: "success",
      });
      fetchCandidates();
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : t({
              id: "candidate_management.notifications.suspend_failed",
              message: "Failed to suspend candidate",
            });
      setNotification({
        title: t({
          id: "candidate_management.notifications.error",
          message: "Error!",
        }),
        description: message,
        variant: "destructive",
      });
    } finally {
      setProcessingIds((prev) => prev.filter((id) => id !== candidateId));
    }
  };

  const handleActivateCandidate = async (candidateId: number) => {
    setProcessingIds((prev) => [...prev, candidateId]);
    try {
      await candidateDashboardService.activateCandidate(candidateId);
      setNotification({
        title: t({
          id: "candidate_management.notifications.success",
          message: "Success!",
        }),
        description: t({
          id: "candidate_management.notifications.activate_success",
          message: "Candidate has been activated.",
        }),
        variant: "success",
      });
      fetchCandidates();
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : t({
              id: "candidate_management.notifications.activate_failed",
              message: "Failed to activate candidate",
            });
      setNotification({
        title: t({
          id: "candidate_management.notifications.error",
          message: "Error!",
        }),
        description: message,
        variant: "destructive",
      });
    } finally {
      setProcessingIds((prev) => prev.filter((id) => id !== candidateId));
    }
  };

  const getPageItems = (
    current: number,
    total: number,
    siblingCount = 1
  ): (number | "…")[] => {
    const items: (number | "…")[] = [];
    if (total <= 1) return [1];

    const first = 1;
    const last = total;
    const start = Math.max(first + 1, current - siblingCount);
    const end = Math.min(last - 1, current + siblingCount);

    items.push(first);

    if (start > first + 1) items.push("…");

    for (let i = start; i <= end; i++) items.push(i);

    if (end < last - 1) items.push("…");

    if (last > first) items.push(last);

    return items;
  };

  const pageItems = getPageItems(page, totalPages, 2);

  return (
    <div className="overflow-x-auto rounded shadow-md pb-5">
      {/* Notification */}
      {notification && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 w-full max-w-xl z-[100] animate-in fade-in-5 slide-in-from-top-5">
          <Alert
            variant={
              notification.variant === "destructive" ? "destructive" : "default"
            }
            className={cn(
              "bg-background",
              notification.variant === "success" &&
                "border-green-500/50 text-green-700 dark:border-green-500 [&>[data-slot=icon]]:text-green-700"
            )}
          >
            {notification.variant === "destructive" ? (
              <AlertCircleIcon className="h-4 w-4" data-slot="icon" />
            ) : (
              <CheckCircle2Icon className="h-4 w-4" data-slot="icon" />
            )}
            <AlertTitle>{notification.title}</AlertTitle>
            {notification.description && (
              <AlertDescription>{notification.description}</AlertDescription>
            )}
          </Alert>
        </div>
      )}

      <table className="min-w-full border-separate border-spacing-y-3 text-sm text-left text-gray-700 bg-white ">
        <thead className="text-xs uppercase bg-gray-50 border-b">
          <tr>
            <th className="px-4 py-3">
              <Trans id="candidate_management.table.headers.first_name">
                First Name
              </Trans>
            </th>
            <th className="px-4 py-3">
              <Trans id="candidate_management.table.headers.last_name">
                Last Name
              </Trans>
            </th>
            <th className="px-4 py-3">
              <div className="flex items-center gap-1">
                <Mail size={20} />
                <Trans id="candidate_management.table.headers.email">
                  Email
                </Trans>
              </div>
            </th>
            <th className="px-4 py-3">
              <div className="flex items-center gap-1">
                <Smartphone size={20} />
                <Trans id="candidate_management.table.headers.phone">
                  Phone
                </Trans>
              </div>
            </th>
            <th className="px-4 py-3">
              <div className="flex items-center gap-1">
                <Briefcase size={20} />
                <Trans id="candidate_management.table.headers.experience">
                  Experience
                </Trans>
              </div>
            </th>
            <th className="px-4 py-3">
              <div className="flex items-center gap-1">
                <BadgeCheck size={20} />
                <Trans id="candidate_management.table.headers.status">
                  Status
                </Trans>
              </div>
            </th>
            <th className="px-4 py-3">
              <div className="flex items-center gap-1">
                <Pickaxe size={20} />
                <Trans id="candidate_management.table.headers.actions">
                  Actions
                </Trans>
              </div>
            </th>
          </tr>
        </thead>

        {loading ? (
          <tbody>
            <tr>
              <td colSpan={8} className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600 mx-auto"></div>
              </td>
            </tr>
          </tbody>
        ) : candidates.length === 0 ? (
          <tbody>
            <tr>
              <td colSpan={8} className="text-center py-8 text-gray-500">
                <Trans id="candidate_management.table.no_candidates">
                  No candidates found.
                </Trans>
              </td>
            </tr>
          </tbody>
        ) : (
          <tbody>
            {candidates.map((candidate) => (
              <tr key={candidate.id} className="border-b hover:bg-gray-50">
                <td className="px-4 py-2">{candidate.firstname}</td>
                <td className="px-4 py-2">{candidate.lastname}</td>
                <td className="px-4 py-2">{candidate.email}</td>
                <td className="px-4 py-2">{candidate.phone}</td>
                <td className="px-4 py-2"></td>
                <td className="px-4 py-2">
                  <div
                    className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                      getStatusStyle(candidate.status).bg
                    } ${getStatusStyle(candidate.status).text} ${
                      getStatusStyle(candidate.status).border
                    }`}
                  >
                    {candidate.status.charAt(0) +
                      candidate.status.slice(1).toLowerCase()}
                  </div>
                </td>
                <td className="px-4 py-2">
                  <div className="flex items-center justify-center h-full space-x-3 text-lg">
                    <button
                      className="text-blue-500 hover:text-blue-700"
                      onClick={() =>
                        navigate(`${candidate.id}`)
                      }
                      title={t({
                        id: "candidate_management.table.actions.view_tooltip",
                        message: "View candidate profile",
                      })}
                    >
                      <Eye size={16} />
                    </button>

                    {processingIds.includes(candidate.id) ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-teal-600 mx-2"></div>
                    ) : (
                      <>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <button
                              disabled={processingIds.includes(candidate.id)}
                              className="text-green-500 hover:text-green-700 disabled:opacity-50"
                              title={t({
                                id: "candidate_management.table.actions.activate_tooltip",
                                message: "Activate candidate",
                              })}
                            >
                              <Check size={15} />
                            </button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>
                                <Trans id="candidate_management.dialogs.activate.title">
                                  Confirm Activation
                                </Trans>
                              </AlertDialogTitle>
                              <AlertDialogDescription>
                                <Trans id="candidate_management.dialogs.activate.description">
                                  Are you sure you want to activate "
                                  {candidate.firstname} {candidate.lastname}"?
                                </Trans>
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>
                                <Trans id="candidate_management.dialogs.activate.cancel">
                                  Cancel
                                </Trans>
                              </AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() =>
                                  handleActivateCandidate(candidate.id)
                                }
                              >
                                <Trans id="candidate_management.dialogs.activate.confirm">
                                  Activate
                                </Trans>
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>

                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <button
                              disabled={processingIds.includes(candidate.id)}
                              className="text-red-500 hover:text-red-700 disabled:opacity-50"
                              title={t({
                                id: "candidate_management.table.actions.suspend_tooltip",
                                message: "Suspend candidate",
                              })}
                            >
                              <Ban size={15} />
                            </button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>
                                <Trans id="candidate_management.dialogs.suspend.title">
                                  Confirm Suspension
                                </Trans>
                              </AlertDialogTitle>
                              <AlertDialogDescription>
                                <Trans id="candidate_management.dialogs.suspend.description">
                                  Are you sure you want to suspend "
                                  {candidate.firstname} {candidate.lastname}"?
                                </Trans>
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>
                                <Trans id="candidate_management.dialogs.suspend.cancel">
                                  Cancel
                                </Trans>
                              </AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() =>
                                  handleSuspendCandidate(candidate.id)
                                }
                              >
                                <Trans id="candidate_management.dialogs.suspend.confirm">
                                  Suspend
                                </Trans>
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        )}
      </table>

      {/* Pagination */}
      <Pagination className="mt-4">
        <PaginationContent>
          {/* Previous */}
          <PaginationItem>
            <PaginationPrevious
              onClick={() => page > 1 && setPage(page - 1)}
              className={page === 1 ? "pointer-events-none opacity-50" : ""}
            />
          </PaginationItem>

          {/* Pages */}
          {pageItems.map((item, idx) =>
            item === "…" ? (
              <PaginationItem key={`e-${idx}`}>
                <PaginationEllipsis />
              </PaginationItem>
            ) : (
              <PaginationItem key={item}>
                <PaginationLink
                  onClick={() => setPage(item)}
                  isActive={page === item}
                >
                  {item}
                </PaginationLink>
              </PaginationItem>
            )
          )}

          {/* Next */}
          <PaginationItem>
            <PaginationNext
              onClick={() => page < totalPages && setPage(page + 1)}
              className={
                page === totalPages ? "pointer-events-none opacity-50" : ""
              }
            />
          </PaginationItem>
        </PaginationContent>
      </Pagination>
    </div>
  );
}

export default function AllCandidates() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("All");
  const [analyticsData, setAnalyticsData] = useState([
    {
      title: t({
        id: "candidate_management.analytics.total_candidates",
        message: "Total Candidates",
      }),
      value: "248",
      subtitle: t({
        id: "candidate_management.analytics.vs_last_month",
        message: "vs last month",
      }),
      trend: 3.2,
      icon: <Users className="text-white" size={20} />,
      gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
      chartColor: "#238D94",
    },
    {
      title: t({
        id: "candidate_management.analytics.new_applications",
        message: "New applications this week",
      }),
      value: "23",
      subtitle: t({
        id: "candidate_management.analytics.vs_last_month",
        message: "vs last month",
      }),
      trend: 2.1,
      icon: <CalendarPlus className="text-white" size={20} />,
      gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
      chartColor: "#238D94",
    },
    {
      title: t({
        id: "candidate_management.analytics.pending_decisions",
        message: "Pending Decisions",
      }),
      value: "51",
      subtitle: "",
      trend: 0,
      icon: <ClipboardPlusIcon className="text-white" size={20} />,
      gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
      chartColor: "#238D94",
    },
    {
      title: t({
        id: "candidate_management.analytics.approval_rate",
        message: "Approval Rate",
      }),
      value: "32%",
      subtitle: t({
        id: "candidate_management.analytics.vs_last_month",
        message: "vs last month",
      }),
      trend: -0.5,
      icon: <BadgeCheck className="text-white" size={20} />,
      gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
      chartColor: "#238D94",
    },
  ]);

  useEffect(() => {
    fetchStatistics();
  }, []);

  const fetchStatistics = async () => {
    try {
      const stats: statisticsCandidat =
        await candidateDashboardService.getCandidateStatistics();

      setAnalyticsData([
        {
          title: t({
            id: "candidate_management.analytics.total_candidates",
            message: "Total Candidates",
          }),
          value: stats.totalCandidates.toString(),
          subtitle: t({
            id: "candidate_management.analytics.vs_last_month",
            message: "vs last month",
          }),
          trend: parseFloat(
            stats.totalCandidatesTrend.toString().replace("%", "")
          ),
          icon: <Users className="text-white" size={20} />,
          gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
          chartColor: "#238D94",
        },
        {
          title: t({
            id: "candidate_management.analytics.new_applications",
            message: "New applications this week",
          }),
          value: stats.newApplications.toString(),
          subtitle: t({
            id: "candidate_management.analytics.vs_last_month",
            message: "vs last month",
          }),
          trend: parseFloat(
            stats.newApplicationsTrend.toString().replace("%", "")
          ),
          icon: <CalendarPlus className="text-white" size={20} />,
          gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
          chartColor: "#238D94",
        },
        {
          title: t({
            id: "candidate_management.analytics.pending_decisions",
            message: "Pending Decisions",
          }),
          value: stats.pendingDecisions.toString(),
          subtitle: "",
          trend: 0,
          icon: <ClipboardPlusIcon className="text-white" size={20} />,
          gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
          chartColor: "#238D94",
        },
        {
          title: t({
            id: "candidate_management.analytics.approval_rate",
            message: "Approval Rate",
          }),
          value: `${stats.approvalRate}%`,
          subtitle: t({
            id: "candidate_management.analytics.vs_last_month",
            message: "vs last month",
          }),
          trend: stats.approvalRateTrend,
          icon: <BadgeCheck className="text-white" size={20} />,
          gradient: "bg-gradient-to-br from-[#238D94] to-[#1a6b72]",
          chartColor: "#238D94",
        },
      ]);
    } catch (error) {
      console.error("Error fetching statistics:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            <Trans id="candidate_management.header.title">All Candidates</Trans>
          </h1>
          <p className="text-gray-600">
            <Trans id="candidate_management.header.description">
              Browse and manage profiles of all applicants under review.
            </Trans>
          </p>
        </div>

        {/* Analytic cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {analyticsData.map((item, index) => (
            <AnalyticsCard key={index} {...item} />
          ))}
        </div>

        {/* Search and filter */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-10 mt-6">
          <SearchAndFilter
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            onFilterClick={setFilterStatus}
          />
        </div>

        {/* Table */}
        <div className="">
          <TableCandidates
            searchTerm={searchTerm}
            filterStatus={filterStatus}
          />
        </div>
      </div>
    </div>
  );
}
