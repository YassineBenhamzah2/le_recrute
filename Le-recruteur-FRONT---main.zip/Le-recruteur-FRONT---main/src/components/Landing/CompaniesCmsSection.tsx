import { useEffect, useState } from "react";
import { AdminCompanyCmsResponse, PaginatedCmsCompanies } from "@/lib/types/company";
import { companyCmsApi } from "@/lib/network/companyCmsApi";
import { settings } from "@/lib/settings/main";
import { Trans } from '@lingui/macro';
import { useNavigate } from "react-router-dom"; // Import useNavigate

export default function CompaniesCmsSlider() {
  const [companies, setCompanies] = useState<AdminCompanyCmsResponse[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const visibleCount = 3; // nombre de cards visibles

  const navigate = useNavigate(); // Initialize useNavigate hook

  const fetchCompanies = async () => {
    try {
      const res: PaginatedCmsCompanies = await companyCmsApi.getCmsCompanies(0, 100);
      setCompanies(res.content);
    } catch (err) {
      console.error("Erreur chargement CMS companies", err);
    }
  };

  useEffect(() => {
    fetchCompanies();
  }, []);

  const nextSlide = () => {
    if (currentIndex + visibleCount < companies.length) setCurrentIndex(currentIndex + 1);
  };

  const prevSlide = () => {
    if (currentIndex > 0) setCurrentIndex(currentIndex - 1);
  };

  const handleViewCompanyDetails = (companyId: number) => {
    console.log("Navigating to company details for ID:", companyId); // Changed log message
    // Use navigate to go to the company details page
    navigate(`/entreprises/${companyId}`);
  };

  return (
    <section className="py-12 lg:py-16 px-4 bg-white relative z-10">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8 lg:mb-12">
          <h2 className="text-2xl lg:text-3xl font-bold text-[#238D94]">
            <Trans id="companies.title">COMPANIES</Trans>
          </h2>
          <div className="flex items-center gap-2">
            <button
              onClick={prevSlide}
              disabled={currentIndex === 0}
              className="p-4 text-2xl border border-[#238D94] rounded-lg hover:bg-[#238D94] hover:text-white transition-colors disabled:opacity-50"
            >
              &#8249;
            </button>
            <button
              onClick={nextSlide}
              disabled={currentIndex + visibleCount >= companies.length}
              className="p-4 text-2xl border border-[#238D94] rounded-lg hover:bg-[#238D94] hover:text-white transition-colors disabled:opacity-50"
            >
              &#8250;
            </button>
          </div>
        </div>

        {/* Slider */}
        <div className="overflow-hidden relative">
          <div
            className="flex transition-transform duration-300"
            style={{ transform: `translateX(-${currentIndex * (100 / visibleCount)}%)` }}
          >
            {companies.map((company) => (
              <div key={company.cmsId} className="relative flex-shrink-0 w-[calc(100%/3)] px-4">
                <div
                  className="bg-white p-6 rounded-xl shadow-lg hover:shadow-2xl transition-shadow cursor-pointer h-[30rem] lg:h-[34rem]"
                  onClick={() => handleViewCompanyDetails(company.companyId)} // Use company.companyId for navigation
                >
                  <div className="mb-6">
                    <img
                      src={company.logoUrl ? `${settings.IMG_ADDRESS}${company.logoUrl}` : "/default-image.png"}
                      alt={company.name}
                      className="w-full h-64 lg:h-72 object-cover rounded-lg"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "/default-image.png"; // Fallback for broken images
                      }}
                    />
                  </div>
                  <h3 className="text-2xl lg:text-3xl font-bold text-black mb-3">{company.name}</h3>
                  {company.destinationLink && (
                    <p
                      className="font-bold text-[#238D94] mb-3 truncate underline cursor-pointer"
                      onClick={(e) => { e.stopPropagation(); window.open(company.destinationLink!, "_blank"); }} // Open external link, stop propagation to prevent card click
                    >
                      {company.destinationLink}
                    </p>
                  )}
                  <p className="text-[#666] mb-4">{company.description}</p>
                  <button
                    className="text-[#238D94] font-semibold hover:underline text-lg"
                    onClick={(e) => { e.stopPropagation(); handleViewCompanyDetails(company.companyId); }} // Ensure button click also navigates and stops propagation
                  >
                    <Trans id="companies.view_details">View details</Trans>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}