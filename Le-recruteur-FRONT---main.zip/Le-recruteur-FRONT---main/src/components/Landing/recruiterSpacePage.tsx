import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "@/components/Layout/Header";
import Footer from "@/components/Layout/Footer";
import TestimonialsSection from "@/components/Landing/entrepriseSections/TestimonialsSection";
import JobRoleSection from "@/components/Landing/entrepriseSections/JobRoleSection";
import { ContactFormSection } from "@/components/Landing/faqSections/ContactFormSection";
import { MainContentSection } from "@/components/Landing/faqSections/MainContentSection";
import {
  UserPlus,
  Search,
  FacebookIcon,
  InstagramIcon,
  LinkedinIcon,
  MailIcon,
  MapPinIcon,
  PhoneIcon,
  TwitterIcon,
} from "lucide-react";
import { Trans, t } from "@lingui/macro"

interface ContactInfo {
  icon: JSX.Element;
  text: string;
  width: string;
}

interface SocialMedia {
  icon: JSX.Element;
  link: string;
}

interface FormField {
  id: "name" | "email" | "subject" | "message";
  type: "input" | "textarea";
}

const contactFormFields: FormField[] = [
  { id: "name", type: "input" },
  { id: "email", type: "input" },
  { id: "subject", type: "input" },
  { id: "message", type: "textarea" },
];

const RecruiterSpacePage: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  // Handlers pour les actions
  const handleGetStarted = () => {
    // Logic pour "Get Started" - redirection vers inscription
    console.log("Get Started clicked");
  };

  const handleSignIn = () => {
    // Logic pour "Sign In" - redirection vers connexion
    console.log("Sign In clicked");
    navigate("/auth");
  };

  const handleCreateAccount = () => {
    // Navigation vers la page d'inscription recruteur
    navigate("/auth/recruiter-signup");
  };

  const handleSignInRecruiter = () => {
    // Navigation vers la page de connexion recruteur
    navigate("/auth/recruiter-signin");
  };

  const contactInfo: ContactInfo[] = [
    {
      icon: <MapPinIcon className="h-5 w-5 text-[#238D94]" />,
      text: "123 Job Street, San Francisco, CA 94103",
      width: "w-[308px]",
    },
    {
      icon: <PhoneIcon className="h-5 w-5 text-[#238D94]" />,
      text: "+1 (555) 123-4567",
      width: "w-[141px]",
    },
    {
      icon: <MailIcon className="h-5 w-5 text-[#238D94]" />,
      text: "info@jobsearchplatform.com",
      width: "w-[235px]",
    },
  ];

  const socialMedia: SocialMedia[] = [
    {
      icon: <FacebookIcon className="h-4 w-4 text-[#238D94]" />,
      link: "https://facebook.com",
    },
    {
      icon: <TwitterIcon className="h-4 w-4 text-[#238D94]" />,
      link: "https://twitter.com",
    },
    {
      icon: <LinkedinIcon className="h-4 w-4 text-[#238D94]" />,
      link: "https://linkedin.com",
    },
    {
      icon: <InstagramIcon className="h-4 w-4 text-[#238D94]" />,
      link: "https://instagram.com",
    },
  ];

  return (
    <div className="flex flex-col w-full bg-white font-poppins">
      {/* Header */}
      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onGetStarted={handleGetStarted}
        onSignIn={handleSignIn}
      />

      {/* Hero Section */}
      <section className="w-full bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-6">
              <h1 className="text-4xl lg:text-5xl font-bold text-[#238D94] leading-tight">
                <Trans id="recruiter.hero.title">The right candidate, at the right time, in the right place</Trans>
              </h1>

              {/* Underline decoration */}
              <div className="w-16 h-1 bg-[#238D94]"></div>

              <p className="text-lg text-gray-700 leading-relaxed">
                <Trans id="recruiter.hero.description">
                  Discover <span className="font-semibold text-gray-900">thousands of talents</span> available full-time or part-time near you.<br />
                  Quickly find the right profiles for your hiring needs.
                </Trans>
              </p>
            </div>

            {/* Right Images Container */}
            <div className="relative">
              {/* Main Image - Team Meeting */}
              <div className="relative">
                <img
                  src="/teamMeeting.png"
                  alt={t({ id: "hero.mainImageAlt", message: "Team meeting" })}
                  className="w-full h-auto rounded-lg shadow-lg object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src =
                      "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80";
                  }}
                />

                {/* Decorative Form Image - Overlapping bottom right */}
                <div className="absolute -bottom-6 -right-6 w-48 h-32 z-10">
                  <img
                    src="/madarForm.png"
                    alt={t({ id: "hero.decorativeFormAlt", message: "Application form" })}
                    className="w-full h-full rounded-lg shadow-xl object-cover border-4"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        "https://images.unsplash.com/photo-1586281380349-632531db7ed4?auto=format&fit=crop&w=400&q=80";
                    }}
                  />
                </div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-4 -left-4 w-8 h-8 bg-[#238D94] rounded-full opacity-80"></div>
              <div className="absolute -bottom-4 -right-4 w-6 h-6 bg-blue-400 rounded-full opacity-80"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Welcome Section */}
      <section className="w-full bg-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Title */}
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-16">
            <Trans id="recruiter.welcome.title">
              Welcome to your<br />recruiter space
            </Trans>
          </h2>

          {/* Cards Container */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Card 1 - Nouveau ici */}
            <div className="text-center space-y-6 border-2 border-[#238D94] rounded-xl p-8">
              {/* Icon */}
              <div className="flex justify-center">
                <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                  <UserPlus className="w-8 h-8 text-gray-600" />
                </div>
              </div>

              {/* Content */}
              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-gray-900">
                  <Trans id="recruiter.card.new.title">New here?</Trans>
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  <Trans id="recruiter.card.new.description">
                    Sign up to post your job listings,<br />
                    manage applications,<br />
                    and more.
                  </Trans>
                </p>

                {/* Button */}
                <button
                  onClick={handleCreateAccount}
                  className="bg-[#238D94] hover:bg-[#1f7a80] text-white font-medium px-6 py-2.5 rounded-lg transition-colors duration-300"
                >
                  <Trans id="recruiter.card.new.button">Create an account</Trans>
                </button>
              </div>
            </div>

            {/* Card 2 - Déjà inscrit */}
            <div className="text-center space-y-6 border-2 border-[#238D94] rounded-xl p-8">
              {/* Icon */}
              <div className="flex justify-center">
                <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                  <Search className="w-8 h-8 text-gray-600" />
                </div>
              </div>

              {/* Content */}
              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-gray-900">
                  <Trans id="recruiter.card.existing.title">Already registered?</Trans>
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  <Trans id="recruiter.card.existing.description">
                    Access your recruiter dashboard.
                  </Trans>
                </p>

                {/* Button */}
                <button
                  onClick={handleSignInRecruiter}
                  className="bg-[#238D94] hover:bg-[#1f7a80] text-white font-medium px-6 py-2.5 rounded-lg transition-colors duration-300"
                >
                  <Trans id="recruiter.card.existing.button">Sign in</Trans>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <TestimonialsSection />

      {/* Job Role Section */}
      <JobRoleSection />

      {/* Contact Section */}
      <section className="w-full bg-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="mb-12">
            <h2 className="font-rubik font-bold text-[#238D94] text-4xl leading-[54px]">
              <Trans id="contact.title">Get In Touch</Trans>
            </h2>
            <div className="w-[60px] h-[3px] mt-1 bg-[#238D94]" />
          </div>

          <div className="flex flex-col md:flex-row gap-8">
            <MainContentSection
              contactInfo={contactInfo}
              socialMedia={socialMedia}
            />
            <ContactFormSection formFields={contactFormFields} />
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default RecruiterSpacePage;
