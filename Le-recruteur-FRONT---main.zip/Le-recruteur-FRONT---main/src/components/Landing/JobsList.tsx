/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState, useMemo } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import Header from "@/components/Layout/Header";
import Footer from "@/components/Layout/Footer";
import ApplyJobForm from "@/components/Modals/applyJobForm";
import { Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { JobSearch } from "./LandingJobsComponents/JobSearch";
import { JobFilters } from "./LandingJobsComponents/JobFilters";
import { sectorsService } from "@/lib/network/sector";
import { Sector } from "@/lib/types/base";
import { JobCard } from "./LandingJobsComponents/JobCard";
import Pagination, {
  usePaginationWithURL,
} from "@/components/CandidateComponents/Pagination";
import { jobOffersService } from "@/lib/network/pages/jobOffers";
import { JobOffer } from "@/lib/types/jobOffer";
import { useAuth } from "@/contexts/AuthContext";
import SortDropdown from "../CandidateComponents/SortDropdown";
import { Trans, t } from "@lingui/macro";

interface JobsListPageProps {
  onGetStarted?: () => void;
  onSignIn: () => void;
}
const jobsPerPage = 6;
const JobsListPage: React.FC<JobsListPageProps> = ({ onGetStarted }) => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { currentPage } = usePaginationWithURL();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSector, setSelectedSector] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("");
  const [expandedJobs, setExpandedJobs] = useState<{ [key: number]: boolean }>(
    {}
  );
  const [isApplyFormOpen, setIsApplyFormOpen] = useState(false);
  const [selectedJobTitle, setSelectedJobTitle] = useState<string>("");
  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);
  const [selectedQuestions, setSelectedQuestions] = useState<
    string[] | undefined
  >(undefined);
  const [selectedQuestionIds, setSelectedQuestionIds] = useState<
    number[] | undefined
  >(undefined);

  const [allJobs, setAllJobs] = useState<JobOffer[]>([]);
  const [filteredJobs, setFilteredJobs] = useState<JobOffer[]>([]);
  const [sortedJobs, setSortedJobs] = useState<JobOffer[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [sectors, setSectors] = useState<Sector[]>([]);
  const [loadingSectors, setLoadingSectors] = useState<boolean>(true);

  const { user } = useAuth();
  // Use the Auth context's role type checking
  const isCandidate = user?.role.type === "CANDIDATE";
  const candidateId = +(user?.id || 0);

  // Sync URL -> state (handles back/forward and direct links)
  useEffect(() => {
    const pairs: [
      key: string,
      setter: React.Dispatch<React.SetStateAction<string>>
    ][] = [
      ["title", setSearchQuery],
      ["sector", setSelectedSector],
      ["location", setSelectedLocation],
    ];
    for (const [key, setter] of pairs) {
      const next = searchParams.get(key) || "";
      setter((prev) => (prev === next ? prev : next));
    }
  }, [searchParams]);

  // Fetch all jobs
  useEffect(() => {
    const fetchAllJobs = async () => {
      setLoading(true);
      setError(null);

      try {
        // First, get metadata to know how many items exist
        const metadataResponse = await jobOffersService.getAll({
          page: 0,
          size: 1,
        });

        if (!metadataResponse.metadata?.pagination) {
          setError("Failed to fetch job metadata");
          return;
        }

        const { totalItems } = metadataResponse.metadata.pagination;

        let allFetchedJobs: JobOffer[] = [];

        // If total items is reasonable, fetch all at once
        if (totalItems <= 200) {
          const response = await jobOffersService.getAll({
            page: 0,
            size: totalItems,
          });
          if (response.data) {
            allFetchedJobs = response.data;
          }
        } else {
          // For larger datasets, fetch in reasonable chunks
          const pageSize = 50;
          const totalPages = Math.ceil(totalItems / pageSize);

          for (let page = 0; page < totalPages; page++) {
            const response = await jobOffersService.getAll({
              page: page,
              size: pageSize,
            });
            if (response.data) {
              allFetchedJobs = [...allFetchedJobs, ...response.data];
            }
          }
        }
        setAllJobs(allFetchedJobs);
        setFilteredJobs(allFetchedJobs);
        setSortedJobs(allFetchedJobs);
        setTotalPages(Math.ceil(allFetchedJobs.length / jobsPerPage));
      } catch (err: any) {
        setError(err.message || "An error occurred while fetching job offers");
        console.error("Error fetching job offers:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchAllJobs();
  }, []);

  // Apply pagination to sorted jobs
  const paginatedJobs = useMemo(() => {
    const startIndex = (currentPage - 1) * jobsPerPage;
    return sortedJobs.slice(startIndex, startIndex + jobsPerPage);
  }, [sortedJobs, currentPage]);

  // Update total pages when filtered jobs change
  useEffect(() => {
    setTotalPages(Math.ceil(filteredJobs.length / jobsPerPage));
  }, [filteredJobs]);

  // Fetch all sectors
  useEffect(() => {
    const fetchSectors = async () => {
      setLoadingSectors(true);
      try {
        const response = await sectorsService.getAll();
        if (response.success && response.data) {
          setSectors(response.data);
        }
      } catch (err) {
        console.error("Error fetching sectors:", err);
      } finally {
        setLoadingSectors(false);
      }
    };

    fetchSectors();
  }, []);

  // Move popularJobs inside component render to access i18n context
  const popularJobs = useMemo(
    () => [
      t({ id: "jobs.popular.ui_designer", message: "UI Designer" }),
      t({ id: "jobs.popular.ux_researcher", message: "UX Researcher" }),
      t({
        id: "jobs.popular.frontend_developer",
        message: "Front-End Developer",
      }),
    ],
    []
  );

  const toggleJobDetails = (jobId: number) => {
    setExpandedJobs((prev) => ({
      ...prev,
      [jobId]: !prev[jobId],
    }));
  };

  // handle search: title and sector are server side filters but location still just UI
  const handleSearch = () => {
    // Apply search filters to allJobs
    const filtered = allJobs.filter((job) => {
      const matchesSearch =
        !searchQuery ||
        job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (job.company?.name || "")
          .toLowerCase()
          .includes(searchQuery.toLowerCase());

      const matchesSector =
        !selectedSector ||
        (job.company?.sector !== undefined &&
          // Find matching sector by name or ID
          (job.company.sector === selectedSector ||
            // If sector ID is selected, find the sector with matching name
            sectors.find((s) => String(s.id) === selectedSector)?.name ===
              job.company.sector));

      const matchesLocation =
        !selectedLocation ||
        job.location.toLowerCase().includes(selectedLocation.toLowerCase());

      return matchesSearch && matchesSector && matchesLocation;
    });

    setFilteredJobs(filtered);
    setSearchParams((prev) => {
      const newParams = new URLSearchParams(prev);
      newParams.set("page", "1");
      if (searchQuery) newParams.set("title", searchQuery);
      else newParams.delete("title");
      if (selectedSector) newParams.set("sector", selectedSector);
      else newParams.delete("sector");
      if (selectedLocation) newParams.set("location", selectedLocation);
      else newParams.delete("location");
      return newParams;
    });
  };

  // Handle comprehensive filters from JobFilters component
  const handleFiltersChange = (filters: any) => {
    console.log("Received filters in JobsList:", filters);

    const filtered = allJobs.filter((job) => {
      // Job Title filter
      if (filters.jobTitle && filters.jobTitle.trim()) {
        const matchesTitle =
          job.title.toLowerCase().includes(filters.jobTitle.toLowerCase()) ||
          (job.company?.name || "")
            .toLowerCase()
            .includes(filters.jobTitle.toLowerCase());
        if (!matchesTitle) return false;
      }

      // Description filter
      if (filters.description && filters.description.trim()) {
        const matchesDescription =
          job.description
            ?.toLowerCase()
            .includes(filters.description.toLowerCase()) ||
          (Array.isArray(job.requirements) ? job.requirements.join(" ") : "")
            .toLowerCase()
            .includes(filters.description.toLowerCase());
        if (!matchesDescription) return false;
      }

      // Application Deadline filter
      if (filters.applicationDeadline) {
        const filterDate = new Date(filters.applicationDeadline);
        const jobDeadline = new Date(job.deadlineDate);
        if (jobDeadline > filterDate) return false;
      }

      // Salary Range filter
      if (filters.salaryRange) {
        if (filters.salaryRange.min && job.minSalary < filters.salaryRange.min)
          return false;
        if (filters.salaryRange.max && job.maxSalary > filters.salaryRange.max)
          return false;
      }

      // Sector of activity filter
      if (
        filters["Sector of activity"] &&
        filters["Sector of activity"].length > 0
      ) {
        if (!filters["Sector of activity"].includes(job.company?.sector))
          return false;
      }

      // Hiring Company filter
      if (filters["Hiring Company"] && filters["Hiring Company"].length > 0) {
        if (!filters["Hiring Company"].includes(job.company?.name))
          return false;
      }

      // Region filter (maps to location)
      if (filters["Region"] && filters["Region"].length > 0) {
        if (!filters["Region"].includes(job.location)) return false;
      }

      // Contract Type filter
      if (filters["Contract Type"] && filters["Contract Type"].length > 0) {
        if (!filters["Contract Type"].includes(job.contractType)) return false;
      }

      // Work Mode filter
      if (filters["Work Mode"] && filters["Work Mode"].length > 0) {
        if (!filters["Work Mode"].includes(job.workMode)) return false;
      }

      // Requirements filter
      if (filters["Requirements"] && filters["Requirements"].length > 0) {
        const jobRequirements = Array.isArray(job.requirements)
          ? job.requirements
          : [];
        const hasMatchingRequirement = filters["Requirements"].some(
          (req: string) =>
            jobRequirements.some((jobReq: string) =>
              jobReq.toLowerCase().includes(req.toLowerCase())
            )
        );
        if (!hasMatchingRequirement) return false;
      }

      return true;
    });

    setFilteredJobs(filtered);
  };

  const handleApplyNow = (
    jobId: number,
    jobTitle: string,
    questions?: string[],
    questionIds?: number[]
  ) => {
    setSelectedJobId(jobId);
    setSelectedJobTitle(jobTitle);
    setSelectedQuestions(questions);
    setSelectedQuestionIds(questionIds);
    setIsApplyFormOpen(true);
  };

  const handleCloseApplyForm = () => {
    setIsApplyFormOpen(false);
    setSelectedJobTitle("");
    setSelectedJobId(null);
    setSelectedQuestions(undefined);
    setSelectedQuestionIds(undefined);
  };

  // handle bookmark (save/unsave): server side
  const handleToggleBookmark = async (jobId: number) => {
    if (!user) {
      navigate("/auth");
      return;
    }
    try {
      await jobOffersService.bookmarkJob(jobId);
      // Update both allJobs and filteredJobs with the new bookmarkedBy array
      setAllJobs((prevJobs) =>
        prevJobs.map((job) => {
          if (job.id !== jobId) return job;

          const isBookmarked = job.bookmarkedBy?.includes(candidateId);
          const newBookmarkedBy = isBookmarked
            ? job.bookmarkedBy?.filter((id) => id !== candidateId) || []
            : [...(job.bookmarkedBy || []), candidateId];

          return {
            ...job,
            bookmarkedBy: newBookmarkedBy,
          };
        })
      );

      setFilteredJobs((prevJobs) =>
        prevJobs.map((job) => {
          if (job.id !== jobId) return job;

          const isBookmarked = job.bookmarkedBy?.includes(candidateId);
          const newBookmarkedBy = isBookmarked
            ? job.bookmarkedBy?.filter((id) => id !== candidateId) || []
            : [...(job.bookmarkedBy || []), candidateId];

          return {
            ...job,
            bookmarkedBy: newBookmarkedBy,
          };
        })
      );
    } catch (e) {
      console.error("Error toggling bookmark:", e);
    }
  };

  const handleApplied = async (jobId: number) => {
    // Optimistically mark as applied for current candidate
    if (isCandidate) {
      setAllJobs((prev) =>
        prev.map((job) =>
          job.id === jobId
            ? {
                ...job,
                appliedBy: Array.from(
                  new Set([...(job.appliedBy || []), candidateId])
                ),
              }
            : job
        )
      );
      setFilteredJobs((prev) =>
        prev.map((job) =>
          job.id === jobId
            ? {
                ...job,
                appliedBy: Array.from(
                  new Set([...(job.appliedBy || []), candidateId])
                ),
              }
            : job
        )
      );
    }
  };

  // This handler receives sorted data from SortDropdown
  const handleSortedDataChange = (sortedData: JobOffer[]) => {
    setSortedJobs(sortedData);
  };

  return (
    <div className="min-h-screen">
      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onSignIn={() => navigate("/auth")}
        onGetStarted={onGetStarted}
      />

      {/* Hero Section */}
      <div className="bg-white overflow-hidden">
        <div className="lg:px-8 py-16 bg-gray-50 relative overflow-hidden">
          <img
            src="/boxes.png"
            className="w-full h-[30rem] object-fit max-w-[600px] absolute right-[-10rem] top-[-30px] opacity-[25%] pointer-events-none"
          />
          {/* Main Title */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-6xl font-bold text-ehc-green mb-6 font-poppins">
              <Trans id="jobs.hero.title">Find Your Dream Job</Trans>
            </h1>
            <div className="space-y-2 text-lg md:text-xl text-gray-700 font-poppins">
              <p>
                <Trans id="jobs.hero.discover">
                  <span className="font-semibold">Discover</span> Thousands Of
                  Full-Time
                </Trans>
              </p>
              <p>
                <Trans id="jobs.hero.parttime">
                  And Part-Time{" "}
                  <span className="font-semibold">Opportunities</span> Near You.
                </Trans>
              </p>
            </div>
            <p className="mt-8 text-gray-600 max-w-4xl mx-auto font-poppins">
              <Trans id="jobs.hero.subtitle">
                From Tech To Design To Business, Explore Jobs Across Every
                Industry And Find The One That Fits You.
              </Trans>
            </p>
          </div>

          {/* Search Section */}
          <JobSearch
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            selectedSector={selectedSector}
            setSelectedSector={setSelectedSector}
            selectedLocation={selectedLocation}
            setSelectedLocation={setSelectedLocation}
            popularJobs={popularJobs}
            onSearch={handleSearch}
            sectors={sectors}
            loadingSectors={loadingSectors}
          />
        </div>
      </div>

      {/* Filter Jobs Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-ehc-green" />
            <span className="text-lg font-semibold text-gray-800 font-poppins">
              <Trans id="jobs.filters.label">Filter Jobs</Trans>
            </span>
          </div>
          <div>
            <SortDropdown
              data={filteredJobs}
              onSortedDataChange={handleSortedDataChange}
              defaultSort="most-recent"
            />
          </div>
        </div>
      </div>

      {/* Results Section with Filters and Job Listings */}
      <div className="max-w-[85%] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-12 gap-8">
          {/* Left Sidebar - Filters (25%) */}
          <div className="col-span-12 lg:col-span-3">
            <JobFilters
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              onFiltersChange={handleFiltersChange}
              sectors={sectors}
            />
          </div>

          {/* Right Content - Job Listings (75%) */}
          <div className="col-span-12 lg:col-span-9 job-listings-container">
            <div className="space-y-4">
              {loading && (
                <div className="text-gray-600">
                  <Trans id="jobs.loading">Loading jobs...</Trans>
                </div>
              )}
              {error && <div className="text-red-600">{error}</div>}
              {!loading && !error && paginatedJobs.length === 0 && (
                <div className="text-gray-600">
                  <Trans id="jobs.no_offers">No offers found.</Trans>
                </div>
              )}
              {!loading &&
                !error &&
                paginatedJobs.length > 0 &&
                paginatedJobs.map((job) => (
                  <JobCard
                    key={job.id}
                    job={job}
                    expanded={!!expandedJobs[job.id]}
                    onToggle={toggleJobDetails}
                    onApplyNow={handleApplyNow}
                    onViewMore={(id) => navigate(`/jobs/${id}`)}
                    onToggleBookmark={handleToggleBookmark}
                  />
                ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <Pagination
                totalPages={totalPages}
                preserveOtherParams={true}
                onPageChange={() => {
                  setExpandedJobs({});
                  const jobListings = document.querySelector(
                    ".job-listings-container"
                  );
                  if (jobListings)
                    jobListings.scrollIntoView({ behavior: "smooth" });
                }}
              />
            )}
          </div>
        </div>
      </div>

      {/* Got a role to fill section */}
      <div className="flex justify-center">
        <div className="max-w-[100rem]">
          <div className="bg-ehc-green rounded-l py-24 px-24 text-center">
            <h2 className="text-3xl font-bold text-white font-poppins mb-4">
              <Trans id="jobs.role.fill">Got a role to fill?</Trans>
            </h2>
            <p className="text-white font-poppins mb-6 text-lg">
              <Trans id="jobs.role.subtitle">
                Join top startups hiring talent like you. Post your job in
                minutes and find your next team member.
              </Trans>
            </p>
            <Button className="bg-white text-ehc-green hover:bg-gray-100 px-8 py-3 font-poppins font-semibold rounded-md">
              <Trans id="jobs.role.button">Post a Job Now</Trans>
            </Button>
          </div>
        </div>
      </div>

      {/* Job Categories Section */}
      <div className="bg-white py-16">
        <div className="max-w-screen">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-screen">
            {/* Left Side - Job Cards */}
            <div className="max-w-[450px] space-y-6 relative right-[-29rem] z-10">
              {/* First Card */}
              <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-100">
                <h3 className="text-xl font-bold text-gray-900 mb-3 font-poppins">
                  <Trans id="jobs.card.title">245 UX/UI Design Jobs</Trans>
                </h3>
                <p className="text-gray-600 mb-4 font-poppins text-sm">
                  <Trans id="jobs.card.subtitle">
                    Choose from a number of great projects
                  </Trans>
                </p>
                <Button className="bg-white border-2 border-ehc-green text-ehc-green hover:bg-ehc-green hover:text-white px-6 py-2 font-poppins text-sm font-medium rounded-md transition-colors duration-200">
                  <Trans id="jobs.card.button">See Listing</Trans>
                </Button>
              </div>

              {/* Second Card */}
              <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-100">
                <h3 className="text-xl font-bold text-gray-900 mb-3 font-poppins">
                  <Trans id="jobs.card.title">245 UX/UI Design Jobs</Trans>
                </h3>
                <p className="text-gray-600 mb-4 font-poppins text-sm">
                  <Trans id="jobs.card.subtitle">
                    Choose from a number of great projects
                  </Trans>
                </p>
                <Button className="bg-white border-2 border-ehc-green text-ehc-green hover:bg-ehc-green hover:text-white px-6 py-2 font-poppins text-sm font-medium rounded-md transition-colors duration-200">
                  <Trans id="jobs.card.button">See Listing</Trans>
                </Button>
              </div>
            </div>

            {/* Right Side - Team Image */}
            <div className="max-w-[30rem] pl-10">
              <div className="relative">
                <img
                  src="/listingEx.png"
                  alt="Team working together"
                  className="object-fit rounded-lg shadow-md"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Apply Job Form Modal */}
      <ApplyJobForm
        isOpen={isApplyFormOpen}
        onClose={handleCloseApplyForm}
        jobId={selectedJobId ?? undefined}
        jobTitle={selectedJobTitle}
        questions={selectedQuestions}
        questionIds={selectedQuestionIds}
        onApplied={handleApplied}
      />

      <Footer />
    </div>
  );
};

export default JobsListPage;
