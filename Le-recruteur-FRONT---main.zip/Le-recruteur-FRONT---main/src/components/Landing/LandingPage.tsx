import React, { useState } from 'react';
import { Search, MapPin, ChevronDown, ArrowRight, Star } from 'lucide-react';
import Header from '../Layout/Header';
import Footer from '../Layout/Footer';

interface LandingPageProps {
  onGetStarted?: () => void;
  onSignIn?: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted, onSignIn }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <Header 
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onSignIn={onSignIn}
        onGetStarted={onGetStarted}
      />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#f8f8fd] to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Hero Content */}
            <div className="space-y-8">
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                <span className="text-[#238D94]">Explore Over </span>
                <span className="text-gray-900">+8,000</span>
                <br />
                <span className="text-[#238D94]">Job</span>
                <span className="text-gray-900"> Opportunities</span>
              </h1>
              
              <p className="text-xl text-gray-600 leading-relaxed max-w-lg">
                Discover opportunities that <strong>inspire</strong> you and roles where your skills drive real change. 
                Step into a place where you don't just work—you <strong>grow</strong>, <strong>create</strong>, and leave your mark.
              </p>

              {/* Search Box */}
              <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-600">I am :</label>
                    <div className="flex items-center space-x-2">
                      <Search className="w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Job title or keyword"
                        className="flex-1 border-b border-gray-300 pb-2 focus:outline-none focus:border-[#238D94]"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-600">Location :</label>
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        defaultValue="Meknes, Morocco"
                        className="flex-1 border-b border-gray-300 pb-2 focus:outline-none focus:border-[#238D94]"
                      />
                      <ChevronDown className="w-4 h-4 text-gray-400" />
                    </div>
                  </div>
                  
                  <div className="flex items-end">
                    <button className="w-full bg-[#25324b] text-white py-4 px-6 rounded-xl font-semibold hover:bg-[#1e293e] transition-colors">
                      Find Jobs
                    </button>
                  </div>
                </div>
                
                <p className="text-sm text-gray-500 mt-4">
                  <span className="font-medium">Popular:</span> UI Designer, UX Researcher, Front-End Developer
                </p>
              </div>
            </div>

            {/* Hero Image */}
            <div className="relative">
              <div className="relative bg-[#238D94] rounded-[120px_8px_120px_8px] shadow-xl p-8">
                <img
                  src="/image.png"
                  alt="Professional"
                  className="w-full h-auto rounded-lg"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='500' viewBox='0 0 400 500'%3E%3Crect width='400' height='500' fill='%23f3f4f6'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial' font-size='16' fill='%236b7280' text-anchor='middle' dy='0.3em'%3EProfessional Image%3C/text%3E%3C/svg%3E";
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Categories */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-4xl font-bold">
              <span className="text-gray-900">Popular </span>
              <span className="text-[#238D94]">Categories</span>
            </h2>
            <button className="text-[#238D94] font-semibold hover:underline">
              View All Jobs
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: "Graphics & Design", positions: "357 Open Position", featured: false },
              { title: "Digital Marketing", positions: "248 Open Position", featured: true },
              { title: "Code & Programming", positions: "123 Open Position", featured: false },
              { title: "Data Science", positions: "89 Open Position", featured: false },
              { title: "Business Development", positions: "156 Open Position", featured: false },
              { title: "Content Writing", positions: "234 Open Position", featured: false },
            ].map((category, index) => (
              <div
                key={index}
                className={`p-8 rounded-lg border-2 text-center transition-all hover:shadow-lg ${
                  category.featured
                    ? 'bg-[#238D94] text-white border-[#238D94]'
                    : 'bg-white text-gray-900 border-gray-200 hover:border-[#238D94]'
                }`}
              >
                <div className={`w-16 h-16 mx-auto mb-4 rounded-lg flex items-center justify-center ${
                  category.featured ? 'bg-white' : 'bg-[#238D94]'
                }`}>
                  <div className={`w-8 h-8 ${category.featured ? 'bg-[#238D94]' : 'bg-white'} rounded`}></div>
                </div>
                <h3 className="text-xl font-semibold mb-2">{category.title}</h3>
                <p className={`text-sm ${category.featured ? 'text-gray-200' : 'text-gray-600'}`}>
                  {category.positions}
                </p>
                <ArrowRight className="w-6 h-6 mx-auto mt-4" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-[#f8f8fd]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-16">
            <span className="text-gray-900">Get </span>
            <span className="text-[#238D94]">Started</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: "Create account", description: "Sign up in seconds and set up your profile.", step: "01" },
              { title: "Upload CV/Resume", description: "Showcase your experience and skills.", step: "02" },
              { title: "Find suitable job", description: "Browse startup jobs that match your vibe.", step: "03" },
              { title: "Apply job", description: "Send your application and start your journey.", step: "04" },
            ].map((step, index) => (
              <div key={index} className="bg-white rounded-xl border border-[#238D94] p-8 text-center">
                <div className="w-16 h-16 bg-[#238D94] text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                  {step.step}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600 text-sm">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Testimonials</h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {[
              {
                name: "Yassine B.",
                role: "Product Designer",
                quote: "EHC made my job search feel exciting again. I connected with a startup that values creativity and fast thinking. Within two weeks, I had an offer in hand!"
              },
              {
                name: "Salma R.",
                role: "Marketing Specialist",
                quote: "I love how easy and focused the platform is. Unlike traditional job boards, EHC understands what startup talent is really looking for."
              }
            ].map((testimonial, index) => (
              <div key={index} className="bg-white border border-[#238D94] rounded-lg p-8 shadow-sm">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-[#238D94] rounded-full flex items-center justify-center text-white font-bold text-xl">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div className="ml-4">
                    <h4 className="font-bold text-[#238D94] text-lg">{testimonial.name}</h4>
                    <p className="text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-gray-700 leading-relaxed">"{testimonial.quote}"</p>
                <div className="flex mt-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Candidate CTA */}
            <div className="bg-[#e6f4f1] rounded-xl p-8">
              <h3 className="text-3xl font-bold text-[#238D94] mb-4">Become a Candidate</h3>
              <p className="text-gray-700 mb-6">
                Create your profile, showcase your skills, and land your next big opportunity with a startup that matches your ambition.
              </p>
              <button 
                className="bg-[#238D94] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#1a6b75] transition-colors"
                onClick={onGetStarted}
              >
                Register Now
              </button>
            </div>

            {/* Employer CTA */}
            <div className="bg-[#238D94] rounded-xl p-8">
              <h3 className="text-3xl font-bold text-white mb-4">Become an Employer</h3>
              <p className="text-gray-200 mb-6">
                Post your job, connect with top talent, and build the dream team to take your startup to the next level.
              </p>
              <button 
                className="bg-white text-[#238D94] px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
                onClick={onGetStarted}
              >
                Register Now
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default LandingPage;