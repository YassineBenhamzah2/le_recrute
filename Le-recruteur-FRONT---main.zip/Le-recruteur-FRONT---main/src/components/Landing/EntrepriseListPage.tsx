import { companyService } from "@/lib/network/company";
import { GetCompanysQuery, Sector } from "@/lib/types/base";
import { Company } from "@/lib/types/company";
import { useEffect, useState } from "react";
import Footer from "../Layout/Footer";
import Header from "../Layout/Header";
import { FilterSection } from "./entreprisesSections/FilterSection";
import { HeroSection } from "./entreprisesSections/HeroSection";
import { JobListSection } from "./entreprisesSections/JobListSection";
import { useDebounce } from "../Auth/hooks/useDebounce";
import { sectorsService } from "@/lib/network/sector";
import { t } from "@lingui/macro";

interface EntreprisePageProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

const EntreprisePage = ({
  onGetStarted,
  onSignIn,
}: EntreprisePageProps): JSX.Element => {

  // Employment types data using JobType from main.ts
  const employmentTypesData = [
    { id: "FREELANCE", label: t({ id: "employment.freelance", message: "Freelance" }) },
    { id: "FULL_TIME", label: t({ id: "employment.fullTime", message: "Full Time" }) },
    { id: "INTERNSHIP", label: t({ id: "employment.internship", message: "Internship" }) },
    { id: "PART_TIME", label: t({ id: "employment.partTime", message: "Part Time" }) },
  ];

  // Contract types data using ContractType from main.ts
  const contractTypesData = [
    { id: "CDI", label: t({ id: "contract.cdi", message: "CDI" }) },
    { id: "CDD", label: t({ id: "contract.cdd", message: "CDD" }) },
    { id: "CONTRACT_PROJECT", label: t({ id: "contract.project", message: "Contract Project" }) },
    { id: "CONTRACT_ANAPEC", label: t({ id: "contract.anapec", message: "Contract ANAPEC" }) },
  ];

  // Tags data
  const tagsData = [
    { id: "general", label: t({ id: "tag.general", message: "General" }) },
    { id: "jobs", label: t({ id: "tag.jobs", message: "Jobs" }) },
    { id: "payment", label: t({ id: "tag.payment", message: "Payment" }) },
    { id: "application", label: t({ id: "tag.application", message: "Application" }) },
    { id: "work", label: t({ id: "tag.work", message: "Work" }) },
    { id: "recruiting", label: t({ id: "tag.recruiting", message: "Recruiting" }) },
    { id: "employer", label: t({ id: "tag.employer", message: "Employer" }) },
    { id: "income", label: t({ id: "tag.income", message: "Income" }) },
    { id: "tips", label: t({ id: "tag.tips", message: "Tips" }) },
  ];

  // State for mobile menu
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // State for companies data
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // State for filter and search
  const [searchKeyword, setSearchKeyword] = useState("");
  const [searchLocation, setSearchLocation] = useState("");
  const [selectedSector, setSelectedSector] = useState("all");
  const [sectors, setSectors] = useState<Sector[]>([]);
  const [loadingSectors, setLoadingSectors] = useState(true);

  // Fetch sectors
  useEffect(() => {
    const fetchSectors = async () => {
      setLoadingSectors(true);
      try {
        const response = await sectorsService.getAll();
        if (response.success && response.data) {
          setSectors(response.data);
        } else {
          console.error("Failed to load sectors");
        }
      } catch (err) {
        console.error("Error fetching sectors:", err);
      } finally {
        setLoadingSectors(false);
      }
    };

    fetchSectors();
  }, []);

  const [selectedEmploymentTypes, setSelectedEmploymentTypes] = useState<
    string[]
  >([]);
  const [selectedContractTypes, setSelectedContractTypes] = useState<string[]>(
    []
  );
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  // Debounced search values to avoid too many API calls
  const debouncedSearchKeyword = useDebounce(searchKeyword, 500);
  const debouncedSearchLocation = useDebounce(searchLocation, 500);

  // State for pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [sortBy, setSortBy] = useState("recent");
  const [totalPages, setTotalPages] = useState(0);

  // Fetch companies from API
  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        setLoading(true);
        setError(null);

        const queryParams: GetCompanysQuery = {
          search: debouncedSearchKeyword || undefined,
          page: currentPage,
          sector: selectedSector !== "all" ? selectedSector : undefined,
          address: debouncedSearchLocation || undefined,
          contractTypes:
            selectedContractTypes.length > 0
              ? selectedContractTypes.join(",")
              : undefined,
          jobTypes:
            selectedEmploymentTypes.length > 0
              ? selectedEmploymentTypes.join(",")
              : undefined,
          tags: selectedTags.length > 0 ? selectedTags.join(",") : undefined,
        };

        const response = await companyService.getCompanies(queryParams);

        if (response.success) {
          setCompanies(response.data);
          if (response.metadata?.pagination) {
            setTotalPages(response.metadata.pagination.totalPages);
          }
        } else {
          setError("Failed to load companies");
        }
      } catch (err) {
        console.error("Error fetching companies:", err);
        setError("An error occurred while loading companies");
      } finally {
        setLoading(false);
      }
    };

    fetchCompanies();
  }, [
    debouncedSearchKeyword,
    debouncedSearchLocation,
    selectedSector,
    selectedEmploymentTypes,
    currentPage,
    selectedContractTypes,
    selectedTags,
  ]);

  // Reset to first page when search filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [
    debouncedSearchKeyword,
    debouncedSearchLocation,
    selectedSector,
    selectedEmploymentTypes,
  ]);

  // Handle page change
  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  // Handle employment type selection
  const handleEmploymentTypeChange = (typeId: string) => {
    setSelectedEmploymentTypes((prev) => {
      if (prev.includes(typeId)) {
        return prev.filter((id) => id !== typeId);
      } else {
        return [...prev, typeId];
      }
    });
  };

  // Handle contract type selection
  const handleContractTypeChange = (typeId: string) => {
    setSelectedContractTypes((prev) => {
      if (prev.includes(typeId)) {
        return prev.filter((id) => id !== typeId);
      } else {
        return [...prev, typeId];
      }
    });
  };

  // Handle tag selection
  const handleTagClick = (tagId: string) => {
    setSelectedTags((prev) => {
      if (prev.includes(tagId)) {
        return prev.filter((id) => id !== tagId);
      } else {
        return [...prev, tagId];
      }
    });
  };

  // Define decorative elements data for easier mapping
  const decorativeElements = [
    {
      position: "top-[750px] left-[40px]",
      src: "decorativeElement.png",
      alt: t({ id: "decorative.element1", message: "Decorative element 1" }),
    },
    {
      position: "top-[1050px] right-[10px]",
      src: "decorativeElement.png",
      alt: t({ id: "decorative.element2", message: "Decorative element 2" }),
    },
    {
      position: "bottom-[800px] left-[33px]",
      src: "decorativeElement.png",
      alt: t({ id: "decorative.element3", message: "Decorative element 3" }),
    },
    {
      position: "bottom-[500px] right-[10px]",
      src: "decorativeElement.png",
      alt: t({ id: "decorative.element4", message: "Decorative element 4" }),
    },
  ];

  // Handle reset filters
  const handleResetFilters = () => {
    setSearchKeyword("");
    setSearchLocation("");
    setSelectedSector("all");
    setSelectedEmploymentTypes([]);
    setSelectedContractTypes([]);
    setSelectedTags([]);
  };

  return (
    <div className="relative w-full bg-[#f5f7fa] min-h-screen flex flex-col">
      {/* Header section */}
      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onSignIn={onSignIn}
        onGetStarted={onGetStarted}
      />

      {/* Hero section */}
      <HeroSection />

      {/* Filter section */}
      <div className="w-full px-6 md:px-8">
        <FilterSection
          searchKeyword={searchKeyword}
          setSearchKeyword={setSearchKeyword}
          searchLocation={searchLocation}
          setSearchLocation={setSearchLocation}
          selectedSector={selectedSector}
          setSelectedSector={setSelectedSector}
          onResetFilters={handleResetFilters}
          sectors={sectors.map((sector) => ({
            id: sector.id.toString(),
            name: sector.name,
          }))}
          loadingSectors={loadingSectors}
        />
      </div>

      {/* Job listings section with filters - flex-grow to push footer down */}
      <div className="w-full px-6 sm:px-16 md:px-32 relative flex-grow ">
        <JobListSection
          companies={companies}
          employmentTypes={employmentTypesData}
          contractTypes={contractTypesData}
          tags={tagsData}
          selectedEmploymentTypes={selectedEmploymentTypes}
          handleEmploymentTypeChange={handleEmploymentTypeChange}
          selectedContractTypes={selectedContractTypes}
          handleContractTypeChange={handleContractTypeChange}
          selectedTags={selectedTags}
          handleTagClick={handleTagClick}
          currentPage={currentPage}
          handlePageChange={handlePageChange}
          totalPages={totalPages}
          itemsPerPage={itemsPerPage}
          setItemsPerPage={setItemsPerPage}
          sortBy={sortBy}
          setSortBy={setSortBy}
          loading={loading}
          error={error}
        />
      </div>

      {/* Footer section - will stick to bottom */}
      <Footer />

      {/* Decorative elements */}
      {decorativeElements.map((element, index) => (
        <img
          key={`decorative-element-${index}`}
          className={`absolute w-[73px] h-[106px] ${element.position}`}
          alt={element.alt}
          src={element.src}
        />
      ))}
    </div>
  );
};
export default EntreprisePage;
