import { Search, Building2, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import React, { useState, useEffect } from "react";
import { jobOffersService } from "@/lib/network/pages/jobOffers";
import { Trans } from '@lingui/macro';

interface JobSearchProps {
  searchQuery: string;
  setSearchQuery: (val: string) => void;
  selectedSector: string;
  setSelectedSector: (val: string) => void;
  selectedLocation: string;
  setSelectedLocation: (val: string) => void;
  popularJobs: string[];
  onSearch: () => void;
  sectors?: { id: number; name: string }[];
  loadingSectors?: boolean;
}

export const JobSearch: React.FC<JobSearchProps> = ({
  searchQuery,
  setSearchQuery,
  selectedSector,
  setSelectedSector,
  selectedLocation,
  setSelectedLocation,
  popularJobs,
  onSearch,
  sectors = [],
  loadingSectors = false,
}) => {
  // Use provided sectors from props
  const [apiLocations, setApiLocations] = useState<string[]>([]);

  useEffect(() => {
    jobOffersService.getLocations().then((response) => {
      if (response.success && response.data) {
        setApiLocations(response.data);
      }
    });
  }, []);

  const displayLocations =
    apiLocations.length > 0 ? apiLocations : ["All locations"];

  return (
    <div className="max-w-[85%] mx-auto relative z-20">
      <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-6 relative z-20">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          {/* Job Position Search */}
          <div className="md:col-span-1">
            <label className="block text-sm font-semibold text-gray-700 mb-2 font-poppins text-[1rem]">
              <Trans id="job_search.position">Position</Trans>
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="text"
                placeholder="........"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 font-poppins"
              />
            </div>
          </div>

          {/* Sector Dropdown (uses real API sectors) */}
          <div className="md:col-span-1">
            <label className="block text-sm font-semibold text-gray-700 mb-2 font-poppins text-[1rem]">
              <Trans id="job_search.sector">Sector of activity:</Trans>
            </label>
            <Select
              value={selectedSector}
              onValueChange={(val) =>
                setSelectedSector(val === "__all__" ? "" : val)
              }
            >
              <SelectTrigger className="font-poppins">
                <div className="flex items-center">
                  <Building2 className="w-4 h-4 mr-2 text-gray-400" />
                  <SelectValue placeholder={<Trans id="job_search.all_sectors">All sectors</Trans>} />
                </div>
              </SelectTrigger>
              <SelectContent>
                {/* All sectors: removes sector from URL by setting empty state */}
                <SelectItem value="__all__" className="font-poppins">
                  <Trans id="job_search.all_sectors">All sectors</Trans>
                </SelectItem>
                {loadingSectors ? (
                  <SelectItem
                    value="__loading__"
                    disabled
                    className="font-poppins text-gray-500"
                  >
                    <Trans id="job_search.loading_sectors">Loading sectors...</Trans>
                  </SelectItem>
                ) : sectors.length > 0 ? (
                  sectors.map((sector) => (
                    <SelectItem
                      key={sector.id}
                      value={String(sector.id)} // Use sector ID as the value
                      className="font-poppins"
                    >
                      {sector.name}
                    </SelectItem>
                  ))
                ) : (
                  <SelectItem
                    value="__no_sectors__"
                    disabled
                    className="font-poppins"
                  >
                    <Trans id="job_search.no_sectors">No sectors available</Trans>
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Location Dropdown */}
          <div className="md:col-span-1">
            <label className="block text-sm font-semibold text-gray-700 mb-2 font-poppins text-[1rem]">
              <Trans id="job_search.location">Location:</Trans>
            </label>
            <Select
              value={selectedLocation}
              onValueChange={(val) =>
                setSelectedLocation(val === "__all__" ? "" : val)
              }
            >
              <SelectTrigger className="font-poppins">
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                  <SelectValue placeholder={<Trans id="job_search.all_locations">All locations</Trans>} />
                </div>
              </SelectTrigger>
              <SelectContent>
                {/* All locations: clears location filter (removes URL key) */}
                <SelectItem value="__all__" className="font-poppins">
                  <Trans id="job_search.all_locations">All locations</Trans>
                </SelectItem>
                {displayLocations.map((location) => (
                  <SelectItem
                    key={location}
                    value={location}
                    className="font-poppins"
                  >
                    {location}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Find Jobs Button */}
          <div className="md:col-span-1 flex items-end">
            <Button
              onClick={onSearch}
              type="button"
              className="w-full bg-slate-700 hover:bg-slate-800 text-white font-semibold py-3 px-6 rounded-md transition-colors duration-200 font-poppins"
              size="lg"
            >
              <Trans id="job_search.find_jobs">Find Jobs</Trans>
            </Button>
          </div>
        </div>

        {/* Popular Jobs */}
        <div className="border-t border-gray-200 pt-4">
          <div className="flex flex-wrap items-center gap-2 max-w-[30%]">
            <span className="text-sm text-gray-600 font-poppins">
              <Trans id="job_search.popular">Popular:</Trans>
            </span>
            {popularJobs.map((job, index) => (
              <button
                key={job}
                className="text-sm text-ehc-green hover:text-ehc-green-dark font-medium transition-colors duration-200 font-poppins"
                onClick={() => {
                  setSearchQuery(job);
                }}
              >
                <Trans id={`job_search.popular_jobs.${job}`}>{job}</Trans>
                {index < popularJobs.length - 1 && (
                  <span className="text-gray-400 ml-1">,</span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
