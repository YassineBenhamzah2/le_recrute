import React from "react";
import { Bookmark, Clock, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { JobOffer } from "@/lib/types/jobOffer";
import { settings } from "@/lib/settings/main";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Trans } from "@lingui/macro";

// Helpers to map API -> UI fields
const mapJobType = (t?: string): React.ReactNode => {
  switch (t) {
    case "FULL_TIME":
      return <Trans id="job_type.full_time">Full Time</Trans>;
    case "PART_TIME":
      return <Trans id="job_type.part_time">Part Time</Trans>;
    case "INTERNSHIP":
      return <Trans id="job_type.internship">Internship</Trans>;
    case "FREELANCE":
      return <Trans id="job_type.freelance">Freelance</Trans>;
    default:
      return t?.replace(/_/g, " ") || "";
  }
};

const formatSalary = (
  min?: number,
  max?: number,
  currency?: string,
  negotiable?: boolean
): string => {
  if (negotiable) return "Negotiable";
  const cur = currency || "";
  if (min && max) return `${min} - ${max} ${cur}`.trim();
  if (min) return `From ${min} ${cur}`.trim();
  if (max) return `Up to ${max} ${cur}`.trim();
  return "";
};

const timeAgo = (dateStr?: string): string => {
  if (!dateStr) return "";
  const then = new Date(dateStr).getTime();
  const now = Date.now();
  const diff = Math.max(0, now - then);
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hours ago`;
  const days = Math.floor(hrs / 24);
  return `${days} days ago`;
};

interface JobCardProps {
  job: JobOffer;
  expanded: boolean;
  onToggle: (id: number) => void;
  onApplyNow: (
    id: number,
    title: string,
    questions?: string[],
    questionIds?: number[]
  ) => void;
  onViewMore: (id: number) => void;
  onToggleBookmark: (id: number) => void;
}

export const JobCard: React.FC<JobCardProps> = ({
  job,
  expanded,
  onToggle,
  onApplyNow,
  onViewMore,
  onToggleBookmark,
}) => {
  const navigate = useNavigate();
  const jobTypeLabel = mapJobType(job.jobType);
  const salaryStr = formatSalary(
    job.minSalary,
    job.maxSalary,
    job.currency,
    job.negotiable
  );
  const posted = timeAgo(job.publicationDate);
  const skills = job.skills || [];
  const companyName = job.company?.name || "";
  const companyLogo =
    `${settings.IMG_ADDRESS}${job.company?.logo}` || "/ehc logo.png";
  const { user, isCandidate: checkIsCandidate } = useAuth();
  const isLoggedIn = !!user;
  const isCandidate = checkIsCandidate();
  const candidateId = user?.id;
  const isBookmarked = Boolean(
    isCandidate &&
    Array.isArray(job.bookmarkedBy) &&
    job.bookmarkedBy.some((id) => Number(id) === candidateId)
  );
  const isApplied = Boolean(
    isCandidate &&
    Array.isArray(job.appliedBy) &&
    job.appliedBy.some((id) => Number(id) === candidateId)
  );
  const bookmarkDisabled = isLoggedIn && !isCandidate;
  const applyDisabled =
    (isLoggedIn && !isCandidate) || (isCandidate && isApplied);
  return (
    <div className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow duration-200">
      <div className="p-6 cursor-pointer" onClick={() => onToggle(job.id)}>
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-start space-x-4">
            <div className="w-[7rem] h-[7rem] bg-white rounded-lg flex items-center justify-center shadow-sm p-2">
              <img
                src={companyLogo}
                alt={`${companyName} logo`}
                className="w-full h-full object-contain"
              />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h3 className="text-xl font-semibold text-ehc-green font-poppins">
                  {job.title}
                </h3>
                <span
                  className={`px-3 py-1 rounded-[5px] text-xs font-medium font-poppins ${jobTypeLabel === "Full Time"
                      ? "bg-[#32c6d1d3] text-white"
                      : jobTypeLabel === "Part Time"
                        ? "bg-[#32c6d1d3] text-white"
                        : jobTypeLabel === "Internship"
                          ? "bg-[#32c6d1d3] text-white"
                          : jobTypeLabel === "Freelance"
                            ? "bg-[#32c6d1d3] text-white"
                            : jobTypeLabel === "Contract"
                              ? "bg-[#32c6d1d3] text-white"
                              : "bg-gray-500 text-white"
                    }`}
                >
                  {jobTypeLabel}
                </span>
              </div>
              <p className="text-gray-700 text-base font-medium font-poppins mb-3">
                {companyName}
              </p>
              <div className="flex items-center gap-6 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-gray-500" />
                  <span className="font-poppins">{job.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gray-500" />
                  <span className="font-poppins">
                    <Trans id="job_card.posted">Posted {posted}</Trans>
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xl font-bold text-ehc-green font-poppins">
                {salaryStr}
              </div>
              <div className="text-sm text-gray-600 font-poppins">
                {job.id === 3 ? <Trans id="salary.hourly_rate">Hourly Rate</Trans> : <Trans id="salary.annual_salary">Annual Salary</Trans>}
              </div>
            </div>
            <button
              className={`p-2 transition-colors duration-200 ${isBookmarked
                  ? "text-ehc-green bg-ehc-green/10 rounded"
                  : "text-gray-400 hover:text-ehc-green"
                } ${bookmarkDisabled ? "opacity-50 cursor-not-allowed" : ""}`}
              disabled={bookmarkDisabled}
              onClick={(e) => {
                e.stopPropagation();
                onToggleBookmark(job.id);
              }}
            >
              <Bookmark
                className="w-6 h-6"
                fill={isBookmarked ? "currentColor" : "none"}
              />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-6">
          {skills && skills.length > 0 ? (
            skills.map((skill) => (
              <span
                key={skill}
                className="px-2 py-1 bg-white text-ehc-green rounded-[5px] text-sm font-poppins border border-ehc-green/20"
              >
                {skill}
              </span>
            ))
          ) : (
            <span>{/* No skills specified */}</span>
          )}
        </div>

        <div className="flex justify-end">
          <Button
            className={`bg-ehc-green hover:bg-ehc-green-dark text-white px-8 py-2 font-poppins font-medium ${applyDisabled ? "opacity-50 cursor-not-allowed" : ""
              }`}
            disabled={applyDisabled}
            onClick={(e) => {
              e.stopPropagation();
              if (!isLoggedIn) {
                navigate("/auth");
                return;
              }
              onApplyNow(job.id, job.title, job.questions, job.questionsIds);
            }}
          >
            {isCandidate && isApplied ? <Trans id="job_card.applied">Applied</Trans> : <Trans id="job_card.apply_now">Apply Now</Trans>}
          </Button>
        </div>
      </div>

      {expanded && job.description && (
        <div className="px-6 pb-6 border-t border-gray-200">
          <div className="pt-4">
            <span className="text-ehc-green hover:text-ehc-green-dark font-medium text-sm font-poppins mb-4">
              • <Trans id="job_card.details">Job Details :</Trans>
            </span>
            <div className="bg-white rounded-lg border border-gray-200 p-4 mb-3">
              <div className="space-y-3 text-sm text-gray-700 font-poppins">
                {/* Publication Period */}
                <div>
                  <span className="font-semibold text-gray-800">
                    <Trans id="job_card.publication">Publication :</Trans>{" "}
                  </span>
                  <span>
                    Du{" "}
                    {new Date(job.publicationDate).toLocaleDateString("fr-FR")}{" "}
                    Au {new Date(job.deadlineDate).toLocaleDateString("fr-FR")}
                  </span>
                </div>

                {/* Function */}
                <div>
                  <span className="font-semibold text-gray-800">
                    <Trans id="job_card.function">Function :</Trans>{" "}
                  </span>
                  <span>{job.title}</span>
                </div>

                {/* Contract Type */}
                <div>
                  <span className="font-semibold text-gray-800">
                    <Trans id="job_card.contract_type">Contract Type Proposed :</Trans>{" "}
                  </span>
                  <span>{job.contractType}</span>
                </div>

                {/* Work Mode */}
                {job.workMode && (
                  <div>
                    <span className="font-semibold text-gray-800">
                      <Trans id="job_card.work_mode">Work Mode :</Trans>{" "}
                    </span>
                    <span>{job.workMode}</span>
                  </div>
                )}

                {/* Description */}
                <div>
                  <span className="font-semibold text-gray-800">
                    <Trans id="job_card.description">Description :</Trans>{" "}
                  </span>
                  <span className="leading-relaxed whitespace-pre-line">
                    {job.description}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex justify-end">
              <button
                className="bg-ehc-green hover:bg-ehc-green-dark text-white px-6 py-2 rounded-md font-medium text-sm font-poppins"
                onClick={() => onViewMore(job.id)}
              >
                <Trans id="job_card.view_more">View More</Trans>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
