/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect, useMemo } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Input } from "@/components/ui/input";
import { jobOffersService } from "@/lib/network/candidateJobOffer";
import { Trans } from "@lingui/macro";

interface JobFiltersProps {
  searchQuery: string;
  setSearchQuery: (val: string) => void;
  onFiltersChange?: (filters: any) => void;
  sectors?: { id: number; name: string }[];
}

interface FilterState {
  [key: string]: string[] | string;
}

export const JobFilters: React.FC<JobFiltersProps> = ({
  searchQuery,
  setSearchQuery,
  onFiltersChange,
  sectors = [],
}) => {
  const [isJobTitleExpanded, setIsJobTitleExpanded] = useState(false);
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);
  const [openFilters, setOpenFilters] = useState<{ [key: string]: boolean }>(
    {}
  );
  const [selectedFilters, setSelectedFilters] = useState<FilterState>({});
  const [descriptionQuery, setDescriptionQuery] = useState("");
  const [applicationDeadline, setApplicationDeadline] = useState("");
  const [salaryRange, setSalaryRange] = useState<{ min: string; max: string }>({
    min: "",
    max: "",
  });

  // API data for dynamic options
  const [apiFilters, setApiFilters] = useState<any>(null);

  // Fetch filter options from API
  useEffect(() => {
    jobOffersService
      .getJobsFilters()
      .then((response) => {
        if (response.success && response.data) {
          console.log("API Filter Response:", response.data);
          setApiFilters(response.data);
        }
      })
      .catch((error) => {
        console.error("Error fetching filters:", error);
      });
  }, []);

  // Helper function to extract string values from API data
  const extractStringValues = (data: any[]): string[] => {
    if (!Array.isArray(data)) return [];
    return data
      .map((item) => {
        if (typeof item === "string") return item;
        if (typeof item === "object" && item !== null) {
          return item.name || item.title || item.label || String(item);
        }
        return String(item);
      })
      .filter(Boolean);
  };

  const filterOptions = useMemo(
    () => ({
      "Sector of activity": sectors.map((sector) => String(sector.id)), // Use sector IDs
      "Hiring Company": extractStringValues(apiFilters?.companies || []),
      "Work Mode": extractStringValues(apiFilters?.workModes || []),
      Region: extractStringValues(apiFilters?.locations || []),
      "Contract Type": extractStringValues(apiFilters?.contractTypes || []),
      Requirements: extractStringValues(apiFilters?.requirements || []),
    }),
    [sectors, apiFilters]
  );

  // Map to display sector names in the UI but use IDs for filtering
  const sectorMap = Object.fromEntries(
    sectors.map((s) => [String(s.id), s.name])
  );

  const toggleFilter = (filterName: string) => {
    setOpenFilters((prev) => ({
      ...prev,
      [filterName]: !prev[filterName],
    }));
  };

  const handleFilterChange = (filterName: string, option: string) => {
    setSelectedFilters((prev) => {
      const currentOptions = (prev[filterName] as string[]) || [];
      const isSelected = currentOptions.includes(option);

      if (isSelected) {
        return {
          ...prev,
          [filterName]: currentOptions.filter(
            (item: string) => item !== option
          ),
        };
      } else {
        return {
          ...prev,
          [filterName]: [...currentOptions, option],
        };
      }
    });
  };

  const applyFilters = () => {
    // Prepare filter query for client-side filtering
    const filterQuery: any = {
      jobTitle: searchQuery,
      description: descriptionQuery,
      applicationDeadline: applicationDeadline,
    };

    // Add salary range if provided
    if (salaryRange.min || salaryRange.max) {
      filterQuery.salaryRange = {
        min: salaryRange.min ? parseInt(salaryRange.min) : undefined,
        max: salaryRange.max ? parseInt(salaryRange.max) : undefined,
      };
    }

    // Add multi-select filters
    Object.entries(selectedFilters).forEach(([filterName, options]) => {
      if (Array.isArray(options) && options.length > 0) {
        filterQuery[filterName] = options;
      }
    });

    console.log("Applying filters with query:", filterQuery);

    // Send filters to parent component
    if (onFiltersChange) {
      onFiltersChange(filterQuery);
    }
  };

  const resetFilters = () => {
    setSelectedFilters({});
    setSearchQuery("");
    setDescriptionQuery("");
    setApplicationDeadline("");
    setSalaryRange({ min: "", max: "" });

    // Close all filter dropdowns
    const closedFilters = Object.keys(openFilters).reduce((acc, key) => {
      acc[key] = false;
      return acc;
    }, {} as { [key: string]: boolean });
    setOpenFilters(closedFilters);
    setIsJobTitleExpanded(false);
    setIsDescriptionExpanded(false);

    // Apply empty filters
    if (onFiltersChange) {
      onFiltersChange({});
    }
  };

  // Initialize openFilters state
  useEffect(() => {
    const initialOpenState = Object.keys(filterOptions).reduce((acc, key) => {
      acc[key] = false;
      return acc;
    }, {} as { [key: string]: boolean });

    setOpenFilters(initialOpenState);
  }, [filterOptions]);

  return (
    <div className="bg-white rounded-lg border border-[rgb(35,141,148)] p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4 font-poppins">
        <Trans id="filters.title">Filters</Trans>
      </h3>

      {/* Job Title Filter (Input Field) */}
      <div className="mb-4 border-b border-gray-200 pb-4">
        <button
          className="flex items-center justify-between w-full"
          onClick={() => setIsJobTitleExpanded(!isJobTitleExpanded)}
        >
          <span className="text-sm font-medium">
            <Trans id="filters.job_title">Job Title</Trans>
          </span>
          <ChevronDown
            className={`h-4 w-4 transition-transform ${
              isJobTitleExpanded ? "rotate-180" : ""
            }`}
          />
        </button>

        {isJobTitleExpanded && (
          <div className="mt-2">
            <Input
              type="text"
              placeholder="Search job titles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
            />
          </div>
        )}
      </div>

      {/* Description Filter (Input Field) */}
      <div className="mb-4 border-b border-gray-200 pb-4">
        <button
          className="flex items-center justify-between w-full"
          onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
        >
          <span className="text-sm font-medium">
            <Trans id="filters.description">Description</Trans>
          </span>
          <ChevronDown
            className={`h-4 w-4 transition-transform ${
              isDescriptionExpanded ? "rotate-180" : ""
            }`}
          />
        </button>

        {isDescriptionExpanded && (
          <div className="mt-2">
            <Input
              type="text"
              placeholder="Search in job descriptions..."
              value={descriptionQuery}
              onChange={(e) => setDescriptionQuery(e.target.value)}
              className="w-full"
            />
          </div>
        )}
      </div>

      {/* Application Deadline Filter (Date Field) */}
      <div className="mb-4 border-b border-gray-200 pb-4">
        <div className="mb-2">
          <span className="text-sm font-medium">
            <Trans id="filters.application_deadline">Application Deadline</Trans>
          </span>
        </div>
        <Input
          type="date"
          placeholder="Select deadline..."
          value={applicationDeadline}
          onChange={(e) => setApplicationDeadline(e.target.value)}
          className="w-full"
        />
      </div>

      {/* Salary Range Filter */}
      <div className="mb-4 border-b border-gray-200 pb-4">
        <div className="mb-2">
          <span className="text-sm font-medium">
            <Trans id="filters.salary_range">Salary Range</Trans>
          </span>
        </div>
        <div className="flex gap-2">
          <Input
            type="number"
            placeholder="Min salary"
            value={salaryRange.min}
            onChange={(e) =>
              setSalaryRange((prev) => ({ ...prev, min: e.target.value }))
            }
            className="w-full"
          />
          <Input
            type="number"
            placeholder="Max salary"
            value={salaryRange.max}
            onChange={(e) =>
              setSalaryRange((prev) => ({ ...prev, max: e.target.value }))
            }
            className="w-full"
          />
        </div>
      </div>

      {/* Other Filters (Checkbox Selection) */}
      {Object.entries(filterOptions).map(([filterName, options]) => (
        <div
          key={filterName}
          className="mb-4 border-b border-gray-200 pb-4 last:border-b-0"
        >
          <button
            onClick={() => toggleFilter(filterName)}
            className="flex items-center justify-between w-full text-left text-sm font-medium text-gray-700 hover:text-gray-900 font-poppins"
          >
            <span>{filterName}</span>
            {openFilters[filterName] ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </button>

          {openFilters[filterName] && (
            <div className="mt-3 max-h-32 overflow-y-auto space-y-2">
              {options.length === 0 ? (
                <div className="text-sm text-gray-400">
                  <Trans id="filters.no_options">No options available</Trans>
                </div>
              ) : (
                options.map((option) => {
                  // Ensure option is a string
                  const optionString =
                    typeof option === "string" ? option : String(option);
                  const isChecked =
                    selectedFilters[filterName]?.includes(optionString) ||
                    false;

                  // For sectors, show the name but use ID as the value
                  const displayText =
                    filterName === "Sector of activity" &&
                    sectorMap[optionString]
                      ? sectorMap[optionString]
                      : optionString;

                  return (
                    <label key={optionString} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() =>
                          handleFilterChange(filterName, optionString)
                        }
                        className="rounded border-gray-300 text-ehc-green focus:ring-ehc-green"
                      />
                      <span className="ml-2 text-sm text-gray-600 font-poppins">
                        {displayText}
                      </span>
                    </label>
                  );
                })
              )}
            </div>
          )}
        </div>
      ))}

      {/* Disabled Filters (Experience Level, Education Level, Language) */}
      {["Experience Level", "Education Level", "Language"].map((label) => (
        <div key={label} className="mb-4 border-b border-gray-200 pb-4 opacity-50">
          <div className="mb-2">
            <span className="text-sm font-medium text-gray-400">
              <Trans id={`filters.${label.replace(/\s+/g, "_").toLowerCase()}`}>{label} (Coming Soon)</Trans>
            </span>
          </div>
          <div className="text-xs text-gray-400">
            <Trans id="filters.coming_soon">This filter will be available in a future update.</Trans>
          </div>
        </div>
      ))}

      {/* Reset Button */}
      <button
        onClick={resetFilters}
        className="w-full mt-4 bg-red-400 text-white py-2 px-4 rounded-md hover:bg-red-500 transition-colors mb-2"
      >
        <Trans id="filters.reset">Reset All Filters</Trans>
      </button>

      <button
        onClick={applyFilters}
        className="w-full bg-ehc-green hover:bg-teal-700 text-white py-2 px-4 rounded-md font-medium transition-colors"
      >
        <Trans id="filters.apply">Apply Filters</Trans>
      </button>
    </div>
  );
};
