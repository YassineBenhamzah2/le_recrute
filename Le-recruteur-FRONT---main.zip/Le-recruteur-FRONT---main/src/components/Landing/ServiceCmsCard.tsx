import { useEffect, useState } from "react";
import { settings } from "@/lib/settings/main";
import {
  AdminServiceCmsResponse,
  PaginatedCmsServices,
} from "@/lib/types/service";
import { serviceCmsApi } from "@/lib/network/serviceApi";
import { Trans } from "@lingui/macro";

export default function ServicesCmsSection() {
  const [services, setServices] = useState<AdminServiceCmsResponse[]>([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const itemsPerPage = 4; // Pour avoir 4 services par "page" dans la grille

  const fetchServices = async () => {
    try {
      const res: PaginatedCmsServices = await serviceCmsApi.getCmsServices(
        page,
        itemsPerPage
      );
      setServices(res.content);
      setTotalPages(res.totalPages);
    } catch (err) {
      console.error("Erreur chargement CMS services", err);
    }
  };

  useEffect(() => {
    fetchServices();
  }, [page]);

  const handleViewServices = () => {
    console.log("Voir tous les services ou naviguer vers la page dédiée");
  };

  return (
    <section className="py-12 lg:py-16 px-4 relative z-10">
      {/* Section decorative elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 right-16 w-6 h-6 bg-[#238D94]/12 rounded-full"></div>
        <div className="absolute bottom-12 left-16 w-28 h-28 bg-gradient-to-tr from-[#238D94]/6 to-transparent rounded-full"></div>
        <div className="absolute top-1/2 right-5 w-18 h-2 bg-gradient-to-l from-[#238D94]/10 to-transparent rounded-full"></div>
      </div>

      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8 lg:mb-12">
          <h2 className="text-2xl lg:text-3xl font-bold">
            <span className="text-black">
              <Trans id="services.title.prefix">Our</Trans>
            </span>
            <span className="text-[#238D94]">
              <Trans id="services.title.main">Services</Trans>
            </span>
          </h2>
          <button
            onClick={handleViewServices}
            className="bg-[#238D94] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#1f7a80] transition-colors"
          >
            <Trans id="services.view_all">View All Services</Trans>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {services.map((service) => (
            <div
              key={service.cmsId}
              className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow"
            >
              <img
                src={
                  service.imageUrl
                    ? `${settings.IMG_ADDRESS}${service.imageUrl}`
                    : "/default-image.png"
                }
                alt={service.title}
                className="w-full h-48 object-cover mb-4 rounded-lg"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='192' viewBox='0 0 400 192'%3E%3Crect width='400' height='192' fill='%23f3f4f6'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial' font-size='16' fill='%236b7280' text-anchor='middle' dy='0.3em'%3E${service.title}%3C/text%3E%3C/svg%3E`;
                }}
              />
              <h3 className="text-[#238D94] font-semibold mb-2 text-lg">
                {service.title}
              </h3>
              {service.description && (
                <p className="text-gray-600 mb-4 text-sm">
                  {service.description}
                </p>
              )}
              <button
                onClick={handleViewServices}
                className="bg-[#238D94] text-white px-6 py-3 rounded-lg w-full hover:bg-[#1f7a80] transition-colors"
              >
                <Trans id="services.learn_more">Learn More</Trans>
              </button>
            </div>
          ))}
        </div>

        {/* Slider / Pagination simple */}
        <div className="flex justify-center mt-8 gap-4">
          <button
            onClick={() => setPage((prev) => Math.max(prev - 1, 0))}
            disabled={page === 0}
            className="px-4 py-2 bg-[#238D94] text-white rounded disabled:opacity-50 hover:bg-[#1f7a80] transition-colors"
          >
            <Trans id="services.prev">Previous</Trans>
          </button>
          <button
            onClick={() =>
              setPage((prev) => Math.min(prev + 1, totalPages - 1))
            }
            disabled={page === totalPages - 1}
            className="px-4 py-2 bg-[#238D94] text-white rounded disabled:opacity-50 hover:bg-[#1f7a80] transition-colors"
          >
            <Trans id="services.next">Next</Trans>
          </button>
        </div>
      </div>
    </section>
  );
}
