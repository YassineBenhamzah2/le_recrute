import { EntrepriseDetailsSection } from "@/components/Landing/entrepriseSections/EntrepriseDetailsSection";
import { JobListingsSection } from "@/components/Landing/entrepriseSections/JobListingSection";
import { useAuth } from "@/contexts/AuthContext";
import { companyService } from "@/lib/network/company";
import { CompanyDetails } from "@/lib/types/company";
import { Clock, Mail, MapPin, Phone, User } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import Footer from "../Layout/Footer";
import Header from "../Layout/Header";
import SeparatorSection from "./entrepriseSections/SeparatorSection";
import { t } from "@lingui/macro";

interface EntrepriseDetailsProps {
  companyId: number;
  onGetStarted: () => void;
  onSignIn: () => void;
}

const EntrepriseDetails = ({
  companyId,
  onGetStarted,
  onSignIn,
}: EntrepriseDetailsProps) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [companyDetails, setCompanyDetails] = useState<CompanyDetails | null>(
    null
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isCompanyBookmarked, setIsCompanyBookmarked] = useState(false);
  const [bookmarkedJobs, setBookmarkedJobs] = useState<Set<number>>(new Set());
  const [bookmarkLoading, setBookmarkLoading] = useState<Set<number>>(
    new Set()
  );

  const { user } = useAuth();

  // Check if user is authenticated and is a candidate
  const canBookmark = user && user.role.type === "CANDIDATE";

  // Handle company bookmark
  const handleCompanyBookmark = async () => {
    if (!canBookmark) {
      onSignIn();
      return;
    }

    try {
      setBookmarkLoading((prev) => new Set(prev).add(-1)); // Use -1 for company bookmark

      const response = await companyService.bookmarkCompany(companyId);

      if (response.success) {
        setIsCompanyBookmarked(!isCompanyBookmarked);
        toast.success(
          isCompanyBookmarked
            ? t({ id: "entreprise.companyRemovedBookmark", message: "Company removed from bookmarks" })
            : t({ id: "entreprise.companyBookmarked", message: "Company bookmarked successfully!" })
        );
      } else {
        toast.error(t({ id: "entreprise.failedBookmarkCompany", message: "Failed to bookmark company" }));
      }
    } catch (error) {
      console.error("Error bookmarking company:", error);
      toast.error(t({ id: "entreprise.errorBookmarkCompany", message: "An error occurred while bookmarking" }));
    } finally {
      setBookmarkLoading((prev) => {
        const newSet = new Set(prev);
        newSet.delete(-1);
        return newSet;
      });
    }
  };

  // Handle job bookmark
  const handleJobBookmark = async (jobId: number) => {
    if (!canBookmark) {
      onSignIn();
      return;
    }

    try {
      setBookmarkLoading((prev) => new Set(prev).add(jobId));

      const response = await companyService.bookmarkJob(jobId);

      if (response.success) {
        setBookmarkedJobs((prev) => {
          const newSet = new Set(prev);
          if (newSet.has(jobId)) {
            newSet.delete(jobId);
            toast.success(t({ id: "entreprise.jobRemovedBookmark", message: "Job removed from bookmarks" }));
          } else {
            newSet.add(jobId);
            toast.success(t({ id: "entreprise.jobBookmarked", message: "Job bookmarked successfully!" }));
          }
          return newSet;
        });
      } else {
        toast.error(t({ id: "entreprise.failedBookmarkJob", message: "Failed to bookmark job" }));
      }
    } catch (error) {
      console.error("Error bookmarking job:", error);
      toast.error(t({ id: "entreprise.errorBookmarkJob", message: "An error occurred while bookmarking" }));
    } finally {
      setBookmarkLoading((prev) => {
        const newSet = new Set(prev);
        newSet.delete(jobId);
        return newSet;
      });
    }
  };

  // Fetch company details from API
  useEffect(() => {
    const fetchCompanyDetails = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await companyService.getCompanyById(companyId);

        if (response.success) {
          setCompanyDetails(response.data);
          // Set initial bookmark states from API data
          setIsCompanyBookmarked(response.data.isSaved || false);
          // Initialize job bookmarks state
          const bookmarkedJobIds = new Set(
            response.data.jobOffers
              ?.filter((job) => job.isBookmarked)
              .map((job) => job.id) || []
          );
          setBookmarkedJobs(bookmarkedJobIds);
        } else {
          setError(t({ id: "entreprise.failedLoadCompanyDetails", message: "Failed to load company details" }));
        }
      } catch (err) {
        console.error("Error fetching company details:", err);
        setError(t({ id: "entreprise.errorLoadCompanyDetails", message: "An error occurred while loading company details" }));
      } finally {
        setLoading(false);
      }
    };

    fetchCompanyDetails();
  }, [companyId]);

  if (loading) {
    return (
      <div className="flex flex-col w-full bg-white min-h-screen">
        <Header
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          onGetStarted={onGetStarted}
          onSignIn={onSignIn}
        />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-lg">
            {t({ id: "entreprise.loadingDetails", message: "Loading company details..." })}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !companyDetails) {
    return (
      <div className="flex flex-col w-full bg-white min-h-screen">
        <Header
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          onGetStarted={onGetStarted}
          onSignIn={onSignIn}
        />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-lg text-red-500">
            {error || t({ id: "entreprise.companyNotFound", message: "Company not found" })}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Map API data to component props
  const companyInfo = {
    name: companyDetails.name,
    address: companyDetails.address,
    website: companyDetails.website || "N/A",
    logoUrl: companyDetails.logo,
    mapUrl: companyDetails.logo, // Using logo as placeholder for map
    latitude: companyDetails.lat || 34.0766, // Los Angeles default
    longitude: companyDetails.lng || -118.2646,
    about: companyDetails.description
      ? companyDetails.description.split("\n")
      : ["No description available"],
  };

  // Profile info data
  const profileDetails = [
    {
      icon: <User className="text-ehc-green" />,
      label: t({ id: "entreprise.labelEmployees", message: "employees" }),
      value: `${companyDetails.numEmployees}` || "N/A",
    },
    {
      icon: <Clock className="text-ehc-green" />,
      label: t({ id: "entreprise.labelExperience", message: "Experience" }),
      value: companyDetails.experience || "N/A",
    },
    {
      icon: <Phone className="text-ehc-green" />,
      label: t({ id: "entreprise.labelPhone", message: "Phone" }),
      value: companyDetails.phone || "N/A",
    },
    {
      icon: <Mail className="text-ehc-green" />,
      label: t({ id: "entreprise.labelEmail", message: "Email" }),
      value: companyDetails.email || "N/A",
    },
    {
      icon: <MapPin className="text-ehc-green" />,
      label: t({ id: "entreprise.labelAddress", message: "Address" }),
      value: companyDetails.address || "N/A",
    },
  ];

  // Responsibilities data from API or default
  const responsibilities =
    companyDetails.responsibilities &&
    companyDetails.responsibilities.length > 0
      ? companyDetails.responsibilities
      : [
          t({ id: "entreprise.responsibility1", message: "Establish and promote design guidelines, best practices and standards." }),
          t({ id: "entreprise.responsibility2", message: "Accurately estimate design tickets during planning sessions." }),
          t({ id: "entreprise.responsibility3", message: "Partnering with product and engineering to translate business and user goals." }),
        ];

  // Job Listings from API
  const jobListings =
    companyDetails.jobOffers?.map((job) => ({
      id: job.id,
      title: job.title,
      company: companyDetails.name,
      location: job.location || companyDetails.address,
      postedTime: `Posted ${new Date(
        job.publicationDate
      ).toLocaleDateString()}`,
      jobType: job.jobType,
      salary: `$${job.minSalary} - $${job.maxSalary}`,
      salaryPeriod: t({ id: "entreprise.monthlySalary", message: "Monthly Salary" }),
      skills: [
                { name: t({ id: "job.skillProfessional", message: "Professional" }) },
                { name: t({ id: "job.skillExperience", message: "Experience" }) }
              ], // Default skills since API doesn't provide them
      companyLogo: companyDetails.logo,
      isBookmarked: bookmarkedJobs.has(job.id),
      onBookmark: () => handleJobBookmark(job.id),
      bookmarkLoading: bookmarkLoading.has(job.id),
    })) || [];

  return (
    <div className="flex flex-col w-full bg-white min-h-screen">
      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onGetStarted={onGetStarted}
        onSignIn={onSignIn}
      />
      <div className="mb-8  bg-[#E6F4F1] min-h-[250px] flex flex-col gap-3 items-center justify-end pb-10 ">
        <h1 className="text-6xl text-ehc-green font-extrabold">
          {t({ id: "entreprise.header", message: "Companies" })}
        </h1>
        <div className="flex items-center gap-4 mt-2">
          <p className="text-black text-3xl font-medium">
            {companyDetails.name}
          </p>
        </div>
      </div>
      <div className="flex-grow py-8 font-rubik">
        <div className="w-full max-w-[1170px] mx-auto px-4">
          {/* Page header */}
          <EntrepriseDetailsSection
            companyInfo={companyInfo}
            profileDetails={profileDetails}
            responsibilities={responsibilities}
            handleCompanyBookmark={handleCompanyBookmark}
            bookmarkLoading={bookmarkLoading}
            isCompanyBookmarked={isCompanyBookmarked}
          />
        </div>
        <SeparatorSection />
        <div className="w-full max-w-[1170px] mx-auto px-4 pb-24">
          <JobListingsSection jobListing={jobListings} />
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default EntrepriseDetails;
