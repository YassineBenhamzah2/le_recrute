import Header from "../Layout/Header";
import Footer from "../Layout/Footer";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, ChevronRight, Clock, User } from "lucide-react";

import { BlogDetails } from "@/lib/types/Blog";
import { blogService } from "@/lib/network/pages/Blogs";
import { settings } from "@/lib/settings/main";
import { Trans, t } from "@lingui/macro";

interface BlogProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

interface PaginationMetadata {
  totalPages: number;
  currentPage: number;
  totalItems: number;
  itemsPerPage: number;
}

const Blog = ({ onGetStarted, onSignIn }: BlogProps) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [blogPosts, setBlogPosts] = useState<BlogDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [paginationMetadata, setPaginationMetadata] =
    useState<PaginationMetadata | null>(null);
  const navigate = useNavigate();

  // item page est le nombre des card in page
  const itemsPerPage = 6;

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        setLoading(true);
        const response = await blogService.getBlogs({
          page: currentPage,
          size: itemsPerPage,
          status: "PUBLISHED",
          sortBy: "createdAt",
          sortOrder: "desc",
        });

        if (response.success) {
          setBlogPosts(response.data);

          // Extraction des métadonnées de pagination depuis la réponse
          if (response.metadata && response.metadata.pagination) {
            setPaginationMetadata({
              totalPages: response.metadata.pagination.totalPages,
              currentPage: response.metadata.pagination.page,
              totalItems: response.metadata.pagination.totalItems,
              itemsPerPage: response.metadata.pagination.pageSize,
            });
          } else {
            // Fallback si la structure des métadonnées est différente
            console.warn(
              "Métadonnées de pagination non trouvées dans la réponse"
            );
            setPaginationMetadata({
              totalPages: Math.ceil(response.data.length / itemsPerPage),
              currentPage: currentPage,
              totalItems: response.data.length,
              itemsPerPage: itemsPerPage,
            });
          }
        } else {
          setError(
            t({ id: "blog.error.load", message: "Error loading blogs" })
          );
        }
      } catch (err) {
        setError(
          t({ id: "blog.error.connection", message: "Server connection error" })
        );
        console.error("Error fetching blogs:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchBlogs();
  }, [currentPage]); // Correction: Suppression de itemsPerPage des dépendances

  const handleBlogPostClick = (postId: number) => {
    navigate(`/blog/${postId}`);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    const blogSection = document.getElementById("blog-section");
    if (blogSection) {
      blogSection.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      handlePageChange(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (paginationMetadata && currentPage < paginationMetadata.totalPages) {
      handlePageChange(currentPage + 1);
    }
  };

  if (error) {
    return (
      <div className="min-h-screen bg-[#ffffff]">
        <Header
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          onGetStarted={onGetStarted}
          onSignIn={onSignIn}
        />
        <div className="flex justify-center items-center h-96">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-red-600 mb-4">
              <Trans id="blog.error.title">Error</Trans>
            </h2>
            <p className="text-gray-600">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="mt-4 px-4 py-2 bg-[#238d94] text-white rounded-md hover:bg-[#1a6c72]"
            >
              <Trans id="blog.error.retry">Retry</Trans>
            </button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#ffffff]">
      <style>{`
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>

      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onGetStarted={onGetStarted}
        onSignIn={onSignIn}
      />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#e6f4f1] to-[#f5f7fa] py-8 md:py-16 px-4 ">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between">
          {/* Contenu texte - toujours en premier dans l'ordre du DOM */}
          <div className="flex-1 max-w-lg text-center md:text-left">
            <h1 className="text-3xl md:text-5xl font-bold text-[#238d94] mb-4">
              <Trans id="blog.hero.title">Jobs Blog</Trans>
            </h1>
            <p className="text-lg md:text-xl text-[#3c3c3c] leading-relaxed">
              <Trans id="blog.hero.description">
                Your Guide to Finding Jobs and Building Your Career in Morocco
              </Trans>
            </p>
          </div>

          <div className="flex-1 flex justify-center md:justify-end mt-8 md:mt-0">
            <div className="relative w-full md:w-[400px] h-[250px] md:h-[300px]">
              <img
                src="/Frame-update.png"
                alt={t({
                  id: "blog.hero.imageAlt",
                  message: "Professional man making a phone call",
                })}
                className="object-contain mx-auto md:absolute md:top-1/2 md:right-[50px] md:transform md:-translate-y-1/2  w-3/5 md:w-auto"
                style={{ top: "55%" }}
              />
            </div>
          </div>
        </div>
      </section>
      <br />
      <br />

      {/* Blog Section */}
      <section id="blog-section" className="py-16 px-4 bg-[#ffffff]">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-[#238d94] text-center mb-12">
            <Trans id="blog.section.title">Blog</Trans>
          </h2>
          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : blogPosts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">
                <Trans id="blog.empty">
                  No blog posts available at the moment.
                </Trans>
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                {blogPosts.map((post) => (
                  <article
                    key={post.id}
                    onClick={() => handleBlogPostClick(post.id)}
                    className="group bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 cursor-pointer flex flex-col"
                  >
                    {/* Image Container with Overlay */}
                    <div className="relative h-52 overflow-hidden">
                      <img
                        src={
                          `${settings.IMG_ADDRESS}${post.image?.url}` ||
                          "/placeholder.svg"
                        }
                        alt={post.image?.filename}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />

                      {/* Category Badges */}
                      <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                        {post.categories &&
                          post.categories.slice(0, 2).map((category, index) => (
                            <span
                              key={index}
                              className="bg-[#238d94] text-white text-xs font-semibold px-2 py-1 rounded-full shadow-lg"
                            >
                              {typeof category === "string"
                                ? category
                                : category.name}
                            </span>
                          ))}
                        {post.categories && post.categories.length > 2 && (
                          <span className="bg-[#238d94] text-white text-xs font-semibold px-2 py-1 rounded-full shadow-lg">
                            +{post.categories.length - 2}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Content Container with Flex Grow */}
                    <div className="p-6 flex flex-col flex-grow">
                      {/* Meta Information */}
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3 text-xs text-gray-500">
                          <div className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>
                              {Math.ceil((post.content || "").length / 200)}
                              <Trans id="blog.post.readTime">min read</Trans>
                            </span>
                          </div>
                        </div>
                        <span className="text-xs text-[#238d94] font-medium">
                          {new Date(post.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      {/* Title */}
                      <h3 className="text-lg font-bold text-gray-900 mb-3 leading-tight line-clamp-2 group-hover:text-[#238d94] transition-colors duration-200">
                        {post.title}
                      </h3>

                      {/* Description with Flex Grow */}
                      <p className="text-gray-600 text-sm mb-4 leading-relaxed line-clamp-3 flex-grow">
                        {post.description}
                      </p>

                      {/* Author and Read More - Fixed at Bottom */}
                      <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-100">
                        <div className="flex items-center space-x-2">
                          <div className="w-8 h-8 bg-gradient-to-r from-[#238d94] to-[#14b8a6] rounded-full flex items-center justify-center">
                            <User className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-sm text-gray-700 font-medium">
                            {post.creator}
                          </span>
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleBlogPostClick(post.id);
                          }}
                          className="text-[#238d94] hover:text-[#14b8a6] font-semibold text-sm transition-colors duration-200 flex items-center space-x-1 group/btn"
                        >
                          <span>
                            <Trans id="blog.post.readMore">Read More</Trans>
                          </span>
                          <ChevronRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform duration-200" />
                        </button>
                      </div>
                    </div>

                    {/* Progress Bar Animation */}
                    <div className="h-1 bg-gray-100">
                      <div className="h-full bg-gradient-to-r from-[#238d94] to-[#14b8a6] w-0 group-hover:w-full transition-all duration-700 ease-out"></div>
                    </div>
                  </article>
                ))}
              </div>

              {/* Pagination Controls */}
              {paginationMetadata && paginationMetadata.totalPages > 1 && (
                <div className="flex items-center justify-center space-x-2">
                  {/* Previous Button */}
                  <button
                    onClick={handlePrevPage}
                    disabled={currentPage === 1}
                    className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                      currentPage === 1
                        ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                        : "bg-white text-[#238d94] border border-[#238d94] hover:bg-[#238d94] hover:text-white"
                    }`}
                  >
                    <ChevronLeft className="w-4 h-4 mr-1" />
                    <Trans id="blog.pagination.previous">Previous</Trans>
                  </button>

                  {/* Page Numbers */}
                  <div className="flex space-x-1">
                    {Array.from(
                      { length: paginationMetadata.totalPages },
                      (_, i) => i + 1
                    ).map((page) => (
                      <button
                        key={page}
                        onClick={() => handlePageChange(page)}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                          currentPage === page
                            ? "bg-[#238d94] text-white"
                            : "bg-white text-[#238d94] border border-[#238d94] hover:bg-[#238d94] hover:text-white"
                        }`}
                      >
                        {page}
                      </button>
                    ))}
                  </div>

                  {/* Next Button */}
                  <button
                    onClick={handleNextPage}
                    disabled={currentPage === paginationMetadata.totalPages}
                    className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                      currentPage === paginationMetadata.totalPages
                        ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                        : "bg-white text-[#238d94] border border-[#238d94] hover:bg-[#238d94] hover:text-white"
                    }`}
                  >
                    <Trans id="blog.pagination.next">Next</Trans>
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Blog;
