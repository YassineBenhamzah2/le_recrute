import { MessageSquareIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ContactFormSection } from "@/components/Landing/faqSections/ContactFormSection";
import { FaqSection } from "@/components/Landing/faqSections/FaqSection";
import { MainContentSection } from "@/components/Landing/faqSections/MainContentSection";
import Header from "../Layout/Header";
import Footer from "../Layout/Footer";
import { useState, useEffect } from "react";
import {
  FacebookIcon,
  InstagramIcon,
  LinkedinIcon,
  MailIcon,
  MapPinIcon,
  PhoneIcon,
  TwitterIcon,
  Loader2,
} from "lucide-react";
import { faqPageService } from "@/lib/network/pages/faq";
import { FAQ } from "@/lib/types/page/faq";
import { toast } from "sonner";
import { t, Trans } from '@lingui/macro';


interface FAQPageProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

// FAQ data types (keeping compatibility with existing components)
interface FaqItem {
  question: string;
  answer: string;
  category: string;
  defaultOpen?: boolean;
}

interface FaqCategory {
  id: string;
  label: string;
  active: boolean;
}

interface ContactInfo {
  icon: JSX.Element;
  text: string;
  width: string;
}

interface SocialMedia {
  icon: JSX.Element;
  link: string;
}

const FaqPage = ({ onGetStarted, onSignIn }: FAQPageProps) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState("general");
  const [faqItems, setFaqItems] = useState<FaqItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Static FAQ categories (can be made dynamic later if needed)
  const faqCategories: FaqCategory[] = [
    { id: "general", label: "General", active: true },
    { id: "jobs", label: "Jobs", active: false },
    { id: "payment", label: "Payment", active: false },
  ];

  // Convert API FAQ type to component FAQ type
  const convertAPIFAQsToItems = (faqs: FAQ[]): FaqItem[] => {
    return faqs.map((faq, index) => ({
      question: faq.question,
      answer: faq.answer,
      category: faq.type.toLowerCase(), // Convert GENERAL -> general
      defaultOpen: index === 0, // First item is open by default
    }));
  };

  // Fetch FAQs from API
  useEffect(() => {
    const fetchFAQs = async () => {
      try {
        setLoading(true);
        const response = await faqPageService.getFAQs();
        const faqData = response.data; // Remove extra .data since it's already typed correctly
        const convertedFAQs = convertAPIFAQsToItems(faqData);
        setFaqItems(convertedFAQs);

        // Set default category to the first available category with data
        if (convertedFAQs.length > 0) {
          const firstCategory = convertedFAQs[0].category;
          setActiveCategory(firstCategory);
        }
      } catch (error) {
        console.error("Error fetching FAQs:", error);
        toast.error("Failed to load FAQ data. Using fallback data.");
        // Fallback data in case API fails
        setFaqItems([
          {
            question: t({ id: "faq.q1", message: "How can I get started?" }),
            answer: t({ id: "faq.a1", message: "You can get started by creating an account and exploring our platform features." }),
            category: "general",
            defaultOpen: true,
          },
          {
            question: t({ id: "faq.q2", message: "How do I post a job?" }),
            answer: t({ id: "faq.a2", message: "To post a job, navigate to your dashboard and click the 'Post Job' button." }),
            category: "jobs",
          },
          {
            question: t({ id: "faq.q3", message: "What payment methods do you accept?" }),
            answer: t({ id: "faq.a3", message: "We accept all major credit cards and PayPal for your convenience." }),
            category: "payment",
          },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchFAQs();
  }, []);

  // Centralized contact info data
  const contactInfo: ContactInfo[] = [
    {
      icon: <MapPinIcon className="h-5 w-5 text-ehc-green" />,
      text: t({ id: "contact.address", message: "123 Job Street, San Francisco, CA 94103" }),
      width: "w-[308px]",
    },
    {
      icon: <PhoneIcon className="h-5 w-5 text-ehc-green" />,
      text: "+1 (555) 123-4567",
      width: "w-[141px]",
    },
    {
      icon: <MailIcon className="h-5 w-5 text-ehc-green" />,
      text: "info@jobsearchplatform.com",
      width: "w-[235px]",
    },
  ];

  // Centralized social media data
  const socialMedia: SocialMedia[] = [
    {
      icon: <FacebookIcon className="h-4 w-4 text-ehc-green" />,
      link: "https://facebook.com",
    },
    {
      icon: <TwitterIcon className="h-4 w-4 text-ehc-green" />,
      link: "https://twitter.com",
    },
    {
      icon: <LinkedinIcon className="h-4 w-4 text-ehc-green" />,
      link: "https://linkedin.com",
    },
    {
      icon: <InstagramIcon className="h-4 w-4 text-ehc-green" />,
      link: "https://instagram.com",
    },
  ];
  return (
    <div className="flex flex-col w-full bg-white font-rubik">
      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onGetStarted={onGetStarted}
        onSignIn={onSignIn}
      />

      {/* Hero Section */}
      <section className="w-full bg-ehc-green/10 overflow-hidden relative">
        <div className="relative w-full py-16">
          {/* Background circles */}
          <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-ehc-green/10 rounded-[150px]" />
          <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-ehc-green/10 rounded-[150px]" />

          {/* Girl image and decorations */}
          <div className="relative mx-auto max-w-[1440px] px-4 flex items-center justify-between">
            <div className="relative w-fit">
              <img
                className="w-[451px] h-[482px] bg-cover bg-[50%_50%]"
                src="/faq.png"
              />
              <img
                className=" absolute w-[65px] h-[71px] -top-16 left-[180px] rotate-[30deg]"
                src="/questionmark.png"
              />
              <img
                className=" absolute w-[65px] h-[71px] -top-14 left-[230px] rotate-[30deg]"
                src="/questionmark.png"
              />
              <img
                className=" absolute w-[65px] h-[71px] -top-8 left-[280px] rotate-[30deg]"
                src="/questionmark.png"
              />
            </div>
            {/* Title and description */}
            <div className="flex flex-col items-start justify-center pt-16 flex-1">
              <h1 className="font-rubik font-bold ml-10 text-ehc-green text-5xl text-center tracking-[0] leading-[60px] mb-8">
                <Trans id="faq.title">Frequently Asked Questions</Trans>
              </h1>
              <p className="max-w-[893px]  font-rubik font-semibold text-gray-900 text-xl text-center leading-normal">
                <Trans id="faq.description">
                  Welcome To The ehc faq Section. Here You'll Find Clear Answers
                  To Our Most Common User Inquiries. If You Have Additional
                  Questions, Please Don't Hesitate To Contact Us Through Our
                  "contact" page.
                </Trans>
              </p>
            </div>
          </div>
        </div>
      </section>

      {loading ? (
        <section className="w-full bg-white py-16">
          <div className="container mx-auto flex flex-col items-center gap-12">
            <div className="flex items-center justify-center gap-2">
              <Loader2 className="w-6 h-6 animate-spin text-ehc-green" />
              <span className="font-rubik text-lg text-gray-600">
                <Trans id="faq.loading">Loading FAQ data...</Trans>
              </span>
            </div>
          </div>
        </section>
      ) : (
        <FaqSection
          categories={faqCategories}
          faqItems={faqItems}
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
        />
      )}

      <div className="flex justify-center my-8">
        <Button className="bg-ehc-green hover:bg-ehc-green-dark rounded-[37px] h-[47px] px-6">
          <MessageSquareIcon className="w-5 h-5 mr-2" />
          <span className="font-rubik font-semibold text-white text-base">
            <Trans id="faq.contact_us_button">Contact Us</Trans>
          </span>
        </Button>
      </div>

      <section className="w-full" id="contact">
        <div className="max-w-7xl mx-auto px-4">
          <div className="mb-12">
            <h2 className="font-rubik font-bold text-ehc-green text-4xl leading-[54px]">
              <Trans id="faq.contact_title">Get In Touch</Trans>
            </h2>
            <div className="w-[60px] h-[3px] mt-1 bg-ehc-green" />
          </div>

          <div className="flex flex-col md:flex-row gap-8">
            <MainContentSection
              contactInfo={contactInfo}
              socialMedia={socialMedia}
            />
            <ContactFormSection
              formFields={[
                { id: "name", type: "input" },
                { id: "email", type: "input" },
                { id: "subject", type: "input" },
                { id: "message", type: "textarea" },
              ]} 
             />
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};
export default FaqPage;
