import TestimonialsSection from "@/components/Landing/entrepriseSections/TestimonialsSection";
import UxUiSection from "@/components/Landing/entrepriseSections/UxUiSection";
import Footer from "@/components/Layout/Footer";
import Header from "@/components/Layout/Header";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import CompaniesCmsSection from "./CompaniesCmsSection";
import SectionAd from "./SectionAd";
import ServiceCmsCard from "./ServiceCmsCard";
import { Trans, t } from "@lingui/macro";
import { BlogDetails } from "@/lib/types/Blog";
import { blogService } from "@/lib/network/pages/Blogs";
import { settings } from "@/lib/settings/main";

const HomePage = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  const [blogPosts, setBlogPosts] = useState<BlogDetails[]>([]);

  const handleGetStarted = () => console.log("Get Started clicked");
  const handleSignIn = () => navigate("/auth");
  const handleCandidateRegister = () => navigate("/auth/signup");
  const handleEmployerRegister = () => navigate("/auth/recruiter-signup");
  const handleFindJobsNow = () => navigate("/jobs");
  const handleBlogNavigation = () => navigate("/blog");
  const handleReadMore = (id: number) => navigate(`/blog/${id}`);

  const handleGetStartedStep = (step: string) => {
    switch (step) {
      case "create":
        navigate("/auth/signup");
        break;
      case "upload":
        navigate("/candidate/profile");
        console.log("Upload CV/Resume");
        break;
      case "find":
        navigate("/jobs");
        break;
      case "apply":
        navigate("/candidate/applications");
        break;
      default:
        break;
    }
  };

  const dreamJobAlts: Record<number, string> = {
    1: t({ id: "home.dream_job.alt_1", message: "Dream Job Image 1" }),
    2: t({ id: "home.dream_job.alt_2", message: "Dream Job Image 2" }),
    3: t({ id: "home.dream_job.alt_3", message: "Dream Job Image 3" }),
  };

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await blogService.getBlogs({
          sortBy: "createdAt",
          sortOrder: "desc",
        });

        if (response.success) {
          setBlogPosts(response.data);
        }
      } catch (err) {
        console.error("Error fetching blogs:", err);
      }
    };

    fetchBlogs();
  }, []);

  return (
    <div className="w-full overflow-hidden relative">
      {/* Background Decorative Elements */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-20 right-10 w-32 h-32 bg-gradient-to-br from-[#238D94]/10 to-[#1f7a80]/5 rounded-full blur-xl"></div>
        <div className="absolute top-1/4 -left-16 w-64 h-64 bg-gradient-to-br from-[#238D94]/5 to-transparent rounded-full"></div>
        <div className="absolute bottom-20 right-20 w-40 h-40 bg-gradient-to-tl from-[#238D94]/8 to-[#1f7a80]/3 transform rotate-45 rounded-lg"></div>
        <div className="absolute top-2/3 left-10 w-16 h-16 bg-[#238D94]/10 rounded-full"></div>
        <div className="absolute top-2/3 left-20 w-8 h-8 bg-[#238D94]/15 rounded-full"></div>
        <div className="absolute top-32 left-1/2 transform -translate-x-1/2 w-96 h-2 bg-gradient-to-r from-transparent via-[#238D94]/10 to-transparent rounded-full"></div>
        <div className="absolute bottom-40 left-5 w-24 h-24 bg-gradient-to-tr from-[#238D94]/6 to-transparent rounded-full"></div>
        <div className="absolute top-1/2 right-5 w-1 h-32 bg-gradient-to-b from-[#238D94]/10 to-transparent rounded-full"></div>
        <div className="absolute top-1/3 right-1/4 w-3 h-3 bg-[#238D94]/20 rounded-full"></div>
        <div className="absolute top-1/2 left-1/4 w-2 h-2 bg-[#238D94]/15 rounded-full"></div>
        <div className="absolute top-3/4 right-1/3 w-4 h-4 bg-[#238D94]/10 rounded-full"></div>
      </div>

      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onGetStarted={handleGetStarted}
        onSignIn={handleSignIn}
      />

      {/* Hero Section */}
      <section className="relative w-full bg-[#F8F8FD] overflow-hidden pb-20 lg:pb-24 z-10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-10 items-center pt-20 lg:pt-28 pb-12 lg:pb-16">
            <div className="text-center lg:text-left space-y-6">
              <h1 className="text-4xl lg:text-6xl xl:text-7xl font-black leading-tight">
                <Trans id="home.hero.title">
                  <span className="text-[#238D94] font-black">
                    Explore Over
                  </span>{" "}
                  <span className="text-black font-black" dir="ltr">
                    +8,000
                  </span>{" "}
                  <span className="underline decoration-[#238D94] decoration-4 text-[#238D94] font-black">
                    Job
                  </span>
                </Trans>
              </h1>
              <p className="text-gray-600 max-w-xl mx-auto lg:mx-0 text-base lg:text-lg font-medium">
                <Trans id="home.hero.description">
                  Discover opportunities that{" "}
                  <span className="font-bold">inspire</span> you and roles where
                  your skills drive real change. Step into a place where you
                  don't just work—you{" "}
                  <span className="font-bold">grow, create</span>, and leave
                  your mark.
                </Trans>
              </p>
            </div>
            <div className="relative flex justify-center lg:justify-end">
              <div className="relative bg-[#238D94] rounded-[60px_8px_60px_8px] lg:rounded-[120px_8px_120px_8px] shadow-xl p-4 lg:p-8 w-[260px] sm:w-[320px] lg:w-[380px]">
                <img
                  src="/heroImag.png"
                  alt={t({
                    id: "home.hero.alt",
                    message: "Professional working",
                  })}
                  className="w-full h-auto rounded-lg"
                />
              </div>
            </div>
          </div>

          <div className="w-full px-0 lg:px-4">
            {/* Decorative gradient background */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#238D94]/5 to-[#1f7a80]/5 rounded-3xl"></div>

            <button
              onClick={handleFindJobsNow}
              className="relative w-full lg:w-auto group bg-gradient-to-r from-[#238D94] to-[#1f7a80] hover:from-[#1f7a80] hover:to-[#238D94] text-white font-bold px-8 py-4 rounded-2xl transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:-translate-y-1 border-2 border-transparent hover:border-white/20"
            >
              {/* Button glow effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-[#238D94] to-[#1f7a80] rounded-2xl blur opacity-0 group-hover:opacity-30 transition-opacity duration-300 -z-10"></div>

              {/* Button content with icon */}
              <div className="flex items-center justify-center gap-2">
                <svg
                  className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
                <span className="text-lg">
                  <Trans id="home.search.find_jobs_button">Find Jobs</Trans>
                </span>
                <svg
                  className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </div>

              {/* Shimmer effect */}
              <div className="absolute inset-0 -top-px bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 skew-x-12 rounded-2xl"></div>
            </button>
          </div>
        </div>
      </section>

      <SectionAd />
      <CompaniesCmsSection />
      <ServiceCmsCard />

      <section className="py-12 lg:py-16 px-4 bg-gray-100 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-2xl lg:text-3xl font-bold text-[#238D94]">
                <Trans id="home.dream_job.title">Find your dream job</Trans>
              </h2>
              <p className="text-gray-700 text-lg leading-relaxed">
                <Trans id="home.dream_job.description">
                  Discover thousands of job opportunities tailored to your
                  skills and aspirations. Your dream career is waiting for you.
                </Trans>
              </p>
              <button
                onClick={handleFindJobsNow}
                className="bg-[#238D94] text-white px-8 py-4 rounded-lg font-semibold hover:bg-[#1f7a80] transition-colors"
              >
                <Trans id="home.dream_job.find_jobs_button">
                  Find Jobs Now
                </Trans>
              </button>
            </div>
            <div className="grid grid-cols-3 gap-4">
              {[1, 2, 3].map((item) => (
                <div key={item} className="aspect-square">
                  <img
                    src={`/dream-${item}.png`}
                    alt={dreamJobAlts[item]}
                    className="w-full h-full object-cover rounded-lg shadow-md"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 lg:py-20 bg-[#f8f8fd] relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl lg:text-4xl font-bold text-center mb-12 lg:mb-16">
            <Trans id="home.get_started.title">
              <span className="text-gray-900">Get </span>
              <span className="text-[#238D94]">Started</span>
            </Trans>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            {[
              {
                title: (
                  <Trans id="home.get_started.step1_title">
                    Create account
                  </Trans>
                ),
                description: (
                  <Trans id="home.get_started.step1_desc">
                    Sign up in seconds and set up your profile.
                  </Trans>
                ),
                step: "01",
                action: "create",
              },
              {
                title: (
                  <Trans id="home.get_started.step2_title">
                    Upload CV/Resume
                  </Trans>
                ),
                description: (
                  <Trans id="home.get_started.step2_desc">
                    Showcase your experience and skills.
                  </Trans>
                ),
                step: "02",
                action: "upload",
              },
              {
                title: (
                  <Trans id="home.get_started.step3_title">
                    Find suitable job
                  </Trans>
                ),
                description: (
                  <Trans id="home.get_started.step3_desc">
                    Browse startup jobs that match your vibe.
                  </Trans>
                ),
                step: "03",
                action: "find",
              },
              {
                title: (
                  <Trans id="home.get_started.step4_title">Apply job</Trans>
                ),
                description: (
                  <Trans id="home.get_started.step4_desc">
                    Send your application and start your journey.
                  </Trans>
                ),
                step: "04",
                action: "apply",
              },
            ].map((step, index) => (
              <div
                key={index}
                onClick={() => handleGetStartedStep(step.action)}
                className="bg-white rounded-xl border border-[#238D94] p-6 lg:p-8 text-center hover:shadow-lg transition-shadow cursor-pointer hover:border-2"
              >
                <div className="w-16 h-16 bg-[#238D94] text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                  {step.step}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  {step.title}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <TestimonialsSection />

      <section className="py-12 lg:py-16 px-4 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-8 lg:mb-12">
            <h2
              onClick={handleBlogNavigation}
              className="text-2xl lg:text-3xl font-bold text-[#238D94] cursor-pointer hover:underline"
            >
              <Trans id="home.blog.title">Blog</Trans>
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {blogPosts &&
              blogPosts.slice(0, 3).map((post) => (
                <div
                  key={post.id}
                  className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <img
                    src={
                      `${settings.IMG_ADDRESS}${post.image?.url}` ||
                      "/placeholder.svg"
                    }
                  />
                  <div className="p-4 lg:p-6">
                    <span className="bg-[#238D94] text-white text-xs px-2 py-1 rounded">
                      {new Date(post.createdAt).toLocaleDateString("en-US", {
                        month: "long",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </span>

                    <h3 className="mt-3 font-semibold text-lg">{post.title}</h3>
                    <p className="text-gray-600 text-sm my-3 leading-relaxed">
                      {post.description}
                    </p>
                    <button
                      onClick={() => handleReadMore(post.id)}
                      className="text-[#238D94] font-medium hover:underline"
                    >
                      <Trans id="home.blog.read_more">Read more</Trans>
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </section>

      <UxUiSection />

      <section className="py-12 lg:py-16 px-4 bg-white relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
            <div className="bg-[#E6F4F1] p-6 lg:p-8 rounded-lg">
              <h3 className="text-[#238D94] font-bold text-xl lg:text-2xl mb-4">
                <Trans id="home.register.candidate_title">
                  Become a Candidate
                </Trans>
              </h3>
              <p className="text-[#0F141E] mb-6 leading-relaxed">
                <Trans id="home.register.candidate_desc">
                  Join us and start applying for jobs today.
                </Trans>
              </p>
              <button
                onClick={handleCandidateRegister}
                className="bg-[#238D94] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#1f7a80] transition-colors"
              >
                <Trans id="home.register.register_now_button">
                  Register Now
                </Trans>
              </button>
            </div>
            <div className="bg-[#238D94] p-6 lg:p-8 rounded-lg">
              <h3 className="text-white font-bold text-xl lg:text-2xl mb-4">
                <Trans id="home.register.employer_title">
                  Become an Employer
                </Trans>
              </h3>
              <p className="text-white mb-6 leading-relaxed">
                <Trans id="home.register.employer_desc">
                  Post your job offers and find the best talent.
                </Trans>
              </p>
              <button
                onClick={handleEmployerRegister}
                className="bg-white text-[#238D94] px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                <Trans id="home.register.register_now_button">
                  Register Now
                </Trans>
              </button>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default HomePage;
