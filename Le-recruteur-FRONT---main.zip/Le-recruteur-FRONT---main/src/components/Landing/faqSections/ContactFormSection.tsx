import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { SendIcon, Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { ContactFormSchema, ContactFormData } from "@/lib/form/faq";
import { faqPageService } from "@/lib/network/pages/faq";
import { Trans, t } from "@lingui/macro";
import React from "react"; 

interface FormField {
  id: keyof ContactFormData;
  type: 'input' | 'textarea';
}

interface ContactFormSectionProps {
  formFields: FormField[];
}

export const ContactFormSection: React.FC<ContactFormSectionProps> = ({ formFields }): JSX.Element => {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
  } = useForm<ContactFormData>({
    resolver: zodResolver(ContactFormSchema),
  });

  const onSubmit = async (data: ContactFormData) => {
    try {
      await faqPageService.submitContactForm(data);
      toast.success(t({ id: "about.form.message_sent_success", message: "Message sent successfully!" }));
      reset();
    } catch (error) {
      console.error("Error submitting form:", error);
      toast.error(t({ id: "about.form.message_send_failed", message: "Failed to send message. Please try again." }));
    }
  };

  const translatedLabels = {
    name: t({ id: "about.form.name_label", message: "Your Name" }),
    email: t({ id: "about.form.email_label", message: "Email Address" }),
    subject: t({ id: "about.form.subject_label", message: "Subject" }),
    message: t({ id: "about.form.message_label", message: "Message" }),
  };

  const translatedPlaceholders = {
    name: t({ id: "about.form.name_placeholder", message: "Enter your name" }),
    email: t({ id: "about.form.email_placeholder", message: "Enter your email" }),
    subject: t({ id: "about.form.subject_placeholder", message: "Enter subject" }),
    message: t({ id: "about.form.message_placeholder", message: "Enter your message" }),
  };

  return (
    <Card className="w-full max-w-[656px] rounded-[20px] shadow-[0px_10px_30px_#00000014] mb-8 overflow-hidden">
      {/* Teal header bar */}
      <div className="w-full h-2.5 bg-ehc-green rounded-[20px_20px_0px_0px]" />
      <CardContent className="p-10">
        <form className="space-y-6" onSubmit={handleSubmit(onSubmit)}>
          {formFields.map((field, index) => {
            if (!field || typeof field.id === 'undefined' || typeof field.type === 'undefined') {
              console.error("Malformed form field detected, skipping:", field, "at index:", index);
              return null; 
            }

            const fieldId = field.id; 

            return (
              <div key={fieldId} className="space-y-2">
                <Label htmlFor={fieldId} className="block font-medium text-gray-700 text-base font-rubik">
                  {/* Lookup the pre-translated label */}
                  {translatedLabels[fieldId]}
                </Label>
                {field.type === "input" ? (
                  <Input
                    id={fieldId}
                    placeholder={translatedPlaceholders[fieldId]}
                    className="h-[50px] bg-gray-50 rounded-[10px] border border-slate-200 font-rubik text-gray-500"
                    {...register(field.id)}
                  />
                ) : ( 
                  <Textarea
                    id={fieldId}
                    placeholder={translatedPlaceholders[fieldId]}
                    className="h-[150px] bg-gray-50 rounded-[10px] border border-slate-200 font-rubik text-gray-500 resize-none"
                    {...register(field.id)}
                  />
                )}
                {errors[field.id] && (
                  <p className="text-sm text-red-500 font-rubik">
                    {errors[field.id]?.message}
                  </p>
                )}
              </div>
            );
          })}

          <Button
            type="submit"
            className="w-full h-11 bg-ehc-green hover:bg-ehc-green-dark rounded-lg font-rubik font-semibold text-white"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                <Trans id="about.form.button_sending">Sending...</Trans>
              </>
            ) : (
              <>
                <SendIcon className="w-4 h-4 mr-2" />
                <Trans id="about.form.button_sendMessage">Send Message</Trans>
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};