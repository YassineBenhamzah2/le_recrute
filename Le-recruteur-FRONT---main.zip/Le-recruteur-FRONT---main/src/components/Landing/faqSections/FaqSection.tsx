import {
    Accordion,
    AccordionContent,
    AccordionItem,
} from "@/components/ui/accordion";
import * as AccordionPrimitive from "@radix-ui/react-accordion";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Dispatch, SetStateAction, forwardRef } from "react";
import { cn } from "@/lib/utils";
import { PlusIcon, MinusIcon } from "lucide-react";

interface FaqItem {
    question: string;
    answer: string;
    category: string;
    defaultOpen?: boolean;
}

interface FaqCategory {
    id: string;
    label: string;
    active: boolean;
}

interface FaqSectionProps {
    categories: FaqCategory[];
    faqItems: FaqItem[];
    activeCategory: string;
    onCategoryChange: Dispatch<SetStateAction<string>>;
}

// Custom Accordion Trigger with plus/minus icons
const CustomAccordionTrigger = forwardRef<
    React.ElementRef<typeof AccordionPrimitive.Trigger>,
    React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
    <AccordionPrimitive.Header className="flex">
        <AccordionPrimitive.Trigger
            ref={ref}
            className={cn(
                "flex flex-1 items-center justify-between font-medium transition-all text-left group",
                className
            )}
            {...props}
        >
            {children}
            <div className="flex items-center justify-center w-8 h-8 border-4 border-black font-bold text-black rounded-md transition-transform duration-200">
                <PlusIcon className="h-6 w-6 shrink-0 group-data-[state=open]:hidden" />
                <MinusIcon className="h-6 w-6 shrink-0 hidden group-data-[state=open]:block" />
            </div>
        </AccordionPrimitive.Trigger>
    </AccordionPrimitive.Header>
));
CustomAccordionTrigger.displayName = AccordionPrimitive.Trigger.displayName;

export const FaqSection = ({
    categories,
    faqItems,
    activeCategory,
    onCategoryChange
}: FaqSectionProps): JSX.Element => {

    // Filter FAQ items based on active category
    const filteredFaqItems = faqItems.filter(item => item.category === activeCategory);

    return (
        <section className="w-full bg-white py-16">
            <div className="container mx-auto flex flex-col items-center gap-12">
                {/* Category Toggle Group */}
                <ToggleGroup
                    type="single"
                    value={activeCategory}
                    onValueChange={(value) => {
                        if (value) onCategoryChange(value);
                    }}
                    className="flex justify-center"
                >
                    {categories.map((category) => (
                        <ToggleGroupItem
                            key={category.id}
                            value={category.id}
                            className={`px-[15px] py-[5px] rounded-[10px] ${category.id === activeCategory
                                ? "bg-ehc-green text-white"
                                : "bg-ehc-green/10 text-ehc-green"
                                }`}
                        >
                            <span className="font-rubik text-sm leading-[23.8px] font-medium">
                                {category.label}
                            </span>
                        </ToggleGroupItem>
                    ))}
                </ToggleGroup>

                {/* FAQ Accordion */}
                <div className="w-full max-w-[830px]">
                    <Accordion
                        type="single"
                        defaultValue="item-0"
                        collapsible
                        className="flex flex-col gap-5"
                    >
                        {filteredFaqItems.map((item, index) => (
                            <AccordionItem
                                key={`item-${index}`}
                                value={`item-${index}`}
                                className="border border-solid border-gray-100 rounded-[10px] overflow-hidden bg-ehc-green/10 p-px"
                            >
                                <CustomAccordionTrigger
                                    className={`px-4 py-2.5 font-rubik font-bold text-gray-900 text-lg leading-[30.6px] bg-white
                                         hover:no-underline`}
                                >
                                    {item.question}
                                </CustomAccordionTrigger>
                                <AccordionContent className="px-5 py-4 font-rubik font-normal text-gray-700 text-[15px] leading-[25.5px]">
                                    {item.answer}
                                </AccordionContent>
                            </AccordionItem>
                        ))}
                    </Accordion>
                </div>
            </div>
        </section>
    );
};
