import { Trans } from '@lingui/macro'; 

interface ContactInfo {
  icon: JSX.Element;
  text: string;
  width: string;
}

interface SocialMedia {
  icon: JSX.Element;
  link: string;
}

interface MainContentSectionProps {
  contactInfo: ContactInfo[];
  socialMedia: SocialMedia[];
}

export const MainContentSection = ({
  contactInfo,
  socialMedia,
}: MainContentSectionProps): JSX.Element => {
  return (
    <section className="w-full py-8 bg-white">
      <div className="container mx-auto flex flex-col md:flex-row gap-8">
        {/* Left side - Contact Information */}
        <div className="w-full ">
          <div className="mb-8">
            <p className="font-normal text-gray-700 text-base leading-[28.8px] font-rubik">
              <Trans id="contact.intro">
                Have questions about our platform or interested in partnering with us?
                <br />
                Reach out to our team and we&apos;ll get back to you as soon as possible.
              </Trans>
            </p>
          </div>

          {/* Contact details */}
          <div className="space-y-6 mb-10">
            {contactInfo.map((item, index) => (
              <div key={index} className="flex items-center">
                <div className="w-[50px] h-[50px] bg-ehc-green/10 rounded-[10px] flex items-center justify-center mr-5">
                  {item.icon}
                </div>
                <div
                  className={`${item.width} font-rubik font-normal text-gray-700 text-base leading-6`}
                  dir='ltr'
                >
                  {item.text} 
                </div>
              </div>
            ))}
          </div>

          {/* Social Media */}
          <div>
            <h3 className="font-rubik font-bold text-ehc-green text-[18.7px] leading-[28.1px] mb-4">
              <Trans id="about.contact.followUs">Follow Us</Trans>
            </h3>
            <div className="flex space-x-4">
              {socialMedia.map((item, index) => (
                <a
                  key={index}
                  href={item.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-ehc-green/10 rounded-[20px] flex items-center justify-center hover:bg-ehc-green/20 transition-colors"
                >
                  {item.icon}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};