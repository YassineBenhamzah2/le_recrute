import Footer from "@/components/Layout/Footer";
import Header from "@/components/Layout/Header";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { blogService } from "@/lib/network/pages/Blogs";
import { settings } from "@/lib/settings/main";
import { BlogCount, BlogDetails } from "@/lib/types/Blog";
import { Trans, t } from "@lingui/macro";
import { Calendar, Clock, User } from "lucide-react";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

export default function BlogDetail() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [blogPost, setBlogPost] = useState<BlogDetails>();
  const [error, setError] = useState<string | null>(null);
  const { id } = useParams();
  const [totalBlogCounts, setTotalBlogCounts] = useState<BlogCount[]>([]);
  const [loadingCounts, setLoadingCounts] = useState(false);

  useEffect(() => {
    const fetchDetailsBlog = async () => {
      if (!id) {
        setError(
          t({ id: "blog.detail.error.noId", message: "Blog ID not specified" })
        );
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const response = await blogService.getBlogById(parseInt(id));
        if (response.success) {
          setBlogPost(response.data);
        } else {
          setError(
            t({
              id: "blog.detail.error.load",
              message: "Error loading the blog",
            })
          );
        }
      } catch (err) {
        setError(
          t({
            id: "blog.detail.error.connection",
            message: "Server connection error",
          })
        );
        console.error("Error fetching blog:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchDetailsBlog();
  }, [id]);

  useEffect(() => {
    const fetchBlogCounts = async () => {
      try {
        setLoadingCounts(true);
        const response = await blogService.getBlogCounts();

        if (response.success) {
          setTotalBlogCounts(response.data);
        } else {
          console.error("Erreur lors du chargement des comptes de blogs");
        }
      } catch (err) {
        console.error(
          "Erreur de connexion au serveur pour les comptes de blogs:",
          err
        );
      } finally {
        setLoadingCounts(false);
      }
    };

    fetchBlogCounts();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#ffffff]">
        <Header
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
        />
        <div className="flex justify-center items-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#238d94]"></div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !blogPost) {
    return (
      <div className="min-h-screen bg-[#ffffff]">
        <Header
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
        />
        <div className="flex justify-center items-center h-96">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-red-600 mb-4">
              <Trans id="blog.detail.error.title">Error</Trans>
            </h2>
            <p className="text-gray-600">
              {error ||
                t({
                  id: "blog.detail.error.notFound",
                  message: "Blog not found",
                })}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="mt-4 px-4 py-2 bg-[#238d94] text-white rounded-md hover:bg-[#1a6c72]"
            >
              <Trans id="blog.detail.error.retry">Retry</Trans>
            </button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("fr-FR", {
      month: "long",
      day: "numeric",
      year: "numeric",
    });
  };

  const readTime = blogPost.content
    ? Math.ceil(blogPost.content.length / 200)
    : 0;

  return (
    <div className="min-h-screen bg-[#ffffff]">
      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
      />

      <section className="relative w-full h-[250px] bg-[#e6f4f1] overflow-hidden md:h-[450px]">
        <div className="relative h-[350px] mt-[-60px] md:mt-[-113px] md:h-[600px]">
          <div className="absolute w-full h-[250px] top-[60px] left-0 bg-[linear-gradient(90deg,rgba(230,244,241,0.9)_50%,rgba(230,244,241,0.7)_100%)] md:h-[450px] md:top-[113px]" />

          <div className="absolute w-full max-w-[90%] top-[80px] left-1/2 -translate-x-1/2 px-4 md:max-w-[1332px] md:top-[213px] md:px-5">
            <div className="relative">
              <h1 className="text-2xl font-bold text-[#238d94] [font-family:'Bai_Jamjuree-Bold',Helvetica] leading-[30px] md:text-5xl md:leading-[72px]">
                <Trans id="blog.hero.title">Jobs Blog</Trans>
              </h1>
              <div className="w-10 h-1 mt-1 bg-[#238d94] md:w-20" />
            </div>
            <p className="mt-2 text-base font-extralight text-black [font-family:'Bai_Jamjuree-ExtraLight',Helvetica] leading-[20px] max-w-full md:mt-5 md:text-3xl md:leading-[44px] md:max-w-[646px]">
              <Trans id="blog.hero.description">
                Your Guide to Finding Jobs and Building Your Career in Morocco
              </Trans>
            </p>
          </div>

          {/* Version desktop de l'image - affichée uniquement sur desktop */}
          <div className="hidden md:flex flex-1 justify-end">
            <div
              className="relative"
              style={{
                position: "relative",
                height: "200px",
                width: "250px",
                marginRight: "20px",
              }}
            >
              <img
                src="/Frame 158.png"
                alt={t({
                  id: "blog.hero.imageAlt",
                  message: "Professional man making a phone call",
                })}
                style={{
                  position: "absolute",
                  top: "137%",
                  right: "40%",
                  transform: "translateY(-50%)",
                  maxWidth: "100%",
                  height: "auto",
                }}
                className="object-contain"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 md:py-12 md:pr-[10pc] md:pl-[6pc]">
        <div className="flex flex-col lg:grid lg:grid-cols-3 gap-8">
          {/* Blog Content */}
          <div className="lg:col-span-2 order-2 lg:order-1">
            <article className="bg-[#ffffff] rounded-lg shadow-sm">
              <img
                src={
                  `${settings.IMG_ADDRESS}${blogPost.image?.url}` ||
                  "/placeholder.svg"
                }
                alt={blogPost?.image?.filename}
                className="w-full h-48 object-cover rounded-t-lg md:h-64"
              />

              <div className="p-4 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center text-sm text-[#666666] mb-4 space-y-2 md:space-y-0">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>{formatDate(blogPost.createdAt)}</span>
                  </div>
                  <span className="hidden md:block mx-2">
                    <Trans id="blog.detail.by">By</Trans>
                  </span>
                  <div className="flex items-center md:ml-2">
                    <User className="h-4 w-4 mr-1" />
                    <span className="text-[#238d94]">{blogPost?.creator}</span>
                  </div>
                  <div className="flex items-center md:ml-4">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>
                      {readTime}
                      <Trans id="blog.post.readTime">min read</Trans>
                    </span>
                  </div>
                </div>

                <h2 className="text-2xl font-bold text-[#000000] mb-4 md:text-3xl md:mb-6">
                  {blogPost?.title}
                </h2>

                <div className="prose prose-gray max-w-none">
                  <p className="text-[#666666] leading-relaxed mb-4 md:mb-6">
                    <div className="prose max-w-none text-justify">
                      {(() => {
                        const rawContent = String(blogPost.content || "");
                        const cleanContent = rawContent
                          .replace(/^"|"$/g, "")
                          .trim();

                        // 3. Return the div with the cleaned content
                        return (
                          <div
                            dangerouslySetInnerHTML={{ __html: cleanContent }}
                          />
                        );
                      })()}
                    </div>
                  </p>
                </div>
              </div>
            </article>
          </div>

          {/* Sidebar */}
          <div className="space-y-6 order-1 lg:order-2">
            {/* Sticky Container */}
            <div className="lg:sticky lg:top-24 lg:h-fit space-y-6">
              {/* Categories */}
              <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                <CardContent className="p-4 md:p-6">
                  <h3 className="text-lg font-semibold text-[#000000] mb-3 md:mb-4">
                    <Trans id="blog.detail.categories">Categories</Trans>
                  </h3>
                  {loadingCounts ? (
                    <div className="flex justify-center py-4">
                      <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-[#238d94]"></div>
                    </div>
                  ) : totalBlogCounts && totalBlogCounts.length > 0 ? (
                    <div className="space-y-2 mb-3 md:space-y-3 md:mb-4">
                      {totalBlogCounts.map((category, index) => (
                        <div
                          key={index}
                          className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-md transition-colors cursor-pointer"
                        >
                          <span className="text-[#666666] text-sm md:text-base">
                            {category.categoryName}
                          </span>
                          <span className="text-[#238d94] text-xs md:text-sm font-semibold bg-[#e6f4f1] px-2 py-1 rounded-full">
                            {category.count}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[#666666] text-xs md:text-sm">
                      <Trans id="blog.detail.noCategory">
                        No categories available
                      </Trans>
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Tags */}
              <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                <CardContent className="p-4 md:p-6">
                  <h3 className="text-lg font-semibold text-[#000000] mb-3 md:mb-4">
                    <Trans id="blog.detail.tags">Tags</Trans>
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {blogPost.tags && blogPost.tags.length > 0 ? (
                      blogPost.tags.map((tag, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="bg-[#f0f6fe] text-[#1967d2] hover:bg-[#e3ebff] hover:scale-105 transition-all duration-200 text-xs md:text-sm cursor-pointer"
                        >
                          {typeof tag === "object" ? tag.name : tag}
                        </Badge>
                      ))
                    ) : (
                      <p className="text-[#666666] text-xs md:text-sm">
                        <Trans id="blog.detail.noTags">No tags available</Trans>
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}