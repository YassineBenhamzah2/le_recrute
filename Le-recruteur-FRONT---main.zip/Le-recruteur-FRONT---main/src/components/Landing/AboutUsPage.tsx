import React from "react";
import Header from "@/components/Layout/Header";
import Footer from "@/components/Layout/Footer";
import { MainContentSection } from "@/components/Landing/faqSections/MainContentSection";
import { ContactFormSection } from "@/components/Landing/faqSections/ContactFormSection";
import {
  FacebookIcon,
  InstagramIcon,
  LinkedinIcon,
  MailIcon,
  MapPinIcon,
  PhoneIcon,
  TwitterIcon,
} from "lucide-react";
import { Trans, t } from "@lingui/macro";
import { ContactFormData } from "@/lib/form/faq";

// Define FormField type here if not globally available, to match ContactFormSection's expectation
interface FormField {
  id: keyof ContactFormData;
  type: "input" | "textarea";
}

interface AboutUsPageProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

const AboutUsPage: React.FC<AboutUsPageProps> = ({
  onGetStarted,
  onSignIn,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  // Contact info data
  const contactInfo = [
    {
      icon: <MapPinIcon className="h-5 w-5 text-ehc-green" />,
      text: t({
        id: "about.contact.address",
        message: "123 Business Street, City, Country",
      }),
      width: "w-[308px]",
    },
    {
      icon: <PhoneIcon className="h-5 w-5 text-ehc-green" />,
      text: t({ id: "about.contact.phone", message: "+1 (555) 123-4567" }),
      width: "w-[141px]",
    },
    {
      icon: <MailIcon className="h-5 w-5 text-ehc-green" />,
      text: t({
        id: "about.contact.email",
        message: "contact@expertshumancapital.com",
      }),
      width: "w-[235px]",
    },
  ];

  const socialMedia = [
    {
      icon: <FacebookIcon className="h-4 w-4 text-ehc-green" />,
      link: "https://facebook.com",
    },
    {
      icon: <TwitterIcon className="h-4 w-4 text-ehc-green" />,
      link: "https://twitter.com",
    },
    {
      icon: <LinkedinIcon className="h-4 w-4 text-ehc-green" />,
      link: "https://linkedin.com",
    },
    {
      icon: <InstagramIcon className="h-4 w-4 text-ehc-green" />,
      link: "https://instagram.com",
    },
  ];

  const formFields: FormField[] = [
    {
      id: "name",
      type: "input",
    },
    {
      id: "email",
      type: "input",
    },
    {
      id: "subject",
      type: "input",
    },
    {
      id: "message",
      type: "textarea",
    },
  ];

  return (
    <div className="flex flex-col w-full bg-white font-rubik">
      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onGetStarted={onGetStarted}
        onSignIn={onSignIn}
      />

      {/* Hero Section - About Our Company */}
      <section className="w-full bg-ehc-green/10 py-20">
        <div className="max-w-[1440px] mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-6">
              <h1 className="text-5xl font-bold font-rubik text-ehc-green leading-[60px]">
                <Trans id="about.hero.title">About Our Company</Trans>
              </h1>

              {/* Underline decoration */}
              <div className="w-16 h-1 bg-[#238D94]"></div>

              <p className="text-gray-700 text-xl leading-relaxed">
                <Trans id="about.hero.description">
                  Learn more about our mission, values, and the team behind our
                  job search platform that's transforming careers worldwide.
                </Trans>
              </p>
              <button className="bg-ehc-green hover:bg-ehc-green-dark text-white px-8 py-4 rounded-lg font-semibold transition-colors duration-200">
                <Trans id="about.hero.button">Learn More</Trans>
              </button>
            </div>

            {/* Right Image with decorative elements */}
            <div className="relative">
              <div className="rounded-lg overflow-hidden">
                <img
                  src="/teamMeeting.png"
                  alt="Team meeting"
                  className="w-full h-auto object-cover"
                />
              </div>
              {/* Decorative curve - similar to the original */}
              <div className="absolute -top-8 -right-8 w-32 h-32 border-4 border-ehc-green/20 rounded-full"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Separator */}
      <div className="w-full h-8 bg-white"></div>

      {/* Our Story Section */}
      <section className="w-full bg-white py-20">
        <div className="max-w-[1440px] mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-6">
              <h2 className="text-4xl font-bold font-rubik text-ehc-green leading-[54px]">
                <Trans id="about.story.title">Our Story</Trans>
              </h2>
              <div className="space-y-5 text-gray-700 text-lg leading-relaxed">
                <p>
                  <Trans id="about.story.p1">
                    Our company was founded in 2015 with a critical mission: to
                    connect talented individuals with careers they are truly
                    passionate about and to connect employers with positive
                    candidates.
                  </Trans>
                </p>
                <p>
                  <Trans id="about.story.p2">
                    What started as a small startup with just 5 team members has
                    now grown into a thriving organization with over 200
                    dedicated experts - but our fundamental commitment to
                    excellence remains unchanged.
                  </Trans>
                </p>
                <p>
                  <Trans id="about.story.p3">
                    We believe that finding the right job should be easy,
                    transparent, and accessible to everyone. That's why we built
                    a platform that bridges the gap between top talent and major
                    competitive companies.
                  </Trans>
                </p>
              </div>
            </div>

            {/* Right Image */}
            <div className="relative">
              <div className="rounded-lg overflow-hidden border-4 border-ehc-green/10">
                <img
                  src="/womenWork.png"
                  alt="Professional workspace"
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Separator */}
      <div className="w-full h-8 bg-white"></div>

      {/* Mission & Values Section */}
      <section className="w-full bg-gradient-to-r from-slate-100 to-ehc-green/5 py-20">
        <div className="max-w-[1440px] mx-auto px-4">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold font-rubik text-ehc-green mb-6">
              <Trans id="about.mission.title">Our Mission & Values</Trans>
            </h2>
            <p className="text-gray-700 text-xl max-w-3xl mx-auto leading-relaxed">
              <Trans id="about.mission.description">
                We're not just focused on transforming how people find jobs and
                how companies hire talent. Our purpose is built on these core
                values that guide everything we do.
              </Trans>
            </p>
          </div>

          {/* Values Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {/* Excellence Card */}
            <div className="bg-white rounded-lg p-10 text-center shadow-lg border">
              <div className="w-20 h-20 bg-ehc-green/10 rounded-full flex items-center justify-center mx-auto mb-8">
                <svg
                  className="w-10 h-10 text-ehc-green"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
                  />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6 font-rubik">
                <Trans id="about.values.excellence_title">Excellence</Trans>
              </h3>
              <p className="text-gray-600 leading-relaxed">
                <Trans id="about.values.excellence_desc">
                  We maintain the highest standards in everything we do. From
                  the jobs we recommend to our platform's functionality, we
                  strive for excellence and innovation.
                </Trans>
              </p>
            </div>

            {/* Innovation Card - Center/Featured */}
            <div className="bg-ehc-green rounded-lg p-10 text-center shadow-xl transform scale-105">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-8">
                <svg
                  className="w-10 h-10 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
                  />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-6 font-rubik">
                <Trans id="about.values.innovation_title">Innovation</Trans>
              </h3>
              <p className="text-white/90 leading-relaxed">
                <Trans id="about.values.innovation_desc">
                  We embrace flexibility and transparency to connect all job
                  applications and matches. Our innovative approach ensures
                  exceptional results.
                </Trans>
              </p>
            </div>

            {/* Integrity Card */}
            <div className="bg-white rounded-lg p-10 text-center shadow-lg border">
              <div className="w-20 h-20 bg-ehc-green/10 rounded-full flex items-center justify-center mx-auto mb-8">
                <svg
                  className="w-10 h-10 text-ehc-green"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6 font-rubik">
                <Trans id="about.values.integrity_title">Integrity</Trans>
              </h3>
              <p className="text-gray-600 leading-relaxed">
                <Trans id="about.values.integrity_desc">
                  We continuously seek to improve our platform to better serve
                  job seekers and employers, creating more efficient and
                  innovative connections.
                </Trans>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Separator */}
      <div className="w-full h-8 bg-white"></div>

      {/* How It Works Section 1 */}
      <section className="w-full bg-white py-20">
        <div className="max-w-[1440px] mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold font-rubik text-ehc-green">
              <Trans id="about.how_it_works.title">How It Works?</Trans>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {/* Step 1 */}
            <div className="bg-blue-500 rounded-lg p-8 text-white relative">
              <div className="absolute -top-4 -right-4 bg-white text-blue-500 rounded-full w-16 h-16 flex items-center justify-center font-bold text-2xl">
                01
              </div>
              <div className="mb-6">
                <svg
                  className="w-16 h-16 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                  />
                </svg>
              </div>
              <h3 className="text-2xl font-bold mb-4">
                <Trans id="about.how_it_works.step1_title">
                  Create Your Account
                </Trans>
              </h3>
              <p className="opacity-90 leading-relaxed">
                <Trans id="about.how_it_works.step1_desc">
                  Sign up for free and complete your professional profile to get
                  started.
                </Trans>
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-ehc-green rounded-lg p-8 text-white relative">
              <div className="absolute -top-4 -right-4 bg-white text-ehc-green rounded-full w-16 h-16 flex items-center justify-center font-bold text-2xl">
                02
              </div>
              <div className="mb-6">
                <svg
                  className="w-16 h-16 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>
              <h3 className="text-2xl font-bold mb-4">
                <Trans id="about.how_it_works.step2_title">
                  Find Your Job Opening
                </Trans>
              </h3>
              <p className="opacity-90 leading-relaxed">
                <Trans id="about.how_it_works.step2_desc">
                  Use our AI-powered search to find jobs that match your skills
                  and preferences.
                </Trans>
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-400 rounded-lg p-8 text-white relative">
              <div className="absolute -top-4 -right-4 bg-white text-slate-400 rounded-full w-16 h-16 flex items-center justify-center font-bold text-2xl">
                03
              </div>
              <div className="mb-6">
                <svg
                  className="w-16 h-16 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z"
                  />
                </svg>
              </div>
              <h3 className="text-2xl font-bold mb-4">
                <Trans id="about.how_it_works.step3_title">
                  Find & Hire Top Talents
                </Trans>
              </h3>
              <p className="opacity-90 leading-relaxed">
                <Trans id="about.how_it_works.step3_desc">
                  Review candidates and find the best talent for your company
                  needs.
                </Trans>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Separator */}
      <div className="w-full h-8 bg-white"></div>

      {/* How It Works Section 2 */}
      <section className="w-full bg-slate-50 py-20">
        <div className="max-w-[1440px] mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-10">
              <div className="bg-blue-100 rounded-full w-24 h-24 flex items-center justify-center">
                <svg
                  className="w-12 h-12 text-blue-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>

              <div>
                <p className="text-ehc-green font-semibold mb-4 text-lg">
                  <Trans id="about.how_it_works_alt.subtitle">
                    How It Works
                  </Trans>
                </p>
                <h2 className="text-4xl font-bold text-gray-900 mb-8 font-rubik">
                  <Trans id="about.how_it_works_alt.title">
                    Follow our steps, we will help you.
                  </Trans>
                </h2>

                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-3 h-3 bg-ehc-green rounded-full"></div>
                    <p className="text-gray-700 text-lg">
                      <Trans id="about.how_it_works_alt.feature1">
                        Trusted & Quality Job
                      </Trans>
                    </p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-3 h-3 bg-ehc-green rounded-full"></div>
                    <p className="text-gray-700 text-lg">
                      <Trans id="about.how_it_works_alt.feature2">
                        International Jobs
                      </Trans>
                    </p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-3 h-3 bg-ehc-green rounded-full"></div>
                    <p className="text-gray-700 text-lg">
                      <Trans id="about.how_it_works_alt.feature3">
                        No Extra Charge
                      </Trans>
                    </p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-3 h-3 bg-ehc-green rounded-full"></div>
                    <p className="text-gray-700 text-lg">
                      <Trans id="about.how_it_works_alt.feature4">
                        Top Companies
                      </Trans>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Process Steps */}
            <div className="grid grid-cols-2 gap-8">
              {/* Step 1 */}
              <div className="bg-ehc-green rounded-lg p-8 text-white relative">
                <div className="absolute -top-4 -left-4 bg-white text-ehc-green rounded-full w-16 h-16 flex items-center justify-center font-bold text-2xl">
                  01
                </div>
                <div className="pt-8">
                  <h3 className="font-bold mb-3 text-lg">
                    <Trans id="about.how_it_works_alt.step1_title">
                      Create Your Account
                    </Trans>
                  </h3>
                  <p className="text-sm opacity-90">
                    <Trans id="about.how_it_works_alt.step1_desc">
                      Register and build your professional profile
                    </Trans>
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="bg-teal-400 rounded-lg p-8 text-white relative mt-12">
                <div className="absolute -top-4 -left-4 bg-white text-teal-400 rounded-full w-16 h-16 flex items-center justify-center font-bold text-2xl">
                  02
                </div>
                <div className="pt-8">
                  <h3 className="font-bold mb-3 text-lg">
                    <Trans id="about.how_it_works_alt.step2_title">
                      Search, Find and Apply
                    </Trans>
                  </h3>
                  <p className="text-sm opacity-90">
                    <Trans id="about.how_it_works_alt.step2_desc">
                      Browse through thousands of job opportunities
                    </Trans>
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="bg-blue-300 rounded-lg p-8 text-white relative">
                <div className="absolute -top-4 -left-4 bg-white text-blue-300 rounded-full w-16 h-16 flex items-center justify-center font-bold text-2xl">
                  03
                </div>
                <div className="pt-8">
                  <h3 className="font-bold mb-3 text-lg">
                    <Trans id="about.how_it_works_alt.step3_title">
                      Apply For Dream Job
                    </Trans>
                  </h3>
                  <p className="text-sm opacity-90">
                    <Trans id="about.how_it_works_alt.step3_desc">
                      Submit applications to your preferred positions
                    </Trans>
                  </p>
                </div>
              </div>

              {/* Step 4 */}
              <div className="bg-orange-400 rounded-lg p-8 text-white relative mt-12">
                <div className="absolute -top-4 -left-4 bg-white text-orange-400 rounded-full w-16 h-16 flex items-center justify-center font-bold text-2xl">
                  04
                </div>
                <div className="pt-8">
                  <h3 className="font-bold mb-3 text-lg">
                    <Trans id="about.how_it_works_alt.step4_title">
                      Upload Your Resume
                    </Trans>
                  </h3>
                  <p className="text-sm opacity-90">
                    <Trans id="about.how_it_works_alt.step4_desc">
                      Share your experience and qualifications
                    </Trans>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Separator */}
      <div className="w-full h-8 bg-white"></div>

      {/* Testimonials Section */}
      <section className="w-full bg-white py-20">
        <div className="max-w-[1440px] mx-auto px-4">
          <div className="text-center mb-16">
            <p className="text-ehc-green font-semibold mb-4 text-lg">
              <Trans id="about.testimonials.subtitle">Testimonials</Trans>
            </p>
            <h2 className="text-4xl font-bold font-rubik text-gray-900">
              <Trans id="about.testimonials.title">
                What People Say About Us!
              </Trans>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {/* Testimonial 1 */}
            <div className="bg-white rounded-lg p-8 shadow-lg border">
              <div className="flex items-center mb-6">
                <img
                  src="/avatars/Esther1.png"
                  alt="Miles Esther"
                  className="w-16 h-16 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-bold text-gray-900 text-lg">
                    <Trans id="about.testimonials.user1_name">
                      Miles, Esther
                    </Trans>
                  </h4>
                  <p className="text-gray-600">
                    <Trans id="about.testimonials.user1_role">
                      Marketing Student
                    </Trans>
                  </p>
                </div>
              </div>
              <p className="text-gray-700 mb-6 leading-relaxed">
                <Trans id="about.testimonials.user1_quote">
                  "Architectures and serving is what constitutes the drawbacks.
                  Minus the drawbacks, the delights are a pleasure to the palate
                  and something more."
                </Trans>
              </p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <svg
                    key={i}
                    className="w-5 h-5 fill-current"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white rounded-lg p-8 shadow-lg border">
              <div className="flex items-center mb-6">
                <img
                  src="/avatars/Esther.png"
                  alt="Miles Esther"
                  className="w-16 h-16 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-bold text-gray-900 text-lg">
                    <Trans id="about.testimonials.user1_name">
                      Miles, Esther
                    </Trans>
                  </h4>
                  <p className="text-gray-600">
                    <Trans id="about.testimonials.user1_role">
                      Marketing Student
                    </Trans>
                  </p>
                </div>
              </div>
              <p className="text-gray-700 mb-6 leading-relaxed">
                <Trans id="about.testimonials.user1_quote">
                  "Architectures and serving is what constitutes the drawbacks.
                  Minus the drawbacks, the delights are a pleasure to the palate
                  and something more."
                </Trans>
              </p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <svg
                    key={i}
                    className="w-5 h-5 fill-current"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-white rounded-lg p-8 shadow-lg border">
              <div className="flex items-center mb-6">
                <img
                  src="/avatars/Miles.png"
                  alt="Miles Esther"
                  className="w-16 h-16 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-bold text-gray-900 text-lg">
                    <Trans id="about.testimonials.user1_name">
                      Miles, Esther
                    </Trans>
                  </h4>
                  <p className="text-gray-600">
                    <Trans id="about.testimonials.user1_role">
                      Marketing Student
                    </Trans>
                  </p>
                </div>
              </div>
              <p className="text-gray-700 mb-6 leading-relaxed">
                <Trans id="about.testimonials.user1_quote">
                  "Architectures and serving is what constitutes the drawbacks.
                  Minus the drawbacks, the delights are a pleasure to the palate
                  and something more."
                </Trans>
              </p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <svg
                    key={i}
                    className="w-5 h-5 fill-current"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
            </div>
          </div>

          {/* Navigation dots */}
          <div className="flex justify-center mt-12 space-x-3">
            <a className="w-4 h-4 bg-ehc-green rounded-full" />
            <a className="w-4 h-4 bg-gray-300 rounded-full" />
            <a className="w-4 h-4 bg-gray-300 rounded-full" />
          </div>
        </div>
      </section>

      {/* Get In Touch Section */}
      <section className="w-full bg-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="mb-12">
            <h2 className="font-rubik font-bold text-[#238D94] text-4xl leading-[54px]">
              <Trans id="about.get_in_touch.title">Get In Touch</Trans>
            </h2>
            <div className="w-[60px] h-[3px] mt-1 bg-[#238D94]" />
          </div>

          <div className="flex flex-col md:flex-row gap-8">
            <MainContentSection
              contactInfo={contactInfo}
              socialMedia={socialMedia}
            />
            <ContactFormSection formFields={formFields} />
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default AboutUsPage;
