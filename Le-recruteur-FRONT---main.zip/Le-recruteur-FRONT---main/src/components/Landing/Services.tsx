import Header from "../Layout/Header";
import Footer from "../Layout/Footer";
import React, { useEffect, useState } from "react";
import {
  Star,
  Target,
  HeadphonesIcon,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { ServiceCandidat } from "@/lib/network/pages/ServicesCandidat";
import { Service } from "@/lib/types/service";
import { useNavigate } from "react-router-dom";
import { settings } from "@/lib/settings/main";
import { Trans, t } from "@lingui/macro";

interface ServicesProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

const Services = ({ onGetStarted, onSignIn }: ServicesProps) => {
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [servicePosts, setServicePosts] = useState<Service[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(0);
  const [pagination, setPagination] = useState({
    totalCount: 0,
    totalPages: 1,
    hasNextPage: false,
    hasPreviousPage: false,
  });

  // Utilisation d'une valeur fixe pour itemsPerPage
  const itemsPerPage = 6;

  useEffect(() => {
    const fetchServices = async () => {
      try {
        setLoading(true);
        const response = await ServiceCandidat.getAllService({
          page: currentPage,
          size: itemsPerPage,
        });

        if (response) {
          setServicePosts(response.data || []);

          // Correction: Utilisation des données de pagination de la réponse API avec valeurs par défaut
          setPagination({
            totalCount: response.totalCount || 0,
            totalPages: response.totalPages || 1,
            hasNextPage: response.hasNextPage || false,
            hasPreviousPage: response.hasPreviousPage || false,
          });
        } else {
          setError(
            t({ id: "error.loadServices", message: "Error loading services" })
          );
        }
      } catch (error) {
        setError(
          t({
            id: "error.serverConnection",
            message: "Server connection error",
          })
        );
        console.error("Error fetching services:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchServices();
  }, [currentPage]);

  // Why choose us data
  const whyChooseUs = [
    {
      icon: <Star className="w-6 h-6 text-ehc-green" />,
      title: t({ id: "whyChooseUs.0.title", message: "Recognized Expertise" }),
      description: t({
        id: "whyChooseUs.0.description",
        message:
          "Our team of qualified experts guides you towards excellence with a personalized approach and proven solutions.",
      }),
    },
    {
      icon: <Target className="w-6 h-6 text-ehc-green" />,
      title: t({ id: "whyChooseUs.1.title", message: "Tailored Approach" }),
      description: t({
        id: "whyChooseUs.1.description",
        message:
          "Every journey is unique. We adapt our services to your specific goals to maximize your potential.",
      }),
    },
    {
      icon: <HeadphonesIcon className="w-6 h-6 text-ehc-green" />,
      title: t({ id: "whyChooseUs.2.title", message: "Continuous Support" }),
      description: t({
        id: "whyChooseUs.2.description",
        message:
          "Ongoing support and unlimited resources to ensure your progress and success.",
      }),
    },
  ];

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };


  return (
    <div className="flex flex-col w-full bg-white min-h-screen">
      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onGetStarted={onGetStarted}
        onSignIn={onSignIn}
      />

      {/* Hero Section */}
      <div className="bg-[#238d94] min-h-[400px] flex flex-col items-center justify-center px-6 py-16 relative overflow-hidden">
        {/* Image de fond */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              "url(https://www.visionhelpdesk.com/wp-content/uploads/2017/01/customer-service-team.jpg)",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        ></div>

        {/* Contenu */}
        <div className="text-center text-white max-w-4xl mx-auto relative z-10">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            <Trans id="services.hero.title">Professional Services</Trans>
          </h1>
          <p className="text-lg md:text-xl mb-8 leading-relaxed opacity-90">
            <Trans id="services.hero.description">
              Discover our complete range of professional services designed to
              support your company in all your recruitment projects.
            </Trans>
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={onGetStarted}
              className="bg-white text-[#238d94] px-8 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors duration-200"
            >
              <Trans id="services.hero.getStarted">Get Started Now</Trans>
            </button>
            <button
              onClick={() => navigate("/faq#contact")}
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-[#238d94] transition-colors duration-200"
            >
              <Trans id="services.hero.contactUs">Contact Us</Trans>
            </button>
          </div>
        </div>
      </div>

      <div className="flex-grow py-16 font-rubik">
        {/* Main Services Grid */}
        <div className="w-full max-w-7xl mx-auto px-6 mb-16">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              <Trans id="services.section.title">Our Services</Trans>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              <Trans id="services.section.description">
                Tailored solutions to transform your recruitment approach
              </Trans>
            </p>
          </div>

          {/* Services Grid */}
{loading ? (
            <div className="flex justify-center items-center h-96">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-ehc-green"></div>
            </div>
          ) : error ? (
            <div className="flex justify-center items-center h-96">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-red-600 mb-4">
                  <Trans id="error.title">Error</Trans>
                </h2>
                <p className="text-gray-600">{error}</p>
                <button
                  onClick={() => window.location.reload()} // You could also trigger fetchServices directly here
                  className="mt-4 px-4 py-2 bg-ehc-green text-white rounded-md hover:bg-[#1a6c72]"
                >
                  <Trans id="error.retry">Retry</Trans>
                </button>
              </div>
            </div>
          ) : servicePosts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">
                <Trans id="services.empty">
                  No services available at the moment.
                </Trans>
              </p>
            </div>
          ) : (
            <>
              {/* Services Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {servicePosts.map((service, index) => (
                  <div
                    key={index}
                    className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow duration-300 flex flex-col h-full"
                  >
                    {/* Service Image */}
                    <div className="h-48 bg-gray-100 flex items-center justify-center">
                      <img
                        src={`${settings.IMG_ADDRESS}${service.imageUrl}`}
                        alt={service.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = "none";
                          target.parentElement!.innerHTML = `<div class="w-full h-full bg-ehc-green/10 flex items-center justify-center"><div class="text-ehc-green text-3xl font-bold">${service.title.charAt(
                            0
                          )}</div></div>`;
                        }}
                      />
                    </div>

                    {/* Service Content */}
                    <div className="p-6 flex flex-col flex-grow">
                      <h3 className="text-xl font-bold text-gray-900 mb-3">
                        {service.title}
                      </h3>
                      <div className="flex-grow mb-4">
                        <p className="text-gray-600 text-sm leading-relaxed line-clamp-4">
                          {service.description}
                        </p>
                      </div>
                      <button
                        onClick={() => navigate("/Services")}
                        className="w-full bg-ehc-green text-white py-3 px-4 rounded-lg font-semibold hover:bg-ehc-green/90 transition-colors duration-200 mt-auto"
                      >
                        <Trans id="services.button.learnMore">Learn More</Trans>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination Controls */}
              {pagination.totalPages > 1 && (
                <div className="flex items-center justify-center space-x-4 mt-12">
                  <button
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={!pagination.hasPreviousPage}
                    className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                      !pagination.hasPreviousPage
                        ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                        : "bg-white text-ehc-green border border-ehc-green hover:bg-ehc-green hover:text-white"
                    }`}
                  >
                    <ChevronLeft className="w-4 h-4 mr-1" />
                    <Trans id="pagination.previous">Previous</Trans>
                  </button>

                  <div className="flex space-x-1">
                    {Array.from(
                      { length: pagination.totalPages },
                      (_, i) => i
                    ).map((page) => (
                      <button
                        key={page}
                        onClick={() => handlePageChange(page)}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                          currentPage === page
                            ? "bg-ehc-green text-white"
                            : "bg-white text-ehc-green border border-ehc-green hover:bg-ehc-green hover:text-white"
                        }`}
                      >
                        {page + 1}
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={!pagination.hasNextPage}
                    className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                      !pagination.hasNextPage
                        ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                        : "bg-white text-ehc-green border border-ehc-green hover:bg-ehc-green hover:text-white"
                    }`}
                  >
                    <Trans id="pagination.next">Next</Trans>
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </button>
                </div>
              )}
            </>
          )}
        </div>
        
        {/* Why Choose Us Section */}
        <div className="bg-gray-50 py-16">
          <div className="w-full max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-ehc-green mb-4">
                <Trans id="whyChooseUs.title">Why Choose Us?</Trans>
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {whyChooseUs.map((item, index) => (
                <div
                  key={index}
                  className="bg-white p-6 rounded-lg text-left border-2 border-ehc-green shadow-sm"
                >
                  <div className="flex items-start mb-4">
                    <div className="w-12 h-12 bg-ehc-green/10 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                      {React.cloneElement(item.icon, {
                        className: "w-6 h-6 text-ehc-green",
                      })}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 mb-2">
                        {item.title}
                      </h3>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Contact Button */}
            <div className="text-center">
              <button
                onClick={() => navigate("/faq#contact")}
                className="bg-ehc-green text-white px-8 py-3 rounded-full text-sm font-medium hover:bg-ehc-green/90 transition-colors duration-200"
              >
                <Trans id="whyChooseUs.contactButton">Contact Us</Trans>
              </button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Services;
