import Header from "../Layout/Header";
import Footer from "../Layout/Footer";
import { useState } from "react";
import { Check, Shield, Award, Building2 } from "lucide-react";
import { Trans } from "@lingui/macro";


interface PricingProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}




const Pricing = ({ onGetStarted, onSignIn }: PricingProps) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);



  return (
    <div className="min-h-screen ">
      <Header
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        onGetStarted={onGetStarted}
        onSignIn={onSignIn}
      />

      {/* Hero Section */}
      <section className="py-20 px-4 bg-[#f8f8fd]">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-[#263238] mb-4">
            <Trans id="pricing.hero.title">
              Choose Your<br />
              <span className="text-[#238d94]">Perfect Plan</span>
            </Trans>
          </h1>
          <p className="text-[#6b7280] text-lg mb-12 max-w-2xl mx-auto">
            <Trans id="pricing.hero.subtitle">
              Transform your recruitment process with our cutting-edge platform. From startups to enterprises, we have the perfect solution for your hiring needs.
            </Trans>
          </p>

          {/* Feature Badges */}
          <div className="flex flex-wrap justify-center gap-8 mb-16">
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-[#238d94]" />
              <span className="text-[#6b7280]">
                <Trans id="pricing.hero.feature1">Enterprise Security</Trans>
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Award className="w-5 h-5 text-[#238d94]" />
              <span className="text-[#6b7280]">
                <Trans id="pricing.hero.feature2">Award Winning</Trans>
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Building2 className="w-5 h-5 text-[#238d94]" />
              <span className="text-[#6b7280]">
                <Trans id="pricing.hero.feature3">10,000+ Companies</Trans>
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Packages */}
      <section className="px-4 mb-20">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-[#263238] mb-12">
            <Trans id="pricing.packages.title">
              Pricing <span className="text-[#238d94]">Packages</span>
            </Trans>
          </h2>

          <div className="grid md:grid-cols-3 gap-10">
            {/* Pack 6 */}
            <div className="bg-white shadow-lg rounded-lg flex flex-col h-full .package-card">
              <div className="text-center py-10">
                <h3 className="text-xl font-bold text-[#263238] mb-2">
                  <Trans id="pricing.pack6.title">
                    Recruitment Pack<br />(6 Listings)
                  </Trans>
                </h3>
              </div>
              <div className="px-8 pb-10">
                <h4 className="font-semibold text-[#263238] mb-4">
                  <Trans id="pricing.pack6.included">What's included</Trans>
                </h4>
                <ul className="space-y-3 mb-10">
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#238d94] mt-0.5 flex-shrink-0" />
                    <span className="text-[#6b7280] text-sm">
                      <Trans id="pricing.pack6.feature1">Broadcast 6 listings per day</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#238d94] mt-0.5 flex-shrink-0" />
                    <span className="text-[#6b7280] text-sm">
                      <Trans id="pricing.pack6.feature2">Posts on the news feed</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#238d94] mt-0.5 flex-shrink-0" />
                    <span className="text-[#6b7280] text-sm">
                      <Trans id="pricing.pack6.feature3">Share your job offers on Facebook</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#238d94] mt-0.5 flex-shrink-0" />
                    <span className="text-[#6b7280] text-sm">
                      <Trans id="pricing.pack6.feature4">Presence in weekly newsletter</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#238d94] mt-0.5 flex-shrink-0" />
                    <span className="text-[#6b7280] text-sm">
                      <Trans id="pricing.pack6.feature5">
                        Multi-distribution of your listings on sites Indeed, Google Jobs.
                      </Trans>
                    </span>
                  </li>
                </ul>
                <button
                  onClick={onGetStarted}
                  className="w-full bg-[#238d94] hover:bg-[#14b8a6] text-white py-2 px-4 rounded-md transition-colors duration-200"
                >
                  <Trans id="pricing.pack6.button">Get started</Trans>
                </button>
              </div>
            </div>

            {/* Pack 9 - Popular */}
           <div className="bg-[#238d94] shadow-lg relative z-10 rounded-lg flex flex-col h-full">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-[#facc15] to-[#f59e0b] text-[#713f12] text-sm px-4 py-1 shadow-lg border border-[#f59e0b]/20 font-semibold z-20 rounded-full">
                <Trans id="pricing.pack9.badge">⭐ Most Popular</Trans>
              </div>
              <div className="text-center py-10">
                <h3 className="text-xl font-bold text-white mb-2">
                  <Trans id="pricing.pack9.title">
                    Recruitment Pack<br />(9 Listings)
                  </Trans>
                </h3>
              </div>
              <div className="px-8 pb-10">
                <h4 className="font-semibold text-white mb-4">
                  <Trans id="pricing.pack9.included">What's included</Trans>
                </h4>
                <ul className="space-y-3 mb-10">
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#ccfbf1] mt-0.5 flex-shrink-0" />
                    <span className="text-[#ccfbf1] text-sm">
                      <Trans id="pricing.pack9.feature1">Broadcast 9 listings per day</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#ccfbf1] mt-0.5 flex-shrink-0" />
                    <span className="text-[#ccfbf1] text-sm">
                      <Trans id="pricing.pack9.feature2">Posts on the news feed</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#ccfbf1] mt-0.5 flex-shrink-0" />
                    <span className="text-[#ccfbf1] text-sm">
                      <Trans id="pricing.pack9.feature3">Presence in weekly newsletter</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#ccfbf1] mt-0.5 flex-shrink-0" />
                    <span className="text-[#ccfbf1] text-sm">
                      <Trans id="pricing.pack9.feature4">
                        Multi-distribution of your listings on sites Indeed, Google Jobs, Talent, Optioncarriere, Jooble…
                      </Trans>
                    </span>
                  </li>
                </ul>
                <button
                  onClick={onGetStarted}
                  className="w-full bg-white text-[#238d94] hover:bg-[#f9fafb] py-2 px-4 rounded-md transition-colors duration-200"
                >
                  <Trans id="pricing.pack9.button">Get started</Trans>
                </button>
              </div>
            </div>

            {/* Pack 12 */}
            <div className="bg-white shadow-lg rounded-lg flex flex-col h-full">
              <div className="text-center py-10">
                <h3 className="text-xl font-bold text-[#263238] mb-2">
                  <Trans id="pricing.pack12.title">
                    Recruitment Pack<br />(12 Listings)
                  </Trans>
                </h3>
              </div>
              <div className="px-8 pb-10">
                <h4 className="font-semibold text-[#263238] mb-4">
                  <Trans id="pricing.pack12.included">What's included</Trans>
                </h4>
                <ul className="space-y-3 mb-10">
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#238d94] mt-0.5 flex-shrink-0" />
                    <span className="text-[#6b7280] text-sm">
                      <Trans id="pricing.pack12.feature1">Broadcast 12 listings per day</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#238d94] mt-0.5 flex-shrink-0" />
                    <span className="text-[#6b7280] text-sm">
                      <Trans id="pricing.pack12.feature2">Posts on the news feed</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#238d94] mt-0.5 flex-shrink-0" />
                    <span className="text-[#6b7280] text-sm">
                      <Trans id="pricing.pack12.feature3">Presence in weekly newsletter</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#238d94] mt-0.5 flex-shrink-0" />
                    <span className="text-[#6b7280] text-sm">
                      <Trans id="pricing.pack12.feature4">Share your job offers on Facebook</Trans>
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-[#238d94] mt-0.5 flex-shrink-0" />
                    <span className="text-[#6b7280] text-sm">
                      <Trans id="pricing.pack12.feature5">
                        Multi-distribution of your listings on sites Indeed, Google Jobs.
                      </Trans>
                    </span>
                  </li>
                </ul>
                <button
                  onClick={onGetStarted}
                  className="w-full bg-[#238d94] hover:bg-[#14b8a6] text-white py-2 px-4 rounded-md transition-colors duration-200"
                >
                  <Trans id="pricing.pack12.button">Get started</Trans>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Comparison Table */}
      <section className="px-4 mb-12 bg-[#e9f3f3] md:mb-20">
  <div className="max-w-7xl mx-auto">
    {/* Version Mobile */}
    <div className="block md:hidden">
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="bg-[#238d94] text-white text-center py-6">
          <h3 className="text-xl font-bold">
            <Trans id="pricing.comparison.title">Complete Feature Comparison</Trans>
          </h3>
          <p className="text-[#ccfbf1] text-sm mt-2">
            <Trans id="pricing.comparison.subtitle">
              Compare all features across our recruitment plans
            </Trans>
          </p>
        </div>
        
        <div className="p-4">
          {/* Feature 1 */}
          <div className="border-b border-[#e5e7eb] py-4">
            <h4 className="font-medium text-[#1f2937] text-sm mb-3">
              <Trans id="pricing.comparison.feature1">Listings broadcast per day</Trans>
            </h4>
            <div className="grid grid-cols-3 gap-2">
              <div className="text-center">
                <div className="font-medium text-xs text-[#1f2937] mb-1">
                  <Trans id="pricing.pack6.short">Pack 6</Trans>
                </div>
                <div className="text-[#1f2937] font-bold text-lg">6</div>
              </div>
              <div className="text-center bg-gradient-to-b from-[#238d94] to-[#50bcc4] text-white rounded py-2 relative">
                <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-[#facc15] to-[#f59e0b] text-[#713f12] text-xs px-2 py-0.5 font-semibold rounded-full">
                  ⭐
                </div>
                <div className="font-medium text-xs mb-1">
                  <Trans id="pricing.pack9.short">Pack 9</Trans>
                </div>
                <div className="font-bold text-lg">9</div>
              </div>
              <div className="text-center">
                <div className="font-medium text-xs text-[#1f2937] mb-1">
                  <Trans id="pricing.pack12.short">Pack 12</Trans>
                </div>
                <div className="text-[#1f2937] font-bold text-lg">12</div>
              </div>
            </div>
          </div>
          
          {/* Feature 2 */}
          <div className="border-b border-[#e5e7eb] py-4">
            <h4 className="font-medium text-[#1f2937] text-sm mb-3">
              <Trans id="pricing.comparison.feature2">Post on the news feed</Trans>
            </h4>
            <div className="grid grid-cols-3 gap-2">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-center bg-[#f0f9f9] rounded py-2">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
            </div>
          </div>
          
          {/* Feature 3 */}
          <div className="border-b border-[#e5e7eb] py-4">
            <h4 className="font-medium text-[#1f2937] text-sm mb-3">
              <Trans id="pricing.comparison.feature3">Presence in weekly newsletter</Trans>
            </h4>
            <div className="grid grid-cols-3 gap-2">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-center bg-[#f0f9f9] rounded py-2">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
            </div>
          </div>
          
          {/* Feature 4 */}
          <div className="border-b border-[#e5e7eb] py-4">
            <h4 className="font-medium text-[#1f2937] text-sm mb-3">
              <Trans id="pricing.comparison.feature4">Share on Facebook</Trans>
            </h4>
            <div className="grid grid-cols-3 gap-2">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-center bg-[#f0f9f9] rounded py-2">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
            </div>
          </div>
          
          {/* Feature 5 */}
          <div className="py-4">
            <h4 className="font-medium text-[#1f2937] text-sm mb-3">
              <Trans id="pricing.comparison.feature5">
                Multi-distribution (Indeed, Google Jobs, etc.)
              </Trans>
            </h4>
            <div className="grid grid-cols-3 gap-2">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-center bg-[#f0f9f9] rounded py-2">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5] mx-auto">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <div className="hidden md:block">
      <div className="bg-white shadow-lg rounded-lg min-h-[500px] relative pt-8">
        <div className="bg-[#238d94] text-white text-center py-8 rounded-t-lg">
          <h3 className="text-2xl font-bold">
            <Trans id="pricing.comparison.desktop.title">Complete Feature Comparison</Trans>
          </h3>
          <p className="text-[#ccfbf1] mb-6">
            <Trans id="pricing.comparison.desktop.subtitle">
              Compare all features across our recruitment plans
            </Trans>
          </p>
        </div>
        <div className="pt-12 px-0 pb-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#e5e7eb]">
                  <th className="text-left p-6 font-medium text-[#1f2937]">
                    <Trans id="pricing.comparison.table.heading.features">Plan Features</Trans>
                  </th>
                  <th className="text-center p-6 font-medium text-[#1f2937]">
                    <Trans id="pricing.comparison.table.heading.pack6">Pack 6 listings</Trans>
                  </th>
                  <th className="text-center  z-10 p-6 bg-gradient-to-r from-[#238d94] to-[#50bcc4] text-white  shadow-lg">
                    <div className="absolute  transform -translate-x-1/2 bg-gradient-to-r from-[#facc15] to-[#f59e0b] text-[#713f12] text-sm px-4 py-1 shadow-lg border border-[#f59e0b]/20 font-semibold z-20 rounded-full"
                      style={{
                        right: '21%',
                        left: '70%',
                        top: '29%'
                      }}>
                        <Trans id="pricing.comparison.table.heading.popular">⭐ Popular</Trans>
                    </div>
                    <div className="pt-6">
                      <Trans id="pricing.comparison.table.heading.pack9">Pack 9 listings</Trans>
                    </div>
                  </th>
                  <th className="text-center p-6 font-medium text-[#1f2937]">
                    <Trans id="pricing.comparison.table.heading.pack12">Pack 12 listings</Trans>
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-[#e5e7eb]">
                  <td className="p-6 text-[#1f2937]">
                    <Trans id="pricing.comparison.table.row1">Listings broadcast per day</Trans>
                  </td>
                  <td className="text-center p-6 text-[#1f2937]">6</td>
                  <td className="text-center p-6 bg-gradient-to-b text-[#1f2937] shadow-inner">
                    9
                  </td>
                  <td className="text-center p-6 text-[#1f2937]">12</td>
                </tr>
                <tr className="border-b border-[#e5e7eb]">
                  <td className="p-6 text-[#1f2937]">
                    <Trans id="pricing.comparison.table.row2">Post on the news feed</Trans>
                  </td>
                  <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                 <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                  <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                </tr>
                <tr className="border-b border-[#e5e7eb]">
                  <td className="p-6 text-[#1f2937]">
                    <Trans id="pricing.comparison.table.row3">Presence in weekly newsletter</Trans>
                  </td>
                  <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                  <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                  <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                </tr>
                <tr className="border-b border-[#e5e7eb]">
                  <td className="p-6 text-[#1f2937]">
                    <Trans id="pricing.comparison.table.row4">Share on Facebook</Trans>
                  </td>
                  <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                 <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                  <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                </tr>
                <tr>
                  <td className="p-6 text-[#1f2937]">
                    <Trans id="pricing.comparison.table.row5">
                      Multi-distribution (Indeed, Google Jobs, etc.)
                    </Trans>
                  </td>
                  <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                  <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                  <td className="text-center p-6">
                   <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#39bcc5]">
                       <Check className="w-5 h-5 text-white" />
                   </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

      <Footer />
    </div>
  );
};

export default Pricing;
