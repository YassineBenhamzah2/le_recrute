import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
} from "@/components/ui/pagination";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Company } from "@/lib/types/company";
import JobItem from "./JobItemSection";
import { Trans, t } from '@lingui/macro';

interface EmploymentType {
  id: string;
  label: string;
}

interface ContractType {
  id: string;
  label: string;
}

interface Tag {
  id: string;
  label: string;
}

interface JobListSectionProps {
  companies: Company[];
  employmentTypes: EmploymentType[];
  contractTypes: ContractType[];
  tags: Tag[];
  selectedEmploymentTypes: string[];
  handleEmploymentTypeChange: (typeId: string) => void;
  selectedContractTypes: string[];
  handleContractTypeChange: (typeId: string) => void;
  selectedTags: string[];
  handleTagClick: (tagId: string) => void;
  currentPage: number;
  handlePageChange: (page: number) => void;
  totalPages: number;
  itemsPerPage: number;
  setItemsPerPage: (value: number) => void;
  sortBy: string;
  setSortBy: (value: string) => void;
  loading: boolean;
  error: string | null;
}

export const JobListSection = ({
  companies,
  employmentTypes,
  contractTypes,
  tags,
  selectedEmploymentTypes,
  handleEmploymentTypeChange,
  selectedContractTypes,
  handleContractTypeChange,
  selectedTags,
  handleTagClick,
  currentPage,
  handlePageChange,
  totalPages,
  itemsPerPage,
  setItemsPerPage,
  sortBy,
  setSortBy,
  loading,
  error,
}: JobListSectionProps): JSX.Element => {
  // Calculate pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;

  return (
    <div className="flex flex-col w-full items-start pb-16 ">
      <div className="flex w-full gap-6">
        {/* Left sidebar with filters */}
        <div className="flex flex-col w-full md:w-1/3 lg:w-1/4">
          <Card className="bg-[#fcfcfc] rounded-[10px]">
            <CardContent className="flex flex-col gap-[30px] p-[30px]">
              {/* Employment type checkboxes */}
              <div className="flex flex-col gap-6 pt-1.5">
                <div className="font-bold text-[#17171d] text-lg leading-[21.6px] font-['Rubik',Helvetica]">
                  <Trans id="jobList.employmentType">Type of employment</Trans>
                </div>
                <div className="flex flex-col gap-5">
                  {employmentTypes.map((type) => (
                    <div key={type.id} className="flex items-center gap-2">
                      <Checkbox
                        id={type.id}
                        className="w-4 h-4 rounded-lg border-[#00000040]"
                        checked={selectedEmploymentTypes.includes(type.id)}
                        onCheckedChange={() =>
                          handleEmploymentTypeChange(type.id)
                        }
                      />
                      <label
                        htmlFor={type.id}
                        className="font-normal text-[#666666] text-base leading-[27.2px] font-['Rubik',Helvetica]"
                      >
                        {type.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              {/* Contract type checkboxes */}
              <div className="flex flex-col gap-6 pt-1.5">
                <div className="font-bold text-[#17171d] text-lg leading-[21.6px] font-['Rubik',Helvetica]">
                  <Trans id="jobList.contractType">Type of Contrat</Trans>
                </div>
                <div className="flex flex-col gap-5">
                  {contractTypes.map((type) => (
                    <div key={type.id} className="flex items-center gap-2">
                      <Checkbox
                        id={type.id}
                        className="w-4 h-4 rounded-lg border-[#00000040]"
                        checked={selectedContractTypes.includes(type.id)}
                        onCheckedChange={() =>
                          handleContractTypeChange(type.id)
                        }
                      />
                      <label
                        htmlFor={type.id}
                        className="font-normal text-[#666666] text-base leading-[27.2px] font-['Rubik',Helvetica]"
                      >
                        {type.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              {/* Tags section */}
              <div className="flex flex-col gap-3.5">
                <div className="h-[26.39px] border-l-[3px] border-[#238d94] pl-[13px]">
                  <h3 className="font-bold text-[#17171d] text-[22px] leading-[26.4px] font-['Rubik',Helvetica]">
                    <Trans id="jobList.tags">Tags</Trans>
                  </h3>
                </div>
                <div className="flex flex-wrap gap-2.5">
                  {tags.map((tag) => (
                    <Badge
                      key={tag.id}
                      className={`${
                        selectedTags.includes(tag.id)
                          ? "bg-[#238d94] text-white"
                          : "bg-[#f0f6fe] text-[#238d94]"
                      } hover:bg-[#238d94] hover:text-white rounded-[10px] px-[15px] py-[5px] text-sm font-normal font-['Rubik',Helvetica] cursor-pointer`}
                      onClick={() => handleTagClick(tag.id)}
                    >
                      {tag.label}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right content area with job listings */}
        <div className="flex flex-col w-full md:w-2/3 lg:w-3/4 gap-[30px]">
          {/* Results header */}
          <div className="flex flex-col md:flex-row items-center justify-between pb-[30px]">
            <div className="font-bold text-[#3c3c3c] text-base leading-[27.2px] font-['Rubik',Helvetica]">
              Showing {indexOfFirstItem + 1}-
              {Math.min(indexOfLastItem, companies.length)} of{" "}
              {companies.length} Result
            </div>
            <div className="flex items-center gap-5 mt-4 md:mt-0">
              <span className="font-bold text-[#3c3c3c] text-base leading-[27.2px] font-['Rubik',Helvetica]">
                <Trans id="jobList.sortBy">Short By</Trans>
              </span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40 h-[50px] bg-[#f0f6fe] rounded-[10px] border-0">
                  <SelectValue
                    placeholder={t({ id: 'jobList.mostRecent', message: 'Most Recent' })}
                    className="text-[#6c757d] text-sm font-['Rubik',Helvetica]"
                  />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">
                    {t({ id: 'jobList.mostRecent', message: 'Most Recent' })}
                  </SelectItem>
                  <SelectItem value="nameAsc">
                    {t({ id: 'jobList.nameAsc', message: 'Name (A-Z)' })}
                  </SelectItem>
                  <SelectItem value="nameDesc">
                    {t({ id: 'jobList.nameDesc', message: 'Name (Z-A)' })}
                  </SelectItem>
                  <SelectItem value="vacanciesDesc">
                    {t({ id: 'jobList.mostVacancies', message: 'Most Vacancies' })}
                  </SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={itemsPerPage.toString()}
                onValueChange={(value) => setItemsPerPage(Number(value))}
              >
                <SelectTrigger className="w-40 h-[50px] bg-[#f0f6fe] rounded-[10px] border-0">
                  <SelectValue
                    placeholder={t({ id: 'jobList.show10', message: 'Show 10' })}
                    className="text-[#6c757d] text-sm font-['Rubik',Helvetica]"
                  />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">
                    {t({ id: 'jobList.show5', message: 'Show 5' })}
                  </SelectItem>
                  <SelectItem value="10">
                    {t({ id: 'jobList.show10', message: 'Show 10' })}
                  </SelectItem>
                  <SelectItem value="20">
                    {t({ id: 'jobList.show20', message: 'Show 20' })}
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {loading && (
            <div className="flex justify-center items-center py-10">
              <div className="text-lg">
                <Trans id="jobList.loading">Loading companies...</Trans>
              </div>
            </div>
          )}

          {error && (
            <div className="flex justify-center items-center py-10">
              <div className="text-lg text-red-500">{error}</div>
            </div>
          )}
          {!error && !loading && (
            <div className="flex flex-col gap-12">
              {companies
                .slice(indexOfFirstItem, indexOfLastItem)
                .map((company) => (
                  <JobItem key={company.id} company={company} />
                ))}
            </div>
          )}

          {/* Pagination */}
          <Pagination className="pt-12 flex justify-center">
            <PaginationContent className="flex justify-center gap-2">
              {/* Previous Button */}
              <PaginationItem>
                <PaginationLink
                  href="#"
                  className="w-[40px] h-[40px] flex items-center justify-center rounded-[5px] border border-[#eaeaea] hover:bg-[#f5f5f5]"
                  onClick={(e) => {
                    e.preventDefault();
                    if (currentPage > 1) handlePageChange(currentPage - 1);
                  }}
                  tabIndex={currentPage === 1 ? -1 : 0}
                  aria-disabled={currentPage === 1}
                >
                  <span className="sr-only">Previous page</span>
                  <svg
                    width="8"
                    height="12"
                    viewBox="0 0 8 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M7.41 10.59L2.83 6L7.41 1.41L6 0L0 6L6 12L7.41 10.59Z"
                      fill={currentPage === 1 ? "#D1D1D1" : "#333333"}
                    />
                  </svg>
                </PaginationLink>
              </PaginationItem>

              {/* Page Numbers with Ellipsis */}
              {(() => {
                // Logic for showing specific page numbers with ellipsis
                const pageNumbers = [];

                // Always show first page
                if (totalPages > 0) {
                  pageNumbers.push(
                    <PaginationItem key={1}>
                      <PaginationLink
                        href="#"
                        className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium font-['Rubik',Helvetica] ${
                          currentPage === 1
                            ? "bg-[#238d94] text-white"
                            : "border border-[#eaeaea] hover:bg-[#f5f5f5]"
                        }`}
                        onClick={(e) => {
                          e.preventDefault();
                          handlePageChange(1);
                        }}
                      >
                        1
                      </PaginationLink>
                    </PaginationItem>
                  );
                }

                // Add ellipsis if needed
                if (currentPage > 3) {
                  pageNumbers.push(
                    <PaginationItem key="ellipsis1">
                      <PaginationEllipsis className="w-[40px] h-[40px] flex items-center justify-center" />
                    </PaginationItem>
                  );
                }

                // Add pages around current page
                for (
                  let i = Math.max(2, currentPage - 1);
                  i <= Math.min(totalPages - 1, currentPage + 1);
                  i++
                ) {
                  if (i <= 1 || i >= totalPages) continue; // Skip first and last page as they're handled separately

                  pageNumbers.push(
                    <PaginationItem key={i}>
                      <PaginationLink
                        href="#"
                        className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium font-['Rubik',Helvetica] ${
                          currentPage === i
                            ? "bg-[#238d94] text-white"
                            : "border border-[#eaeaea] hover:bg-[#f5f5f5]"
                        }`}
                        onClick={(e) => {
                          e.preventDefault();
                          handlePageChange(i);
                        }}
                      >
                        {i}
                      </PaginationLink>
                    </PaginationItem>
                  );
                }

                // Add ellipsis if needed
                if (currentPage < totalPages - 2) {
                  pageNumbers.push(
                    <PaginationItem key="ellipsis2">
                      <PaginationEllipsis className="w-[40px] h-[40px] flex items-center justify-center" />
                    </PaginationItem>
                  );
                }

                // Always show last page if there's more than one page
                if (totalPages > 1) {
                  pageNumbers.push(
                    <PaginationItem key={totalPages}>
                      <PaginationLink
                        href="#"
                        className={`w-[40px] h-[40px] flex items-center justify-center rounded-[5px] font-medium font-['Rubik',Helvetica] ${
                          currentPage === totalPages
                            ? "bg-[#238d94] text-white"
                            : "border border-[#eaeaea] hover:bg-[#f5f5f5]"
                        }`}
                        onClick={(e) => {
                          e.preventDefault();
                          handlePageChange(totalPages);
                        }}
                      >
                        {totalPages}
                      </PaginationLink>
                    </PaginationItem>
                  );
                }

                return pageNumbers;
              })()}

              {/* Next Button */}
              <PaginationItem>
                <PaginationLink
                  href="#"
                  className="w-[40px] h-[40px] flex items-center justify-center rounded-[5px] border border-[#eaeaea] hover:bg-[#f5f5f5]"
                  onClick={(e) => {
                    e.preventDefault();
                    if (currentPage < totalPages)
                      handlePageChange(currentPage + 1);
                  }}
                  tabIndex={currentPage === totalPages ? -1 : 0}
                  aria-disabled={currentPage === totalPages}
                >
                  <span className="sr-only">Next page</span>
                  <svg
                    width="8"
                    height="12"
                    viewBox="0 0 8 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M0.59 1.41L5.17 6L0.59 10.59L2 12L8 6L2 0L0.59 1.41Z"
                      fill={currentPage === totalPages ? "#D1D1D1" : "#333333"}
                    />
                  </svg>
                </PaginationLink>
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      </div>
    </div>
  );
};
