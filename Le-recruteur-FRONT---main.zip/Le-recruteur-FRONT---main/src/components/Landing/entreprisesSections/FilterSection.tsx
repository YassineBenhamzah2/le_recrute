/* eslint-disable @typescript-eslint/no-explicit-any */
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { BriefcaseIcon, MapPinIcon, SearchIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { GetCountries, GetState } from "react-country-state-city";
import { Country, State } from "react-country-state-city/dist/esm/types";
import { Trans, t } from '@lingui/macro';

interface FilterSectionProps {
  searchKeyword: string;
  setSearchKeyword: (value: string) => void;
  searchLocation: string;
  setSearchLocation: (value: string) => void;
  selectedSector: string;
  setSelectedSector: (value: string) => void;
  onSearch?: () => void;
  onResetFilters?: () => void;
  sectors: { id: string; name: string }[];
  loadingSectors: boolean;
}

export const FilterSection = ({
  searchKeyword,
  setSearchKeyword,
  setSearchLocation,
  selectedSector,
  setSelectedSector,
  onResetFilters,
  sectors,
  loadingSectors,
}: FilterSectionProps): JSX.Element => {
  const [countries, setCountries] = useState<Country[]>([]);
  const [states, setStates] = useState<State[]>([]);
  const [country, setCountry] = useState<Country | null>(null);
  const [state, setState] = useState<State | null>(null);

  useEffect(() => {
    GetCountries().then(setCountries);
  }, []);

  useEffect(() => {
    if (country) {
      GetState(country.id).then(setStates);
    } else {
      setStates([]);
      setState(null);
    }
  }, [country]);

  // Handle location change
  const handleLocationChange = (countryVal: any, stateVal: any = null) => {
    let locationString = "";
    if (countryVal) {
      // locationString = countryVal.name;
      if (stateVal) {
        locationString += `${stateVal.name}`;
      }
    }
    console.log("Location changed:", locationString);
    setSearchLocation(locationString);
  };

  // Handle reset filters
  const handleResetFilters = () => {
    setCountry(null);
    setState(null);
    if (onResetFilters) {
      onResetFilters();
    }
  };

  // Using sectors from props that were fetched from the API

  return (
    <div className="w-full py-16 px-6">
      <Card className="w-full rounded-2xl shadow-[0px_4px_10px_#238d9426] p-5">
        <div className="flex flex-wrap gap-4 items-center">
          {/* Job Position Filter */}
          <div className="flex-1 min-w-[250px]">
            <div className="font-bold text-2xl text-[#182230cc] mb-2">
              <Trans id="filter.companyName">Company Name</Trans>
            </div>
            <div className="flex items-center gap-2">
              <SearchIcon className="w-6 h-6 text-[#0000000]" />
              <div className="w-full">
                <Input
                  className="border-0 border-b border-[#00000040] rounded-none px-0 text-xl font-medium text-[#00000040] focus-visible:ring-0 focus-visible:border-[#00000040] h-10 placeholder:text-[#00000040]"
                  placeholder={t({
                    id: "filter.searchPlaceholder",
                    message: "Search for companies..."
                  })}
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                />
              </div>
            </div>
          </div>

          <Separator
            orientation="vertical"
            className="h-[88px] bg-[#00000040]"
          />

          {/* Industry Sector Filter */}
          <div className="flex-1 min-w-[250px]">
            <div className="font-medium text-2xl text-[#182230cc] mb-2">
              <Trans id="filter.sector">Secteur d'activité :</Trans>
            </div>
            <div className="flex items-center gap-2">
              <BriefcaseIcon className="w-6 h-6 text-[#0000000]" />
              <div className="w-full">
                <Select
                  value={selectedSector}
                  onValueChange={setSelectedSector}
                >
                  <SelectTrigger className="border-0 border-b border-[#00000040] rounded-none px-0 text-xl font-medium text-[#00000040] focus:ring-0 h-10">
                    <SelectValue placeholder={t({
                      id: "filter.selectSector",
                      message: "Select sector"
                    })} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem key="all" value="all">
                      {t({ id: "filter.allSectors", message: "All Sectors" })}
                    </SelectItem>
                    {loadingSectors ? (
                      <SelectItem value="loading">
                        {t({ id: "filter.loadingSectors", message: "Loading sectors..." })}
                      </SelectItem>
                    ) : (
                      sectors.map((sector) => (
                        <SelectItem key={sector.id} value={sector.id}>
                          {sector.name}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <Separator
            orientation="vertical"
            className="h-[88px] bg-[#00000040]"
          />

          {/* Location Filter */}
          <div className="flex-1 min-w-[300px]">
            <div className="font-medium text-2xl text-[#182230cc] mb-2">
              <Trans id="filter.location">Location :</Trans>
            </div>
            <div className="flex items-center gap-2">
              <MapPinIcon className="w-7 h-7 text-[#0000000]" />
              <div className="w-full flex gap-2">
                {/* Country Select */}
                <Select
                  value={country?.id?.toString()}
                  onValueChange={(id) => {
                    if (id === "all") {
                      setCountry(null);
                      setState(null);
                    } else {
                      const selected = countries.find(
                        (c) => c.id.toString() === id
                      );
                      setCountry(selected!);
                      setState(null);
                      handleLocationChange(selected!, null);
                    }
                  }}
                >
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder={t({
                      id: "filter.country",
                      message: "Country"
                    })} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem key="all" value="all">
                      {t({ id: "filter.allCountries", message: "All Countries" })}
                    </SelectItem>
                    {countries.map((c) => (
                      <SelectItem key={c.id} value={c.id.toString()}>
                        <img
                          alt={c.name}
                          src={`http://purecatamphetamine.github.io/country-flag-icons/3x2/${c.iso2}.svg`}
                          className="w-6 h-4 inline-block mr-2"
                        />
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* State Select */}
                <Select
                  disabled={!country}
                  value={state?.id?.toString()}
                  onValueChange={(id) => {
                    const selected = states.find((s) => s.id.toString() === id);
                    setState(selected!);
                    handleLocationChange(country, selected);
                  }}
                >
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder={t({
                      id: "filter.state",
                      message: "State"
                    })} />
                  </SelectTrigger>
                  <SelectContent>
                    {states.map((s) => (
                      <SelectItem key={s.id} value={s.id.toString()}>
                        {s.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Reset Filters Button */}
          <Button
            variant="outline"
            className="border-[#25324b] text-[#25324b] hover:bg-[#25324b] hover:text-white font-semibold text-[20px] px-8 py-7 h-auto rounded-xl"
            onClick={handleResetFilters}
          >
            {t({ id: "filter.reset", message: "Reset Filters" })}
          </Button>
        </div>
      </Card>

      {/* Popular searches */}
      <div className="mt-4 ml-12 opacity-70 font-normal text-sm">
        <span className="text-[#182230]">
          <Trans id="filter.popular">Popular :</Trans>
        </span>
        <span className="font-medium text-[#182230]">
          {t({
            id: "filter.popularExamples",
            message: "UI Designer, UX Researcher, Front-End Developer"
          })}
        </span>
      </div>
    </div>
  );
};
