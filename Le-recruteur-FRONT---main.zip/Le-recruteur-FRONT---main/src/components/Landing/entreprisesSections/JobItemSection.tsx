import { Card, CardContent } from "@/components/ui/card";
import { settings } from "@/lib/settings/main";
import { Company } from "@/lib/types/company";
import { useNavigate } from "react-router";
import { Trans } from '@lingui/macro';

interface JobItemProps {
  company: Company;
}

const JobItem = ({ company }: JobItemProps) => {
  const router = useNavigate();
  const handleClick = () => {
    router(`/entreprises/${company.id}`);
  };
  return (
    <Card
      key={company.id}
      className="flex items-center justify-between p-0 bg-white rounded-[10px] border border-[#efefef] relative cursor-pointer"
      onClick={handleClick}
    >
      <CardContent className="flex items-center w-full p-0">
        {/* Company logo */}
        <div className="w-[150px] h-[150px] bg-white rounded-[10px] shadow-[0px_0px_40px_#3898e24c] flex items-center justify-center absolute top-4 left-[21px]">
          <div
            className="w-[125px] h-[125px] rounded-[10px] bg-cover bg-center"
            style={{
              backgroundImage: `url(${settings.IMG_ADDRESS}${company.logo})`,
            }}
          />
        </div>

        {/* Company details */}
        <div className="flex flex-col gap-2 pl-[180px] py-[25px] flex-grow">
          <h3 className="font-bold text-[#17171d] text-lg leading-[21.6px] font-['Rubik',Helvetica]">
            {company.name}
          </h3>
          <p className="font-normal text-[#3c3c3c] text-sm leading-[23.8px] font-['Rubik',Helvetica]">
            {company.address}
          </p>
          <span className="font-normal text-[#238d94] text-[15px] leading-[25.5px] pt-[7px] font-['Rubik',Helvetica]">
            {company.sector}
          </span>
        </div>

        {/* Vacancies count */}
        <div className="w-[100px] flex flex-col items-center py-5 pr-[21px]">
          <span className="font-semibold text-[#00aa18] text-lg leading-[30.6px] text-center font-['Rubik',Helvetica]">
            {company.numEmployees}
          </span>
          <span className="font-medium text-[#17171d] text-sm leading-[23.8px] text-center font-['Rubik',Helvetica]">
            <Trans id="job.employees">Employees</Trans>
          </span>
        </div>
      </CardContent>
    </Card>
  );
};

export default JobItem;
