import { Trans } from '@lingui/macro';

export const HeroSection = (): JSX.Element => {
    return (
        <section className="w-full bg-[#E6F4F1]  relative h-[400px] flex flex-col">
            <div className="container mx-auto px-4 relative flex-1 flex flex-col">

                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between flex-1 w-full gap-8">
                    <div className="max-w-4xl flex flex-col justify-center">
                        <div className="mb-6">
                            <h1 className="font-['Bai_Jamjuree',Helvetica] font-black text-ehc-green-light text-4xl md:text-5xl mb-2">
                                <Trans id="hero.title">Companies</Trans>
                            </h1>
                            <div className="w-20 h-1 bg-[#238d94]" />
                        </div>

                        <p className="font-['Bai_Jamjuree',Helvetica]  text-[#00000053] text-3xl leading-[44px]">
                            <Trans id="hero.subtitle">Find your desire company and get your dream job</Trans>
                        </p>
                    </div>

                    <div className="hidden md:block self-center">
                        <div
                            className="w-[438px] h-[400px] rounded-lg bg-cover bg-center shadow-lg"
                            style={{ backgroundImage: "url(EntrepriseHero.png)" }}
                        />
                    </div>
                </div>
            </div>
        </section>
    );
};
