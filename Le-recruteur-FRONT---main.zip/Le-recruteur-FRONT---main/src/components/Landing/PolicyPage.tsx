import React from 'react';
import { Trans, t } from '@lingui/macro';

const PolicyPage: React.FC = () => {
  return (
    <div className="min-h-screen" style={{ backgroundColor: '#E2E8F0' }}>
      {/* Hero Section */}
      <div className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-card rounded-lg shadow-sm border p-8 text-center">
            <h1
              className="text-4xl font-bold mb-4 font-poppins"
              style={{
                background: 'linear-gradient(135deg, #238D94, #1E293B)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
            >
              <Trans id="policy.title">Privacy Policy</Trans>
            </h1>
            <p className="text-muted-foreground text-lg">
              {t({ id: 'policy.last_updated', message: 'Last updated: 11/06/2025' })}
            </p>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-card rounded-lg shadow-sm border p-8">

          {/* Section 1: Introduction */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <div className="w-1 h-8 bg-chart-2 mr-4 rounded-full"></div>
              <h2 className="text-2xl font-semibold text-foreground font-poppins">
                <Trans id="policy.section1_title">1. Introduction</Trans>
              </h2>
            </div>
            <p className="text-muted-foreground leading-relaxed text-base">
              <Trans id="policy.section1_text">
                This Privacy Policy explains how EHC collects, uses, and protects personal information of users on its website. By accessing our site, you agree to the practices described in this policy.
              </Trans>
            </p>
          </div>

          {/* Section 2: Data Collected */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <div className="w-1 h-8 bg-chart-2 mr-4 rounded-full"></div>
              <h2 className="text-2xl font-semibold text-foreground font-poppins">
                <Trans id="policy.section2_title">2. Data Collected</Trans>
              </h2>
            </div>
            <div className="space-y-4">
              <p className="text-muted-foreground mb-2 leading-relaxed">
                <span className="font-medium text-foreground">
                  <Trans id="policy.section2_user_info">• Information provided by the user:</Trans>
                </span>
                {t({ id: 'policy.section2_user_info_text', message: 'first name, last name, email address, phone number, professional information (if applicable).' })}
              </p>
              <p className="text-muted-foreground leading-relaxed">
                <span className="font-medium text-foreground">
                  <Trans id="policy.section2_auto_data">• Automatically collected data:</Trans>
                </span>
                {t({ id: 'policy.section2_auto_data_text', message: 'IP address, browser type, visited pages, cookies, and similar technologies.' })}
              </p>
            </div>
          </div>

          {/* Section 3: Purpose of Data Collection */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <div className="w-1 h-8 bg-chart-2 mr-4 rounded-full"></div>
              <h2 className="text-2xl font-semibold text-foreground font-poppins">
                <Trans id="policy.section3_title">3. Purpose of Data Collection</Trans>
              </h2>
            </div>
            <div className="space-y-3">
              <p className="text-muted-foreground leading-relaxed">
                <Trans id="policy.section3_point1">• Manage user accounts and requested services.</Trans>
              </p>
              <p className="text-muted-foreground leading-relaxed">
                <Trans id="policy.section3_point2">• Ensure effective customer service and personalized communication.</Trans>
              </p>
              <p className="text-muted-foreground leading-relaxed">
                <Trans id="policy.section3_point3">• Improve user experience and analyze site performance.</Trans>
              </p>
              <p className="text-muted-foreground leading-relaxed">
                <Trans id="policy.section3_point4">• Comply with legal and regulatory obligations.</Trans>
              </p>
            </div>
          </div>

          {/* Section 4: Data Sharing */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <div className="w-1 h-8 bg-chart-2 mr-4 rounded-full"></div>
              <h2 className="text-2xl font-semibold text-foreground font-poppins">
                <Trans id="policy.section4_title">4. Data Sharing</Trans>
              </h2>
            </div>
            <div className="space-y-3">
              <p className="text-muted-foreground leading-relaxed">
                <Trans id="policy.section4_point1">• Our service providers (payment, hosting, technical maintenance).</Trans>
              </p>
              <p className="text-muted-foreground leading-relaxed">
                <Trans id="policy.section4_point2">• Competent authorities if required by law.</Trans>
              </p>
            </div>
          </div>

          {/* Section 5: Data Storage and Security */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <div className="w-1 h-8 bg-chart-2 mr-4 rounded-full"></div>
              <h2 className="text-2xl font-semibold text-foreground font-poppins">
                <Trans id="policy.section5_title">5. Data Storage and Security</Trans>
              </h2>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              <Trans id="policy.section5_text">
                We implement technical and organizational security measures to protect your data against unauthorized access, loss, or alteration.
              </Trans>
            </p>
          </div>

          {/* Section 6: User Rights */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <div className="w-1 h-8 bg-chart-2 mr-4 rounded-full"></div>
              <h2 className="text-2xl font-semibold text-foreground font-poppins">
                <Trans id="policy.section6_title">6. User Rights</Trans>
              </h2>
            </div>
            <div className="space-y-3">
              <p className="text-muted-foreground leading-relaxed">
                <Trans id="policy.section6_access">
                  • <span className="font-medium text-foreground">Access and rectification:</span> view and modify your information.
                </Trans>
              </p>
              <p className="text-muted-foreground leading-relaxed">
                <Trans id="policy.section6_deletion">
                  • <span className="font-medium text-foreground">Deletion:</span> request the deletion of your personal data.
                </Trans>
              </p>
              <p className="text-muted-foreground leading-relaxed">
                <Trans id="policy.section6_objection">
                  • <span className="font-medium text-foreground">Objection:</span> refuse the use of your data for marketing purposes.
                </Trans>
              </p>
              <p className="text-muted-foreground leading-relaxed">
                <Trans id="policy.section6_portability">
                  • <span className="font-medium text-foreground">Portability:</span> retrieve your data in a usable format.
                </Trans>
              </p>
            </div>
            <p className="text-muted-foreground mt-4 leading-relaxed">
              <Trans id="policy.section6_contact">
                You can exercise these rights by contacting us at{' '}
                <a
                  href="mailto:contact@expertshumancapital.com"
                  className="text-chart-2 hover:text-chart-3 transition-colors duration-200 underline"
                >
                  contact@expertshumancapital.com
                </a>
              </Trans>
            </p>
          </div>

          {/* Section 7: Data Retention */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <div className="w-1 h-8 bg-chart-2 mr-4 rounded-full"></div>
              <h2 className="text-2xl font-semibold text-foreground font-poppins">
                <Trans id="policy.section7_title">7. Data Retention Period</Trans>
              </h2>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              <Trans id="policy.section7_text">
                Your data is kept as long as necessary to fulfill the defined purposes, in accordance with legal obligations.
              </Trans>
            </p>
          </div>

          {/* Section 8: Policy Changes */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <div className="w-1 h-8 bg-chart-2 mr-4 rounded-full"></div>
              <h2 className="text-2xl font-semibold text-foreground font-poppins">
                <Trans id="policy.section8_title">8. Policy Changes</Trans>
              </h2>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              <Trans id="policy.section8_text">
                We reserve the right to modify this policy at any time. Any changes will be published on this page.
              </Trans>
            </p>
          </div>

          {/* Section 9: Contact */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <div className="w-1 h-8 bg-chart-2 mr-4 rounded-full"></div>
              <h2 className="text-2xl font-semibold text-foreground font-poppins">
                <Trans id="policy.section9_title">9. Contact</Trans>
              </h2>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              <Trans id="policy.section9_text">
                For any questions about our Privacy Policy, you can contact us at{' '}
                <a
                  href="mailto:contact@expertshumancapital.com"
                  className="text-chart-2 hover:text-chart-3 transition-colors duration-200 underline"
                >
                  contact@expertshumancapital.com
                </a>
              </Trans>
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};

export default PolicyPage;
