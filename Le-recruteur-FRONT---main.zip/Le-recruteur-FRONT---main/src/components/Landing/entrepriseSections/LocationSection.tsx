import "leaflet/dist/leaflet.css";
import { useEffect, useRef } from "react";
import L from 'leaflet';

interface LocationSectionProps {
    location: string;
    latitude: number;
    longitude: number;
}

const LocationSection = ({ location, latitude, longitude }: LocationSectionProps) => {
    const mapRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!mapRef.current) return;

        // Initialize the map
        const map = L.map(mapRef.current).setView([latitude, longitude], 13);

        // Add the OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Add a marker
        const marker = L.marker([latitude, longitude]).addTo(map);
        // Can u set the height and width of the popup
        marker.bindPopup(`<div style="width: 100px; height: auto">${location}</div>`).openPopup();
        // Clean up on component unmount
        return () => {
            map.remove();
        };
    }, [latitude, longitude]);

    return (
        <div className="bg-white rounded-[10px] shadow-md p-5">
            <div ref={mapRef} className="h-[270px] w-full"></div>
        </div>
    );
};

export default LocationSection;