import React from 'react';
import { Trans, t } from '@lingui/macro';

const JobRoleSection: React.FC = () => {
  return (
    <section className="py-12 bg-white">
      <div className="max-w-8xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="bg-[#238D94] rounded-0xl px-8 py-12 text-center">
          <div className="text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 tracking-tight">
              <Trans id="jobrole.title">Got a role to fill?</Trans>
            </h2>
            
            <p className="text-base md:text-lg mb-8 text-white/90 max-w-3xl mx-auto leading-relaxed font-medium">
              <Trans id="jobrole.description">
                Join top startups hiring talent like you that get jobs in innovative and find your next
                <br className="hidden sm:block" />
                team member.
              </Trans>
            </p>
            
            <button className="bg-[#E6F4F1] text-[#238D94] font-bold text-sm px-6 py-3 rounded-lg hover:bg-gray-50 transition-all duration-200 shadow-sm hover:shadow-md border border-white/20">
              {t({ id: 'jobrole.button', message: 'Post a Job Now' })}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default JobRoleSection;
