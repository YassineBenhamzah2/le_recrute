import { t } from "@lingui/macro";

const SeparatorSection = () => {
    return (
        <div className="bg-ehc-green text-3xl font-bold rounded-t-full py-8 text-white flex items-center justify-center">
             {t({ id: "separator.availableJobs", message: "Available Jobs" })}
        </div>
    );
};

export default SeparatorSection;