import React, { useEffect, useMemo, useRef, useState } from "react";
import { Building2, UserCog, MonitorPlay, User } from "lucide-react";
import { Trans, t } from "@lingui/macro";

// Brand color used in the mockup
const BRAND = "#238D94" as const;

// Utility hook to know how many cards to display depending on the width
function useItemsPerView() {
  const [items, setItems] = useState(1);
  useEffect(() => {
    const compute = () => {
      if (window.matchMedia("(min-width: 1024px)").matches) setItems(3);
      else if (window.matchMedia("(min-width: 768px)").matches) setItems(2);
      else setItems(1);
    };
    compute();
    window.addEventListener("resize", compute);
    return () => window.removeEventListener("resize", compute);
  }, []);
  return items;
}

const testimonialsData = [
  {
    id: 1,
    name: "Yassine B.",
    role: "Product Designer",
    avatar: "/avatars/francielo.png",
    content:
      "BHC made my job search feel exciting again. I connected with a startup that values creativity and fast thinking. Within two weeks, I had an offer in hand!",
  },
  {
    id: 2,
    name: "Salma R.",
    role: "Marketing Specialist",
    avatar: "/avatars/iomina.png",
    content:
      "I love how easy and focused the platform is. Unlike traditional job boards, BHC understands what startup talent is really looking for.",
  },
  {
    id: 3,
    name: "Omar K.",
    role: "Frontend Engineer",
    avatar: "/avatars/francielo1.png",
    content:
      "Great matching and a smooth process. The experience felt tailored to me and my goals.",
  },
  {
    id: 4,
    name: "Sara M.",
    role: "Data Analyst",
    avatar: "/avatars/iomina.png",
    content:
      "The platform helped me highlight impact, not just tasks. Landed interviews quickly.",
  },
];

const Dot = ({ active, onClick }: { active: boolean; onClick: () => void }) => (
  <button
    onClick={onClick}
    aria-label={
      active
        ? t({ id: "slider.active_slide", message: "Active slide" })
        : t({ id: "slider.go_to_slide", message: "Go to slide" })
    }
    className={`h-2.5 w-2.5 rounded-full transition-all duration-300 mx-1 ${
      active ? "scale-125 opacity-100" : "opacity-50 hover:opacity-90"
    }`}
    style={{ backgroundColor: BRAND }}
  />
);

const TestimonialsSection: React.FC = () => {
  const itemsPerView = useItemsPerView();
  const trackRef = useRef<HTMLDivElement | null>(null);
  const [page, setPage] = useState(0);

  const statsData = useMemo(
    () => [
      {
        number: "+78",
        label: t({ id: "stats.trainings", message: "Trainings" }),
        icon: MonitorPlay,
      },
      {
        number: "2 000",
        label: t({ id: "stats.companies", message: "Companies" }),
        icon: Building2,
      },
      {
        number: "23 400",
        label: t({ id: "stats.resources", message: "Resources" }),
        icon: UserCog,
      },
      {
        number: "+1 200",
        label: t({ id: "stats.employees", message: "Employees" }),
        icon: User,
      },
    ],
    []
  );

  const pagesCount = useMemo(
    () => Math.max(1, Math.ceil(testimonialsData.length / itemsPerView)),
    [itemsPerView]
  );

  // Auto-play
  useEffect(() => {
    const id = setInterval(() => {
      setPage((p) => (p + 1) % pagesCount);
    }, 6000);
    return () => clearInterval(id);
  }, [pagesCount]);

  // Scroll vers la page active
  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;
    const card = el.querySelector<HTMLElement>("[data-card]");
    if (!card) return;

    const gap = parseFloat(getComputedStyle(el).gap || "24");
    const cardWidth = card.offsetWidth;
    const scrollTo = page * (cardWidth + gap);
    el.scrollTo({ left: scrollTo, behavior: "smooth" });
  }, [page, itemsPerView]);

  return (
    <section className="py-20 bg-gray-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Témoignages */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 tracking-tight">
            <Trans id="testimonials.title">Testimonials</Trans>
          </h2>
        </div>

        {/* Slider */}
        <div className="relative mb-16">
          <div
            ref={trackRef}
            className="flex gap-6 overflow-x-auto no-scrollbar scroll-smooth snap-x snap-mandatory px-5 py-5"
          >
            {testimonialsData.map((t) => (
              <article
                key={t.id}
                data-card
                className="min-w-[85%] md:min-w-[48%] lg:min-w-[32%] snap-start bg-white border rounded-2xl p-6 shadow-md hover:shadow-lg hover:-translate-y-1 transform transition duration-300"
                style={{ borderColor: BRAND }}
              >
                <div className="flex items-center mb-4">
                  {/* avatar */}
                  <img
                    src={t.avatar}
                    alt={t.name}
                    className="w-12 h-12 rounded-full object-cover mr-3 ring-2 ring-offset-2"
                    style={{ "--tw-ring-color": BRAND } as React.CSSProperties}
                    onError={(e) => {
                      (
                        e.currentTarget as HTMLImageElement
                      ).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(
                        t.name
                      )}&background=0ea5e9&color=fff`;
                    }}
                  />
                  <div className="text-left">
                    <h4
                      className="font-semibold text-lg"
                      style={{ color: BRAND }}
                    >
                      {t.name}
                    </h4>
                    <p className="text-sm text-gray-600">{t.role}</p>
                  </div>
                </div>
                <p className="text-gray-700 text-base leading-relaxed italic">
                  "<Trans>{t.content}</Trans>"
                </p>
              </article>
            ))}
          </div>

          {/* Dots */}
          <div className="mt-8 flex items-center justify-center">
            {Array.from({ length: pagesCount }).map((_, i) => (
              <Dot key={i} active={i === page} onClick={() => setPage(i)} />
            ))}
          </div>
        </div>

        {/* Nos Chiffres */}
        <div className="text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">
            <Trans id="stats.title">
              <span className="text-black">Our</span>{" "}
              <span style={{ color: BRAND }}>Figures</span>
            </Trans>
          </h3>

          <div className="bg-white rounded-2xl shadow-md ring-1 ring-gray-100 p-8 md:p-10">
            <div className="grid grid-cols-2 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-gray-200">
              {statsData.map(({ number, label, icon: Icon }, idx) => (
                <div
                  key={idx}
                  className="flex flex-col items-center justify-center py-6 hover:bg-gray-50 transition rounded-xl"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span
                      className="inline-flex items-center justify-center rounded-xl p-2"
                      style={{ background: "#E9F7F8", color: BRAND }}
                    >
                      <Icon className="w-6 h-6" />
                    </span>
                    <span
                      className="text-3xl font-extrabold"
                      style={{ color: BRAND }}
                      dir="ltr"
                    >
                      {number}
                    </span>
                  </div>
                  <p
                    className="font-semibold text-sm md:text-base"
                    style={{ color: BRAND }}
                  >
                    {label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
