import { BookmarkIcon, CalendarIcon, MapPinIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { settings } from "@/lib/settings/main";
import { useNavigate } from "react-router-dom";
import { Trans , t} from "@lingui/macro";


interface JobListingsSectionProps {
  jobListing: {
    id: number;
    title: string;
    company: string;
    location: string;
    postedTime: string;
    jobType: string;
    salary: string;
    salaryPeriod: string;
    skills: {
      name: string;
    }[];
    companyLogo: string;
    isBookmarked?: boolean;
    onBookmark?: () => void;
    bookmarkLoading?: boolean;
  }[];
}

export const JobListingsSection = ({
  jobListing,
}: JobListingsSectionProps): JSX.Element => {
  const navigate = useNavigate();
  
  if (jobListing.length === 0)
    return (
      <div className="flex flex-col items-center justify-center py-16 text-gray-500">
        <svg
          className="w-12 h-12 mb-4 text-ehc-green"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.5}
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M12 17v.01M9 21h6a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2zm3-17a5 5 0 0 1 5 5v2a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V9a5 5 0 0 1 5-5z"
          />
        </svg>
        <div className="text-lg font-semibold mb-1">
          <Trans>No job listings available</Trans>
        </div>
        <div className="text-sm text-gray-400">
          <Trans>Please check back later for new opportunities.</Trans>

        </div>
      </div>
    );

  const handleApply = (jobId: number) => {
    navigate(`/jobs/${jobId}`);
  };

  return (
    <div className="space-y-6">
      {jobListing.map((job) => (
        <Card className="mt-16 rounded-lg shadow-md" key={job.id}>
          <CardContent className="p-6 relative">
            <div className="flex items-start">
              {/* Company logo */}
              <div className="w-20 h-20 bg-white rounded-lg mr-6">
                <img
                  className="w-24 h-24 -ml-2 -mt-1 object-cover"
                  alt={t`Company logo`}
                  src={`${settings.IMG_ADDRESS}${job.companyLogo}`}
                />
              </div>

              {/* Job details */}
              <div className=" relative">
                <h3 className="font-bold text-ehc-green text-xl leading-[30px]">
                  {job.title}
                </h3>
                <div className="font-medium text-gray-800 text-base leading-6 mt-1">
                  {job.company}
                </div>

                <div className="flex items-center mt-4 text-gray-500 text-sm">
                  <MapPinIcon className="w-[18px] h-[18px] mr-3" />
                  <span className="mr-6">{job.location}</span>

                  <CalendarIcon className="w-[18px] h-[18px] mr-3" />
                  <span>{job.postedTime}</span>
                </div>

                {/* Job type badge */}
                <div className="absolute top-0 left-full">
                  <Badge className="bg-ehc-green hover:bg-ehc-green-dark text-white font-normal text-sm px-5 py-1.5 rounded-lg">
                    {job.jobType}
                  </Badge>
                </div>

                {/* Skills */}
                <div className="flex gap-2 mt-4">
                  {job.skills.map((skill, index) => (
                    <Badge
                      key={index}
                      className="bg-ehc-green/10 text-ehc-green font-medium text-xs px-2.5 py-1"
                    >
                      {skill.name}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Salary and actions */}
              <div className="text-right ml-auto">
                <div className="flex items-start justify-center gap-5">
                  <div className="flex flex-col items-end justify-start">
                    <div className="font-bold text-ehc-green text-lg leading-[27px]">
                      {job.salary}
                    </div>
                    <div className="font-normal text-gray-500 text-sm leading-[21px] mt-1">
                      {job.salaryPeriod}
                    </div>
                  </div>

                  {/* Interactive bookmark button */}
                  <button
                    onClick={job.onBookmark}
                    disabled={job.bookmarkLoading || !job.onBookmark}
                    className={`relative top-1 p-1 rounded transition-colors ${
                      job.onBookmark
                        ? "hover:bg-gray-100 cursor-pointer"
                        : "cursor-default"
                    }`}
                    title={
                      job.isBookmarked
                        ? t({ id: "jobs.removeBookmark", message: "Remove from bookmarks" })
                        : t({ id: "jobs.addBookmark", message: "Add to bookmarks" })}

                  >
                    {job.bookmarkLoading ? (
                      <div className="w-6 h-6 border-2 border-ehc-green border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <BookmarkIcon
                        className={`w-6 h-6 transition-colors ${
                          job.isBookmarked
                            ? "text-ehc-green fill-ehc-green"
                            : "text-ehc-green hover:fill-ehc-green/20"
                        }`}
                      />
                    )}
                  </button>
                </div>
                <Button className="bg-ehc-green hover:bg-ehc-green-dark text-white font-semibold text-sm rounded-lg mt-12 px-4 py-2" onClick={() => handleApply(job.id)}>
                  {t({ id: "jobs.applyNow", message: "Apply Now" })}

                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};