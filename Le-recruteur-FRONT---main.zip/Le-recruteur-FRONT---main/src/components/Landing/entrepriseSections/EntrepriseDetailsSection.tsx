import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import React from "react";
import LocationSection from "./LocationSection";
import { settings } from "@/lib/settings/main";
import { t } from "@lingui/macro";

interface EntrepriseDetailsSectionProps {
  companyInfo: {
    name: string;
    address: string;
    website: string;
    logoUrl: string;
    mapUrl: string;
    about: string[];
    latitude: number;
    longitude: number;
  };
  profileDetails: {
    icon: React.ReactNode;
    label: string;
    value: string;
  }[];
  responsibilities: string[];
  handleCompanyBookmark: () => void;
  bookmarkLoading: Set<number>;
  isCompanyBookmarked: boolean;
}

export const EntrepriseDetailsSection = ({
  companyInfo,
  profileDetails,
  responsibilities,
  handleCompanyBookmark,
  bookmarkLoading,
  isCompanyBookmarked,
}: EntrepriseDetailsSectionProps): JSX.Element => {
  return (
    <section className="w-full bg-white py-16">
      <div className="container max-w-[1170px] mx-auto">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Left column - Company details */}
          <div className="flex-1">
            <div className="relative mb-20">
              {/* Company banner */}
              <img
                className="w-full h-[304px] rounded-[10px] object-cover bg-center"
                src={`${settings.IMG_ADDRESS}${companyInfo.mapUrl}`}
              />
              <div className="flex items-center justify-between relative">
                {/* Company logo */}
                <div className="absolute -top-10 left-5 w-[90px] h-[90px] bg-white rounded-[10px] shadow-md overflow-hidden flex items-center justify-center">
                  <img
                    className="w-full h-full object-center object-fill"
                    src={`${settings.IMG_ADDRESS}${companyInfo.logoUrl}`}
                    alt={companyInfo.name}
                    style={{ imageRendering: "auto" }}
                  />
                </div>

                {/* Save company button */}
                <div className="absolute top-5 right-0">
                  <Button
                    variant={isCompanyBookmarked ? "default" : "outline"}
                    className={
                      " text-" +
                      (isCompanyBookmarked
                        ? "ehc-green"
                        : "gray-300 bg-ehc-green-dark") +
                      " border-" +
                      (isCompanyBookmarked
                        ? "ehc-green"
                        : "gray-300 bg-ehc-green-dark") +
                      " font-" +
                      (isCompanyBookmarked ? "semibold" : "normal") +
                      " p-5"
                    }
                    onClick={handleCompanyBookmark}
                    disabled={bookmarkLoading.has(-1)}
                  >
                    {bookmarkLoading.has(-1)
                      ? t({ id: "entreprise.processing", message: "Processing..." })
                      : isCompanyBookmarked
                      ? t({ id: "entreprise.bookmarked", message: "Bookmarked" })
                      : t({ id: "entreprise.bookmarkCompany", message: "Bookmark Company" })}
                  </Button>
                </div>
              </div>

              {/* Company info with logo */}
              <div className="mt-20 space-y-4">
                <div className="font-medium text-gray-900 text-base">
                  {companyInfo.name}
                </div>

                <div className="flex items-start">
                  <div className="w-[15px] h-[15px] mt-0.5"></div>
                  <div className="ml-[18px] font-normal text-gray-700 text-[15px] leading-[25.5px]">
                    {companyInfo.address}
                  </div>
                </div>

                <a
                  href={companyInfo.website}
                  className="inline-block font-normal text-ehc-green-light text-[15px] leading-[25.5px]"
                >
                  {companyInfo.website}
                </a>
              </div>
            </div>

            {/* About Company section */}
            <div className="mb-10">
              <h2 className="font-bold text-gray-900 text-xl mb-6">
                {t({ id: "entreprise.aboutCompany", message: "About Company" })}
              </h2>

              {companyInfo.about.map((paragraph, index) => (
                <p
                  key={index}
                  className="font-normal text-gray-700 text-[15px] text-justify leading-[25.5px] mb-4 last:mb-0"
                >
                  {paragraph}
                </p>
              ))}
            </div>

            {/* Responsibilities section */}
            <div>
              <h2 className="font-bold text-gray-900 text-xl mb-6">
                {t({ id: "entreprise.responsibilities", message: "Responsibilities" })}
              </h2>

              <ul className="space-y-2.5">
                {responsibilities.map((responsibility, index) => (
                  <li key={index} className="flex items-start">
                    <div className="w-7 h-7 flex items-center justify-center rounded-[14px] text-ehc-green text-[22px]">
                      •
                    </div>
                    <div className="ml-[18px] font-medium text-gray-700 text-base leading-[27.2px]">
                      {responsibility}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Right column - Location and Profile Info */}
          <div className="w-full md:w-[390px]">
            <div className="space-y-6">
              <LocationSection
                latitude={companyInfo.latitude || 51.505}
                longitude={companyInfo.longitude || -0.09}
                location={companyInfo.address}
              />

              {/* Profile Info section */}
              <Card className="border-none shadow-none">
                <CardHeader className="px-0 pb-0">
                  <CardTitle className="font-bold text-gray-900 text-xl">
                    {t({ id: "entreprise.profileInfo", message: "Profile Info" })}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0 pt-6">
                  <div className="bg-white rounded-[10px] shadow-md p-10">
                    <div className="space-y-2.5">
                      {/* Other profile details */}
                      {profileDetails.map((detail, index) => (
                        <div
                          key={index}
                          className="flex items-start gap-6 justify-start"
                        >
                          <span className="text-ehc-green translate-y-1">
                            {detail.icon}
                          </span>
                          <div>
                            <div className="font-normal text-gray-500 text-sm leading-[23.8px]">
                              {detail.label}
                            </div>
                            <div className="font-normal text-gray-900 text-base leading-[27.2px] whitespace-pre-line">
                              {detail.value}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
