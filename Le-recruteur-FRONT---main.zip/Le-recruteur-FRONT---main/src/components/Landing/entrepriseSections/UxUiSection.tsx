import React from 'react';
import { Trans, t } from '@lingui/macro';
import { i18n } from '@lingui/core';

const Button: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { className?: string }> = ({ 
  children, 
  className, 
  ...props 
}) => (
  <button className={className} {...props}>
    {children}
  </button>
);
const isRTL = i18n.locale === 'ar';

const UiUxSection: React.FC = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* 2-column layout */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Side - Job Cards */}
          <div className={`relative z-20 ${isRTL?'mr-5':'-mr-20'}`}>
            {/* First Card */}
            <div className="bg-[#F8F8FD] rounded-2xl shadow-xl p-8 mb-8 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-900 mb-4 font-sans">
                <Trans id="uxui.job_count">245 UX/UI Design Jobs</Trans>
              </h3>
              <p className="text-gray-600 mb-6 font-sans leading-relaxed">
                <Trans id="uxui.job_description">Choose from a number of great projects</Trans>
              </p>
              <Button className="bg-white border-2 border-teal-500 text-teal-600 hover:bg-teal-500 hover:text-white px-8 py-3 font-sans font-medium rounded-lg transition-all duration-300 hover:shadow-lg">
                <Trans id="uxui.see_listing_button">See Listing</Trans>
              </Button>
            </div>

            {/* Second Card - Slightly offset */}
            <div className="bg-[#F8F8FD] rounded-2xl shadow-xl p-8 mb-8 border border-gray-100 ">
              <h3 className="text-2xl font-bold text-gray-900 mb-4 font-sans">
                <Trans id="uxui.job_count">245 UX/UI Design Jobs</Trans>
              </h3>
              <p className="text-gray-600 mb-6 font-sans leading-relaxed">
                <Trans id="uxui.job_description">Choose from a number of great projects</Trans>
              </p>
              <Button className="bg-white border-2 border-teal-500 text-teal-600 hover:bg-teal-500 hover:text-white px-8 py-3 font-sans font-medium rounded-lg transition-all duration-300 hover:shadow-lg">
                <Trans id="uxui.see_listing_button">See Listing</Trans>
              </Button>
            </div>
          </div>

          {/* Right Side - Team Image */}
          <div className="relative">
            <div className="w-full max-w-[600px] h-[500px] rounded-3xl overflow-hidden shadow-2xl">
              <img 
                src="/work.png" 
                alt={t({ id: "uxui.alt_team_working", message: "Team working together" })} 
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='500' viewBox='0 0 600 500'%3E%3Crect width='600' height='500' fill='%23f3f4f6'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial' font-size='18' fill='%236b7280' text-anchor='middle' dy='0.3em'%3ETeam working together%3C/text%3E%3C/svg%3E";
                }}
              />
            </div>

            {/* Decorative elements */}
            <div className="absolute -top-4 -left-4 w-8 h-8 bg-teal-500 rounded-full"></div>
            <div className="absolute -bottom-6 -right-6 w-12 h-12 bg-blue-400 rounded-full opacity-80"></div>
            <div className="absolute top-1/3 -left-8 w-6 h-6 bg-yellow-400 rounded-full"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UiUxSection;
