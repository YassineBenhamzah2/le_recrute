import { useState, useEffect } from "react";
import { settings } from "@/lib/settings/main";
import { AdSpace } from "@/lib/types/adSpace";
import { adSpaceService } from "@/lib/network/adSpaceService";
import { Trans } from '@lingui/macro';

export default function SectionAd() {
  const [ads, setAds] = useState<AdSpace[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const visibleCount = 3;

  const fetchAds = async () => {
    const data = await adSpaceService.getAdSpaces();
    setAds(data);
  };

  useEffect(() => {
    fetchAds();
  }, []);

  const nextSlide = () => {
    if (currentIndex + visibleCount < ads.length) setCurrentIndex(currentIndex + 1);
  };

  const prevSlide = () => {
    if (currentIndex > 0) setCurrentIndex(currentIndex - 1);
  };

  return (
    <section className="py-12 lg:py-16 px-4 relative z-10">
      {/* Section decorative elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-5 right-10 w-16 h-16 bg-gradient-to-br from-[#238D94]/8 to-transparent rounded-lg transform rotate-12"></div>
        <div className="absolute bottom-5 left-10 w-12 h-12 bg-[#238D94]/10 rounded-full"></div>
      </div>

      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8 lg:mb-12">
          <h2 className="text-2xl lg:text-3xl font-bold text-[#238D94]">
            <Trans id="ad_space.title">ADVERTISING SPACE</Trans>
          </h2>
          <div className="flex items-center gap-2">
            <button 
              onClick={prevSlide}
              disabled={currentIndex === 0}
      className="p-4 text-2xl border border-[#238D94] rounded-lg hover:bg-[#238D94] hover:text-white transition-colors disabled:opacity-50"
            >
              &#8249;
            </button>
            <button 
              onClick={nextSlide}
              disabled={currentIndex + visibleCount >= ads.length}
      className="p-4 text-2xl border border-[#238D94] rounded-lg hover:bg-[#238D94] hover:text-white transition-colors disabled:opacity-50"
            >
              &#8250;
            </button>
          </div>
        </div>

        {/* Slider */}
        <div className="overflow-hidden relative">
          <div
            className="flex transition-transform duration-300"
            style={{ transform: `translateX(-${currentIndex * (100 / visibleCount)}%)` }}
          >
            {ads.map(ad => (
              <div key={ad.id} className="relative flex-shrink-0 w-[calc(100%/3)] px-2">
                <div 
                  onClick={() => ad.link && window.open(ad.link, "_blank")}
                  className="relative border-2 border-[#238D94] rounded-lg overflow-hidden h-64 lg:h-72 transition-transform duration-300 hover:scale-105 cursor-pointer"
                >
                  <img
                    src={ad.imageUrl ? `${settings.IMG_ADDRESS}${ad.imageUrl}` : "/default-image.png"}
                    alt={ad.title}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>

                {/* Titre flottant */}
            <div className="absolute left-1/2 -translate-x-1/2 -bottom-4 bg-white bg-opacity-90 text-gray-800 px-4 py-2 text-lg font-medium text-center shadow-lg rounded-lg w-[calc(100%-60px)] truncate">
  {ad.title}
</div>


              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
