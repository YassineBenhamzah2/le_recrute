import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles/index.css";
import "react-date-range/dist/styles.css"; // main css file
import "react-date-range/dist/theme/default.css"; // theme css file
import "react-day-picker/dist/style.css";

import { BrowserRouter } from "react-router-dom";
import { Toaster } from "sonner";
import { LocaleProvider } from "./contexts/LocaleContext";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <LocaleProvider>
      <BrowserRouter>
        <App />
        <Toaster richColors />
      </BrowserRouter>
    </LocaleProvider>
  </StrictMode>
);
