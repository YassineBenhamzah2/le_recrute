import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import {
  CandidateTest,
  TestQuestion as CandidateTestQuestion,
  QuestionType,
  TestAnswer,
} from "@/lib/types/candidateTests";
import { candidateTestService } from "@/lib/network/candidateTest";
import { TestQuestion as ApiTestQuestion } from "@/lib/types/test";

// Convert API TestQuestion to CandidateTestQuestion format
const convertApiQuestionToCandidateQuestion = (
  apiQuestion: ApiTestQuestion,
  testId: string,
  order: number
): CandidateTestQuestion => {
  return {
    id: apiQuestion.id,
    testId: testId,
    questionText: apiQuestion.question,
    questionType: apiQuestion.type as QuestionType,
    options: apiQuestion.options,
    correctAnswer: apiQuestion.options.find((opt) => opt.isCorrect)?.text || "",
    points: apiQuestion.points,
    order: order,
  };
};

export const useTestState = (test: CandidateTest) => {
  const [questions, setQuestions] = useState<CandidateTestQuestion[]>([]);
  const [answers, setAnswers] = useState<TestAnswer[]>([]);
  const [flaggedQuestions, setFlaggedQuestions] = useState<Set<string>>(
    new Set()
  );
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [questionStartTimes, setQuestionStartTimes] = useState<Record<string, number>>({});
  const answersRef = useRef(answers);
  answersRef.current = answers; // Keep ref updated

  // Initialize questions and answers
  useEffect(() => {
    const initializeTest = async () => {
      setIsLoading(true);

      try {
        // Check for saved progress
        const savedProgress = localStorage.getItem(`test_progress_${test.id}`);
        let progressData = null;

        if (savedProgress) {
          try {
            progressData = JSON.parse(savedProgress);
            const now = Date.now();
            const progressAge = now - progressData.timestamp;

            // Only restore if progress is less than 1 hour old
            if (progressAge >= 3600000 || progressData.testId !== test.id) {
              // Clean up old progress
              localStorage.removeItem(`test_progress_${test.id}`);
              progressData = null;
            }
          } catch (error) {
            console.warn("Failed to restore test progress:", error);
          }
        }

        // Start a new test or use saved session
        const savedSessionId = progressData?.sessionId;

        if (!savedSessionId) {
          // Start new test session
          const response = await candidateTestService.startTest(test.id);

          if (response.success && response.data) {
            const { sessionId, questions: apiQuestions } = response.data;

            // Store the session ID for later use
            setSessionId(sessionId);
            localStorage.setItem("current_test_session_id", sessionId);

            // Convert API questions to the format our app expects
            const convertedQuestions = apiQuestions.map((q, index) =>
              convertApiQuestionToCandidateQuestion(q, test.id, index + 1)
            );

            setQuestions(convertedQuestions);

            // Initialize empty answers
            const initialAnswers = convertedQuestions.map((q) => ({
              questionId: q.id,
              answer: "",
              isFlagged: false,
              timeSpent: 0,
            }));
            setAnswers(initialAnswers);
            
            // Initialize question start times
            const startTimes: Record<string, number> = {};
            convertedQuestions.forEach(q => {
              startTimes[q.id] = Date.now();
            });
            setQuestionStartTimes(startTimes);
          } else {
            throw new Error("Failed to start test");
          }
        } else {
          // Restore session
          setSessionId(savedSessionId);
          localStorage.setItem("current_test_session_id", savedSessionId);

          if (progressData) {
            setQuestions(progressData.questions || []);
            setAnswers(progressData.answers || []);
            setFlaggedQuestions(new Set(progressData.flaggedQuestions || []));
            setCurrentQuestion(progressData.currentQuestion || 0);
            
            // Restore question start times
            const startTimes: Record<string, number> = {};
            progressData.questions.forEach((q: CandidateTestQuestion) => {
              startTimes[q.id] = Date.now(); // Reset start time on restore
            });
            setQuestionStartTimes(startTimes);
            
            console.log("Test progress restored from previous session");
          }
        }
      } catch (error) {
        console.error("Failed to initialize test:", error);
        // Handle error appropriately
      } finally {
        setIsLoading(false);
      }
    };

    initializeTest();
  }, [test.id, test.totalQuestions]);

  // Update question start time when changing questions
  const handleQuestionChange = useCallback((index: number) => {
    setCurrentQuestion(index);
    
    // Update start time for the new current question
    if (questions[index]) {
      const questionId = questions[index].id;
      setQuestionStartTimes(prev => ({
        ...prev,
        [questionId]: Date.now()
      }));
    }
  }, [questions]);

  // Calculate time spent on a question
  const calculateTimeSpent = useCallback((questionId: string): number => {
    const startTime = questionStartTimes[questionId];
    if (!startTime) return 0;
    
    return Math.floor((Date.now() - startTime) / 1000); // Convert to seconds
  }, [questionStartTimes]);

  // Handle answer changes with API call
  const handleAnswerChange = useCallback(async (questionId: string, answer: string) => {
    const timeSpent = calculateTimeSpent(questionId);
    
    // Update local state immediately for responsive UI
    setAnswers(prev => {
      const existingAnswerIndex = prev.findIndex(a => a.questionId === questionId);
      if (existingAnswerIndex >= 0) {
        const updated = [...prev];
        updated[existingAnswerIndex] = {
          ...updated[existingAnswerIndex],
          answer: answer,
          timeSpent: updated[existingAnswerIndex].timeSpent + timeSpent
        };
        return updated;
      } else {
        return [...prev, { questionId, answer, timeSpent, isFlagged: false }];
      }
    });

    // Reset the timer for this question
    setQuestionStartTimes(prev => ({
      ...prev,
      [questionId]: Date.now()
    }));

    // Submit to API in the background
    // if (sessionId) {
    //   try {
    //     await candidateTestService.submitAnswer(
    //       sessionId,
    //       questionId,
    //       {
    //         answer: answer,
    //         timeSpent: timeSpent
    //       }
    //     );
    //   } catch (error) {
    //     console.error("Failed to submit answer to API:", error);
    //     // We don't need to handle this error in the UI since we've updated local state
    //   }
    // }
  }, [sessionId, calculateTimeSpent]);

  // Handle flag toggle
  const handleFlagToggle = useCallback((questionId: string) => {
    setFlaggedQuestions((prev) => {
      const newFlagged = new Set(prev);
      if (newFlagged.has(questionId)) {
        newFlagged.delete(questionId);
      } else {
        newFlagged.add(questionId);
      }

      // Update answer flag status
      setAnswers((prevAnswers) =>
        prevAnswers.map((a) =>
          a.questionId === questionId
            ? { ...a, isFlagged: newFlagged.has(questionId) }
            : a
        )
      );

      return newFlagged;
    });
  }, []);

  // Get answered count
  const getAnsweredCount = useCallback(() => {
    return answers.filter((answer) => answer.answer.trim().length > 0).length;
  }, [answers]);

  // Get flagged count
  const getFlaggedCount = useCallback(() => {
    return flaggedQuestions.size;
  }, [flaggedQuestions]);

  // Get completion percentage
  const getCompletionPercentage = useCallback(() => {
    return questions.length > 0
      ? (getAnsweredCount() / questions.length) * 100
      : 0;
  }, [getAnsweredCount, questions.length]);

  // Get question status for navigation
  const getQuestionStatus = useCallback(
    (index: number) => {
      const answer = answers[index];
      const question = questions[index];

      if (!question || !answer) return "unanswered";

      const isAnswered = answer.answer.trim().length > 0;
      const isFlagged = answer.isFlagged;
      const isCurrent = index === currentQuestion;

      if (isCurrent) return "current";
      if (isAnswered && isFlagged) return "answered-flagged";
      if (isAnswered) return "answered";
      if (isFlagged) return "flagged";

      return "unanswered";
    },
    [answers, questions, currentQuestion]
  );

  // Validation helpers
  const canSubmitTest = useMemo(() => {
    return answers.some((answer) => answer.answer.trim().length > 0);
  }, [answers]);

  const getUnansweredQuestions = useMemo(() => {
    return questions
      .map((q, index) => ({ question: q, index }))
      .filter(({ question }) => {
        const answer = answers.find((a) => a.questionId === question.id);
        return !answer || answer.answer.trim().length === 0;
      });
  }, [questions, answers]);

  // Auto-save functionality
  useEffect(() => {
    if (!sessionId) return;

    const autoSaveInterval = setInterval(() => {
      // Save current progress to localStorage as backup
      const progressData = {
        sessionId,
        testId: test.id,
        questions,
        answers,
        flaggedQuestions: Array.from(flaggedQuestions),
        currentQuestion,
        timestamp: Date.now(),
      };

      try {
        localStorage.setItem(
          `test_progress_${test.id}`,
          JSON.stringify(progressData)
        );
      } catch (error) {
        console.warn("Failed to auto-save test progress:", error);
      }
    }, 30000); // Auto-save every 30 seconds

    return () => clearInterval(autoSaveInterval);
  }, [
    sessionId,
    test.id,
    questions,
    answers,
    flaggedQuestions,
    currentQuestion,
  ]);

  return {
    questions,
    answers,
    flaggedQuestions,
    currentQuestion,
    isLoading,
    setCurrentQuestion: handleQuestionChange,
    handleAnswerChange,
    handleFlagToggle,
    getAnsweredCount,
    getFlaggedCount,
    getCompletionPercentage,
    getQuestionStatus,
    canSubmitTest,
    getUnansweredQuestions,
    sessionId,
  };
};