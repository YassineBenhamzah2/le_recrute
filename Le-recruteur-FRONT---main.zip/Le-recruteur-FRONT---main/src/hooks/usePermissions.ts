import { useAuth } from "../contexts/AuthContext";

// Hook for checking permissions in components
export const usePermissions = () => {
  const {
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    isAdmin,
    isRecruiter,
    isCandidate,
  } = useAuth();

  return {
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    isAdmin,
    isRecruiter,
    isCandidate,
  };
};
