import { useState, useEffect, useCallback, useRef } from 'react';

interface TestTimerConfig {
  duration: number; // in minutes
  onTimeUp: () => void;
  warningThreshold?: number; // in seconds, default 300 (5 minutes)
}

interface TestTimer {
  remainingTime: number;
  isRunning: boolean;
  isPaused: boolean;
  warningThreshold: number;
  isWarning: boolean;
  isCritical: boolean;
}

export const useTestTimer = ({ 
  duration, 
  onTimeUp, 
  warningThreshold = 300 
}: TestTimerConfig) => {
  const [timer, setTimer] = useState<TestTimer>({
    remainingTime: duration * 60, // Convert minutes to seconds
    isRunning: true,
    isPaused: false,
    warningThreshold,
    isWarning: false,
    isCritical: false
  });

  const onTimeUpRef = useRef(onTimeUp);
  const hasCalledTimeUp = useRef(false);

  // Update the ref when onTimeUp changes
  useEffect(() => {
    onTimeUpRef.current = onTimeUp;
  }, [onTimeUp]);

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (timer.isRunning && !timer.isPaused && timer.remainingTime > 0) {
      interval = setInterval(() => {
        setTimer(prev => {
          const newRemainingTime = prev.remainingTime - 1;
          const isWarning = newRemainingTime <= warningThreshold && newRemainingTime > 60;
          const isCritical = newRemainingTime <= 60 && newRemainingTime > 0;
          
          return {
            ...prev,
            remainingTime: newRemainingTime,
            isWarning,
            isCritical
          };
        });
      }, 1000);
    }

    // Auto-submit when time runs out
    if (timer.remainingTime <= 0 && !hasCalledTimeUp.current) {
      hasCalledTimeUp.current = true;
      onTimeUpRef.current();
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [timer.isRunning, timer.isPaused, timer.remainingTime, warningThreshold]);

  const formatTime = useCallback((seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }, []);

  const pauseTimer = useCallback(() => {
    setTimer(prev => ({ ...prev, isPaused: true }));
  }, []);

  const resumeTimer = useCallback(() => {
    setTimer(prev => ({ ...prev, isPaused: false }));
  }, []);

  const toggleTimer = useCallback(() => {
    setTimer(prev => ({ ...prev, isPaused: !prev.isPaused }));
  }, []);

  return {
    timer,
    formatTime,
    pauseTimer,
    resumeTimer,
    toggleTimer
  };
};
