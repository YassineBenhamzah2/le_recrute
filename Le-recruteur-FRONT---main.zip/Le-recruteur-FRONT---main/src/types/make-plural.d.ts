/* eslint-disable @typescript-eslint/no-explicit-any */
declare module "make-plural/plurals" {
  export const en: any;
  export const fr: any;
  export const ar: any;
}
