import { i18n } from '@lingui/core';
import { en, fr, ar } from 'make-plural/plurals';
import { DEFAULT_LOCALE, SUPPORTED_LOCALES, LocaleInfo } from './locales';

i18n.loadLocaleData({
  en: { plurals: en },
  fr: { plurals: fr },
  ar: { plurals: ar },
});

export async function dynamicActivate(locale: string) {
  const targetLocale = SUPPORTED_LOCALES[locale] ? locale : DEFAULT_LOCALE;
  
  // Dynamically import the single 'messages.mjs' file for the target locale.
  const { messages } = await import(`../locales/${targetLocale}/messages.mjs`);

  i18n.load(targetLocale, messages);
  i18n.activate(targetLocale);
  updateDocumentAttributes(SUPPORTED_LOCALES[targetLocale]);
}

function updateDocumentAttributes(localeInfo: LocaleInfo) {
  document.documentElement.setAttribute("lang", localeInfo.code);
  document.documentElement.setAttribute("dir", localeInfo.direction);
}