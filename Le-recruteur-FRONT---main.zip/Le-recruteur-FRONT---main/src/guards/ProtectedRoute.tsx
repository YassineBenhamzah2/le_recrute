import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { getDefaultDashboardPath } from "../lib/utils/navigation";
import { Trans } from "@lingui/macro";

const ProtectedRoute: React.FC = () => {
  const { user, isLoading } = useAuth();
  const location = useLocation();

  // Show loading spinner while checking authentication
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600"><Trans>Loading...</Trans></p>
        </div>
      </div>
    );
  }

  // Redirect to auth page if not authenticated
  if (!user) {
    return <Navigate to="/auth/signin" state={{ from: location }} replace />;
  }

  console.log("🔐 ProtectedRoute Debug:", {
    user: user,
    userRole: user.role,
    currentPath: location.pathname,
    timestamp: new Date().toISOString(),
  });

  if (!user.role || !user.role.type) {
    console.error("❌ User has no role defined");
    return <Navigate to="/auth/signin" replace />;
  }

  // Use role.type for navigation instead of role.name
  const userRoleType = user.role.type.toLowerCase();
  const allowedPath = `/${userRoleType}`;

  console.log("🎯 Route Check:", {
    roleType: user.role.type,
    roleName: user.role.name,
    userRoleType,
    allowedPath,
    currentPath: location.pathname,
    startsWith: location.pathname.startsWith(allowedPath),
    shouldRedirect: !location.pathname.startsWith(allowedPath),
  });

  // Check if current path matches user's role type
  if (!location.pathname.startsWith(allowedPath)) {
    console.log(
      `🔄 Redirecting ${userRoleType} from ${location.pathname} to ${allowedPath}`
    );
    const defaultPath = getDefaultDashboardPath(user.role);
    return <Navigate to={defaultPath} replace />;
  }

  console.log("✅ Access granted for", userRoleType, "to", location.pathname);
  return <Outlet />;
};

export default ProtectedRoute;
