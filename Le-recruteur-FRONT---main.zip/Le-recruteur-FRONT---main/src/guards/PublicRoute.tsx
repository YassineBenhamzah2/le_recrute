import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { getDefaultDashboardPath } from "../lib/utils/navigation";

const PublicRoute: React.FC = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  console.log("PublicRoute - user:", user);
  // If user is logged in, redirect to their dashboard based on role type
  if (user) {
    const dashboardPath = getDefaultDashboardPath(user.role);
    return <Navigate to={dashboardPath} />;
  }

  return <Outlet />;
};
export default PublicRoute;
