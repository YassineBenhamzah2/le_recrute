import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import Logout from "./components/Auth/Logout";
import AdminBlogDetails from "./components/Dashboard/AdminComponents/AdminBlogComponents/AdminBlogDetails";
import AdminBlogs from "./components/Dashboard/AdminComponents/AdminBlogComponents/AdminBlogs";
import AdminJobsPage from "./components/Dashboard/AdminComponents/AdminJobsPage";
import AdminAnalyticsPage from "./components/Dashboard/AdminComponents/AdminAnalyticsPage";
import Cms from "./components/Dashboard/AdminComponents/Cms";
import AdminDashboard from "./components/Dashboard/AdminDashboard";
import { PaymentHistory } from "./components/Dashboard/AdminPayment";
import AdminServices from "./components/Dashboard/AdminServices";
import AllAdmins from "./components/Dashboard/AllAdmins";
import AllCandidates from "./components/Dashboard/AllCandidates";
import AdminDashboardWrapper from "./components/Layout/AdminDashboardWrapper";
import { AuthProvider } from "./contexts/AuthContext";
import { WebSocketProvider } from "./contexts/WebSocketContext";
import AnalyticsProvider from "./contexts/AnalyticsProvider";
import ProtectedRoute from "./guards/ProtectedRoute";
import PublicRoute from "./guards/PublicRoute";
import AboutUs from "./pages/AboutUs";
import AdminEmployeesPage from "./pages/AdminEmployeesPage";
import AdminLicensesPage from "./pages/AdminLicensesPage";
import AdminPermissionsPage from "./pages/AdminPermissionsPage";
import AdminReportedEmployeesPage from "./pages/AdminReportedEmployeesPage";
import AdminCvthequePage from "./pages/AdminCvthequePage";
import AdminRolesPage from "./pages/AdminRolesPage";
import Blog from "./pages/Blog";
import BlogDetail from "./pages/BlogDetail";
import Candidate from "./pages/Candidate";
import CandidateApplications from "./pages/CandidateApplications";
import CandidateCalendar from "./pages/CandidateCalendar";
import CandidateInterviews from "./pages/CandidateInterviews";
import CandidateJobDetails from "./pages/CandidateJobDetails";
import CandidateSignInPage from "./pages/CandidateSignInPage";
import CandidateSignUpPage from "./pages/CandidateSignUpPage";
import CandidateTests from "./pages/CandidateTests";
import CandidatProfile from "./pages/CandidatProfile";
import EntrepriseItem from "./pages/entrepriseItem";
import EntrepriseList from "./pages/entreprisesList";
import FAQ from "./pages/FAQ";
import Home from "./pages/Home";
import JobDetails from "./pages/JobDetails";
import JobsList from "./pages/JobsList";
import Policy from "./pages/Policy";
import Pricing from "./pages/Pricing";
import Recruiter from "./pages/Recruiter";
import RecruiterCalendar from "./pages/RecruiterCalendar";
import RecruiterCVtheque from "./pages/RecruiterCVthequePage";
import RecruiterInterview from "./pages/RecruiterInterview";
import RecruiterJobDetails from "./pages/RecruiterJobDetails";
import RecruiterJobs from "./pages/RecruiterJobs";
import RecruiterSignInPage from "./pages/RecruiterSignInPage";
import RecruiterSignUpPage from "./pages/RecruiterSignUpPage";
import RecruiterSpace from "./pages/RecruiterSpace";
import RecruiterTest from "./pages/RecruiterTest";
import Services from "./pages/Services";
import Test from "./pages/Test";

import RecruiterProfile from "./pages/RecruiterProfile";
import AdminCandidateView from "./pages/AdminCandidateView";

const App: React.FC = () => {
  return (
    <AuthProvider>
      <WebSocketProvider>
        <AnalyticsProvider>
          <Routes>
            {/* Public routes */}
            <Route path="/" element={<Home />} />
            <Route path="/home" element={<Home />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/jobs" element={<JobsList />} />
            <Route path="/jobs/:id" element={<JobDetails />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/policy" element={<Policy />} />
            <Route path="/entreprises" element={<EntrepriseList />} />
            <Route path="/entreprises/:id" element={<EntrepriseItem />} />
            <Route path="/candidat-service" element={<Services />} />
            <Route path="/pricing" element={<Pricing />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:id" element={<BlogDetail />} />
            <Route path="/recruiter-space" element={<RecruiterSpace />} />

            {/* Auth pages get their own PublicRoute */}
            <Route path="/auth" element={<PublicRoute />}>
              <Route index element={<CandidateSignInPage />} />
              <Route path="signin" element={<CandidateSignInPage />} />
              <Route path="signup" element={<CandidateSignUpPage />} />
              <Route
                path="recruiter-signin"
                element={<RecruiterSignInPage />}
              />
              <Route
                path="recruiter-signup"
                element={<RecruiterSignUpPage />}
              />
            </Route>

            {/* Protected dashboard routes */}
            <Route path="/candidate" element={<ProtectedRoute />}>
              <Route index element={<Candidate />} />
              <Route path="profile" element={<CandidatProfile />} />
              <Route path="tests" element={<CandidateTests />} />
              <Route path="interviews" element={<CandidateInterviews />} />
              <Route path="calendrier" element={<CandidateCalendar />} />
              <Route path="applications">
                <Route index element={<CandidateApplications />} />
                <Route path=":id" element={<CandidateJobDetails />} />
              </Route>
            </Route>
            <Route path="/admin" element={<ProtectedRoute />}>
              <Route path="" element={<AdminDashboardWrapper />}>
                <Route index element={<AdminDashboard />} />
                <Route path="employees" element={<AdminEmployeesPage />} />
                <Route
                  path="reported-employees"
                  element={<AdminReportedEmployeesPage />}
                />
                <Route path="licenses" element={<AdminLicensesPage />} />
                <Route path="cvtheque" element={<AdminCvthequePage />} />
                <Route path="analytics" element={<AdminAnalyticsPage />} />
                <Route path="roles" element={<AdminRolesPage />} />
                <Route path="permissions" element={<AdminPermissionsPage />} />
                <Route path="services" element={<AdminServices />} />

                <Route path="allCandidates" element={<AllCandidates />} />
                <Route
                  path="allCandidates/:candidateId"
                  element={<AdminCandidateView />}
                />

                <Route path="allAdmins" element={<AllAdmins />} />
                <Route path="blogs" element={<AdminBlogs />} />
                <Route path="blogDetails/:id" element={<AdminBlogDetails />} />
                <Route path="cms" element={<Cms />} />
                <Route path="jobs" element={<AdminJobsPage />} />
                <Route path="payments" element={<PaymentHistory />} />
              </Route>
            </Route>

            <Route path="/recruiter" element={<ProtectedRoute />}>
              <Route index element={<Recruiter />} />
              <Route path="profile" element={<RecruiterProfile />} />
              <Route path="jobs" element={<RecruiterJobs />} />
              <Route path="jobs/:jobId" element={<RecruiterJobDetails />} />
              <Route
                path="jobs/:jobId/candidat/:candidateId"
                element={<AdminCandidateView />}
              />

              <Route path="interviews" element={<RecruiterInterview />} />
              <Route path="calendar" element={<RecruiterCalendar />} />
              <Route path="cvtheque" element={<RecruiterCVtheque />} />
              <Route path="tests" element={<RecruiterTest />} />
              <Route path="test" element={<Test />} />
            </Route>

            <Route path="/logout" element={<Logout />} />

            {/* Fallback routes */}
            <Route path="/404" element={<div>Page Not Found</div>} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AnalyticsProvider>
      </WebSocketProvider>
    </AuthProvider>
  );
};

export default App;
