# EHC Recruitment Platform - Frontend

This repository contains the frontend implementation of the EHC Recruitment Platform, a comprehensive solution for connecting job seekers, recruiters, and employers.

## Features

- Job listing and search
- Candidate profiles and applications
- Recruiter dashboards
- Admin analytics and management tools
- Interview scheduling and management
- Resume parsing and management

## Documentation

For detailed documentation on specific features:

- [API Endpoints](./api-endpoints/FRONTEND_COMPLETE_GUIDE.md)
- [Authentication](./api-endpoints/FRONTEND_AUTH_CHANGES.md)
- [Permission System](./api-endpoints/docs/PERMISSION_SYSTEM.md)
- [Analytics Implementation](./docs/ANALYTICS_DOCUMENTATION.md)
- [Google Analytics API Reference](./docs/GOOGLE_ANALYTICS_API_REFERENCE.md)
- [Analytics Dashboard Guide](./docs/ANALYTICS_DASHBOARD_GUIDE.md)

## Analytics

The platform includes comprehensive analytics tracking to monitor user interactions, page views, and system performance. The analytics implementation uses:

- Google Analytics 4 (GA4) for production environments
- Local analytics tracking for development and real-time monitoring
- Automatic tracking of API calls, page views, and errors
- Custom event tracking for user interactions

For more information, see the [Analytics Documentation](./docs/ANALYTICS_DOCUMENTATION.md), [Google Analytics API Reference](./docs/GOOGLE_ANALYTICS_API_REFERENCE.md), and [Analytics Dashboard Guide](./docs/ANALYTICS_DASHBOARD_GUIDE.md).
