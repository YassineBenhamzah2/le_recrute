/* eslint-disable @typescript-eslint/no-explicit-any */
import type { LinguiConfig } from "@lingui/conf";
import { formatter } from "@lingui/format-json";

type ExtendedLinguiConfig = LinguiConfig & {
  babelOptions?: {
    presets?: any[];
    plugins?: any[];
  };
};

const config: ExtendedLinguiConfig = {
  locales: ["en", "fr", "ar"],
  sourceLocale: "en",

  fallbackLocales: {
    default: "en",
  },

  catalogs: [
    // HOME PAGES

    // Home
    {
      path: "src/locales/{locale}/Home",
      include: [
        "src/components/Layout/Header.tsx",
        "src/components/Landing/HomePage.tsx",
        "src/components/Landing/entrepriseSections/TestimonialsSection.tsx",
        "src/components/Landing/entrepriseSections/UxUiSection.tsx",
        "src/components/Layout/Footer.tsx",
        "src/components/Landing/CompaniesCmsSection.tsx",
        "src/components/Landing/SectionAd.tsx",
        "src/components/Landing/ServiceCmsCard.tsx",
      ],
    },

    // AboutUs
    {
      path: "src/locales/{locale}/About",
      include: [
        "src/components/Landing/AboutUsPage.tsx",
        "src/components/Landing/faqSections/MainContentSection.tsx",
        "src/components/Landing/faqSections/ContactFormSection.tsx",
      ],
    },

    // JobsList
    {
      path: "src/locales/{locale}/JobsList",
      include: [
        "src/components/Landing/JobsList.tsx",
        "src/components/Modals/applyJobForm.tsx",
        "src/components/Landing/LandingJobsComponents/JobSearch.tsx",
        "src/components/Landing/LandingJobsComponents/JobFilters.tsx",
        "src/components/Landing/LandingJobsComponents/JobCard.tsx",
        "src/components/CandidateComponents/SortDropdown.tsx",
        "src/pages/JobDetails.tsx",
      ],
    },

    // Report
    {
      path: "src/locales/{locale}/ReprteEmployer",
      include: ["src/pages/ReportForm.tsx"],
    },

    // FAQ
    {
      path: "src/locales/{locale}/FAQ",
      include: ["src/components/Landing/FAQPage.tsx"],
    },

    // Policy
    {
      path: "src/locales/{locale}/Policy",
      include: ["src/components/Landing/PolicyPage.tsx"],
    },

    // Companies
    {
      path: "src/locales/{locale}/Entreprise",
      include: [
        "src/components/Landing/entreprisesSections/FilterSection.tsx",
        "src/components/Landing/entreprisesSections/HeroSection.tsx",
        "src/components/Landing/entreprisesSections/JobItemSection.tsx",
        "src/components/Landing/entreprisesSections/JobListSection.tsx",

        "src/components/Landing/EntrepriseListPage.tsx",
        "src/pages/entrepriseItem.tsx",
        "src/components/Landing/EntrepriseItemPage.tsx",
        "src/components/Landing/entrepriseSections/EntrepriseDetailsSection.tsx",
        "src/components/Landing/entrepriseSections/JobListingSection.tsx",
        "src/components/Landing/entrepriseSections/SeparatorSection.tsx",
      ],
    },

    // Services
    {
      path: "src/locales/{locale}/Services",
      include: ["src/components/Landing/Services.tsx"],
    },

    // Pricing
    {
      path: "src/locales/{locale}/Pricing",
      include: ["src/components/Landing/Pricing.tsx"],
    },

    // Blog
    {
      path: "src/locales/{locale}/Blog",
      include: [
        "src/components/Landing/Blog.tsx",
        "src/components/Landing/BlogDetail.tsx",
      ],
    },

    // Recruiter Space
    {
      path: "src/locales/{locale}/RecruiterSpace",
      include: [
        "src/components/Landing/recruiterSpacePage.tsx",
        "src/components/Landing/entrepriseSections/JobRoleSection.tsx",
      ],
    },

    //candidate profile
    {
      path: "src/locales/{locale}/CandidateProfile",
      include: [
        "src/components/Dashboard/Profile/ProfileHeader.tsx",
        "src/components/Dashboard/Profile/ProfileOverview.tsx",
        "src/components/Dashboard/Profile/ProfileExperience.tsx",
        "src/components/Dashboard/Profile/ProfileEducation.tsx",
        "src/components/Dashboard/Profile/ProfileSkills.tsx",
        "src/components/Dashboard/Profile/ProfileStats.tsx",
        "src/components/Dashboard/Profile/ProfileTabs.tsx",
        "src/components/Dashboard/Profile/QuickActions.tsx",
        "src/components/Dashboard/ProfileCandidate.tsx",

        "src/components/Modals/EditProfileModal.tsx",
        "src/components/Modals/EditExperienceModal.tsx",
        "src/components/Modals/AddSkillModal.tsx",
        "src/components/Modals/AddExperienceModal.tsx",
        "src/components/Modals/AddEducationModal.tsx",
        "src/components/Modals/AddCertificationModal.tsx",
      ],
    },
    // AdminAnalytics
    {
      path: "src/locales/{locale}/AdminAnalytics",
      include: [
        "src/components/Dashboard/AdminComponents/AdminAnalyticsPage.tsx",
      ],
    },

    // AdminCVtheque
    {
      path: "src/locales/{locale}/AdminCvtheque",
      include: ["src/components/Dashboard/AdminComponents/CVthequeAdmin.tsx"],
    },

    //AdminEmployees
    {
      path: "src/locales/{locale}/AdminEmployees",
      include: [
        "src/components/Dashboard/EmployeeManagement.tsx",
        "src/components/Dashboard/AdminComponents/EmployeeTable.tsx",
        "src/components/Dashboard/AdminComponents/SearchAndFilter.tsx",
      ],
    },

    //AdminReportedEmployees
    {
      path: "src/locales/{locale}/AdminReportedEmployees",
      include: [
        "src/components/Dashboard/ReportedEmployees.tsx",
        "src/components/Dashboard/AdminComponents/ReportedEmployeesHeader.tsx",
        "src/components/Dashboard/AdminComponents/CaseHandlingPanel.tsx",
        "src/components/Dashboard/AdminComponents/ReportedEmployeesTable.tsx",
        "src/components/Dashboard/AdminComponents/ReportedEmployeesSearch.tsx",
      ],
    },

    // AdminJobs
    {
      path: "src/locales/{locale}/AdminJobs",
      include: [
        "src/components/Dashboard/AdminComponents/AdminJobsPage.tsx",
        "src/components/Dashboard/AdminComponents/AdminJobCard.tsx",
      ],
    },

    // AdminRoles
    {
      path: "src/locales/{locale}/AdminRoles",
      include: [
        "src/pages/AdminRolesPage.tsx",
        "src/components/Dashboard/RolePermissionManager.tsx",
        "src/components/Modals/CreateRoleModal.tsx",
      ],
    },

    // AdminPermessions
    {
      path: "src/locales/{locale}/AdminPermissions",
      include: ["src/components/Dashboard/PermissionBrowser.tsx"],
    },

    //FronCms
    {
      path: "src/locales/{locale}/CmsAdmin",
      include: [
        "src/components/Dashboard/AdminComponents/cms.tsx",
        "src/components/Dashboard/AdminComponents/ServiceSection.tsx",
        "src/components/Dashboard/AdminComponents/BlogCard.tsx",
        "src/components/Dashboard/AdminComponents/Space.tsx",
      ],
    },

    // AdminDash
    {
      path: "src/locales/{locale}/AdminDashs",
      include: [
        "src/components/Dashboard/AdminDashboard.tsx",
        "src/components/Layout/AdminSidebar.tsx",
        "src/components/Layout/AdminFooter.tsx",
        "src/components/Layout/AdminHeader.tsx",
      ],
    },

    // All Candidates and Admin
    {
      path: "src/locales/{locale}/AllCandAdmi",
      include: [
        "src/components/Dashboard/AllCandidates.tsx",
        "src/components/Dashboard/AllAdmins.tsx",
        "src/components/Dashboard/AdminComponents/AdminForm.tsx",
      ],
    },

    // AdminCandidateView
    {
      path: "src/locales/{locale}/AdmCandView",
      include: [
        "src/pages/AdminCandidateView.tsx",
        "src/components/Dashboard/AdminComponents/CandidateViewComponents/CandidateViewDetails.tsx",
        "src/components/Dashboard/AdminComponents/CandidateViewComponents/CandidateViewSidebar.tsx",
        "src/components/Dashboard/AdminComponents/CandidateViewComponents/CandidateViewExperiences.tsx",
        "src/components/Dashboard/AdminComponents/CandidateViewComponents/CandidateViewEducations.tsx",
        "src/components/Dashboard/AdminComponents/CandidateViewComponents/CandidateViewSkills.tsx",
        "src/components/Dashboard/AdminComponents/CandidateViewComponents/CandidateViewLanguages.tsx",
      ],
    },

    // AdminBlogsdetails
    {
      path: "src/locales/{locale}/AdminBlogsDetails",
      include: [
        "src/components/Dashboard/AdminComponents/AdminBlogComponents/AdminBlogDetails.tsx",
        "src/components/Dashboard/AdminComponents/AdminBlogComponents/BlogForm.tsx",
      ],
    },
    // AUTH PAGES

    // CandidateSignIn
    {
      path: "src/locales/{locale}/CandidateSignIn",
      include: [
        "src/pages/CandidateSignInPage.tsx",
        "src/components/Auth/LoginForm.tsx",
        "src/components/Auth/hooks/useAuthOperations.ts",
        "src/contexts/AuthContext.tsx",
        "src/lib/form/auth.ts",
      ],
    },

    // CandidateSignUp
    {
      path: "src/locales/{locale}/CandidateSignUp",
      include: [
        "src/pages/CandidateSignUpPage.tsx",
        "src/components/Auth/RegisterForm.tsx",
      ],
    },

    // RecruiterSignIn
    {
      path: "src/locales/{locale}/RecruiterSignIn",
      include: [
        "src/pages/RecruiterSignInPage.tsx",
        "src/components/Auth/RecruiterLoginForm.tsx",
      ],
    },

    // RecruiterSignUp
    {
      path: "src/locales/{locale}/RecruiterSignUp",
      include: [
        "src/components/Auth/RegisterRecruiterForm.tsx",
        "src/components/Auth/LicenseKeyInput.tsx",
        "src/pages/RecruiterSignUpPage.tsx",
      ],
    },

    // Candidate > Dashboard
    {
      path: "src/Locales/{locale}/CandidateDashboard",
      include: ["src/components/Dashboard/CandidateDashboard.tsx"],
    },

    // Candidate > SideBare & NavBar
    {
      path: "src/Locales/{locale}/CandidateSideBare",
      include: [
        "src/components/Layout/CandidateSideBar.tsx", // Done
        "src/components/Layout/CandidateNavbar.tsx", // Done
        "src/components/CandidateComponents/CandidateNotificationBell.tsx",
      ],
    },
    // Candidate > tests
    {
      path: "src/Locales/{locale}/CandidateTests",
      include: [
        "src/components/CandidateComponents/TestsComponents/CandidateTestList.tsx", // Done
        "src/components/CandidateComponents/TestsComponents/CandidateTestCard.tsx",
        "src/components/CandidateComponents/TestsComponents/CandidateTestModal.tsx",
        "src/components/CandidateComponents/TestsComponents/TestStatsDashboard.tsx", // Done
        "src/components/CandidateComponents/TestsComponents/TestSidbar.tsx",
        "src/components/CandidateComponents/TestsComponents/ConfirmationModal.tsx",
        "src/components/CandidateComponents/TestsComponents/TestResults.tsx",
        "src/components/CandidateComponents/TestsComponents/TestInstructions.tsx",
        "src/components/CandidateComponents/TestsComponents/TestHeader.tsx",
      ],
    },
    // Candidate > interviews & JobOffer
    {
      path: "src/Locales/{locale}/CanidateInterviews",
      include: [
        "src/components/CandidateComponents/TestsComponents/ApplyJobForm.tsx",
        "src/components/CandidateComponents/ApplicationCard.tsx",
        "src/components/CandidateComponents/CandidateApplicationsDashboard.tsx", //?
        "src/components/CandidateComponents/JobFilters.tsx",
        "src/components/CandidateComponents/InterviewCard.tsx",
        "src/components/CandidateComponents/InterviewSearch.tsx",
        "src/components/CandidateComponents/CandidateJobDetails.tsx",
        "src/components/CandidateComponents/SortDropdown.tsx",
        "src/components/CandidateComponents/CandidateInterviewsDashboard.tsx",
        "src/components/CandidateComponents/InterviewStats.tsx",
      ],
    },

    {
      path: "src/Locales/{locale}/CanidateInterviewCard",
      include: ["src/components/CandidateComponents/InterviewCard.tsx"],
    },

    // Candidate > Calender
    {
      path: "src/Locales/{locale}/CanidateCalender",
      include: [
        "src/components/CandidateComponents/CandidateCalendarDashboard.tsx",
      ],
    },
    // Recruteur > SideBar & Header & Footer & Notification
    {
      path: "src/Locales/{locale}/RecruteurHeader",
      include: [
        "src/components/Layout/RecruiterSidebar.tsx",
        "src/components/Layout/RecruiterFooter.tsx",
        "src/components/Layout/RecruiterHeader.tsx",
        "src/components/Dashboard/recruiterComponents/NotificationBell.tsx",
      ],
    },
    // Recruiter > Profile & jobsDetails
    {
      path: "src/Locales/{locale}/Recruteur",
      include: [
        "src/guards/ProtectedRoute.tsx",
        "src/components/Dashboard/RecruiterDashboard.tsx",
        "src/components/Dashboard/RecruiterProfileDashboard.tsx",
        "src/components/Dashboard/recruiterComponents/profileComponents/Header.tsx",
        "src/components/Dashboard/recruiterComponents/profileComponents/OverviewPage.tsx",
        "src/components/Dashboard/recruiterComponents/profileComponents/CompanyPage.tsx",
        "src/components/Dashboard/recruiterComponents/profileComponents/PermissionsPage.tsx",
        "src/components/Dashboard/recruiterComponents/profileComponents/SecurityPage.tsx",
        "src/components/Dashboard/RecruiterJobsDashboard.tsx",
        "src/components/Dashboard/RecruiterJobDetailsDashboard.tsx",
        // 'src/components/Dashboard/recruiterComponents/CandidateTableSection.tsx'
      ],
    },
    //Recruteur > JobList
    {
      path: "src/Locales/{locale}/RecruteurJobList",
      include: [
        "src/components/Dashboard/recruiterComponents/JobListSection.tsx",
        "src/components/Dashboard/recruiterComponents/DeleteJobModal.tsx",
        "src/components/Dashboard/recruiterComponents/DeleteJobModal.tsx",
        "src/components/Landing/entrepriseSections/JobListingSection.tsx",
      ],
    },

    //Recruiter > CandidateDetailsModal
    {
      path: "src/Locales/{locale}/RecruteurCandidateDetailsModal",
      include: [
        "src/components/Dashboard/recruiterComponents/CandidateDetailsModal.tsx",
      ],
    },
    {
      path: "src/Locales/{locale}/RecruteurInterview",
      include: [
        "src/components/Dashboard/recruiterComponents/InterviewStatsSection.tsx",
        "src/components/Dashboard/recruiterComponents/InterviewDashboardSection.tsx",
        "src/components/Dashboard/RecruiterInterviewDashboard.tsx",
        "src/components/Dashboard/recruiterComponents/EditInterview.tsx",
        "src/components/Dashboard/recruiterComponents/ScoreCandidate.tsx",
        "src/components/Dashboard/recruiterComponents/InterviewInformationSection.tsx",
        "src/components/Dashboard/recruiterComponents/JuryFeedbackSection.tsx",
        "src/components/Dashboard/recruiterComponents/InterviewStatusSection.tsx",
        "src/components/Dashboard/recruiterComponents/InterviewActionsSection.tsx",
      ],
    },

    //Recruteur > profile Calender TestDashboard CvTheque Role
    {
      path: "src/Locales/{locale}/RecruteurProfile",
      include: [
        "src/pages/CandidateProfileView.tsx",
        "src/components/Dashboard/recruiterComponents/HeaderSection.tsx",
        "src/components/Dashboard/recruiterComponents/CandidateTableSection.tsx",
        "src/components/Dashboard/RecruiterCalendar.tsx",
        "src/components/Dashboard/RecruiterCVthequeDashboard.tsx",
        "src/components/Dashboard/recruiterComponents/CandidateFiltersCvTc.tsx",
        "src/components/Dashboard/recruiterComponents/CandidatesTableCvTc.tsx",
        "src/components/Dashboard/recruiterComponents/ServerPagination.tsx",
        "src/components/Dashboard/RecruiterTestDashboard.tsx",
        "src/components/Dashboard/TestPreview.tsx",
      ],
    },
    // Recruteur > Suite
    {
      path: "src/Locales/{locale}/RecruteurProfile2",
      include: [
        "src/components/Dashboard/recruiterComponents/profileComponents/RecruiterInfoProfile.tsx",
        "src/components/Modals/RecruiterModals/RecruiterInfoModal.tsx",
      ],
    },
    // Recruteur > Create & Update & View Test
    {
      path: "src/Locales/{locale}/RecruteurCreateTest",
      include: [
        "src/components/Dashboard/recruiterComponents/CreateTestModal.tsx",
        "src/components/Dashboard/recruiterComponents/EditTestModal.tsx",
        "src/components/Dashboard/recruiterComponents/ViewTestModal.tsx",
        "src/components/Dashboard/recruiterComponents/DashboardSection.tsx",
      ],
    },
    {
      path: "src/Locales/{locale}/RecruteurCreateJobOffer",
      include: [
        "src/components/Dashboard/recruiterComponents/CreateJobModal.tsx",
        "src/components/Dashboard/recruiterComponents/ContainerSubsection.tsx",
        "src/components/Dashboard/recruiterComponents/BackgroundSubsection.tsx",
        "src/components/Dashboard/recruiterComponents/BackgroundWrapperSubsection.tsx",
        "src/components/Dashboard/recruiterComponents/DivWrapperSubsection.tsx",
        "src/components/Dashboard/recruiterComponents/ContainerWrapperSubsection.tsx",
        "src/components/Dashboard/recruiterComponents/SkillsSubsection.tsx",
        "src/components/Dashboard/recruiterComponents/ResponsibilitiesSubsection.tsx",
        "src/components/Dashboard/recruiterComponents/TagsSubsection.tsx",
        "src/components/Dashboard/recruiterComponents/DivSubsection.tsx",
      ],
    },
    // Recruteur > creeteJob > generate AI
    {
      path: "src/Locales/{locale}/RecruteurGenerateAI",
      include: [
        "src/components/Dashboard/recruiterComponents/GenerateWithAi.tsx",
        "src/components/Dashboard/recruiterComponents/LanguagePreferences.tsx",
        "src/components/Dashboard/recruiterComponents/JobInformationSection.tsx",
        "src/components/Dashboard/recruiterComponents/AdditionalPreferences.tsx",
      ],
    },

    {
      path: "src/Locales/{locale}/AdminBlogs",
      include: [
        "src/components/Dashboard/AdminComponents/AdminBlogComponents/AdminBlogs.tsx",
        "src/components/Dashboard/AdminComponents/AdminBlogComponents/CreateBlogForm.tsx",
      ],
    },
    //  Admin > AdminServices
    {
      path: "src/Locales/{locale}/AdminServices",
      include: [
        "src/components/Dashboard/AdminServices.tsx",
        "src/components/Dashboard/AdminComponents/ServicesForm.tsx",
      ],
    },
    // Admin > AdminPyment
    {
      path: "src/Locales/{locale}/AdminPyment",
      include: [
        "src/components/Dashboard/AdminPayment.tsx",
        "src/components/Dashboard/AdminComponents/AddPaymentModal.tsx",
      ],
    },
    // Admin > Licences
    {
      path: "src/Locales/{locale}/AdminLicences",
      include: [
        "src/components/Dashboard/LicenseDashboard.tsx",
        "src/components/Dashboard/LicenseForm.tsx",
        "src/components/Dashboard/LicenseStatsCards.tsx",
        "src/components/Dashboard/AdminComponents/PaymentFilters.tsx",
      ],
    },
  ],

  catalogsMergePath: "src/locales/{locale}/messages",

  compileNamespace: "es",

  format: formatter({ style: "lingui" }),

  formatOptions: {
    origins: true,
  },
};

export default config;
